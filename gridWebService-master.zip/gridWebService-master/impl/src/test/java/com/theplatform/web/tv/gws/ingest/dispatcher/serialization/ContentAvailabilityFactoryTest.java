package com.theplatform.web.tv.gws.ingest.dispatcher.serialization;

import java.util.*;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSContentAvailability;
import com.theplatform.web.tv.gws.sirius.repository.utils.*;
import com.theplatform.web.tv.gws.sirius.serializer.ContentAvailabilitySerializer;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ContentAvailabilityFactoryTest {

    public ContentAvailabilityFactoryTest(){
        SiriusObjectTypeTestUtil.unitTestInitialization();
    }

    @Test
    public void testContentAvailabilityFactory() throws InvalidProtocolBufferException {
        CanonicalIdsFactory canonicalIdsFactory = new CanonicalIdsFactory();
        CRSContentAvailability contentAvailability = new CRSContentAvailability();
        contentAvailability.setId(1234L);
        contentAvailability.setContentId(1234L);
        contentAvailability.setAvailabilityId(1234L);
        contentAvailability.setOwnerId(4567L);
        contentAvailability.setContentType(CRSContentAvailability.CONTENT_TYPE_STREAM);
        contentAvailability.setProductContextIds(canonicalIdsFactory.create(new ArrayList<>()));
        ContentAvailabilitySerializer contentAvailabilityFactory = new ContentAvailabilitySerializer(SiriusObjectType.fromFriendlyName("ContentAvailability"), canonicalIdsFactory);

        CRSContentAvailability retrievedContentAvailability
                = contentAvailabilityFactory.unmarshallPayload(contentAvailabilityFactory.marshallPayload(contentAvailability).toByteArray());

        Assert.assertEquals(contentAvailability, retrievedContentAvailability);
    }
	
}
