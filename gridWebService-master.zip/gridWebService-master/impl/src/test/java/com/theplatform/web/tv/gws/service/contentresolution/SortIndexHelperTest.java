package com.theplatform.web.tv.gws.service.contentresolution;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SortIndexHelperTest {

    @DataProvider
    public Object[][] sortIndexPolicy() {
        return new Object[][] {
                 { SortIndexHelper.COMESBEFORE_PREFIX + "2182918" , 2182918L}
                ,{ null , null}
                ,{ SortIndexHelper.COMESBEFORE_PREFIX + "1" , 1L}
                ,{ "wrong:prefix:2182918" , null}
        };
    }

    @Test(dataProvider = "sortIndexPolicy")
    public void testParseCompanyIdFromSortIndexPolicy( String sortIndexPolicy, Long expectedId){
        SortIndexHelper sortIndexHelper = new SortIndexHelper();
        Assert.assertEquals( sortIndexHelper.parseCompanyIdFromSortIndexPolicy(sortIndexPolicy), expectedId);
    }

}