package com.theplatform.web.tv.gws.ingest.producer.twitter;

import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * User: mmattozzi
 * Date: 2/13/14
 * Time: 5:32 PM
 */
@Test
public class ScoreEvaluatorTest {

    public ScoreEvaluatorTest(){
        SiriusObjectTypeTestUtil.unitTestInitialization();

    }

    public void testTopTrendsCalculationForOneDominateProgram() {
        TwitterSettings settings = new TwitterSettings();
        settings.setNumberOfRankGroups(5);
        settings.setTopTrendThreshold(20);
        ScoreEvaluator trendingProgramScoreEvaluator = new ScoreEvaluator();
        trendingProgramScoreEvaluator.setSettings(settings);

        CRSTrendingPrograms trendingPrograms = createTestTrendingPrograms(new Integer[] {200, 10, 9, 8, 7});
        trendingProgramScoreEvaluator.updateTrendingPrograms(trendingPrograms);

        Assert.assertTrue(trendingPrograms.getPrograms().get(0).isTopTrending());
        Assert.assertFalse(trendingPrograms.getPrograms().get(1).isTopTrending());
        Assert.assertFalse(trendingPrograms.getPrograms().get(2).isTopTrending());
        Assert.assertFalse(trendingPrograms.getPrograms().get(3).isTopTrending());
        Assert.assertFalse(trendingPrograms.getPrograms().get(4).isTopTrending());
    }

    protected CRSTrendingPrograms createTestTrendingPrograms(Integer[] scores) {
        CRSTrendingPrograms trendingPrograms = new CRSTrendingPrograms();
        List<CRSTrendingProgram> trendingProgramList = new ArrayList<>();

        for (int i = 0; i < scores.length; i++) {
            CRSTrendingProgram trendingProgram = new CRSTrendingProgram();
            trendingProgram.setScore(scores[i]);
            trendingProgramList.add(trendingProgram);
        }

        trendingPrograms.setPrograms(trendingProgramList);
        return trendingPrograms;
    }

}
