package com.theplatform.web.tv.gws.ingest.dispatcher.serialization;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSAvailabilityTag;
import com.theplatform.web.tv.gws.sirius.serializer.AvailabilityTagSerializer;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AvailabilityTagFactoryTest {

    public AvailabilityTagFactoryTest(){
        SiriusObjectTypeTestUtil.unitTestInitialization();
    }

    @Test
    public void testAvailabilityTagFactory() throws InvalidProtocolBufferException {
        CRSAvailabilityTag availabilityTag = new CRSAvailabilityTag();
        availabilityTag.setId(1234L);
        availabilityTag.setNational(false);
        availabilityTag.setOwnerId(43123816);
        AvailabilityTagSerializer availabilityTagFactory = new AvailabilityTagSerializer(SiriusObjectType.fromFriendlyName("AvailabilityTag"));

        CRSAvailabilityTag retrievedAvailabilityTag =
                availabilityTagFactory.unmarshallPayload(availabilityTagFactory.marshallPayload(availabilityTag).toByteArray());
        
        Assert.assertEquals(availabilityTag, retrievedAvailabilityTag);
    }

	
}
