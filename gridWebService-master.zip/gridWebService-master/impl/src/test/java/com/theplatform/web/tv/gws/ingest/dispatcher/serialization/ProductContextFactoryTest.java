package com.theplatform.web.tv.gws.ingest.dispatcher.serialization;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.sirius.serializer.ProductContextSerializer;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.web.tv.gws.sirius.model.CRSProductContext;

public class ProductContextFactoryTest {

    @Test
    public void testProductContextFactory() throws InvalidProtocolBufferException {
        CRSProductContext productContext = new CRSProductContext();
        productContext.setId(1234L);
        productContext.setTitle("TestTitle123");
        productContext.setType("Other");
        ProductContextSerializer productContextFactory = new ProductContextSerializer(SiriusObjectType.fromFriendlyName("ProductContext"));

        CRSProductContext retrievedProductContext
                = productContextFactory.unmarshallPayload(productContextFactory.marshallPayload(productContext).toByteArray());
        
        Assert.assertEquals(productContext, retrievedProductContext);
    }
	
}
