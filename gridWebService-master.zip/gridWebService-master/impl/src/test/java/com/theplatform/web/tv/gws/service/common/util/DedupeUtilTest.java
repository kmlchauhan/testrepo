package com.theplatform.web.tv.gws.service.common.util;

import com.theplatform.contrib.data.api.objects.Muri;
import org.testng.Assert;
import org.testng.annotations.Test;

import static com.theplatform.web.tv.gws.TestUtil.MERLIN_ID_HELPER;

/**
 * @author jcoelho
 */
public class DedupeUtilTest {

    @Test
    public void testFirstTakesPrecedence() {
        Muri lower = MERLIN_ID_HELPER.createStationId(100L);
        Muri higher = MERLIN_ID_HELPER.createStationId(200L);
        Assert.assertEquals(true, DedupeUtil.firstTakesPrecedence(lower, higher, MERLIN_ID_HELPER));
        Assert.assertEquals(false, DedupeUtil.firstTakesPrecedence(higher, lower, MERLIN_ID_HELPER));

        lower = MERLIN_ID_HELPER.createStationId(200L);
        higher = MERLIN_ID_HELPER.createStationId(1000L);
        Assert.assertEquals(true, DedupeUtil.firstTakesPrecedence(lower, higher, MERLIN_ID_HELPER));
        Assert.assertEquals(false, DedupeUtil.firstTakesPrecedence(higher, lower, MERLIN_ID_HELPER));
    }

}
