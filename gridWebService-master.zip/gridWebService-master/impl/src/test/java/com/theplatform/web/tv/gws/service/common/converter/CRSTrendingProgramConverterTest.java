package com.theplatform.web.tv.gws.service.common.converter;


import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import com.theplatform.web.tv.contentresolution.api.objects.TrendingProgram;
import com.theplatform.web.tv.contentresolution.api.objects.TrendingPrograms;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms;
import com.theplatform.web.tv.gws.sirius.repository.ProgramRepository;
import com.theplatform.web.tv.gws.uri.IdForm;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.fest.assertions.api.Assertions;
import org.mockito.Mockito;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CRSTrendingProgramConverterTest {
    private Date now = new Date();

    private CRSTrendingPrograms crsTrendingPrograms;

    private CRSTrendingProgram trending1;
    private CRSProgram program1 ;
    private ProgramInfo programInfo1;

    private CRSTrendingProgram trending2;
    private CRSProgram program2 ;
    private ProgramInfo programInfo2;

    private CRSTrendingProgram trending3;
    private CRSProgram program3 ;
    private ProgramInfo programInfo3;

    private CRSTrendingProgram trending4;

    public static final String ENTITY_BASE_URL = "http://test.com/entityDataService";
    private MerlinIdHelper merlinIdHelper = MerlinIdHelper.withDefaultIdForm(ENTITY_BASE_URL,null,null, null, null, IdForm.URN);

    @BeforeClass
    public void setup() {
        SiriusObjectTypeTestUtil.unitTestInitialization();

        program1 = new CRSProgram(1);
        program2 = new CRSProgram(2);
        program3 = new CRSProgram(3);

        trending1 = new CRSTrendingProgram();
        trending1.setProgramId(1);
        trending1.setRankingGroup(1);
        trending1.setScore(1);
        programInfo1 = new ProgramInfo();
        programInfo1.setTitle("info1");

        trending2 = new CRSTrendingProgram();
        trending2.setProgramId(2);
        trending2.setRankingGroup(2);
        trending2.setScore(2);
        programInfo2 = new ProgramInfo();
        programInfo2.setTitle("info2");

        trending3 = new CRSTrendingProgram();
        trending3.setProgramId(3);
        trending3.setRankingGroup(3);
        trending3.setScore(3);
        trending3.setTopTrending(true);
        programInfo3 = new ProgramInfo();
        programInfo3.setTitle("info3");

        trending4 = new CRSTrendingProgram();
        trending4.setProgramId(4);

        List<CRSTrendingProgram> list = new ArrayList<>();
        list.add(trending1);
        list.add(trending2);
        list.add(trending3);
        list.add(trending4);

        crsTrendingPrograms = new CRSTrendingPrograms();
        crsTrendingPrograms.setPrograms(list);
        crsTrendingPrograms.setTimeToLive(100);
        crsTrendingPrograms.setRetrievedTime(now.getTime());
    }

    private void assertTrendingProgram(TrendingProgram program, CRSTrendingProgram crsTrendingProgram, ProgramInfo expectedProgramInfo) {
        Assertions.assertThat(program.getRankingGroup()).isEqualTo(crsTrendingProgram.getRankingGroup());
        Assertions.assertThat(program.getScore()).isEqualTo(crsTrendingProgram.getScore());
        Assertions.assertThat(program.getTopTrending()).isEqualTo(crsTrendingProgram.isTopTrending());
        //Assertions.assertThat(program.getProgramInfo()).isSameAs(expectedProgramInfo);
        Assertions.assertThat(program.getProgramId()).isEqualTo(merlinIdHelper.createProgramId(crsTrendingProgram.getProgramId()));
    }

    @Test
    public void testConvert() {
        // empty object on null input
        CRSTrendingProgramToTrendingProgramConverter converter = new CRSTrendingProgramToTrendingProgramConverter();
        Assertions.assertThat(converter.convert(null, merlinIdHelper, null, null)).isNotNull();

        // each CRSTrendingProgram is linked to a CRSProgram by CRSTrendingProgram.programId
        ProgramRepository mockProgramRepository = Mockito.mock(ProgramRepository.class);
        Mockito.when(mockProgramRepository.get(1L)).thenReturn(program1);
        Mockito.when(mockProgramRepository.get(2L)).thenReturn(program2);
        Mockito.when(mockProgramRepository.get(3L)).thenReturn(program3);
        Mockito.when(mockProgramRepository.get(4L)).thenReturn(null);

        // the converter should call the CRSProgramToProgramInfoConverter for each CRSProgram that had a non-null
        // value in mockProgramRepository
        CRSProgramToProgramInfoConverter mockProgramConverter = Mockito.mock(CRSProgramToProgramInfoConverter.class);
        Mockito.when(mockProgramConverter.convertCRSProgramToProgramInfo(program1)).thenReturn(programInfo1);
        Mockito.when(mockProgramConverter.convertCRSProgramToProgramInfo(program2)).thenReturn(programInfo2);
        Mockito.when(mockProgramConverter.convertCRSProgramToProgramInfo(program3)).thenReturn(programInfo3);

        // inject mocks
        converter.setCrsProgramRepository(mockProgramRepository);
        converter.setProgramToProgramInfoConverter(mockProgramConverter);

        // basic attributes of TrendingPrograms
        TrendingPrograms actual = converter.convert(crsTrendingPrograms, merlinIdHelper, null, null);
        Assertions.assertThat(actual).isNotNull();
        Assertions.assertThat(actual.getRetrievedTime()).isEqualTo(now);
        Assertions.assertThat(actual.getTimeToLive()).isEqualTo(crsTrendingPrograms.getTimeToLive());
        Assertions.assertThat(actual.getTrendingPrograms()).hasSize(3);

        // check each TrendingProgram.  note that trending4 should not be included since the mock repo returned null
        assertTrendingProgram(actual.getTrendingPrograms().get(0), trending1, programInfo1);
        assertTrendingProgram(actual.getTrendingPrograms().get(1), trending2, programInfo2);
        assertTrendingProgram(actual.getTrendingPrograms().get(2), trending3, programInfo3);
    }
}
