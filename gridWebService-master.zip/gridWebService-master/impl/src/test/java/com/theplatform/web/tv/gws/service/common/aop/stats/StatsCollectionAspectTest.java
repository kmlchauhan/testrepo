package com.theplatform.web.tv.gws.service.common.aop.stats;


import com.theplatform.contrib.stats.RollingAverage;
import com.theplatform.contrib.stats.StatsCollector;
import com.theplatform.web.tv.GridException;
import org.springframework.aop.aspectj.annotation.AspectJProxyFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.SortedMap;

public class StatsCollectionAspectTest {

    private TestClass proxy;

    @BeforeClass
    public void beforeMethod() {
        AspectJProxyFactory factory = new AspectJProxyFactory(new TestClass());
        factory.addAspect(StatsCollectionAspect.class);
        proxy = factory.getProxy();
    }

    @Test
    public void callTestMethod_expectStatsCollection() throws GridException {
        proxy.testMethod();
        StatsCollector instance = StatsCollector.getInstance();
        SortedMap<RollingAverage.TimeFrame, RollingAverage.Report> stats = instance.report("TestClass : testMethod");
        Assert.assertNotNull(stats);
        SortedMap<RollingAverage.TimeFrame, RollingAverage.Report> privateStats = instance.report("privateTestMethod");
        Assert.assertNull(privateStats);
    }

    @Test
    public void callTestMethodWithPrefix_expectStatsCollection() throws GridException {
        proxy.testMethod2();
        StatsCollector instance = StatsCollector.getInstance();
        SortedMap<RollingAverage.TimeFrame, RollingAverage.Report> stats = instance.report("TestClass : Prefix-testMethod2");
        Assert.assertNotNull(stats);
        SortedMap<RollingAverage.TimeFrame, RollingAverage.Report> privateStats = instance.report("privateTestMethod");
        Assert.assertNull(privateStats);
    }
}
