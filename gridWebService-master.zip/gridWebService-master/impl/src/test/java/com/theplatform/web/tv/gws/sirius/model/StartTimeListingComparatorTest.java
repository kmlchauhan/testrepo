package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.repository.ListingRepository;
import com.theplatform.web.tv.gws.sirius.repository.StartTimeListingComparator;
import com.theplatform.web.tv.gws.sirius.repository.utils.SortedSetSecondaryIndex;
import org.joda.time.DateTime;
import org.testng.annotations.Test;

import java.util.Collection;
import java.util.Set;

import static org.fest.assertions.api.Assertions.assertThat;

@Test
public class StartTimeListingComparatorTest {

    private static final Long STATION_ID = 1l;
    private StartTimeListingComparator comparator;

    public StartTimeListingComparatorTest() {
        SiriusObjectTypeTestUtil.unitTestInitialization();

        comparator = new StartTimeListingComparator();
    }
    
    public void testComparatorNegative() throws Exception {
        StartTimeListingComparator startTimeListingComparator = new StartTimeListingComparator();
        DateTime dateTime = new DateTime();
        CRSListing aListing = createListing(1l, dateTime.getMillis());
        CRSListing anotherListing = createListing(2l, dateTime.plusMinutes(30).getMillis());
        assertThat(startTimeListingComparator.compare(aListing, anotherListing)).isLessThan(0);
        
    }

    public void testComparatorZero() throws Exception {
        DateTime dateTime = new DateTime();
        CRSListing aListing = createListing(1l, dateTime.getMillis());
        CRSListing anotherListing = createListing(1l, dateTime.getMillis());
        assertThat(comparator.compare(aListing, anotherListing)).isEqualTo(0);
    }
    
    public void testComparatorPositive() throws Exception {
        DateTime dateTime = new DateTime();
        CRSListing aListing = createListing(1l, dateTime.plusMinutes(1).getMillis());
        CRSListing anotherListing = createListing(2l, dateTime.getMillis());
        assertThat(comparator.compare(aListing, anotherListing)).isGreaterThan(0);
    }
    
    public void testComparatorIndex() throws Exception {
        SortedSetSecondaryIndex<Long, CRSListing> setSecondaryIndex = new SortedSetSecondaryIndex<Long, CRSListing>(comparator);
        DateTime dateTime = new DateTime();
        CRSListing aListing = createListing(1l, dateTime.getMillis());
        CRSListing anotherListing = createListing(2l, dateTime.plusMinutes(30).getMillis());
        setSecondaryIndex.put(STATION_ID, aListing);
        setSecondaryIndex.put(STATION_ID, anotherListing);
        Set<CRSListing> listings = setSecondaryIndex.getByIndexKey(STATION_ID);
        assertThat(listings).containsSequence(aListing, anotherListing);
    }
    
    public void testComparatorIndex2() throws Exception {
        SortedSetSecondaryIndex<Long, CRSListing> setSecondaryIndex = new SortedSetSecondaryIndex<Long, CRSListing>(comparator);
        DateTime dateTime = new DateTime();
        CRSListing aListing = createListing(1l, dateTime.getMillis());
        CRSListing anotherListing = createListing(1l, dateTime.plusMinutes(30).getMillis());
        setSecondaryIndex.put(STATION_ID, aListing);
        setSecondaryIndex.put(STATION_ID, anotherListing);
        Set<CRSListing> listings = setSecondaryIndex.getByIndexKey(STATION_ID);
        assertThat(listings).containsSequence(anotherListing);
    }
    
    public void testComparatorIndex3() throws Exception {
        SortedSetSecondaryIndex<Long, CRSListing> setSecondaryIndex = new SortedSetSecondaryIndex<Long, CRSListing>(comparator);
        DateTime dateTime = new DateTime();
        CRSListing aListing = createListing(2l, dateTime.getMillis());
        CRSListing anotherListing = createListing(1l, dateTime.plusMinutes(30).getMillis());
        setSecondaryIndex.put(STATION_ID, aListing);
        setSecondaryIndex.put(STATION_ID, anotherListing);
        Set<CRSListing> listings = setSecondaryIndex.getByIndexKey(STATION_ID);
        assertThat(listings).containsSequence(aListing, anotherListing);
    }
    
    public void testComparatorIndex4() throws Exception {
        SortedSetSecondaryIndex<Long, CRSListing> setSecondaryIndex = new SortedSetSecondaryIndex<Long, CRSListing>(comparator);
        DateTime dateTime = new DateTime();
        CRSListing aListing = createListing(1l, dateTime.plusMinutes(30).getMillis());
        CRSListing anotherListing = createListing(2l, dateTime.plusMinutes(30).getMillis());
        setSecondaryIndex.put(STATION_ID, aListing);
        setSecondaryIndex.put(STATION_ID, anotherListing);
        Set<CRSListing> listings = setSecondaryIndex.getByIndexKey(STATION_ID);
        assertThat(listings).containsSequence(aListing, anotherListing);
    }
    
    public void testComparatorIndex5() throws Exception {
        SortedSetSecondaryIndex<Long, CRSListing> setSecondaryIndex = new SortedSetSecondaryIndex<Long, CRSListing>(comparator);
        DateTime dateTime = new DateTime();
        CRSListing l13 = createListing(1l, dateTime.plusHours(3).getMillis());
        CRSListing l24 = createListing(2l, dateTime.plusHours(4).getMillis());
        CRSListing l31 = createListing(3l, dateTime.plusHours(1).getMillis());
        CRSListing l45 = createListing(4l, dateTime.plusHours(5).getMillis());
        CRSListing l52 = createListing(5l, dateTime.plusHours(2).getMillis());
        setSecondaryIndex.put(STATION_ID, l13);
        setSecondaryIndex.put(STATION_ID, l24);
        setSecondaryIndex.put(STATION_ID, l31);
        setSecondaryIndex.put(STATION_ID, l45);
        setSecondaryIndex.put(STATION_ID, l52);
        Set<CRSListing> listings = setSecondaryIndex.getByIndexKey(STATION_ID);
        assertThat(listings).containsSequence(l31, l52, l13, l24, l45);
    }
    
    @Test
    public void testComparatorIndex6() throws Exception {
        ListingRepository listingRepository = new ListingRepository(SiriusObjectType.fromFriendlyName("Listing"));
        
        DateTime dateTime = new DateTime();
        CRSListing l13 = createListing(1l, dateTime.plusHours(3).getMillis());
        CRSListing l24 = createListing(2l, dateTime.plusHours(4).getMillis());
        CRSListing l31 = createListing(3l, dateTime.plusHours(1).getMillis());
        CRSListing l45 = createListing(4l, dateTime.plusHours(5).getMillis());
        CRSListing l52 = createListing(5l, dateTime.plusHours(2).getMillis());
        listingRepository.addToIndexes(l13);
        listingRepository.addToIndexes(l24);
        listingRepository.addToIndexes(l31);
        listingRepository.addToIndexes(l45);
        listingRepository.addToIndexes(l52);

        Collection<CRSListing> listings = listingRepository.getListings(STATION_ID, dateTime.plusHours(1).toDate(), dateTime.plusHours(4).toDate());

        assertThat(listings).containsSequence(l31, l52, l13);
    }
    
    
    private CRSListing createListing(Long id, Long date) {
        CRSListing crsListing = new CRSListing();
        crsListing.setId(id);
        crsListing.setStartTime(date);
        crsListing.setEndTime(date + 30 * 60 * 100);
        crsListing.setStationId(STATION_ID);
        return crsListing;
    }
}
