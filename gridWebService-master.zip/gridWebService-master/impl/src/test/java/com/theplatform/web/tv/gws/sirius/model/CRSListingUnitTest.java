package com.theplatform.web.tv.gws.sirius.model;


import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

public class CRSListingUnitTest {

    @Test
    public void testBitValues() {
        SiriusObjectTypeTestUtil.unitTestInitialization();

        CRSListing listing = new CRSListing();
        assertNull(listing.getSap());

        listing.setSap(Boolean.FALSE);
        assertFalse(listing.getSap());

        listing.setSap(Boolean.TRUE);
        assertTrue(listing.getSap());

        listing.setSap(null);
        assertNull(listing.getSap());

        listing.setSap(Boolean.TRUE);
        assertTrue(listing.getSap());
    }
}
