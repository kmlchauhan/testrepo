package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.web.tv.gws.sirius.model.CRSCredit;
import org.testng.annotations.Test;

import java.util.Arrays;

import static org.fest.assertions.api.Assertions.assertThat;

public class CreditRepositoryTest {
    private static final SiriusObjectType CREDIT_TYPE
            = SiriusObjectType.register("Credit", Credit.class, MerlinEntityType.CREDIT);

    @Test
    public void testCreditRemovalForPersonWithMultipleCreditsOnProgram() {
        CreditRepository creditRepository = new CreditRepository(CREDIT_TYPE, 10, 10, 10);
        CRSCredit credit1 = new CRSCredit();
        CRSCredit credit2 = new CRSCredit();

        credit1.setId(777107);
        credit2.setId(888107);

        for (CRSCredit credit : Arrays.asList(credit1, credit2)) {
            credit.setProgramId(1234112);
            credit.setPersonId(555111);
        }

        creditRepository.put(credit1);
        creditRepository.put(credit2);

        creditRepository.delete(credit1.getId());

        assertThat(creditRepository.getProgramIds(credit2.getPersonId())).containsExactly(credit2.getProgramId());
    }
}
