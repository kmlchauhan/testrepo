package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.web.tv.gws.sirius.model.CRSStream;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collection;

public class StreamRepositoryTest {

    @BeforeMethod
    public void init(){
    }

    @Test
    public void getByIds_StreamsReturned() {
        StreamRepository streamRepository = new StreamRepository(SiriusObjectType.fromFriendlyName("Stream"));
        CRSStream obj1 = new CRSStream(123L);
        streamRepository.put(obj1.getId(), obj1);

        Collection<CRSStream> byIds = streamRepository.getByIds(Arrays.asList(Long.valueOf(obj1.getId())));
        Assert.assertTrue(byIds.size() == 1);
        Assert.assertEquals(byIds.toArray()[0],obj1);
    }

    @Test
    public void getByTitlePrefix_CorrectStreamReturned() {
        StreamRepository streamRepository = new StreamRepository(SiriusObjectType.fromFriendlyName("Stream"));
        CRSStream obj1 = new CRSStream(123L);
        obj1.setTitle("StationPrefix1234:123");
        streamRepository.put(obj1.getId(), obj1);

        Collection<CRSStream> byIds = streamRepository.getByTitlePrefix("StationPrefix");
        Assert.assertTrue(byIds.size() == 1);
        Assert.assertEquals(byIds.toArray()[0],obj1);
    }


}
