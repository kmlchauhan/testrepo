package com.theplatform.web.tv.gws.service.common.converter;

import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSChannel;
import com.theplatform.web.tv.gws.sirius.model.CRSLocation;
import com.theplatform.web.tv.gws.sirius.model.CRSStation;
import com.theplatform.web.tv.gws.sirius.repository.ChannelRepository;
import com.theplatform.web.tv.gws.sirius.repository.ContentAvailabilityRepository;
import com.theplatform.web.tv.gws.sirius.repository.LocationRepository;
import com.theplatform.web.tv.gws.uri.*;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CRSChannelToChannelInfoConverterTest {

    private static final Long STATION_ID = 789117L;

    public static final String LINEAR_BASE_URL = "http://test.com/linearDataService";
    private MerlinIdHelper merlinIdHelper = MerlinIdHelper.withDefaultIdForm(null,LINEAR_BASE_URL,null, null, null, IdForm.URN);
    private CRSChannelToChannelInfoConverter crsChannelToChannelInfoConverter;

    @Mock
    private CRSStationToStationInfoConverter crsStationToStationInfoConverter;
    @Mock
    private LongObjectRepository<CRSStation> stationRepository;
    @Mock
    private LocationRepository locationRepository;
    @Mock
    private ChannelRepository channelRepository;
    @Mock
    private ContentAvailabilityRepository contentAvailabilityRepository;

    private static int idCount = 100;

    // For Testing New ProductContext Logic
    private static final Long natavailAvailabilityTag = 102143L;   // National Avail Tag
    private static final long locationId_1 = 101110;   // HAS CAs
    private static final long locationId_2 = 102110;   // No CAs

    private static final long[] productContexts = {100174,101174,102174,103174,104174,105174,105555};

    @BeforeMethod
    public void setup(){
        SiriusObjectTypeTestUtil.unitTestInitialization();

        MockitoAnnotations.initMocks(this);

        crsChannelToChannelInfoConverter = new CRSChannelToChannelInfoConverter();
        crsChannelToChannelInfoConverter.setCrsStationToStationInfoConverter(crsStationToStationInfoConverter);
        crsChannelToChannelInfoConverter.setStationRepository(stationRepository);
        crsChannelToChannelInfoConverter.setAccountIdHelper(new AccountIdHelper("http://access.auth.po.ccp.cable.comcast.com"));
    }

    // Mocking CRSStationToStationInfoConverter
    @Test
    public void convert_verifyFields(){
        CRSChannel crsChannel = createCRSChannel();

        CRSLocation crsLocation = createCRSLocation(crsChannel.getLocationId());
        Mockito.when(locationRepository.get(crsLocation.getId())).thenReturn(crsLocation);

        Mockito.when(crsStationToStationInfoConverter.convert( Mockito.any(CRSStation.class)
                                                             , Mockito.any(MerlinIdHelper.class)
                                                             , Mockito.any(String.class))).thenReturn(new StationInfo());

        ChannelInfo channelInfo = crsChannelToChannelInfoConverter.convert(crsChannel, merlinIdHelper, null);
        Assert.assertEquals( channelInfo.getChannelId().getId(), crsChannel.getId());
        Assert.assertEquals(channelInfo.getNumber(), new Integer(crsChannel.getChannelNumber()) );
    }

    // Mocking stationRepository
    @Test
    public void convert_verifyFields2(){
        CRSChannel crsChannel = createCRSChannel();

        CRSStation crsStation = CRSStationToStationInfoConverterTest.createCRSStation();
        long stationId = 100117;
        crsStation.setId(stationId);
        Mockito.when(stationRepository.get(stationId)).thenReturn(crsStation);
        crsChannel.setStationId(stationId);

        CRSLocation crsLocation = createCRSLocation(crsChannel.getLocationId());
        Mockito.when(locationRepository.get(crsLocation.getId())).thenReturn(crsLocation);

        StationInfo stationInfo = new StationInfo();
        stationInfo.setStationId(merlinIdHelper.createStationId(stationId));
        Mockito.when(crsStationToStationInfoConverter.convert( Mockito.any(CRSStation.class), Mockito.any(MerlinIdHelper.class), Mockito.anyString() ))
               .thenReturn(stationInfo);

        ChannelInfo channelInfo = crsChannelToChannelInfoConverter.convert(crsChannel, merlinIdHelper, null);
        Assert.assertEquals( channelInfo.getChannelId().getId(), crsChannel.getId() );
        Assert.assertEquals( channelInfo.getNumber(), new Integer(crsChannel.getChannelNumber()) );
        Assert.assertEquals( channelInfo.getStationInfo().getStationId().getId(),  stationId);
        Assert.assertEquals(channelInfo.getEmergencyAlertSystemType(), crsChannel.getEmergencyAlertSystemType());

    }

    /**
     * Verify that Channel fields take precedence: digicableId, onScreenCallsign
     */
    @Test
    public void verifyChannelPrecedence(){
        CRSChannel crsChannel = createCRSChannel();

        CRSLocation crsLocation = createCRSLocation(crsChannel.getLocationId());
        Mockito.when(locationRepository.get(crsLocation.getId())).thenReturn(crsLocation);

        Mockito.when(crsStationToStationInfoConverter.convert(Mockito.any(CRSStation.class)
                , Mockito.any(MerlinIdHelper.class)
                , Mockito.any(String.class))).thenReturn(new StationInfo());
        ChannelInfo channelInfo = crsChannelToChannelInfoConverter.convert(crsChannel, merlinIdHelper, null);
        Assert.assertEquals( channelInfo.getChannelId().getId(), crsChannel.getId() );
        Assert.assertEquals(channelInfo.getNumber(), new Integer(crsChannel.getChannelNumber()) );
        Assert.assertEquals(channelInfo.getDigicableId(), new Integer(crsChannel.getDigicableId()));
        Assert.assertEquals(channelInfo.getOnScreenCallsign(), crsChannel.getOnScreenCallsign());
        Assert.assertEquals(channelInfo.getEmergencyAlertSystemType(), crsChannel.getEmergencyAlertSystemType());
    }

    /**
     * Verify that when Channel fields are unpopulated that station values are used: digicableId, onScreenCallsign
     */
    @Test
    public void verifyChannelIsNullStationExistsPrecedence(){
        CRSChannel crsChannel = createCRSChannel();
        crsChannel.setDigicableId(0);
        crsChannel.setOnScreenCallsign(null);
        crsChannel.setEmergencyAlertSystemType(null);
        CRSLocation crsLocation = createCRSLocation(crsChannel.getLocationId());
        Mockito.when(locationRepository.get(crsLocation.getId())).thenReturn(crsLocation);

        CRSStation crsStation = CRSStationToStationInfoConverterTest.createCRSStation();
        long stationId = 100117;
        crsStation.setId(stationId);
        Mockito.when(stationRepository.get(stationId)).thenReturn(crsStation);
        crsChannel.setStationId(stationId);

        StationInfo stationInfo = new StationInfo();
        stationInfo.setStationId(merlinIdHelper.createStationId(stationId));
        Mockito.when(crsStationToStationInfoConverter.convert( Mockito.any(CRSStation.class), Mockito.any(MerlinIdHelper.class), Mockito.anyString() ))
                .thenReturn(stationInfo);

        ChannelInfo channelInfo = crsChannelToChannelInfoConverter.convert(crsChannel, merlinIdHelper, null);
        Assert.assertEquals(channelInfo.getChannelId().getId(), crsChannel.getId() );
        Assert.assertEquals(channelInfo.getNumber(), new Integer(crsChannel.getChannelNumber()) );
        Assert.assertEquals(channelInfo.getDigicableId(), new Integer(crsStation.getDigicableId()));
        Assert.assertEquals(channelInfo.getOnScreenCallsign(), crsStation.getOnScreenCallSign());
        Assert.assertEquals(channelInfo.getEmergencyAlertSystemType(), crsStation.getEmergencyAlertSystemType());
    }

    /**
     * Verify that when Channel fields AND Station are unpopulated that we return null without error: digicableId, onScreenCallsign
     */
    @Test
    public void verifyDigicableId_ChannelAndStationDontExists(){
        CRSChannel crsChannel = createCRSChannel();
        crsChannel.setDigicableId(0);
        crsChannel.setOnScreenCallsign(null);
        crsChannel.setEmergencyAlertSystemType(null);
        CRSLocation crsLocation = createCRSLocation(crsChannel.getLocationId());
        Mockito.when(locationRepository.get(crsLocation.getId())).thenReturn(crsLocation);

        CRSStation crsStation = CRSStationToStationInfoConverterTest.createCRSStation();
        crsStation.setDigicableId(0);
        long stationId = 100117;
        crsStation.setId(stationId);
        crsStation.setDigicableId(0);
        crsStation.setOnScreenCallSign(null);
        crsStation.setEmergencyAlertSystemType(null);
        Mockito.when(stationRepository.get(stationId)).thenReturn(crsStation);
        crsChannel.setStationId(stationId);

        StationInfo stationInfo = new StationInfo();
        stationInfo.setStationId(merlinIdHelper.createStationId(stationId));
        Mockito.when(crsStationToStationInfoConverter.convert( Mockito.any(CRSStation.class), Mockito.any(MerlinIdHelper.class), Mockito.anyString() ))
                .thenReturn(stationInfo);

        ChannelInfo channelInfo = crsChannelToChannelInfoConverter.convert(crsChannel, merlinIdHelper, null);
        Assert.assertEquals( channelInfo.getChannelId().getId(), crsChannel.getId() );
        Assert.assertEquals(channelInfo.getNumber(), new Integer(crsChannel.getChannelNumber()) );
        Assert.assertNull(channelInfo.getDigicableId());
        Assert.assertNull(channelInfo.getOnScreenCallsign());
        Assert.assertNull(channelInfo.getEmergencyAlertSystemType());
    }

    protected CRSChannel createCRSChannel(){
        CRSChannel crsChannel = new CRSChannel();
        crsChannel.setId(++idCount);
        crsChannel.setDigicableId(++idCount);
        crsChannel.setChannelNumber(++idCount);
        crsChannel.setLocationId(++idCount);
        crsChannel.setStationId(++idCount);
        crsChannel.setOnScreenCallsign("Channel_OCS");
        crsChannel.setEmergencyAlertSystemType("ChannelEAS");
        crsChannel.setOwnerId(++idCount);
        return crsChannel;
    }

    protected CRSLocation createCRSLocation(long locationId){
        CRSLocation crsLocation = new CRSLocation();
        crsLocation.setId(locationId);
        crsLocation.setProductContextId(new Long(++idCount));
        return crsLocation;
    }


}
