package com.theplatform.web.tv.gws.ingest.dispatcher.serialization;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSLocation;
import com.theplatform.web.tv.gws.sirius.serializer.LocationSerializer;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LocationFactoryTest {

    public LocationFactoryTest(){
        SiriusObjectTypeTestUtil.unitTestInitialization();
    }

    @Test
    public void testLocationFactory() throws InvalidProtocolBufferException{
        CRSLocation location = new CRSLocation();
        location.setProductContextId(1234L);
        location.setId(1234L);
        location.setOwnerId(3333L);
        location.setSource("Gracenote");
        LocationSerializer locationFactory = new LocationSerializer(SiriusObjectType.fromFriendlyName("Location"));

        CRSLocation retrievedLocation
                = locationFactory.unmarshallPayload(locationFactory.marshallPayload(location).toByteArray());
        
        Assert.assertEquals(location, retrievedLocation);
    }
	
}
