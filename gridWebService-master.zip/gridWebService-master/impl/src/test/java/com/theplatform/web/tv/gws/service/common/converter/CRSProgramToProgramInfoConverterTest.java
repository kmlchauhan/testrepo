package com.theplatform.web.tv.gws.service.common.converter;


import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import com.theplatform.web.tv.gws.TestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSRating;
import org.apache.commons.lang3.ArrayUtils;
import org.fest.assertions.api.Assertions;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

import static org.testng.Assert.assertNull;
import static org.testng.Assert.fail;

public class CRSProgramToProgramInfoConverterTest {

    CRSProgramToProgramInfoConverter converter;
    private static long idCount;

    public CRSProgramToProgramInfoConverterTest(){
        converter = new CRSProgramToProgramInfoConverter();
        converter.setMerlinIdHelper(TestUtil.MERLIN_ID_HELPER);
    }

    @Test
    public void convert_verifyFields(){
        CRSProgram crsProgram = createCRSProgram();
        ProgramInfo programInfo = converter.convertCRSProgramToProgramInfo(crsProgram, null);
        assertEquals(programInfo, crsProgram);
    }

    @Test
    public void convert_allTagIds() {
        long[] allTags = new long[] {1118, 2118, 3118};
        CRSProgram crsProgram = createCRSProgram();
        crsProgram.setTagIds(allTags);

        // all tags were requested and the program has each of those tags, so all of them should be
        // returned on the ProgramInfo
        ProgramInfo programInfo = converter.convertCRSProgramToProgramInfo(crsProgram, ArrayUtils.toObject(allTags));
        long[] actualTagIds = Muri.getIdsAsArray(programInfo.getTagIds());
        Assertions.assertThat(actualTagIds).isEqualTo(allTags);

        // same thing except no fitler is supplied.  all tags should be returned
        ProgramInfo programInfo2 = converter.convertCRSProgramToProgramInfo(crsProgram, null);
        long[] actualTagIds2 = Muri.getIdsAsArray(programInfo2.getTagIds());
        Assertions.assertThat(actualTagIds2).isEqualTo(allTags);
    }

    @Test
    public void convert_noMatchingTagIds() {
        CRSProgram crsProgram = createCRSProgram();
        crsProgram.setTagIds(new long[] {1118, 2118, 3118});

        // request tagIds 4, 5, and 6.  the programInfo should have no tagIds since the requested
        // tags don't match any of the tags on the CRSProgram
        ProgramInfo programInfo = converter.convertCRSProgramToProgramInfo(crsProgram, new Long[]{4118L, 5118L, 6118L});
        Assertions.assertThat(programInfo.getTagIds()).isNullOrEmpty();
    }

    @Test
    public void convert_someTagIds() {
        CRSProgram crsProgram = createCRSProgram();
        crsProgram.setTagIds(new long[] {1118, 2118, 3118});

        // request tagIds 2, 3, and 4.  the programInfo should have tagIds 2 and 3
        ProgramInfo programInfo = converter.convertCRSProgramToProgramInfo(crsProgram, new Long[]{2118L, 3118L, 4118L});
        Assertions.assertThat(programInfo.getTagIds()).isNotEmpty();
        long[] actualTagIds = Muri.getIdsAsArray(programInfo.getTagIds());
        Assertions.assertThat(actualTagIds).isEqualTo(new long[] {2118, 3118});
    }

    @Test
    public void convert_verifyNullConversion(){
        CRSProgram crsProgram = new CRSProgram();
        crsProgram.setId( (idCount * 1000) + MerlinEntityType.PROGRAM.getTypeSuffix() );
        ProgramInfo programInfo = converter.convertCRSProgramToProgramInfo(crsProgram, null);
        assertEquals( programInfo, crsProgram);
    }


    protected static void assertEquals( ProgramInfo programInfo, CRSProgram crsProgram){
        Assert.assertEquals( programInfo.getProgramId().getId(), crsProgram.getId());
        Assert.assertEquals( programInfo.getTitle(), crsProgram.getTitle());
        Assert.assertEquals( programInfo.getGridTitle(), crsProgram.getGridTitle());
        if (programInfo.getSeriesId()==null){
            Assert.assertNull(crsProgram.getSeriesId());
        }else{
            Assert.assertEquals( programInfo.getSeriesId().getId(), crsProgram.getSeriesId().longValue());
        }
        Assert.assertEquals( programInfo.getEpisodeTitle(), crsProgram.getEpisodeTitle());
        Assert.assertEquals( programInfo.getSportsSubtitle(), crsProgram.getSportsSubtitle());
        if (crsProgram.getCategory()!=null){
            Assert.assertEquals( programInfo.getCategory(), crsProgram.getCategory().getFriendlyName());
        }else{
            Assert.assertNull(programInfo.getCategory());
        }
        if (crsProgram.getType() != null){
            Assert.assertEquals( programInfo.getType(), crsProgram.getType().getFriendlyName() );
        } else {
            Assert.assertNull(programInfo.getType());
        }

        assertRatings(programInfo.getContentRatings(), crsProgram.getContentRatings());
    }

    protected static CRSProgram createCRSProgram(){
        idCount++;
        CRSProgram crsProgram = new CRSProgram();
        crsProgram.setId((idCount * 1000) + MerlinEntityType.PROGRAM.getTypeSuffix());
        crsProgram.setTitle("Title" + idCount);
        crsProgram.setGridTitle("GridTitle" + idCount);
        crsProgram.setSeriesId(1777L + idCount);
        crsProgram.setEpisodeTitle("EpisodeTitle" + idCount);
        crsProgram.setSportsSubtitle("SportsSubtitle" + idCount);
        crsProgram.setCategory(ProgramCategory.Lifestyle);
        crsProgram.setType(ProgramType.Minisode);
        crsProgram.setLanguage("spa");

        CRSRating rating1 = new CRSRating("zScheme", "zRating", new String[]{"V","SL"});
        CRSRating rating2 = new CRSRating("aScheme", "aRating", null);
        CRSRating rating3 = new CRSRating("nScheme", "nRating", new String[]{"N"});
        crsProgram.setContentRatings( new CRSRating[]{rating1,rating2,rating3});

        return crsProgram;
    }


    public static final void assertRatings( List<Rating> merlinRatings, CRSRating[] crsRatings){
        if (merlinRatings ==null){
            assertNull(crsRatings);
        }else{
            Assert.assertEquals(merlinRatings.size(), crsRatings.length, "Object contains a different numbers of ratings.");
            String previousScheme = null;           // To check order
            for ( Rating rating : merlinRatings){
                boolean success = false;
                for (CRSRating crsRating : crsRatings){
                    if (rating.getScheme().equals(crsRating.getScheme())){
                        Assert.assertEquals(rating.getRating(), crsRating.getRating());
                        Assert.assertEquals(rating.getScheme(), crsRating.getScheme());
                        if (rating.getSubRatings()==null){
                            Assert.assertNull(crsRating.getSubRatings());
                        }else{
                            Assert.assertEquals(rating.getSubRatings().length, crsRating.getSubRatings().length);
                            for (int j = 0; j < crsRating.getSubRatings().length; j++) {
                                Assert.assertEquals(rating.getSubRatings()[j], crsRating.getSubRatings()[j]);
                            }
                        }
                        // Check order
                        if (previousScheme != null){
                            int order = previousScheme.compareTo(rating.getScheme());
                            if (order>0){
                                Assert.fail("Ratings are in the wrong order.  Should be ascending by scheme.");
                            }
                        }
                        previousScheme = rating.getScheme();
                        success=true;
                        break;
                    }
                }
                if (!success){
                    fail("Unable to find rating in ListingInfo with scheme.  The Ratings do not match.");
                }

            }

        }
    }

}