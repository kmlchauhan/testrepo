package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSTag;
import org.testng.annotations.Test;

import java.util.Arrays;

import static com.theplatform.data.tv.entity.api.data.objects.TagType.Station;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

/**
 * @author jcoelho
 * @since 6/23/15.
 */
public class TagRepositoryTest {

    long id = 123L;
    String title = "title";

    public TagRepositoryTest(){
        SiriusObjectTypeTestUtil.unitTestInitialization();
    }

    @Test
    public void putCRSTag_expectCorrectTag() {
        TagRepository repository = new TagRepository(SiriusObjectType.fromFriendlyName("EntityTag"));
        CRSTag crsTag = new CRSTag(id, "title", Station);
        repository.put(id, crsTag);
        assertEquals(crsTag, repository.get(id));
    }

    @Test
    public void putCRSTag_expectCorrectIndex() {
        TagRepository repository = new TagRepository(SiriusObjectType.fromFriendlyName("EntityTag"));
        CRSTag crsTag = new CRSTag(id, title, Station);
        repository.put(id, crsTag);
        CRSTag[] crstTagsByTitle = repository.getCRSTTagsByTitle(title);
        assertTrue(Arrays.asList(crstTagsByTitle).contains(crsTag));
    }

    @Test
    public void removeCRSTag_expectIndexRemoved() {
        TagRepository repository = new TagRepository(SiriusObjectType.fromFriendlyName("EntityTag"));
        CRSTag crsTag = new CRSTag(id, title, Station);
        repository.put(id, crsTag);
        CRSTag[] crstTagsByTitle = repository.getCRSTTagsByTitle(title);
        assertTrue(Arrays.asList(crstTagsByTitle).contains(crsTag));

        repository.delete(id);
        crstTagsByTitle = repository.getCRSTTagsByTitle(title);
        assertTrue(!Arrays.asList(crstTagsByTitle).contains(crsTag));
    }
}
