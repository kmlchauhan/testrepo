package com.theplatform.web.tv.gws.service.common.field.nullification;

import org.fest.assertions.api.Assertions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SelectedPropertiesTest {

    @Test
    public void test_whitespaceIgnored() {
        SelectedProperties properties = new SelectedProperties(NullificationMode.NULLIFY_SELECTED_PROPERTIES, "foo.bar, baz.bar ");
        Assert.assertTrue(properties.included("foo.bar"));
        Assert.assertFalse(properties.included("foo"));
        Assert.assertTrue(properties.childrenIncluded("foo"));
        Assertions.assertThat(properties.childrenOf("foo")).containsOnly("foo.bar");

        Assert.assertTrue(properties.included("baz.bar"));
        Assert.assertFalse(properties.included("baz"));
        Assert.assertTrue(properties.childrenIncluded("baz"));
        Assertions.assertThat(properties.childrenOf("baz")).containsOnly("baz.bar");
    }

    @Test
    public void test_nestedProperties() {
        SelectedProperties properties = new SelectedProperties(NullificationMode.NULLIFY_SELECTED_PROPERTIES, "a.b.3.2,a.b.1,a.b.2,a.b.3.1,a.c");

        Assert.assertFalse(properties.included("a"));
        Assert.assertTrue(properties.childrenIncluded("a"));
        Assertions.assertThat(properties.childrenOf("a")).contains("a.b", "a.c");
        Assert.assertFalse(properties.included("a.b"));
        Assert.assertTrue(properties.childrenIncluded("a.b"));
        Assertions.assertThat(properties.childrenOf("a.b")).containsOnly("a.b.1", "a.b.2", "a.b.3");

        Assert.assertTrue(properties.included("a.b.1"));
        Assert.assertFalse(properties.childrenIncluded("a.b.1"));
        Assert.assertNull(properties.childrenOf("a.b.1"));

        Assert.assertFalse(properties.included("a.b.3"));
        Assert.assertTrue(properties.childrenIncluded("a.b.3"));
        Assertions.assertThat(properties.childrenOf("a.b.3")).containsOnly("a.b.3.1", "a.b.3.2");
    }

    @Test
    public void test_directOverridesChildren() {
        SelectedProperties properties = new SelectedProperties(NullificationMode.NULLIFY_SELECTED_PROPERTIES, "a.b.c,a.b");
        Assert.assertTrue(properties.included("a.b"));
        Assert.assertFalse(properties.childrenIncluded("a.b"));
        Assert.assertFalse(properties.included("a.b.c"));

        SelectedProperties properties2 = new SelectedProperties(NullificationMode.NULLIFY_SELECTED_PROPERTIES, "a.b,a.b.c");
        Assert.assertTrue(properties2.included("a.b"));
        Assert.assertFalse(properties2.childrenIncluded("a.b"));
        Assert.assertFalse(properties2.included("a.b.c"));
    }
}
