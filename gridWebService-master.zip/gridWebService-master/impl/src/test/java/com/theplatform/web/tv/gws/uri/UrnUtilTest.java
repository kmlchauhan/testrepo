package com.theplatform.web.tv.gws.uri;

import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.module.exception.BadParameterException;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.combine.commons.MerlinService;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.net.URI;

import static org.fest.assertions.api.Assertions.assertThat;

public class UrnUtilTest {

    @Test(expectedExceptions = {BadParameterException.class})
    public void generateUrnIdWithMissingObjectType_expectBadParameterException() {
        Assert.assertEquals(
            UrnUtil.generateUrn(1234L, MerlinService.OFFER, null),
            new Muri(UrnUtil.URN_PREFIX + "offer:test:" + id));
    }

    @Test
    public void generateUrnId_getCorrectUrnId() {
        Assert.assertEquals(
            UrnUtil.generateUrn(id, MerlinService.OFFER, MerlinEntityType.PRODUCTCONTEXT),
            new Muri(UrnUtil.URN_PREFIX + "offer:productcontext:" + id));
    }

    private void assertUrn(String urn, MerlinEntityType expectedType) {

        MerlinEntityType actualType = UrnUtil.getUrnEntityType(urn);
        Assert.assertEquals(actualType, expectedType);

        MerlinEntityType actualTypeUppercase = UrnUtil.getUrnEntityType(urn.toUpperCase());
        Assert.assertEquals(actualTypeUppercase, expectedType);

        MerlinEntityType actualTypeLowercase = UrnUtil.getUrnEntityType(urn.toLowerCase());
        Assert.assertEquals(actualTypeLowercase, expectedType);
    }

    @Test
    public void testCaseInsensitivity() {
        assertUrn("merlin:linear:program:12452", MerlinEntityType.PROGRAM);
        assertUrn("comcast:merlin:Program:12452", MerlinEntityType.PROGRAM);
    }


    @DataProvider
    public Object[][] validUrnMappings() {

        // inputString, expectedResult
        return new Object[][]{
            {"comcast:merlin:MainImageTypeGroup:7355478258369051161",  MerlinService.LINEAR, "merlin:linear:mainimagetypegroup:7355478258369051161"},
            {"merLin:offEr:AvailaBilityTaG:5342498276680043143",  null, "merlin:offer:availabilitytag:5342498276680043143"},
            {"comcast:merlin:Linear:Location:100110",  null, "merlin:linear:location:100110"},
            {"comcast:RecorderManager:cdvr-c-rmID-ncs01", null, "comcast:RecorderManager:cdvr-c-rmID-ncs01"},
            {"comcast:merlin:foo:Location:122110", null, "merlin:linear:location:122110"},
            {"comcast:merlin:Linear:foo:122110", null, "merlin:linear:foo:122110"},
            {"comcast:merlin:foo:122110", MerlinService.LINEAR, "merlin:linear:foo:122110"}
        };
    }

    @Test (dataProvider = "validUrnMappings")
    public void testConvertUrn(String inputUrn, MerlinService serviceOverride, String expectedUrn) throws Exception {
        Muri urn = UrnUtil.convertUrn(Muri.create(inputUrn), serviceOverride);
        Assert.assertEquals( urn.toString(), expectedUrn, urn.toString() + " ==> " + expectedUrn);
    }


    @DataProvider
    public Object[][] generateUrnData() {
        // inputString, expectedResult
        return new Object[][]{
            { 7355478258369051161L, MerlinService.LINEAR, MerlinEntityType.MAINIMAGETYPEGROUP, "merlin:linear:mainimagetypegroup:7355478258369051161"},
            { 5342498276680043143L, MerlinService.OFFER,  MerlinEntityType.AVAILABILITYTAG, "merlin:offer:availabilitytag:5342498276680043143"},
            { 100110L, MerlinService.LINEAR, MerlinEntityType.LOCATION, "merlin:linear:location:100110"}
        };
    }

    @Test (dataProvider = "generateUrnData")
    public void generteUrn( Long id, MerlinService merlinService, MerlinEntityType merlinEntityType, String expectedUrn){
        Muri urn = UrnUtil.generateUrn(id, merlinService, merlinEntityType);
        Assert.assertEquals( urn, Muri.create(expectedUrn));
    }

    public static final String OBJECT_TYPE = MerlinEntityType.AVAILABILITYTAG.getTypeString();
    public static final String uriPrefix = "test:test:service:" + OBJECT_TYPE + ":";
    public static final long id = 1234L;

    @Test(expectedExceptions = {BadParameterException.class})
    public void parseUrnObjectNameWithNull_expectBadParameterException() {
        UrnUtil.getUrnEntityType((String) null);
    }

    @Test
    public void testParseObjectName() {
        URI urn = URI.create("merlin:offer:availabilityTag:69164000");
        MerlinEntityType merlinEntityType = UrnUtil.getUrnEntityType(urn);
        assertThat(merlinEntityType).isEqualTo(MerlinEntityType.AVAILABILITYTAG);
    }

    @Test
    public void parseUrnObjectName_expectCorrectObjectType() {
        MerlinEntityType actual = UrnUtil.getUrnEntityType(URI.create(uriPrefix + "1234"));
        Assert.assertEquals(actual, MerlinEntityType.AVAILABILITYTAG);
    }

}