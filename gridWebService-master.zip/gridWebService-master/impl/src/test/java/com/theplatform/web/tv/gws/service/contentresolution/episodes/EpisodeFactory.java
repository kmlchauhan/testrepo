package com.theplatform.web.tv.gws.service.contentresolution.episodes;

import com.theplatform.contrib.testing.factory.field.ConsecutiveLongProvider;
import com.theplatform.contrib.testing.factory.field.EntityTypeAwareIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;

import java.util.ArrayList;
import java.util.List;

class EpisodeFactory {

    private static final ValueProvider<Long> programIdProvider = new EntityTypeAwareIdProvider(
            MerlinEntityType.PROGRAM, new ConsecutiveLongProvider());

    static CRSProgram create() {
        CRSProgram program = create(programIdProvider.getValue());

        return program;
    }

    static CRSProgram create(long seriesId) {
        CRSProgram program = new CRSProgram(programIdProvider.getValue());

        program.setSeriesId(seriesId);
        program.setType(ProgramType.Episode);

        return program;
    }

    static CRSProgram create(long seriesId, int seasonNumber, int episodeNumber) {
        CRSProgram program = create(seriesId);

        program.setTvSeasonNumber(seasonNumber);
        program.setTvSeasonEpisodeNumber(episodeNumber);

        return program;
    }

    static List<CRSProgram> createSeries(int seasons, int episodesPerSeason) {
        List<CRSProgram> series = new ArrayList<>(seasons * episodesPerSeason);
        long seriesId = programIdProvider.getValue();

        for (int s = 1; s <= seasons; ++s) {
            for (int e = 1; e <= episodesPerSeason; ++e) {
                series.add(create(seriesId, s, e));
            }
        }

        return series;
    }
}
