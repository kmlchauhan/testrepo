package com.theplatform.web.tv.gws.service.contentresolution;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.URISyntaxException;
import java.util.*;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: mmattozzi
 * Date: 12/14/11
 * Time: 2:58 PM
 */
public class GridMapperTest {

    @Test(groups = {"gridMapper"})
    public void testCreateGrid() throws Exception {

    	ContentResolutionServiceImpl gridService = mock(ContentResolutionServiceImpl.class);
        when(gridService.getListings(eq(100L), any(Integer.class), any(Integer.class), any(Integer.class), (Long[]) isNull(), (String) isNull()))
                .thenReturn(createListingsWithCategories("Other", "Other", "Movie"));
        when(gridService.getListings(eq(102L), any(Integer.class), any(Integer.class), any(Integer.class), (Long[]) isNull(), (String) isNull()))
                .thenReturn(createListingsWithCategories("Sports", "Sports"));
        when(gridService.getListings(eq(103L), any(Integer.class), any(Integer.class), any(Integer.class), (Long[]) isNull(), (String) isNull()))
                .thenReturn(createListingsWithCategories("Sports", "Movie", "Other", "Children's"));

        List<ChannelInfo> channels = new ArrayList<ChannelInfo>();
        channels.add(createChannelInfoWithStationId(100L));
        channels.add(createChannelInfoWithStationId(102L));
        channels.add(createChannelInfoWithStationId(103L));

        List<Header> header = new ArrayList<Header>();

        GridMapper gridMapper = new GridMapper();

        Grid grid = gridMapper.createGrid(channels, header, gridService, null, null, null, null);

        Assert.assertEquals(grid.getChannels().size(), 3);
        Assert.assertEquals((long) (grid.getChannels().get(0).getStationInfo().getStationId().getId()), 100L);
        Assert.assertEquals((long) (grid.getChannels().get(1).getStationInfo().getStationId().getId()), 102L);
        Assert.assertEquals((long) (grid.getChannels().get(2).getStationInfo().getStationId().getId()), 103L);
        Assert.assertEquals(grid.getHeader(), header);

    }

    @Test(groups = {"gridMapper"})
    public void testCreateFilteredGrid() throws Exception {

    	ContentResolutionServiceImpl gridService = mock(ContentResolutionServiceImpl.class);
        when(gridService.getListings(eq(100L), any(Integer.class), any(Integer.class), any(Integer.class), (Long[]) isNull(), (String) isNull()))
            .thenReturn(createListingsWithCategories("Other", "Other", "Movie"));
        when(gridService.getListings(eq(102L), any(Integer.class), any(Integer.class), any(Integer.class), (Long[]) isNull(), (String) isNull()))
                .thenReturn(createListingsWithCategories("Sports", "Sports"));
        when(gridService.getListings(eq(103L), any(Integer.class), any(Integer.class), any(Integer.class), (Long[]) isNull(), (String) isNull()))
                .thenReturn(createListingsWithCategories("Sports", "Movie", "Other", "Children's"));

        List<ChannelInfo> channels = new ArrayList<ChannelInfo>();
        channels.add(createChannelInfoWithStationId(100L));
        channels.add(createChannelInfoWithStationId(102L));
        channels.add(createChannelInfoWithStationId(103L));

        List<Header> header = new ArrayList<Header>();
        
        GridMapper gridMapper = new GridMapper();
        
        Grid grid = gridMapper.createFilteredGrid(channels, header, gridService, null, null, null,
                new String[] { "Movie" }, null);

        Assert.assertEquals(grid.getChannels().size(), 2);
        Assert.assertEquals((long) (grid.getChannels().get(0).getStationInfo().getStationId().getId()), 100L);
        Assert.assertEquals((long) (grid.getChannels().get(1).getStationInfo().getStationId().getId()), 103L);
        Assert.assertEquals(grid.getHeader(), header);

    }

    @Test(groups = {"gridMapper"})
    public void testListingsMatchFilter() throws Exception {
        GridMapper gridMapper = new GridMapper();

        List<ListingInfo> listings = createListingsWithCategories("Movie", "Other", "Sports");
        Set<String> categories = new HashSet<String>(Arrays.asList("Movie", "Sports"));
        Assert.assertTrue(gridMapper.listingsMatchFilter(listings, categories));

        listings = createListingsWithCategories("News", "Other");
        categories = new HashSet<String>(Arrays.asList("Movie", "Sports"));
        Assert.assertFalse(gridMapper.listingsMatchFilter(listings, categories));
    }
    
    protected ChannelInfo createChannelInfoWithStationId(Long id) throws URISyntaxException {
        ChannelInfo channelInfo = new ChannelInfo();
        StationInfo stationInfo = new StationInfo();

        channelInfo.setStationInfo(stationInfo);
        stationInfo.setStationId(new Muri("http://localhost/linearDataService/data/Station/" + id, id));
        return channelInfo;
    }
    
    protected List<ListingInfo> createListingsWithCategories(String ... categories) {
        List<ListingInfo> listings = new ArrayList<ListingInfo>();
        
        for (String category : categories) {
            ListingInfo listingInfo = new ListingInfo();
            ProgramInfo programInfo = new ProgramInfo();
            programInfo.setCategory(category);
            listingInfo.setProgramInfo(programInfo);
            listings.add(listingInfo);
        }

        return listings;
    }

}
