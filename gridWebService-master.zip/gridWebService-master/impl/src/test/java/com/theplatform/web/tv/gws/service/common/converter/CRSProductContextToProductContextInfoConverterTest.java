package com.theplatform.web.tv.gws.service.common.converter;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ProductContextInfo;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import com.theplatform.web.tv.gws.sirius.model.CRSProductContext;
import com.theplatform.web.tv.gws.sirius.repository.ProductContextRepository;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author jcoelho
 * @since 11/18/14.
 */
public class CRSProductContextToProductContextInfoConverterTest {

    public static final String PRODUCT_CONTEXT_TITLE = "UniversityTitle";
    public static final String PRODUCT_CONTEXT_TYPE = "UniversityType";
    public static final long PRODUCT_CONTEXT_ID = 123L;
    private static final Muri PRODUCT_CONTEXT_ID_URI = new Muri("http://someUrl/" + PRODUCT_CONTEXT_ID, PRODUCT_CONTEXT_ID);

    @Mock
    MerlinIdHelper merlinIdHelper;

    @Mock
    ProductContextRepository productContextRepository;

    CRSProductContextToProductContextInfoConverter converter = new CRSProductContextToProductContextInfoConverter();

    @BeforeTest
    public void before() {
        MockitoAnnotations.initMocks(this);
        Mockito.when(merlinIdHelper.createProductContextId(PRODUCT_CONTEXT_ID)).thenReturn(PRODUCT_CONTEXT_ID_URI);
        Mockito.when(productContextRepository.get(PRODUCT_CONTEXT_ID)).thenReturn(createCRSProductContext(PRODUCT_CONTEXT_ID, PRODUCT_CONTEXT_TITLE, PRODUCT_CONTEXT_TYPE));
        converter.setMerlinIdHelper(merlinIdHelper);
        ((CRSProductContextToProductContextInfoConverter) converter).setProductContextRepository(productContextRepository);
    }

    @Test
    public void convertNull_expectNull() {
        CRSProductContext crsProductContext = null;
        Assert.assertNull(converter.convert(crsProductContext));
    }

    @Test
    public void convertEmptyCRSProductContext_expectCorrectConversion() {
        ProductContextInfo convert = converter.convert(createCRSProductContextWithMissingId());
        Assert.assertEquals(new ProductContextInfo(), convert);
    }

    @Test
    public void convertCRSProductContext_expectCorrectConversion() {
        ProductContextInfo convert = converter.convert(createCRSProductContext(PRODUCT_CONTEXT_ID, PRODUCT_CONTEXT_TITLE, PRODUCT_CONTEXT_TYPE));
        Assert.assertEquals(getProductContextInfoExpected(), convert);
    }

    @Test
    public void convertCRSProductContextLongList_expectCorrectConverstion() {
        List<ProductContextInfo> convert = ((CRSProductContextToProductContextInfoConverter) converter).convert(Arrays.asList(PRODUCT_CONTEXT_ID));
        assertThat(convert).contains(getProductContextInfoExpected());
    }

    static private ProductContextInfo getProductContextInfoExpected() {
        ProductContextInfo expected = new ProductContextInfo();
        expected.setId(PRODUCT_CONTEXT_ID_URI);
        expected.setTitle(PRODUCT_CONTEXT_TITLE);
        expected.setType(PRODUCT_CONTEXT_TYPE);
        return expected;
    }

    static private CRSProductContext createCRSProductContext(long i, String title, String type) {
        CRSProductContext crsProductContext = new CRSProductContext(i);
        crsProductContext.setTitle(title);
        crsProductContext.setType(type);
        return crsProductContext;
    }

    static private CRSProductContext createCRSProductContextWithMissingId() {
        return new CRSProductContext();
    }

}
