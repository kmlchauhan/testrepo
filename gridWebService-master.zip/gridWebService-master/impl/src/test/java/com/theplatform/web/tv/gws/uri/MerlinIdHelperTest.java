package com.theplatform.web.tv.gws.uri;

import com.theplatform.web.context.WebServiceContext;
import com.theplatform.web.endpoint.WebServiceRequest;
import com.theplatform.web.endpoint.WebServiceResponse;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static com.theplatform.web.tv.gws.TestUtil.*;
import static com.theplatform.web.tv.gws.uri.IdForm.URL;
import static com.theplatform.web.tv.gws.uri.IdForm.URN;
import static org.testng.Assert.assertEquals;

/**
 * Created by jcoelho on 8/6/14.
 */
public class MerlinIdHelperTest {

    public static final IdForm DEFAULT_ID_FORM = URL;

    public static final long ID = 123L;

    public MerlinIdHelper createMerlinIdHelper() {
        MerlinIdHelper merlinIdHelper = new MerlinIdHelper();
        merlinIdHelper.setEntityBaseUrl(ENTITY_BASE_URL);
        merlinIdHelper.setLinearBaseUrl(LINEAR_BASE_URL);
        merlinIdHelper.setLocationBaseUrl(LOCATION_BASE_URL);
        merlinIdHelper.setOfferBaseUrl(OFFER_BASE_URL);
        return merlinIdHelper;
    }

    @Test
    public void callGetIdFormMissingContext_expectDefault() {
        assertEquals(createMerlinIdHelper().getIdForm(), DEFAULT_ID_FORM);
    }

    @DataProvider
    public Object[][] urlStrings() {
        return new Object[][]{
                new Object[]{null, DEFAULT_ID_FORM},
                new Object[]{"URL", DEFAULT_ID_FORM},
                new Object[]{"url", DEFAULT_ID_FORM},
                new Object[]{"UrL", DEFAULT_ID_FORM},
                new Object[]{"Urn", URN}
        };
    }

    @Test(dataProvider = "urlStrings")
    public void callGetIdFormURL_expectURL(String url, IdForm expected) {
        MerlinIdHelper merlinIdHelper = createMerlinIdHelper();
        merlinIdHelper.setWebServiceContext(new TestWebServiceContext(url));
        assertEquals(merlinIdHelper.getIdForm(), expected);
    }

    @Test
    public void createChannelId_expectCorrectUri() {
        MerlinIdHelper merlinIdHelper = createMerlinIdHelper();
        assertEquals(merlinIdHelper.createChannelId(ID).toString(), LINEAR_BASE_URL + "data/Channel/" + ID);
        merlinIdHelper.setWebServiceContext(new TestWebServiceContext("urn"));
        assertEquals(merlinIdHelper.createChannelId(ID).toString(), "merlin:linear:channel:" + ID);
    }

    private static class TestWebServiceContext implements WebServiceContext {

        public String idForm;

        public TestWebServiceContext(String idForm) {
            this.idForm = idForm;
        }

        @Override
        public WebServiceRequest getWebServiceRequest() {
            Map<String, String[]> params = new HashMap<>();
            params.put("idForm", new String[]{idForm});
            WebServiceRequest webServiceRequest = new WebServiceRequest();
            webServiceRequest.setParameters(params);
            return webServiceRequest;
        }

        @Override
        public WebServiceResponse getWebServiceResponse() {
            return null;
        }
    }
}
