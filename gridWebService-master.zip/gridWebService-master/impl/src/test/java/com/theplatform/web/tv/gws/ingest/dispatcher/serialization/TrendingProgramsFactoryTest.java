package com.theplatform.web.tv.gws.ingest.dispatcher.serialization;


import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms;
import com.theplatform.web.tv.gws.sirius.serializer.TrendingProgramsSerializer;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

public class TrendingProgramsFactoryTest {

    public TrendingProgramsFactoryTest(){
        SiriusObjectTypeTestUtil.unitTestInitialization();
    }

    private void assertProgramsEqual(CRSTrendingProgram expected, CRSTrendingProgram actual) {
        assertEquals(expected.getProgramId(), actual.getProgramId());
        assertEquals(expected.getScore(), actual.getScore());
        assertEquals(expected.isTopTrending(), actual.isTopTrending());
        assertEquals(expected.getRankingGroup(), actual.getRankingGroup());
    }

    @Test
    public void test() throws InvalidProtocolBufferException {
        CRSTrendingProgram crsProgram1 = new CRSTrendingProgram();
        crsProgram1.setProgramId(1);
        crsProgram1.setScore(1);
        crsProgram1.setTopTrending(true);
        crsProgram1.setRankingGroup(1);

        CRSTrendingProgram crsProgram2 = new CRSTrendingProgram();
        crsProgram2.setProgramId(2);
        crsProgram2.setScore(2);
        crsProgram2.setRankingGroup(2);

        CRSTrendingPrograms crsTrendingPrograms = new CRSTrendingPrograms();
        crsTrendingPrograms.setTimeToLive(3L);
        crsTrendingPrograms.setRetrievedTime(4L);
        crsTrendingPrograms.getPrograms().add(crsProgram1);
        crsTrendingPrograms.getPrograms().add(crsProgram2);

        TrendingProgramsSerializer factory = new TrendingProgramsSerializer(SiriusObjectType.fromFriendlyName("TrendingPrograms"));
        CRSTrendingPrograms deserializedPrograms =
                factory.unmarshallPayload(factory.marshallPayload(crsTrendingPrograms).toByteArray());

        // programs properties
        assertNotNull(deserializedPrograms);
        assertEquals(crsTrendingPrograms.getTimeToLive(), deserializedPrograms.getTimeToLive());
        assertEquals(crsTrendingPrograms.getRetrievedTime(), deserializedPrograms.getRetrievedTime());

        // check each program
        assertNotNull(deserializedPrograms.getPrograms());
        assertEquals(crsTrendingPrograms.getPrograms().size(), deserializedPrograms.getPrograms().size());
        assertProgramsEqual(crsTrendingPrograms.getPrograms().get(0), deserializedPrograms.getPrograms().get(0));
        assertProgramsEqual(crsTrendingPrograms.getPrograms().get(1), deserializedPrograms.getPrograms().get(1));
    }
}
