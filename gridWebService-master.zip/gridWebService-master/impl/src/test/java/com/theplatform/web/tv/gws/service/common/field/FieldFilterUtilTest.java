package com.theplatform.web.tv.gws.service.common.field;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.fest.assertions.api.Assertions.assertThat;

public class FieldFilterUtilTest {

    private Grid grid;
    private List<Header> headerList;
    private List<ListingInfo> listingInfos;

    @BeforeMethod
    public void setUpTest() {
        grid = new Grid();

        ChannelInfo channel1 = new ChannelInfo();
        channel1.setNumber(1);

        ChannelInfo channel2 = new ChannelInfo();
        channel2.setNumber(2);

        grid.setTitle("A Title");
        grid.setChannels(Arrays.asList(channel1, channel2));
        Header header = new Header();
        header.setTitle("Header Title");
        headerList = Arrays.asList(header);
        grid.setHeader(headerList);

        // Listings
        listingInfos = new ArrayList<ListingInfo>() ;
        ListingInfo first = new ListingInfo();
        ProgramInfo firstProgram = new ProgramInfo();
        firstProgram.setSportsSubtitle("firstSubtitle");
        first.setProgramInfo(firstProgram);
        first.setCaptionType("captionTypeFirst");
        first.setCci("cciFirst");
        listingInfos.add(first);

        ListingInfo second = new ListingInfo();
        ProgramInfo secondProgram = new ProgramInfo();
        secondProgram.setSportsSubtitle("firstSubtitle");
        second.setProgramInfo(secondProgram);
        second.setCaptionType("captionTypeSecond");
        second.setCci("cciSecond");
        listingInfos.add(second);
    }
    
    @Test
    public void testSimpleCase() {

        String fields = "channels.number";

        FieldFilterUtil.filterFields(grid, fields, null);

        assertThat(grid.getTitle()).isNull();
        assertThat(grid.getChannels()).isNotEmpty();
        assertThat(grid.getChannels().get(0).getNumber()).isEqualTo(1);
        assertThat(grid.getChannels().get(1).getNumber()).isEqualTo(2);
    }
    
    @Test
    public void testForceIncludeField() {

        String fields = "header";
        String forceInclude = "channels";
        
        FieldFilterUtil.filterFields(grid, fields, null, forceInclude);

        assertThat(grid.getTitle()).isNull();
        assertThat(grid.getHeader()).isEqualTo(headerList);
        assertThat(grid.getChannels()).isNotEmpty();
        assertThat(grid.getChannels().get(0).getNumber()).isEqualTo(1);
        assertThat(grid.getChannels().get(1).getNumber()).isEqualTo(2);
    }
    
    
    @Test
    public void testForceIncludeNestedField() {
        
        String fields = "channels.number";
        String forceInclude = "channels.channelUrn";
        
        FieldFilterUtil.filterFields(grid, fields, null, forceInclude);

        assertThat(grid.getTitle()).isNull();
        assertThat(grid.getChannels()).isNotEmpty();
        assertThat(grid.getChannels().get(0).getNumber()).isEqualTo(1);

        assertThat(grid.getChannels().get(1).getNumber()).isEqualTo(2);
    }

    @Test
    public void testNullifySimpleCase() {

        String fields = "channels.number";

        FieldFilterUtil.nullifyFields(grid, fields);

        assertThat(grid.getTitle()).isNotNull();
        assertThat(grid.getChannels()).isNotEmpty();
        assertThat(grid.getChannels().get(0).getNumber()).isNull();
        assertThat(grid.getChannels().get(1).getNumber()).isNull();
    }


    @Test
    public void testNullifyListCase() {
        String fields = "cci,programInfo.sportsSubtitle";

        // Empty list case should not choke
        FieldFilterUtil.nullifyFields( new ArrayList<ListingInfo>(), fields);

        // Populated list
        for (ListingInfo listingInfo : listingInfos){
            assertThat(listingInfo.getCci()).isNotNull();
            assertThat(listingInfo.getCaptionType()).isNotNull();
            assertThat(listingInfo.getProgramInfo().getSportsSubtitle()).isNotNull();
        }

        FieldFilterUtil.nullifyFields( listingInfos, fields);

        for (ListingInfo listingInfo : listingInfos){
            assertThat(listingInfo.getCci()).isNull();
            assertThat(listingInfo.getCaptionType()).isNotNull();                       // Didn't filter this one
            assertThat(listingInfo.getProgramInfo().getSportsSubtitle()).isNull();
        }
    }

    @Test
    public void testFilter_nestedFields() {
        StreamInfo streamInfo = new StreamInfo();
        streamInfo.setExternal(true);
        streamInfo.setStatus("status");

        Muri uri = Muri.create("urn:foo:123");

        StationInfo stationInfo = new StationInfo();
        stationInfo.setOnScreenCallsign("FOO");
        stationInfo.setDigicableId(1);
        stationInfo.setStream(streamInfo);
        stationInfo.setTagIds(Collections.singletonList(uri));

        ChannelInfo channelInfo = new ChannelInfo();
        channelInfo.setNumber(1);
        channelInfo.setStationInfo(stationInfo);

        ChannelInfoCollection channelInfos = new ChannelInfoCollection();
        channelInfos.getChannels().add(channelInfo);
        channelInfos.setVersion("foobar");

        FieldFilterUtil.filterFields(channelInfos, "channels.stationInfo.onScreenCallsign,channels.stationInfo.stream", null);

        assertThat(channelInfos.getVersion()).isNull();
        assertThat(channelInfos.getChannels()).containsExactly(channelInfo);
        assertThat(channelInfo.getNumber()).isNull();
        assertThat(channelInfo.getStationInfo()).isNotNull();
        assertThat(stationInfo.getOnScreenCallsign()).isNotNull();
        assertThat(stationInfo.getDigicableId()).isNull();
        assertThat(stationInfo.getStream()).isNotNull();
        assertThat(stationInfo.getTagIds()).isNull();
        assertThat(streamInfo.getExternal()).isNotNull();
        assertThat(streamInfo.getStatus()).isNotNull();
    }
}
