package com.theplatform.web.tv.gws.service.contentresolution;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.fest.assertions.api.Assertions.assertThat;

public class ContentResolutionServiceImplTest {

    @DataProvider
    public Object[][] filterByRowsData() {
        return new Object[][] {
                {Arrays.asList(1,2), null, null, Arrays.asList(1,2)},
                {Arrays.asList(1,2), 1, null, Arrays.asList(1,2)},
                {Arrays.asList(1,2), null, 5, Arrays.asList(1,2)},
                {Collections.emptyList(), null, null, Collections.emptyList()},
                {Arrays.asList(1,2), 20, null, Collections.emptyList()},
                {Arrays.asList(1,2,3,4,5), 3, 4, Arrays.asList(3)}
        };
    }

    @Test(dataProvider = "filterByRowsData")
    public void testFilterByRows(List<Integer> in, Integer rowStart, Integer rowEnd, List<Integer> expected)
            throws Exception {
        List<Integer> actualItems = ContentResolutionServiceImpl.filterByRows(in, rowStart, rowEnd);

        assertThat(actualItems).isEqualTo(expected);
    }

    @Test(expectedExceptions = {IllegalArgumentException.class})
    public void testInvalidStart() {
        ContentResolutionServiceImpl.filterByRows(Arrays.asList(1,2,3), 0, null);
    }

    @Test(expectedExceptions = {IllegalArgumentException.class})
    public void testInvalidEnd() {
        ContentResolutionServiceImpl.filterByRows(Arrays.asList(1,2,3), 3, 1);
    }
}
