package com.theplatform.web.tv.gws.ingest.dispatcher.serialization;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.data.tv.entity.api.data.objects.TagType;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSTag;
import com.theplatform.web.tv.gws.sirius.serializer.TagSerializer;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author jcoelho
 * @since 6/18/15.
 */
public class TagFactoryTest {

    @Test
    public void expectConvertedMessage() throws InvalidProtocolBufferException {
        SiriusObjectTypeTestUtil.unitTestInitialization();

        TagSerializer tagFactory = new TagSerializer(SiriusObjectType.fromFriendlyName("EntityTag"));
        CRSTag crsTag = new CRSTag(123L, "Adult", TagType.Station);

        CRSTag expected =
                tagFactory.unmarshallPayload(tagFactory.marshallPayload(crsTag).toByteArray());

        Assert.assertEquals(crsTag, expected);
    }
}
