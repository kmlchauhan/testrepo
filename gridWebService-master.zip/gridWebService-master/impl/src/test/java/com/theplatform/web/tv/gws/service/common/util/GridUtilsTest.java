package com.theplatform.web.tv.gws.service.common.util;

import com.theplatform.module.exception.BadParameterException;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Test(groups = { "unit-tests" })
public class GridUtilsTest {
	private static final String GOOGLE_URI = "http://www.google.com/";
	private static final String BING_URI   = "http://www.bing.com/";

	@Test(groups = { "extractstationids-tests" })
	public void testExtractStationIds() {

		ChannelInfo info1 = new ChannelInfo();
		ChannelInfo info2 = new ChannelInfo();

        info1.setStationInfo(new StationInfo());
        info2.setStationInfo(new StationInfo());

        info1.getStationInfo().setStationId(new Muri(GOOGLE_URI));
		info2.getStationInfo().setStationId(new Muri(BING_URI));

        List<ChannelInfo> channelInfos = new ArrayList<ChannelInfo>();
		
		channelInfos.addAll(Arrays.asList(info1, info2));
		
		List<Muri> uris = GridUtils.extractStationIds(channelInfos);
		
		Assert.assertEquals(uris.get(0).toString(), GOOGLE_URI);
		Assert.assertEquals(uris.get(1).toString(), BING_URI);
	}
	

	@Test(groups = { "rollbacktostartofgrid-tests" })
	public void testRollBackToStartOfGridUnitBeginningOfDayCase() {
		Integer gridUnitWidth = 120;
		
		Calendar unrolledBackCalendar = new GregorianCalendar();
		unrolledBackCalendar.set(Calendar.HOUR_OF_DAY, 1);
		unrolledBackCalendar.set(Calendar.MINUTE, 58);
		unrolledBackCalendar.set(Calendar.SECOND, 15);

		Date rolledBackDate = GridUtils.rollBackToStartOfGridUnit(unrolledBackCalendar.getTime(), gridUnitWidth);
		Calendar rolledBackCalendar = new GregorianCalendar();
		rolledBackCalendar.setTime(rolledBackDate);
		
		Assert.assertEquals(rolledBackCalendar.get(Calendar.HOUR_OF_DAY), 0);
		Assert.assertEquals(rolledBackCalendar.get(Calendar.MINUTE), 0);
		Assert.assertEquals(rolledBackCalendar.get(Calendar.SECOND), 1);
	}

	@Test(groups = { "rollbacktostartofgrid-tests" })
	public void testRollBackToStartOfGridUnitNormalCase() {
		Integer gridUnitWidth = 30;

		Calendar unrolledBackCalendar = new GregorianCalendar();
		unrolledBackCalendar.set(Calendar.HOUR_OF_DAY, 4);
		unrolledBackCalendar.set(Calendar.MINUTE, 58);
		unrolledBackCalendar.set(Calendar.SECOND, 15);

		Date rolledBackDate = GridUtils.rollBackToStartOfGridUnit(unrolledBackCalendar.getTime(), gridUnitWidth);
		Calendar rolledBackCalendar = new GregorianCalendar();
		rolledBackCalendar.setTime(rolledBackDate);

		Assert.assertEquals(rolledBackCalendar.get(Calendar.HOUR_OF_DAY), 4);
		Assert.assertEquals(rolledBackCalendar.get(Calendar.MINUTE), 30);
		Assert.assertEquals(rolledBackCalendar.get(Calendar.SECOND), 1);
	}

	@Test(groups = { "rollbacktostartofgrid-tests" })
	public void testRollBackToStartOfGridUnitNormalCase2() {
		Integer gridUnitWidth = 120;

		Calendar unrolledBackCalendar = new GregorianCalendar();
		unrolledBackCalendar.set(Calendar.HOUR_OF_DAY, 3);
		unrolledBackCalendar.set(Calendar.MINUTE, 58);
		unrolledBackCalendar.set(Calendar.SECOND, 15);

		Date rolledBackDate = GridUtils.rollBackToStartOfGridUnit(unrolledBackCalendar.getTime(), gridUnitWidth);
		Calendar rolledBackCalendar = new GregorianCalendar();
		rolledBackCalendar.setTime(rolledBackDate);

		Assert.assertEquals(rolledBackCalendar.get(Calendar.HOUR_OF_DAY), 2);
		Assert.assertEquals(rolledBackCalendar.get(Calendar.MINUTE), 0);
		Assert.assertEquals(rolledBackCalendar.get(Calendar.SECOND), 1);
	}
	
	@Test(groups = { "rollbacktostartofgrid-tests" })
	public void testRollBackToStartOfGridUnitExceptionCase() {
		Integer gridUnitWidth = 121;

		Calendar unrolledBackCalendar = new GregorianCalendar();
		unrolledBackCalendar.set(Calendar.HOUR_OF_DAY, 3);
		unrolledBackCalendar.set(Calendar.MINUTE, 58);
		unrolledBackCalendar.set(Calendar.SECOND, 15);

		try {
			Date rolledBackDate = GridUtils.rollBackToStartOfGridUnit(unrolledBackCalendar.getTime(), gridUnitWidth);
			Assert.fail("Exception never thrown: " + (rolledBackDate != null ? rolledBackDate.toString() : ""));
		}
		catch (BadParameterException e) {
			Assert.assertTrue(true); // passed
		}
		catch (Exception e) {
			Assert.fail("Unexpected exception");
		}
	}

	@Test(groups = { "rollbacktostartofgrid-tests" })
	public void testRollBackMICEEdgeCase() {
		Integer gridUnitWidth = 30;

		Date date = new Date();
		date.setTime(1333985401000L); // 11:30:01 am America/New York - april 9th 2012

		Date rolledBackDate = GridUtils.rollBackToStartOfGridUnit(date, gridUnitWidth);
		Calendar rolledBackCalendar = new GregorianCalendar();
		rolledBackCalendar.setTime(rolledBackDate);
		rolledBackCalendar.setTimeZone(GridUtils.getTimeZone("UTC", "UTC"));

		Assert.assertEquals(rolledBackCalendar.get(Calendar.HOUR_OF_DAY), 15);
		Assert.assertEquals(rolledBackCalendar.get(Calendar.MINUTE), 30);
		Assert.assertEquals(rolledBackCalendar.get(Calendar.SECOND), 1);
	}

	@Test(groups = { "rollforwardtonextgrid-tests" })
	public void testRollForwardToNextGridUnitBeginningOfDayCase() {
		Integer gridUnitWidth = 120;

		Calendar unrolledForwardCalendar = new GregorianCalendar();
		unrolledForwardCalendar.set(Calendar.HOUR_OF_DAY, 1);
		unrolledForwardCalendar.set(Calendar.MINUTE, 58);
		unrolledForwardCalendar.set(Calendar.SECOND, 15);

		Date rolledForwardDate = GridUtils.rollForwardToNextGridUnit(unrolledForwardCalendar.getTime(), gridUnitWidth);
		Calendar rolledForwardCalendar = new GregorianCalendar();
		rolledForwardCalendar.setTime(rolledForwardDate);

		Assert.assertEquals(rolledForwardCalendar.get(Calendar.HOUR_OF_DAY), 2);
		Assert.assertEquals(rolledForwardCalendar.get(Calendar.MINUTE), 0);
		Assert.assertEquals(rolledForwardCalendar.get(Calendar.SECOND), 0);
	}

	@Test(groups = { "rollforwardtonextgrid-tests" })
	public void testRollForwardToNextGridUnitNormalCase() {
		Integer gridUnitWidth = 30;

		Calendar unrolledForwardCalendar = new GregorianCalendar();
		unrolledForwardCalendar.set(Calendar.HOUR_OF_DAY, 4);
		unrolledForwardCalendar.set(Calendar.MINUTE, 58);
		unrolledForwardCalendar.set(Calendar.SECOND, 15);

		Date rolledForwardDate = GridUtils.rollForwardToNextGridUnit(unrolledForwardCalendar.getTime(), gridUnitWidth);
		Calendar rolledForwardCalendar = new GregorianCalendar();
		rolledForwardCalendar.setTime(rolledForwardDate);

		Assert.assertEquals(rolledForwardCalendar.get(Calendar.HOUR_OF_DAY), 5);
		Assert.assertEquals(rolledForwardCalendar.get(Calendar.MINUTE), 0);
		Assert.assertEquals(rolledForwardCalendar.get(Calendar.SECOND), 0);
	}

	@Test(groups = { "rollforwardtonextgrid-tests" })
	public void testRollForwardToNextGridUnitNormalCase2() {
		Integer gridUnitWidth = 120;

		Calendar unrolledForwardCalendar = new GregorianCalendar();
		unrolledForwardCalendar.set(Calendar.HOUR_OF_DAY, 3);
		unrolledForwardCalendar.set(Calendar.MINUTE, 58);
		unrolledForwardCalendar.set(Calendar.SECOND, 15);

		Date rolledForwardDate = GridUtils.rollForwardToNextGridUnit(unrolledForwardCalendar.getTime(), gridUnitWidth);
		Calendar rolledForwardCalendar = new GregorianCalendar();
		rolledForwardCalendar.setTime(rolledForwardDate);

		Assert.assertEquals(rolledForwardCalendar.get(Calendar.HOUR_OF_DAY), 4);
		Assert.assertEquals(rolledForwardCalendar.get(Calendar.MINUTE), 0);
		Assert.assertEquals(rolledForwardCalendar.get(Calendar.SECOND), 0);
	}

	@Test(groups = { "rollforwardtonextgrid-tests" })
	public void testRollForwardToNextGridUnitExceptionCase() {
		Integer gridUnitWidth = 121;

		Calendar unrolledForwardCalendar = new GregorianCalendar();
		unrolledForwardCalendar.set(Calendar.HOUR_OF_DAY, 3);
		unrolledForwardCalendar.set(Calendar.MINUTE, 58);
		unrolledForwardCalendar.set(Calendar.SECOND, 15);

		try {
			Date rolledForwardDate = GridUtils.rollForwardToNextGridUnit(unrolledForwardCalendar.getTime(), gridUnitWidth);
			Assert.fail("Exception never thrown: " + (rolledForwardDate != null ? rolledForwardDate.toString() : ""));
		}
		catch (BadParameterException e) {
			Assert.assertTrue(true); // passed
		}
		catch (Exception e) {
			Assert.fail("Unexpected exception");
		}
	}

	@Test(groups = { "gettimezone-tests" })
	public void testGetTimeZoneNullParameter() {
		String defaultId = "UTC";
		TimeZone timeZone = GridUtils.getTimeZone(null, defaultId);
		Assert.assertEquals(timeZone.getID(), defaultId);
	}

	@Test(groups = { "gettimezone-tests" })
	public void testGetTimeZoneValidParameter() {
		String id = "America/Los_Angeles";
		String defaultId = "UTC";
		TimeZone timeZone = GridUtils.getTimeZone(id, defaultId);
		Assert.assertEquals(timeZone.getID(), id);
	}

	@Test(groups = { "gettimezone-tests" })
	public void testGetTimeZoneInvalidParameter() {
		String id = "DAVE ZONE!";
		String defaultId = "UTC";
		TimeZone timeZone = GridUtils.getTimeZone(id, defaultId);
		Assert.assertEquals(timeZone.getID(), defaultId);
	}

	@Test(groups = { "gettimezone-tests" })
	public void testGetTimeZoneGMTParameter() {
		String id = "GMT";
		String defaultId = "UTC";
		TimeZone timeZone = GridUtils.getTimeZone(id, defaultId);
		Assert.assertEquals(timeZone.getID(), id);
	}

	@Test(groups = { "gettime-tests" })
	public void testGetTimeAM() {
		int hour   = 9;
		int minute = 23;

		TimeZone timeZone = TimeZone.getTimeZone("America/Chicago");
		TimeZone utc = TimeZone.getTimeZone("UTC");

		Calendar calendar = new GregorianCalendar(utc);
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);

		String time = GridUtils.getTime(calendar.getTime(), timeZone);

		long converted = TimeUnit.MILLISECONDS.toHours(TimeUnit.HOURS.toMillis(hour) - TimeUnit.HOURS.toMillis(6));
		if (timeZone.inDaylightTime(new Date()))
			converted += 1;

		String expected = converted + ":" + minute + " AM";
		Assert.assertEquals(time, expected, "Time is " + time + ", but expected " + expected);
	}

	@Test(groups = { "gettime-tests" })
	public void testGetTimePM() {
		int hour   = 23;
		int minute = 23;

		TimeZone timeZone = TimeZone.getTimeZone("CST");
		TimeZone utc = TimeZone.getTimeZone("UTC");

		Calendar calendar = new GregorianCalendar(utc);
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);

		String time = GridUtils.getTime(calendar.getTime(), timeZone);

		long converted = TimeUnit.MILLISECONDS.toHours(TimeUnit.HOURS.toMillis(hour) - TimeUnit.HOURS.toMillis(6)) - 12;
		if (timeZone.inDaylightTime(new Date()))
			converted += 1;

		String expected = converted + ":" + minute + " PM";
		Assert.assertEquals(time, expected, "Time is " + time + ", but expected " + expected);
	}

	@Test(groups = { "gettime-tests" })
	public void testGetTimePMToAM() {
		int hour   = 11;
		int minute = 23;

		TimeZone timeZone = TimeZone.getTimeZone("America/Los_Angeles");
		TimeZone utc = TimeZone.getTimeZone("UTC");

		Calendar calendar = new GregorianCalendar(utc);
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);

		String time = GridUtils.getTime(calendar.getTime(), timeZone);

		long converted = TimeUnit.MILLISECONDS.toHours(TimeUnit.HOURS.toMillis(hour) - TimeUnit.HOURS.toMillis(8));
		if (timeZone.inDaylightTime(new Date()))
			converted += 1;

		String expected = converted + ":" + minute + " AM";
		Assert.assertEquals(time, expected, "Time is " + time + ", but expected " + expected);
	}

    @Test(groups = {"timeutil-tests"})
    public void testRoundDateDownToMinute() throws ParseException {
        DateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date d1 = dfm.parse("2011-12-13 07:00:01");
        Date dateExpected = dfm.parse("2011-12-13 07:00:00");
        Assert.assertEquals(GridUtils.roundDateDownToMinute(d1), dateExpected);

        Date d2 = dfm.parse("2011-12-13 07:00:00");
        Assert.assertEquals(GridUtils.roundDateDownToMinute(d2), dateExpected);

        Date d3 = dfm.parse("2011-12-13 07:15:48");
        dateExpected = dfm.parse("2011-12-13 07:15:00");
        Assert.assertEquals(GridUtils.roundDateDownToMinute(d3), dateExpected);
    }
}
