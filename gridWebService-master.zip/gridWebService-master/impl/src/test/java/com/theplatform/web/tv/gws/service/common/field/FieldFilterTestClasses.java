package com.theplatform.web.tv.gws.service.common.field;


import java.util.Collection;
import java.util.List;

public abstract class FieldFilterTestClasses {

    // primitives

    public static class Primitives {
        private int primitiveInt;
        private Integer objectInt;

        public int getPrimitiveInt() {
            return primitiveInt;
        }

        public void setPrimitiveInt(int primitiveInt) {
            this.primitiveInt = primitiveInt;
        }

        public Integer getObjectInt() {
            return objectInt;
        }

        public void setObjectInt(Integer objectInt) {
            this.objectInt = objectInt;
        }
    }

    public static class PrimitiveArray {
        private int[] primitiveArray;

        public int[] getPrimitiveArray() {
            return primitiveArray;
        }

        public void setPrimitiveArray(int[] primitiveArray) {
            this.primitiveArray = primitiveArray;
        }
    }


    // nested properties

    public static class Nested1 {
        private String nested1Prop;
        private Nested2 nested2;

        public String getNested1Prop() {
            return nested1Prop;
        }

        public void setNested1Prop(String nested1Prop) {
            this.nested1Prop = nested1Prop;
        }

        public Nested2 getNested2() {
            return nested2;
        }

        public void setNested2(Nested2 nested2) {
            this.nested2 = nested2;
        }
    }

    public static class Nested2 {
        private String nested2Prop;
        private Nested3 nested3;

        public String getNested2Prop() {
            return nested2Prop;
        }

        public void setNested2Prop(String nested2Prop) {
            this.nested2Prop = nested2Prop;
        }

        public Nested3 getNested3() {
            return nested3;
        }

        public void setNested3(Nested3 nested3) {
            this.nested3 = nested3;
        }
    }

    public static class Nested3 {
        private String nested3Prop;

        public String getNested3Prop() {
            return nested3Prop;
        }

        public void setNested3Prop(String nested3Prop) {
            this.nested3Prop = nested3Prop;
        }
    }




    public static class Collection1 {
        private List<String> stringList;

        private Collection<Item> itemCollection;
        private List<Item> itemList;

        private Collection2 collection2;
        private List<Collection2> collection2List;

        private Collection2[] collection2Array;

        public Collection<Item> getItemCollection() {
            return itemCollection;
        }

        public void setItemCollection(Collection<Item> itemCollection) {
            this.itemCollection = itemCollection;
        }

        public List<Item> getItemList() {
            return itemList;
        }

        public void setItemList(List<Item> itemList) {
            this.itemList = itemList;
        }

        public List<String> getStringList() {
            return stringList;
        }

        public void setStringList(List<String> stringList) {
            this.stringList = stringList;
        }

        public Collection2 getCollection2() {
            return collection2;
        }

        public void setCollection2(Collection2 collection2) {
            this.collection2 = collection2;
        }

        public List<Collection2> getCollection2List() {
            return collection2List;
        }

        public void setCollection2List(List<Collection2> collection2List) {
            this.collection2List = collection2List;
        }

        public Collection2[] getCollection2Array() {
            return collection2Array;
        }

        public void setCollection2Array(Collection2[] collection2Array) {
            this.collection2Array = collection2Array;
        }
    }

    public static class Collection2 {
        private String collection2Prop;
        private List<Item> itemList;
        private List<String> stringList;

        public String getCollection2Prop() {
            return collection2Prop;
        }

        public void setCollection2Prop(String collection2Prop) {
            this.collection2Prop = collection2Prop;
        }

        public List<Item> getItemList() {
            return itemList;
        }

        public void setItemList(List<Item> itemList) {
            this.itemList = itemList;
        }

        public List<String> getStringList() {
            return stringList;
        }

        public void setStringList(List<String> stringList) {
            this.stringList = stringList;
        }
    }

    public static class Item {
        private String itemProp;

        public Item(String itemProp) {
            this.itemProp = itemProp;
        }

        public String getItemProp() {
            return itemProp;
        }

        public void setItemProp(String itemProp) {
            this.itemProp = itemProp;
        }
    }



    public static class RootInheritance {
        private MarkerInterface interfaceObject;
        private Base baseObject;
        private Extension1 extension1;
        private Extension2 extension2;
        private List<Base> baseList;
        private List<MarkerInterface> interfaceList;

        public MarkerInterface getInterfaceObject() {
            return interfaceObject;
        }

        public void setInterfaceObject(MarkerInterface interfaceObject) {
            this.interfaceObject = interfaceObject;
        }

        public Base getBaseObject() {
            return baseObject;
        }

        public void setBaseObject(Base baseObject) {
            this.baseObject = baseObject;
        }

        public Extension1 getExtension1() {
            return extension1;
        }

        public void setExtension1(Extension1 extension1) {
            this.extension1 = extension1;
        }

        public Extension2 getExtension2() {
            return extension2;
        }

        public void setExtension2(Extension2 extension2) {
            this.extension2 = extension2;
        }

        public List<Base> getBaseList() {
            return baseList;
        }

        public void setBaseList(List<Base> baseList) {
            this.baseList = baseList;
        }

        public List<MarkerInterface> getInterfaceList() {
            return interfaceList;
        }

        public void setInterfaceList(List<MarkerInterface> interfaceList) {
            this.interfaceList = interfaceList;
        }
    }

    public interface MarkerInterface {
    }

    public static class Base {
        private Integer foo;

        public Integer getFoo() {
            return foo;
        }

        public void setFoo(Integer foo) {
            this.foo = foo;
        }
    }

    public static class Extension1 extends Base implements MarkerInterface {
        private String bar;

        public String getBar() {
            return bar;
        }

        public void setBar(String bar) {
            this.bar = bar;
        }
    }

    public static class Extension2 extends Extension1 {
        private String baz;

        public String getBaz() {
            return baz;
        }

        public void setBaz(String baz) {
            this.baz = baz;
        }
    }

    public static class Extension3 extends Extension1 {
        private String other;

        public String getOther() {
            return other;
        }

        public void setOther(String other) {
            this.other = other;
        }
    }
}
