package com.theplatform.web.tv.gws.service;


import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static com.theplatform.web.tv.gws.service.ContentResolutionInvokePhase.isVersionGreaterThanOrEqualRequiredSchema;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

/**
 * Created by jcoelho on 8/19/14.
 */
public class ContentResolutionInvokePhaseTest {
    Map<String,String> map = new HashMap<>();
    String serviceCR = "contentResolution";

    @BeforeMethod
    public void setup(){
        new HashMap<>();
        map.put(serviceCR, "1.10");
    }
    
    
    @Test
    public void testGreaterThan() {
        assertTrue(isVersionGreaterThanOrEqualRequiredSchema("1.10", serviceCR, map));
        assertTrue(isVersionGreaterThanOrEqualRequiredSchema("1.11", serviceCR, map));
        assertTrue(isVersionGreaterThanOrEqualRequiredSchema("1.12", serviceCR, map));
        assertTrue(isVersionGreaterThanOrEqualRequiredSchema("2.0", serviceCR, map));
        assertFalse(isVersionGreaterThanOrEqualRequiredSchema("1.9", serviceCR, map));
        assertFalse(isVersionGreaterThanOrEqualRequiredSchema("1.09", serviceCR, map));
        assertFalse(isVersionGreaterThanOrEqualRequiredSchema("1.1", serviceCR, map));
        assertFalse(isVersionGreaterThanOrEqualRequiredSchema("1.0", serviceCR, map));

    }

    @Test(expectedExceptions = RuntimeException.class)
    public void testInvalidSchermaVersion() {

        assertFalse(isVersionGreaterThanOrEqualRequiredSchema("1", serviceCR, map));
    }
}


