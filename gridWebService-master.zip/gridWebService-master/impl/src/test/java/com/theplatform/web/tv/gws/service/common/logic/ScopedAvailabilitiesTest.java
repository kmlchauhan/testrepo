package com.theplatform.web.tv.gws.service.common.logic;

import com.comcast.compass.availability.common.domain.Availabilities;
import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.List;

import static java.util.Arrays.asList;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

/**
 * Created by jcoelho on 6/19/13.
 */
public class ScopedAvailabilitiesTest {

	public static final Scope SCOPE_1 = Scope.CHANNEL;
	public static final Scope SCOPE_2 = Scope.STATION;
	public static final Scope SCOPE_3 = Scope.STREAM;

	private static final Scope SCOPE_FALSE = Scope.UNKNOWN;

	public static final URI PRODUCT_CONTEXT = URI.create("test:123");

	public static final URI AD_ZONE = URI.create("uri:test");
	public static final URI RECORDER_MANAGER = URI.create("uri:test");
	public static final URI DISTRIBUTION_MODE_ZONE = URI.create("uri:test");

	private static ScopedAvailabilities scopedAvailabilities;

	private static ScopedAvailabilities scopedAvailabilitiesWithNullAvailabilities;

	private static List<Availabilities> availablityGroups;

	private static Availabilities a1;

	static {
		a1 = new Availabilities(URI.create("test:123"), SCOPE_1.name());
		Availabilities a2 = new Availabilities(PRODUCT_CONTEXT, SCOPE_2.name());
		Availabilities a3 = new Availabilities(PRODUCT_CONTEXT, SCOPE_3.name());
		availablityGroups = asList(a1, a2, a3);

		scopedAvailabilities = ScopedAvailabilities.create(new AvailabilityResolution(availablityGroups, AD_ZONE, RECORDER_MANAGER, DISTRIBUTION_MODE_ZONE, null));
		scopedAvailabilitiesWithNullAvailabilities = ScopedAvailabilities.create(new AvailabilityResolution((List<Availabilities>) null, AD_ZONE, RECORDER_MANAGER, DISTRIBUTION_MODE_ZONE, null));
	}


	@Test
	public void availabilitiesGroupsHasScopeNullAvailabilities_expectFalse() {
	    assertFalse(scopedAvailabilitiesWithNullAvailabilities.hasScope(SCOPE_1));
	}

	@Test
	public void availabilitiesGroupsHasScope_expectTrue() {
	    assertTrue(scopedAvailabilities.hasScope(SCOPE_1));
	}

	@Test
	public void availabilitiesGroupsHasScope_expectFalse() {
	    assertFalse(scopedAvailabilities.hasScope(SCOPE_FALSE));
	}

	@Test
	public void filterByNonExistentScopeNullAvailabilityGroups_expectEmptyList() {
	    assertThat(ScopedAvailabilities.create(null).getByScope(SCOPE_1)).isEmpty();
	}

	@Test
	public void filterByScope_expectCorrectFilteredAvailabilityReturned() {
	    assertThat(scopedAvailabilities.getByScope(SCOPE_1)).containsOnly(a1);
	}

	@Test
	public void filterByNonExistentScope_expectEmptyList() {
	    assertThat(scopedAvailabilities.getByScope(SCOPE_FALSE)).isEmpty();
	}

}
