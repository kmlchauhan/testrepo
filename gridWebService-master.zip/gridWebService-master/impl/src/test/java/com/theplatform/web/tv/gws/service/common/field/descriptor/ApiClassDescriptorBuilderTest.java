package com.theplatform.web.tv.gws.service.common.field.descriptor;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonValue;
import com.theplatform.web.tv.gws.service.common.field.FieldFilteringException;
import org.apache.commons.collections4.CollectionUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

import static com.theplatform.web.tv.gws.service.common.field.FieldFilterTestClasses.*;
import static org.fest.assertions.api.Assertions.assertThat;

@SuppressWarnings("unused")
public class ApiClassDescriptorBuilderTest {

    // assertion helpers

    private ApiPropertyDescriptor assertSingleProperty(Class<?> clazz, String expectedProperty) {
        ApiClassDescriptor descriptor = new ApiClassDescriptorBuilder(clazz).build();
        assertThat(descriptor.getChildren()).hasSize(1);
        ApiPropertyDescriptor propertyDescriptor = CollectionUtils.extractSingleton(descriptor.getChildren());
        assertThat(propertyDescriptor.getPath()).isEqualTo(expectedProperty);
        return propertyDescriptor;
    }

    private ApiPropertyDescriptor assertChildProperty(List<ApiPropertyDescriptor> children, String propertyName) {
        assertThat(children).isNotEmpty();
        for (ApiPropertyDescriptor child : children) {
            if (propertyName.equals(child.getPath())) {
                return child;
            }
        }
        Assert.fail("Property " + propertyName + " is missing");
        return null;
    }

    private ApiPropertyDescriptor assertChildProperty(ApiClassDescriptor descriptor, String propertyName) {
        return assertChildProperty(descriptor.getChildren(), propertyName);
    }

    private ApiPropertyDescriptor assertChildProperty(ApiPropertyDescriptor descriptor, String propertyName) {
        return assertChildProperty(descriptor.getChildren(), propertyName);
    }

    // test primitives

    @Test
    public void testPrimitivesIgnored() {
        assertSingleProperty(Primitives.class, "objectInt");
    }

    @Test
    public void testPrimitiveArray() {
        assertSingleProperty(PrimitiveArray.class, "primitiveArray");
    }

    // test @JsonIgnore

    @Test
    public void testJsonIgnore() {
        assertSingleProperty(JsonIgnore1.class, "jsonIgnore2");
    }

    public static class JsonIgnore1 {
        private JsonIgnore2 jsonIgnore2;

        public JsonIgnore2 getJsonIgnore2() {
            return jsonIgnore2;
        }

        public void setJsonIgnore2(JsonIgnore2 jsonIgnore2) {
            this.jsonIgnore2 = jsonIgnore2;
        }
    }

    public static class JsonIgnore2 {
        private JsonIgnore1 jsonIgnore1;

        @JsonIgnore
        public JsonIgnore1 getJsonIgnore1() {
            return jsonIgnore1;
        }

        public void setJsonIgnore1(JsonIgnore1 jsonIgnore1) {
            this.jsonIgnore1 = jsonIgnore1;
        }
    }

    public static class JsonValueRoot {
        private JsonValueObject jsonValueObject;

        public JsonValueObject getJsonValueObject() {
            return jsonValueObject;
        }

        public void setJsonValueObject(JsonValueObject jsonValueObject) {
            this.jsonValueObject = jsonValueObject;
        }
    }

    // test @JsonValue

    @Test
    public void testJsonValue() {
        ApiPropertyDescriptor descriptor = assertSingleProperty(JsonValueRoot.class, "jsonValueObject");
        assertThat(descriptor.getChildren()).isEmpty();
    }

    public static class JsonValueObject {
        private String foo;
        private String bar;
        private OtherJsonValueObject other;

        @JsonValue
        public String getFoo() {
            return foo;
        }

        public void setFoo(String foo) {
            this.foo = foo;
        }

        public String getBar() {
            return bar;
        }

        public void setBar(String bar) {
            this.bar = bar;
        }

        public OtherJsonValueObject getOther() {
            return other;
        }

        public void setOther(OtherJsonValueObject other) {
            this.other = other;
        }
    }

    public static class OtherJsonValueObject {
        private String foo;

        public String getFoo() {
            return foo;
        }

        public void setFoo(String foo) {
            this.foo = foo;
        }
    }


    // infinite recursion

    @Test(expectedExceptions = FieldFilteringException.class)
    public void testInfiniteRecursionPrevented() {
        new ApiClassDescriptorBuilder(InfiniteRecursion1.class).build();
    }

    public static class InfiniteRecursion1 {
        private InfiniteRecursion2 recursion2;

        public InfiniteRecursion2 getRecursion2() {
            return recursion2;
        }

        public void setRecursion2(InfiniteRecursion2 recursion2) {
            this.recursion2 = recursion2;
        }
    }

    public static class InfiniteRecursion2 {
        private InfiniteRecursion1 recursion1;

        public InfiniteRecursion1 getRecursion1() {
            return recursion1;
        }

        public void setRecursion1(InfiniteRecursion1 recursion1) {
            this.recursion1 = recursion1;
        }
    }


    // nested properties

    @Test
    public void testNestedProperties() {
        ApiClassDescriptor root = new ApiClassDescriptorBuilder(Nested1.class).build();
        ApiPropertyDescriptor nested1Prop = assertChildProperty(root, "nested1Prop");
        assertThat(nested1Prop.getChildren()).isEmpty();
        ApiPropertyDescriptor nested2 = assertChildProperty(root, "nested2");

        ApiPropertyDescriptor nested2Prop = assertChildProperty(nested2, "nested2.nested2Prop");
        assertThat(nested2Prop.getChildren()).isEmpty();
        ApiPropertyDescriptor nested3 = assertChildProperty(nested2, "nested2.nested3");

        assertChildProperty(nested3, "nested2.nested3.nested3Prop");
    }


    // collections and nested collections

    @Test
    public void testCollections() {
        ApiClassDescriptor root = new ApiClassDescriptorBuilder(Collection1.class).build();

        ApiPropertyDescriptor stringList = assertChildProperty(root, "stringList");
        assertThat(stringList.isListType()).isTrue();
        assertThat(stringList.getChildren()).isEmpty();

        ApiPropertyDescriptor itemCollection = assertChildProperty(root, "itemCollection");
        assertThat(itemCollection.isCollectionType()).isTrue();
        assertThat(itemCollection.isListType()).isFalse();
        assertChildProperty(itemCollection, "itemCollection.itemProp");

        ApiPropertyDescriptor itemList = assertChildProperty(root, "itemList");
        assertThat(itemList.isCollectionType()).isTrue();
        assertThat(itemList.isListType()).isTrue();
        assertChildProperty(itemList, "itemList.itemProp");

        ApiPropertyDescriptor collection2 = assertCollection2Props("collection2", root);
        assertThat(collection2.isCollectionType()).isFalse();

        ApiPropertyDescriptor collection2List = assertCollection2Props("collection2List", root);
        assertThat(collection2List.isCollectionType()).isTrue();

        ApiPropertyDescriptor collection2Array = assertCollection2Props("collection2Array", root);
        assertThat(collection2Array.isArrayType()).isTrue();
    }

    private ApiPropertyDescriptor assertCollection2Props(String basePath, ApiClassDescriptor root) {
        ApiPropertyDescriptor collection2 = assertChildProperty(root, basePath);
        assertChildProperty(collection2, basePath + ".collection2Prop");

        ApiPropertyDescriptor itemList = assertChildProperty(collection2, basePath + ".itemList");
        assertThat(itemList.isCollectionType()).isTrue();
        assertThat(itemList.isListType()).isTrue();

        ApiPropertyDescriptor itemProp = assertChildProperty(itemList, basePath + ".itemList.itemProp");
        assertThat(itemProp.isCollectionType()).isFalse();

        ApiPropertyDescriptor stringList = assertChildProperty(collection2, basePath + ".stringList");
        assertThat(stringList.isCollectionType()).isTrue();
        assertThat(stringList.isListType()).isTrue();
        assertThat(stringList.getChildren()).isEmpty();

        return collection2;
    }


    // inheritance

    @Test
    public void testSimpleInheritance() {
        ApiClassDescriptor descriptor = new ApiClassDescriptorBuilder(Extension1.class).build();
        assertChildProperty(descriptor, "foo");
        assertChildProperty(descriptor, "bar");
    }

    @Test
    public void testPropertyInheritance() {
        ApiClassDescriptor descriptor = new ApiClassDescriptorBuilder(RootInheritance.class).build();

        ApiPropertyDescriptor interfaceObject = assertChildProperty(descriptor, "interfaceObject");
        assertThat(interfaceObject.getSubTypes().keySet()).contains(Extension1.class, Extension2.class);

        ApiPropertyDescriptor baseList = assertChildProperty(descriptor, "baseList");
        assertChildProperty(baseList, "baseList.foo");

        assertThat(baseList.getSubTypes()).hasSize(3);
        ApiPropertyDescriptor extension1 = baseList.getSubTypes().get(Extension1.class);
        assertThat(extension1.getSubTypes()).isEmpty();
        assertChildProperty(extension1, "baseList.foo");

        ApiPropertyDescriptor extension2 = baseList.getSubTypes().get(Extension2.class);
        assertThat(extension2.getSubTypes()).isEmpty();
        assertChildProperty(extension2, "baseList.foo");
        assertChildProperty(extension2, "baseList.bar");
        assertChildProperty(extension2, "baseList.baz");

        ApiPropertyDescriptor interfaceList = assertChildProperty(descriptor, "interfaceList");
        assertThat(interfaceList.getSubTypes()).hasSize(3);
    }
}
