package com.theplatform.web.tv.gws.sirius.converter;


import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSTag;
import org.testng.annotations.Test;

import java.net.URI;

import static com.theplatform.data.tv.entity.api.data.objects.TagType.Station;
import static org.testng.Assert.assertEquals;

/**
 * @author jcoelho
 * @since 6/18/15.
 */
public class TagConverterTest {

    @Test(expectedExceptions = RuntimeException.class)
    public void emptyTag_expectValidationException() {
        TagConverter tagConverter = new TagConverter();
        Tag tag = new Tag();
        tagConverter.convert(tag);
    }

    @Test
    public void expectCorrectTagConversion() {
        SiriusObjectTypeTestUtil.unitTestInitialization();

        TagConverter tagConverter = new TagConverter();
        Tag tag = new Tag();
        tag.setId(URI.create("http://uri/123"));
        tag.setType("Station");
        tag.setTitle("Adult");
        CRSTag convert = tagConverter.convert(tag);

        assertEquals(convert.getId(), 123L);
        assertEquals(convert.getType(), Station);
        assertEquals(convert.getTitle(), "Adult");
    }
}
