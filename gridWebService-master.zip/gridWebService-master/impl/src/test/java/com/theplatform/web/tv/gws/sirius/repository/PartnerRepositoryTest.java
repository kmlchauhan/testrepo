package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSPartner;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class PartnerRepositoryTest {
    private PartnerRepository partnerRepository;

    private long COMCAST_OWNER_ID = 55555L;
    private long TARGET_OWNER_ID  = 99999L;


    @BeforeClass
    public void init(){
        SiriusObjectTypeTestUtil.unitTestInitialization();
    }

    @BeforeMethod
    public void initMethod(){
        partnerRepository = new PartnerRepository(SiriusObjectType.fromFriendlyName("Partner"), COMCAST_OWNER_ID);
    }

    @Test
    public void comcastTest() {
        long comcastPartnerId = 20000191;

        // Comcast Partner
        CRSPartner crsComcastPartner = new CRSPartner();
        crsComcastPartner.setId(20000191);
        crsComcastPartner.setParentPartnerId(null);
        crsComcastPartner.setInternalAccountId(COMCAST_OWNER_ID);
        partnerRepository.put(crsComcastPartner);

        Assert.assertFalse(partnerRepository.isComcastOwnerId(TARGET_OWNER_ID));
        Assert.assertTrue(partnerRepository.isComcastOwnerId(COMCAST_OWNER_ID));
    }

    @Test
    public void orphanedReferenceTest() {
        PartnerRepository partnerRepository = new PartnerRepository(SiriusObjectType.fromFriendlyName("Partner"), COMCAST_OWNER_ID);

        long partnerId = 10000191;
        long comcastPartnerId = 20000191;

        // Orphaned
        CRSPartner crsPartner = new CRSPartner();
        crsPartner.setId(partnerId);
        crsPartner.setInternalAccountId(TARGET_OWNER_ID);
        crsPartner.setParentPartnerId(comcastPartnerId);
        partnerRepository.put(crsPartner);

        Assert.assertFalse(partnerRepository.isComcastOwnerId(TARGET_OWNER_ID));

        // Add Comcast Partner
        CRSPartner crsComcastPartner = new CRSPartner();
        crsComcastPartner.setId(20000191);
        crsComcastPartner.setParentPartnerId(null);
        crsComcastPartner.setInternalAccountId(COMCAST_OWNER_ID);
        partnerRepository.put(crsComcastPartner);
        Assert.assertTrue(partnerRepository.isComcastOwnerId(TARGET_OWNER_ID));

        // Delete Comcast Partner
        partnerRepository.delete(crsComcastPartner.getId());
        Assert.assertFalse(partnerRepository.isComcastOwnerId(TARGET_OWNER_ID));

    }

    @Test
    public void multipleReferencesTest() {
        PartnerRepository partnerRepository = new PartnerRepository(SiriusObjectType.fromFriendlyName("Partner"), COMCAST_OWNER_ID);

        long partnerId = 10000191;
        long middlePartnerId = 30000191;
        long comcastPartnerId = 20000191;

        // Add Comcast Partner
        CRSPartner crsComcastPartner = new CRSPartner();
        crsComcastPartner.setId(comcastPartnerId);
        crsComcastPartner.setParentPartnerId(null);
        crsComcastPartner.setInternalAccountId(COMCAST_OWNER_ID);
        partnerRepository.put(crsComcastPartner);

        // Target
        CRSPartner crsPartner = new CRSPartner();
        crsPartner.setId(partnerId);
        crsPartner.setInternalAccountId(TARGET_OWNER_ID);
        crsPartner.setParentPartnerId(middlePartnerId);
        partnerRepository.put(crsPartner);

        Assert.assertFalse(partnerRepository.isComcastOwnerId(TARGET_OWNER_ID));

        // Middle
        CRSPartner crsMiddlePartner = new CRSPartner();
        crsMiddlePartner.setId(middlePartnerId);
        crsMiddlePartner.setInternalAccountId(7777L);
        crsMiddlePartner.setParentPartnerId(comcastPartnerId);
        partnerRepository.put(crsMiddlePartner);

        Assert.assertTrue(partnerRepository.isComcastOwnerId(TARGET_OWNER_ID));

        // Delete the middle Partner
        partnerRepository.delete(crsMiddlePartner.getId());

        Assert.assertFalse(partnerRepository.isComcastOwnerId(TARGET_OWNER_ID));

    }

}