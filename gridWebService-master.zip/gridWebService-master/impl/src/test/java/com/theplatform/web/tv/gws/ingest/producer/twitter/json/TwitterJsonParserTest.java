package com.theplatform.web.tv.gws.ingest.producer.twitter.json;


import org.apache.commons.io.IOUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import static org.testng.Assert.assertEquals;


public class TwitterJsonParserTest {

    public TwitterTrendingResponse  createTwitterTrendingResponse() {
        AlternateIdSource rovi = AlternateIdSource.register( "Rovi1.1", "TVGUIDE");
        AlternateIdSource tms = AlternateIdSource.register( "Tms", "TMS");

        TwitterItem faCupSoccer = new TwitterItem();
        faCupSoccer.setTweetCount(162566);
        faCupSoccer.getAlternateIds().put( rovi, "26248194");
        faCupSoccer.getAlternateIds().put( tms, "EP008965610547");
        faCupSoccer.setTitle("Bolton vs. Liverpool FC");
        faCupSoccer.setShowTitle("FA Cup Soccer");

        TwitterItem espnSigningDay = new TwitterItem();
        espnSigningDay.setTweetCount(99582);
        espnSigningDay.getAlternateIds().put( tms, "EP015407950001");
        espnSigningDay.setTitle("ESPNU National Signing Day Special");
        espnSigningDay.setShowTitle("ESPNU Signing Day Special");

        TwitterItem howIMetYourMother = new TwitterItem();
        howIMetYourMother.setTweetCount(14);
        howIMetYourMother.getAlternateIds().put( rovi, "23491060");
        howIMetYourMother.getAlternateIds().put( tms, "EP007537960216");
        howIMetYourMother.setTitle("Rally");
        howIMetYourMother.setShowTitle("How I Met Your Mother");

        TwitterTrendingResponse expected = new TwitterTrendingResponse();
        expected.addItem(faCupSoccer);
        expected.addItem(espnSigningDay);
        expected.addItem(howIMetYourMother);
        return expected;
    }

    @Test
    public void testParseTrendingResponse() throws IOException, TwitterJsonException {
        TwitterTrendingResponse expected = createTwitterTrendingResponse();

        try (InputStream stream = this.getClass().getClassLoader().getResourceAsStream("twitter/twitter.json")) {
            String json = IOUtils.toString(stream);

            TwitterJsonParser parser = new TwitterJsonParser();
            TwitterTrendingResponse actualResponse = parser.parseTrendingResponse(json);

            Assert.assertEquals(actualResponse.getItems().toArray(), expected.getItems().toArray());
        }
    }

    @Test(expectedExceptions = TwitterJsonException.class)
    public void testParseTrendingResponse_malformedDoc() throws TwitterJsonException {
        TwitterJsonParser parser = new TwitterJsonParser();
        parser.parseTrendingResponse("{foo : }");
    }

    @Test(expectedExceptions = TwitterJsonException.class)
    public void testParseTrendingResponse_missingItems() throws TwitterJsonException {
        TwitterJsonParser parser = new TwitterJsonParser();
        parser.parseTrendingResponse("{}");
    }

    @Test(expectedExceptions = TwitterJsonException.class)
    public void testParseTrendingResponse_emptyItems() throws TwitterJsonException {
        TwitterJsonParser parser = new TwitterJsonParser();
        parser.parseTrendingResponse("{ items: {} }");
    }

    @Test
    public void testParseTrendingResponse_missingRequiredAttribues() throws TwitterJsonException, IOException {
        // test that none of these are parsed into TwitterItems.  each item in this file is missing something that
        // should cause it to be skipped.

        try (InputStream stream = this.getClass().getClassLoader().getResourceAsStream("twitter/twitter_missingRequiredAttrs.json")) {
            String json = IOUtils.toString(stream);

            TwitterJsonParser parser = new TwitterJsonParser();
            TwitterTrendingResponse actualResponse = parser.parseTrendingResponse(json);

            assertEquals(actualResponse.size(), 0);
        }
    }

    @Test
    public void testParseAuthResponse() throws TwitterJsonException {
        String authResponse = "{\"token_type\": \"bearer\", \"access_token\": \"foo\"}";

        TwitterJsonParser parser = new TwitterJsonParser();
        String bearerToken = parser.parseAuthResponse(authResponse);

        assertEquals(bearerToken, "foo");
    }

    @Test(expectedExceptions = TwitterJsonException.class)
    public void testParseAuthResponse_nonBearerType() throws TwitterJsonException {
        String authResponse = "{\"token_type\": \"xxxxxxx\", \"access_token\": \"foo\"}";

        TwitterJsonParser parser = new TwitterJsonParser();
        parser.parseAuthResponse(authResponse);
    }

    @Test
    public void testParseErrorsResponse() {
        String json = "{\"errors\":[{\"code\":99,\"label\":\"authenticity_token_error\",\"message\":\"Unable to verify your credentials\"}]}";

        TwitterError expected = new TwitterError();
        expected.setCode(99);
        expected.setMessage("Unable to verify your credentials");
        expected.setLabel("authenticity_token_error");

        TwitterJsonParser parser = new TwitterJsonParser();
        List<TwitterError> errors = parser.parseErrorsResponse(json);

        assertEquals(errors.size(), 1);
        assertEquals(errors.get(0), expected);

        // make sure it doesn't blow up on invalid input
        List<TwitterError> empty = parser.parseErrorsResponse(null);
        assertEquals(empty.size(), 0);

        // make sure it dosn't blow up on invalid input
        List<TwitterError> invalid = parser.parseErrorsResponse("{{{{:");
        assertEquals(invalid.size(), 0);
    }
}
