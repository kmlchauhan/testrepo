package com.theplatform.web.tv.gws.service.common.converter;

import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.google.common.collect.Sets;
import com.theplatform.web.tv.contentresolution.api.objects.LocatorInfo;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.sirius.repository.ChannelRepository;
import com.theplatform.web.tv.gws.sirius.repository.CompanyRepository;
import com.theplatform.web.tv.gws.sirius.repository.LocatorRepository;
import com.theplatform.web.tv.gws.sirius.repository.StationCompanyRepository;
import com.theplatform.web.tv.gws.uri.IdForm;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.mockito.Mockito;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.theplatform.data.tv.linear.api.data.objects.LocatorType.OnDemand;

public class CRSLocatorToLocatorInfoConverterTest {
    public static final String LINEAR_BASE_URL = "http://test.com/linearDataService";
    public static final String BASE_URI = LINEAR_BASE_URL + "/data/";

    public String VOD_LOCATOR_DEFAULT_URL ="xre:///guide/on_demand/?focus=menu&menu=Movies";
    public String VOD_LOCATOR_BASE_URL ="xre:///guide/on_demand/networks/company?availabilityMode=onVideo&";


    private static final Long CHANNEL_ID = 100104l;
    private static final Long STATION_ID = 100117l;
    private static final Long STREAM_ID = 456163L;
    private static final Long OTHER_STREAM_ID = 789163L;
    private static final Long LOCATOR_ID_1 = 123162L;
    private static final Long LOCATOR_ID_2 = 456162L;
    private static final Long COMPANY_ID = 700105L;

    public static final long BITRATE = 123L;
    public static final String CODEC = "codec";
    public static final String FORMAT = "format";
    public static final int HEIGHT = 12345;
    public static final int WIDTH = 5432;
    public static final String PROTECTION_SCHEME = "protectionScheme";

    private static int idCount = 0;
    private static final long ownerId = 8086;


    private MerlinIdHelper merlinIdHelper = MerlinIdHelper.withDefaultIdForm(null,LINEAR_BASE_URL,null, null, null, IdForm.URN);

    private CRSLocatorToLocatorInfoConverter converter;
    private ChannelRepository channelRepository;
    private LongObjectRepository<CRSStation> stationRepository;
    private LocatorRepository locatorRepository;
    private CompanyRepository companyRepository;

    @BeforeMethod
    public void setup(){
        SiriusObjectTypeTestUtil.unitTestInitialization();

        channelRepository = Mockito.mock(ChannelRepository.class);
        Mockito.when(channelRepository.get(Mockito.anyLong())).thenReturn(null);

        stationRepository = Mockito.mock(LongObjectRepository.class);
        Mockito.when(stationRepository.get(Mockito.anyLong())).thenReturn(null);

        locatorRepository = Mockito.mock(LocatorRepository.class);
        Mockito.when(locatorRepository.getOnDemandLocators(Mockito.anyLong(),Mockito.anyLong())).thenReturn(null);

        companyRepository = Mockito.mock(CompanyRepository.class);
        Mockito.when(companyRepository.get(Mockito.anyLong())).thenReturn(null);

        converter = new CRSLocatorToLocatorInfoConverter();
        converter.setChannelRepository(channelRepository);
        converter.setStationRepository(stationRepository);
        converter.setLocatorRepository(locatorRepository);
        converter.setDefaultVodLocatorUrl(VOD_LOCATOR_DEFAULT_URL);
        converter.setVodLocatorUrl(VOD_LOCATOR_BASE_URL);
        converter.setCompanyRepository(companyRepository);
        converter.setMerlinIdHelper(merlinIdHelper);
    }

    @Test
    public void getIPLocatorsTest(){
        List<CRSLocator> locatorsFirst = createCRSLocators(2);

        List<CRSLocator> locatorsSecond = createCRSLocators(2);

        Mockito.when(locatorRepository.getIPLocators(ownerId, STREAM_ID)).thenReturn( Sets.newHashSet(locatorsFirst));
        Mockito.when(locatorRepository.getIPLocators(ownerId, OTHER_STREAM_ID)).thenReturn(Sets.newHashSet(locatorsSecond) );

        CRSStream crsStream = new CRSStream();
        crsStream.setId(STREAM_ID);;
        crsStream.setOwnerId(ownerId);

        List<LocatorInfo> actualLocators = converter.getIpLocators(crsStream);

        Assert.assertEquals( actualLocators.size(), locatorsFirst.size());
        for (LocatorInfo locatorInfo: actualLocators ){
            boolean success = false;
            for (CRSLocator crsLocator: locatorsFirst){
                if (locatorInfo.getLocatorUri().toString().equals(crsLocator.getLocatorURI())){
                    success = true;
                    break;
                }
            }
            if (!success) Assert.fail("IP Locators returned are not correct");
        }
    }

    @Test
    public void getOnDemandLocatorTest(){
        List<CRSLocator> locators = createCRSLocators(3);
        CRSStation crsStation = new CRSStation();
        crsStation.setId(STATION_ID);
        crsStation.setVod(false);

        // Mock StationCompany
        StationCompanyRepository mockStationCompanyRepository = Mockito.mock(StationCompanyRepository.class);
        converter.setStationCompanyRepository(mockStationCompanyRepository);

        // No OnDemand
        Mockito.when(stationRepository.get(STATION_ID)).thenReturn(crsStation);
        LocatorInfo locatorInfo = converter.getOnDemandLocator(STATION_ID, ownerId);
        Assert.assertNull(locatorInfo);

        crsStation.setVod(true);

        // OnDemand Value - Default Value - Default URL
        locatorInfo = converter.getOnDemandLocator(STATION_ID, ownerId);
        Assert.assertEquals( locatorInfo.getLocatorUri().toString(), VOD_LOCATOR_DEFAULT_URL);
        Assert.assertEquals( locatorInfo.getFormat(), "OnDemand");

        // Set StationCompany
        CRSStationCompany crsStationCompany = new CRSStationCompany(10_000);
        crsStationCompany.setCompanyId( COMPANY_ID);
        List<CRSStationCompany> listStationCompany = new ArrayList<>();
        listStationCompany.add(crsStationCompany);
        Mockito.when(mockStationCompanyRepository.getStationCompanyByStationId(STATION_ID)).thenReturn(listStationCompany);

        // OnDemand Value - Default Value - Generated using the Associated Company Name and Company Id using StationCompany
        String companyDisplayName = "FOOBAR";
        crsStation.setVod(true);
        CRSCompany crsCompany = new CRSCompany();
        crsCompany.setDisplayName(companyDisplayName);
        crsCompany.setId(COMPANY_ID);
        Mockito.when(companyRepository.get(COMPANY_ID)).thenReturn(crsCompany);
        locatorInfo = converter.getOnDemandLocator(STATION_ID, ownerId);
        URI expectedLocatorURI = URI.create(String.format("%scompanyName=%s&companyId=%s", VOD_LOCATOR_BASE_URL, companyDisplayName, COMPANY_ID));
        Assert.assertEquals( locatorInfo.getLocatorUri().toString(), expectedLocatorURI.toString());
        Assert.assertEquals( locatorInfo.getFormat(), "OnDemand");

        // OnDemand Value -
        crsStation.setVod(true);
        locators.get(1).setFormat(OnDemand.toString());
        Mockito.when(locatorRepository.getOnDemandLocators( ownerId, STATION_ID)).thenReturn(Sets.newHashSet(locators.get(1)));
        locatorInfo = converter.getOnDemandLocator(STATION_ID, ownerId);
        Assert.assertEquals( locators.get(1).getLocatorURI(), locatorInfo.getLocatorUri().toString());
        Assert.assertEquals( locators.get(1).getFormat(), "OnDemand");

    }


    @Test
    public void getQAMLocatorTest(){
        CRSStation crsStation = new CRSStation();
        crsStation.setId(STATION_ID);
        crsStation.setDigicableId(0);
        Mockito.when(stationRepository.get(STATION_ID)).thenReturn(crsStation);

        CRSChannel crsChannel = new CRSChannel();
        crsChannel.setId(CHANNEL_ID);
        crsChannel.setStationId(STATION_ID);
        crsChannel.setDigicableId(0);
        Mockito.when(channelRepository.get(CHANNEL_ID)).thenReturn(crsChannel);
        LocatorInfo locatorInfo = converter.getQAMLocator(CHANNEL_ID,STATION_ID);
        Assert.assertNull(locatorInfo);

        crsStation.setDigicableId(100);
        locatorInfo = converter.getQAMLocator(CHANNEL_ID,STATION_ID);
        Assert.assertEquals( locatorInfo.getFormat(), "QAM");
        validateQamUri( 100l, locatorInfo );

        crsChannel.setDigicableId(200);
        locatorInfo = converter.getQAMLocator(CHANNEL_ID,STATION_ID);
        Assert.assertEquals( locatorInfo.getFormat(), "QAM");
        validateQamUri( 200l, locatorInfo );

    }

    @Test
    public void getStationQAMLocatorTest(){
        CRSStation crsStation = new CRSStation();
        crsStation.setId(STATION_ID);
        crsStation.setDigicableId(0);

        // No digicable
        Mockito.when(stationRepository.get(STATION_ID)).thenReturn(crsStation);
        LocatorInfo locatorInfo = converter.getStationQAMLocator(STATION_ID);
        Assert.assertNull(locatorInfo);

        // digicable value
        crsStation.setDigicableId(100);
        locatorInfo = converter.getStationQAMLocator(STATION_ID);
        Assert.assertEquals( locatorInfo.getFormat(), "QAM");
        validateQamUri( 100l, locatorInfo );
    }

    @Test
    public void getChannelQAMLocatorTest(){
        CRSChannel crsChannel = new CRSChannel();
        crsChannel.setId(CHANNEL_ID);
        crsChannel.setDigicableId(0);

        // No digicable
        Mockito.when(channelRepository.get(CHANNEL_ID)).thenReturn(crsChannel);
        LocatorInfo locatorInfo = converter.getStationQAMLocator(CHANNEL_ID);
        Assert.assertNull(locatorInfo);

        // digicable value
        crsChannel.setDigicableId(100);
        locatorInfo = converter.getChannelQAMLocator(CHANNEL_ID);
        Assert.assertEquals( locatorInfo.getFormat(), "QAM");
        validateQamUri( 100l, locatorInfo );

    }

    protected static void assertEquals( List<LocatorInfo> mainLocatorInfos, List<CRSLocator> crsLocators){
        Assert.assertEquals(mainLocatorInfos.size(), crsLocators.size());
        HashMap<String,LocatorInfo> mapLocatorInfo = new HashMap<>();
        for (LocatorInfo locatorInfo : mainLocatorInfos){
            mapLocatorInfo.put( locatorInfo.getLocatorUri().toString(), locatorInfo);
        }
        for (CRSLocator crsLocator : crsLocators){
            LocatorInfo locatorInfo = mapLocatorInfo.get(crsLocator.getLocatorURI());
            Assert.assertNotNull(locatorInfo);
            assertEquals( locatorInfo, crsLocator);
        }
    }

    protected static void assertEquals( LocatorInfo locatorInfo, CRSLocator crsLocator){
        Assert.assertEquals( locatorInfo.getLocatorUri().toString(), crsLocator.getLocatorURI());
        Assert.assertEquals( locatorInfo.getBitrate(), new Long(crsLocator.getBitrate()));
        Assert.assertEquals( locatorInfo.getCodec(), crsLocator.getCodec());
        Assert.assertEquals( locatorInfo.getFormat(), crsLocator.getFormat());
        Assert.assertEquals( locatorInfo.getHeight(), new Integer(crsLocator.getHeight()));
        Assert.assertEquals( locatorInfo.getWidth(), new Integer(crsLocator.getWidth()));
        Assert.assertEquals( locatorInfo.getProtectionScheme(), crsLocator.getProtectionScheme());
    }


    protected static List<CRSLocator> createCRSLocators(int count){
        List<CRSLocator> locators = new ArrayList<>(count);
        for (int i=0; i<count; i++){
            locators.add(createCRSLocator());
        }
        return locators;
    }

    protected static CRSLocator createCRSLocator(){
        CRSLocator loc = new CRSLocator();
        idCount++;
        loc.setId(idCount);
        loc.setLocatorURI("http://link.xcal.tv/" + idCount);
        loc.setDigicableId(idCount);
        loc.setWidth(WIDTH);
        loc.setHeight(HEIGHT);
        loc.setProtectionScheme(PROTECTION_SCHEME);
        loc.setFormat(FORMAT);
        loc.setCodec(CODEC);
        loc.setBitrate(BITRATE);
        return loc;
    }

    private void validateQamUri(Long expectedDigi, LocatorInfo actualLocatorInfo){
        URI expectedUri = URI.create("ocap://0x" + Long.toHexString(expectedDigi));
        Assert.assertEquals(actualLocatorInfo.getLocatorUri().toUri(), expectedUri);
    }

}



