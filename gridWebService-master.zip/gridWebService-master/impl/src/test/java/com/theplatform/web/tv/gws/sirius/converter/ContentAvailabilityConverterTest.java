package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.model.*;
import com.theplatform.contrib.data.api.objects.ContentId;
import com.theplatform.contrib.data.api.objects.ContentIdType;
import com.theplatform.data.tv.offer.api.data.objects.ContentAvailability;
import com.theplatform.web.tv.gws.sirius.repository.utils.*;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.*;

/**
 * @author jcoelho
 * @since 11/21/14.
 */
public class ContentAvailabilityConverterTest {

    public static final URI ID_URI = URI.create("http://test/123");
    ContentAvailabilityConverter contentAvailabilityConverter ;

    public ContentAvailabilityConverterTest() {
        contentAvailabilityConverter = new ContentAvailabilityConverter();
        contentAvailabilityConverter.setProductContextCanonicalIdsFactory(new CanonicalIdsFactory());
    }

    @Test
    public void convertNull_expectNull() {
        Assert.assertNull(contentAvailabilityConverter.convert(null));
    }

    @Test(expectedExceptions = IllegalArgumentException.class)
    public void convertEmptyObject_expectIllegalArgumentException() {
        Assert.assertNull(contentAvailabilityConverter.convert(new ContentAvailability()));
    }

    @Test
    public void convertContentAvailabilityWithNoContentType_expectCorrectConversion() {
        ContentAvailability contentAvailability = new ContentAvailability();
        contentAvailability.setContentId(new ContentId());
        Assert.assertNull(contentAvailabilityConverter.convert(contentAvailability));
    }

    @Test
    public void convertContentAvailability_expectCorrectConversion() {
        SiriusObjectType.registerNonMerlinObjectType("ContentAvailability");
        ContentAvailability contentAvailability = new ContentAvailability();
        contentAvailability.setProductContexts(new HashSet());
        contentAvailability.setId(ID_URI);
        contentAvailability.setAvailabilityId(ID_URI);
        ContentId contentId = new ContentId();
        contentId.setId(ID_URI);
        contentId.setType(ContentIdType.Stream);
        contentAvailability.setContentId(contentId);
        contentAvailability.setOwnerId(ID_URI);
        Assert.assertNotNull(contentAvailabilityConverter.convert(contentAvailability));
    }
}
