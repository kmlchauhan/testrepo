package com.theplatform.web.tv.gws.sirius.repository.utils;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Set;

public class JdkCollectionsCompositeKeySecondaryIndexTest {
    JdkCollectionsCompositeKeySecondaryIndex<Integer,Integer,Integer> compositeKeySecondaryIndex ;

    @BeforeMethod
    private void setup() {
        compositeKeySecondaryIndex = new JdkCollectionsCompositeKeySecondaryIndex<>();
        compositeKeySecondaryIndex.put(100,101,111);
        compositeKeySecondaryIndex.put(100,101,222);
        compositeKeySecondaryIndex.put(200,101,333);
        compositeKeySecondaryIndex.put(100,201,444);
        compositeKeySecondaryIndex.put(100,201,555);
        compositeKeySecondaryIndex.put(100,201,111);
    }

    @Test
    public void testPut() throws Exception {
        Set vals = compositeKeySecondaryIndex.getByIndexKey(200,101);
        Assert.assertEquals(vals.size(), 1);
        compositeKeySecondaryIndex.put(200,101,444);
        vals = compositeKeySecondaryIndex.getByIndexKey(200,101);
        Assert.assertEquals(vals.size(),2);
        Assert.assertTrue(vals.contains(333));
        Assert.assertTrue(vals.contains(444));
        // Put the same value should have no impact
        compositeKeySecondaryIndex.put(200,101,444);
        Assert.assertEquals(vals.size(),2);
        Assert.assertTrue(vals.contains(333));
        Assert.assertTrue(vals.contains(444));
    }

    @Test
    public void testRemove() throws Exception {
        Set vals = compositeKeySecondaryIndex.getByIndexKey(100,201);
        Assert.assertEquals(vals.size(),3);
        Assert.assertTrue(vals.contains(444));
        Assert.assertTrue(vals.contains(555));
        Assert.assertTrue(vals.contains(111));
        compositeKeySecondaryIndex.remove(100,201,555);
        Assert.assertEquals(vals.size(),2);
        Assert.assertTrue(vals.contains(444));
        Assert.assertTrue(vals.contains(111));
        // Removing a nonexistant value should have no impact
        compositeKeySecondaryIndex.remove(100,201,999);
        Assert.assertEquals(vals.size(),2);
        Assert.assertTrue(vals.contains(444));
        Assert.assertTrue(vals.contains(111));
    }

    @Test
    public void testRemoveAll() throws Exception {
        Assert.assertEquals(compositeKeySecondaryIndex.getByIndexKey(100,101).size(),2);
        Assert.assertEquals(compositeKeySecondaryIndex.getByIndexKey(200,101).size(),1);
        Assert.assertEquals(compositeKeySecondaryIndex.getByIndexKey(100,201).size(),3);
        compositeKeySecondaryIndex.removeAll(100, 201);
        Assert.assertEquals(compositeKeySecondaryIndex.getByIndexKey(100,101).size(),2);
        Assert.assertEquals(compositeKeySecondaryIndex.getByIndexKey(200, 101).size(), 1);
        Assert.assertEquals(compositeKeySecondaryIndex.getByIndexKey(100,201).size(),0);
    }

    @Test
    public void testGetByIndexKey() throws Exception {
        Set vals = compositeKeySecondaryIndex.getByIndexKey(100,101);
        Assert.assertEquals(vals.size(),2);
        Assert.assertTrue(vals.contains(111));
        Assert.assertTrue(vals.contains(222));
    }
}
