package com.theplatform.web.tv.gws.ingest.dispatcher.serialization;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.sirius.model.CRSLocator;
import com.theplatform.web.tv.gws.sirius.model.CRSStation;
import com.theplatform.web.tv.gws.sirius.serializer.StationSerializer;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.*;

public class StationFactoryTest {


	protected void assertStationsEqual(CRSStation actual, CRSStation expected) {
		assertEquals(actual.getAssociatedStationId(), expected.getAssociatedStationId());
		assertEquals(actual.getCallSign(), expected.getCallSign());
		assertEquals(actual.getDigicableId(), expected.getDigicableId());
		assertEquals(actual.getEmergencyAlertSystemType(), expected.getEmergencyAlertSystemType());
		assertEquals(actual.getExpirationDate(), expected.getExpirationDate());
		assertEquals(actual.getLanguage(), expected.getLanguage());
		assertEquals(actual.getOnScreenCallSign(), expected.getOnScreenCallSign());
		assertEquals(actual.getOtaChannelNumber(), expected.getOtaChannelNumber());
		assertEquals(actual.getPayPerView(), expected.getPayPerView());
		assertEquals(actual.getShortName(), expected.getShortName());
		assertEquals(actual.getTimeZone(), expected.getTimeZone());
		assertEquals(actual.getTitle(), expected.getTitle());


	}

	@Test
    public void testStationFactoryNoLocators() throws InvalidProtocolBufferException {

        CRSStation station = new CRSStation();
        station.setId(1234L);
        station.setTitle("station title");
        station.setCallSign("call sign");
        station.setOnScreenCallSign("on screen call sign");
        station.setTimeZone("time zone");
        station.setExpirationDate(1234L);
        station.setAssociatedStationId(1234L);
        station.setLanguage("language");
        station.setOtaChannelNumber(1234);
        station.setPayPerView(true);
        station.setShortName("short name");
        station.setVod(true);
        station.setDigicableId(1234);

        StationSerializer stationFactory = new StationSerializer(SiriusObjectType.fromFriendlyName("Station"));
        CRSStation retrievedStation
                = stationFactory.unmarshallPayload(stationFactory.marshallPayload(station).toByteArray() );

		assertStationsEqual(station, retrievedStation);
    }

    @Test
    public void testStationFactoryOneListEntry() throws InvalidProtocolBufferException {

    	CRSLocator locator = new CRSLocator();
    	locator.setFormat("test format");
    	locator.setLocatorURI("locator uri");
    	locator.setDigicableId(1234);
    	locator.setWidth(1234);
    	locator.setHeight(1234);
    	locator.setBitrate(1234L);
    	locator.setProtectionScheme("protection scheme");
    	locator.setCodec("codec");

    	List<CRSLocator> locators = new ArrayList<CRSLocator>();
    	locators.add(locator);

        CRSStation station = new CRSStation();
        station.setId(1234L);
        station.setTitle("station title");
        station.setCallSign("call sign");
        station.setOnScreenCallSign("on screen call sign");
        station.setTimeZone("time zone");
        station.setExpirationDate(1234L);
        station.setAssociatedStationId(1234L);
        station.setLanguage("language");
        station.setOtaChannelNumber(1234);
        station.setPayPerView(true);
        station.setShortName("short name");
        station.setVod(true);
        station.setDigicableId(1234);

        StationSerializer stationFactory = new StationSerializer(SiriusObjectType.fromFriendlyName("Station"));
        CRSStation retrievedStation
                = stationFactory.unmarshallPayload(stationFactory.marshallPayload(station).toByteArray() );

		assertStationsEqual(station, retrievedStation);
    }

    @Test
    public void testStationFactoryMultipleListEntries() throws InvalidProtocolBufferException {

    	CRSLocator locator1 = new CRSLocator();
    	locator1.setFormat("test format");
    	locator1.setLocatorURI("locator uri");
    	locator1.setDigicableId(1234);
    	locator1.setWidth(1234);
    	locator1.setHeight(1234);
    	locator1.setBitrate(1234L);
    	locator1.setProtectionScheme("protection scheme");
    	locator1.setCodec("codec");

    	CRSLocator locator2 = new CRSLocator();
    	locator2.setFormat("test format2");
    	locator2.setLocatorURI("locator uri2");
    	locator2.setDigicableId(2);
    	locator2.setWidth(2);
    	locator2.setHeight(2);
    	locator2.setBitrate(2222L);
    	locator2.setProtectionScheme("protection scheme2");
    	locator2.setCodec("codec2");


    	List<CRSLocator> locators = new ArrayList<CRSLocator>();
    	locators.add(locator1);
    	locators.add(locator2);

        CRSStation station = new CRSStation();
        station.setId(1234L);
        station.setTitle("station title");
        station.setCallSign("call sign");
        station.setOnScreenCallSign("on screen call sign");
        station.setTimeZone("time zone");
        station.setExpirationDate(1234L);
        station.setAssociatedStationId(1234L);
        station.setLanguage("language");
        station.setOtaChannelNumber(1234);
        station.setPayPerView(true);
        station.setShortName("short name");
        station.setVod(true);
        station.setDigicableId(1234);

        StationSerializer stationFactory = new StationSerializer(SiriusObjectType.fromFriendlyName("Station"));
        CRSStation retrievedStation
                = stationFactory.unmarshallPayload(stationFactory.marshallPayload(station).toByteArray());

		assertStationsEqual(station, retrievedStation);
    }

}
