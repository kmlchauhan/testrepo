package com.theplatform.web.tv.gws.service.common.logic;

import com.comcast.merlin.sirius.model.*;
import com.theplatform.data.tv.ingest.type.*;
import com.theplatform.data.tv.linear.api.data.objects.*;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.sirius.repository.*;
import java.util.*;
import org.mockito.*;
import org.testng.*;
import org.testng.annotations.*;


public class LocatorLogicTest {

    @BeforeTest
    public void setup(){
        SiriusObjectType.register("Stream", Stream.class, MerlinEntityType.STREAM);
    }

    @Test
    public void testStreamWithPrecedence_multipleStreamStatus(){
        LocatorLogic locatorLogic = new LocatorLogic();
        StreamRepository streamRepository = Mockito.mock(StreamRepository.class);
        locatorLogic.setStreamRepository(streamRepository);

        Set<CRSStream> streams = new HashSet<>();
        // 10L
        CRSStream crsStream_10 = new CRSStream(10L);
        crsStream_10.setStatus("Staging");
        streams.add(crsStream_10);
        // 50L
        CRSStream crsStream_50 = new CRSStream(50L);
        crsStream_50.setStatus("Production");
        streams.add(crsStream_50);
        // 70L
        CRSStream crsStream_70 = new CRSStream(70L);
        crsStream_70.setStatus("Staging");
        streams.add(crsStream_70);
        // 100L
        CRSStream crsStream_100 = new CRSStream(100L);
        crsStream_100.setStatus("Production");
        streams.add(crsStream_100);

        Set<Long> streamIds = new HashSet<>(Arrays.asList(10L, 100L, 50L, 70L));
        Mockito.when(streamRepository.getByIds(streamIds)).thenReturn(streams);

        Set<String> allowedStreamStatus = new HashSet<>(Arrays.asList("Producation","Staging"));
        Long streamWithPrecedence = locatorLogic.streamWithPrecedence(streamIds, allowedStreamStatus);

        Assert.assertEquals(streamWithPrecedence, new Long(50L));
    }

    @Test
    public void testStreamWithPrecedence_singleStreamStatus(){
        LocatorLogic locatorLogic = new LocatorLogic();
        Set<String> allowedStreamStatus = new HashSet<>(Arrays.asList("Foo"));
        Set<Long> streamIds = new HashSet<>(Arrays.asList(10L, 50L, 20L));
        Long streamWithPrecedence = locatorLogic.streamWithPrecedence(streamIds, allowedStreamStatus);
        Assert.assertEquals(streamWithPrecedence, new Long(10L));

    }

}