package com.theplatform.web.tv.gws.service.common.field;


import org.testng.Assert;
import org.testng.annotations.Test;

public class FieldFilterCacheTest {

    @Test
    public void testCache() {
        Object obj1 = new Object();
        Object obj2 = new Object();
        Object obj3 = new Object();
        Object obj4 = new Object();

        FieldFilterCache<String, Object> cache = new FieldFilterCache<>(3);
        cache.put("obj1", obj1);
        cache.put("obj2", obj2);
        cache.put("obj3", obj3);

        Assert.assertTrue(cache.get("obj1") == obj1);
        Assert.assertTrue(cache.get("obj2") == obj2);
        Assert.assertTrue(cache.get("obj3") == obj3);

        cache.put("obj4", obj4);
        Assert.assertNull(cache.get("obj1"));
        Assert.assertTrue(cache.get("obj4") == obj4);
    }
}
