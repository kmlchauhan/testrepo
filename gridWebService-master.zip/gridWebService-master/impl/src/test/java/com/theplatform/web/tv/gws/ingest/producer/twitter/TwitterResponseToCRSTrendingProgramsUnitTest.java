package com.theplatform.web.tv.gws.ingest.producer.twitter;


import com.theplatform.data.api.Range;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.id.api.client.MerlinSourceClient;
import com.theplatform.data.tv.id.api.client.query.merlinsource.ByProviderName;
import com.theplatform.data.tv.id.api.data.objects.MerlinSource;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms;
import com.theplatform.web.tv.gws.ingest.producer.twitter.json.AlternateIdSource;
import com.theplatform.web.tv.gws.ingest.producer.twitter.json.TwitterItem;
import com.theplatform.web.tv.gws.ingest.producer.twitter.json.TwitterTrendingResponse;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.fest.assertions.api.Assertions;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.mockito.Mockito;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class TwitterResponseToCRSTrendingProgramsUnitTest {

    private TwitterTrendingResponse jsonResponse;
    private TwitterSettings settings;
    private Feed<MerlinSource> roviFeed;
    private Feed<MerlinSource> tmsFeed;
    private MerlinSource simpleItemMs;
    private MerlinSource multipleNativeIdsMs;
    private MerlinSource tmsOnlyMs;

    @BeforeClass
    public void setup() throws URISyntaxException {
        AlternateIdSource rovi = AlternateIdSource.register( "Rovi1.1", "TVGUIDE");
        AlternateIdSource tms = AlternateIdSource.register( "Tms", "TMS");

        settings = new TwitterSettings();
        settings.setRefreshIntervalSeconds(5);

        // simple item.  has a single ID for each provider
        TwitterItem simpleItem = new TwitterItem();
        simpleItem.setTweetCount(1);
        simpleItem.getAlternateIds().put( rovi, "RoviId_item1_num_1");
        simpleItem.getAlternateIds().put( tms, "Tms_item1_num_1");

        // matching MerlinSource
        simpleItemMs = new MerlinSource();
        simpleItemMs.setProviderName( rovi.getMerlinSourceProviderName());
        simpleItemMs.setNativeProviderId("RoviId_item1_num_1");
        simpleItemMs.setMerlinId(new URI("simpleItemMs/100"));


        // multiple IDs for each provider
        TwitterItem multipleNativeIds = new TwitterItem();
        multipleNativeIds.setTweetCount(2);
        multipleNativeIds.getAlternateIds().put( rovi, "RoviId_item2_num_1");
        multipleNativeIds.getAlternateIds().put( rovi, "RoviId_item2_num_2");
        multipleNativeIds.getAlternateIds().put( rovi, "RoviId_item2_num_3");
        multipleNativeIds.getAlternateIds().put( tms, "TmsId_item2_num_1");
        multipleNativeIds.getAlternateIds().put( tms, "TmsId_item2_num_2");

        // matching MerlinSource
        multipleNativeIdsMs = new MerlinSource();
        multipleNativeIdsMs.setProviderName( rovi.getMerlinSourceProviderName());
        multipleNativeIdsMs.setNativeProviderId("RoviId_item2_num_1");
        multipleNativeIdsMs.setMerlinId(new URI("multipleNativeIdsMs/200"));

        // as the name implies, only has a TMS ID
        TwitterItem tmsOnly = new TwitterItem();
        tmsOnly.setTweetCount(3);
        tmsOnly.getAlternateIds().put( tms, "TmsId_item3_num_1");

        // matching MerlinSource for tmsOnly
        tmsOnlyMs = new MerlinSource();
        tmsOnlyMs.setProviderName( tms.getMerlinSourceProviderName());
        tmsOnlyMs.setNativeProviderId("TmsId_item3_num_1");
        tmsOnlyMs.setMerlinId(new URI("tmsOnlyMs/300"));

        // JSON response containing  simpleItem, multipleNativeIds, and tmsOnly
        jsonResponse = new TwitterTrendingResponse();
        jsonResponse.getItems().add(simpleItem);
        jsonResponse.getItems().add(multipleNativeIds);
        jsonResponse.getItems().add(tmsOnly);

        // MerlinSources for TVGUIDE/Rovi TwitterItems
        List<MerlinSource> sources = new ArrayList<>();
        sources.add(simpleItemMs);
        sources.add(multipleNativeIdsMs);
        roviFeed = new Feed<>();
        roviFeed.setEntries(sources);

        // MerlinSources for TVGUIDE/Rovi TwitterItems
        List<MerlinSource> tmsSources = Collections.singletonList(tmsOnlyMs);
        tmsFeed = new Feed<>();
        tmsFeed.setEntries(tmsSources);
    }

    @Test
    public void testMap() {

        MerlinSourceClient merlinSourceClient = Mockito.mock(MerlinSourceClient.class);
        Mockito.when(
            merlinSourceClient.getAll(
                Mockito.any(String[].class),
                Mockito.argThat(new ByProviderNameMatcher("TVGUIDE")),
                Mockito.any(Sort[].class),
                Mockito.any(Range.class),
                Mockito.eq(false))
            )
            .thenReturn(roviFeed);
        Mockito.when(
            merlinSourceClient.getAll(
                Mockito.any(String[].class),
                Mockito.argThat(new ByProviderNameMatcher("TMS")),
                Mockito.any(Sort[].class),
                Mockito.any(Range.class),
                Mockito.eq(false))
        )
            .thenReturn(tmsFeed);

        TwitterMBean doNothingMBean = Mockito.mock(TwitterMBean.class);

        Date beforeTest = new Date();

        // build the TwitterResponseToCRSTrendingPrograms and run the test
        TwitterResponseToCRSTrendingPrograms mapper = new TwitterResponseToCRSTrendingPrograms();
//        mapper.setIdHelper(idHelper);
        mapper.setMerlinSourceClient(merlinSourceClient);
        mapper.setMbean(doNothingMBean);
        mapper.setSettings(settings);
        CRSTrendingPrograms actual = mapper.map(jsonResponse);

        // TTL and retrievedTime
        Assertions.assertThat(actual.getRetrievedTime())
            .isGreaterThanOrEqualTo(beforeTest.getTime())
            .isLessThan(beforeTest.getTime() + 5000);
        Assertions.assertThat(actual.getTimeToLive()).isEqualTo(settings.getRefreshIntervalSeconds());

        // check that CRSTrendingPrograms.programs is the expected size
        Assertions.assertThat(actual).isNotNull();
        List<CRSTrendingProgram> programs = actual.getPrograms();
        Assertions.assertThat(programs).isNotEmpty();
        Assertions.assertThat(programs.size()).isEqualTo(3);

        // sort by natural order (descending by score)
        Collections.sort(programs);

        // the first program in the collection should come from the TwitterItem that only had a TMS id
        CRSTrendingProgram program1 = programs.get(0);
        Assertions.assertThat(program1.getProgramId()).isEqualTo(300L);
        Assertions.assertThat(program1.getScore()).isEqualTo(3);

        // second item should come from the TwitterItem with multiple TVGUIDE ids
        CRSTrendingProgram program2 = programs.get(1);
        Assertions.assertThat(program2.getProgramId()).isEqualTo(200L);
        Assertions.assertThat(program2.getScore()).isEqualTo(2);

        // lastly the third one should be from the TwitterItem with a single TVGUIDE id
        CRSTrendingProgram program3 = programs.get(2);
        Assertions.assertThat(program3.getProgramId()).isEqualTo(100L);
        Assertions.assertThat(program3.getScore()).isEqualTo(1);
    }

    /**
     * Match any array of Query where at least one of the queries in the array is a ByProviderName
     * that matches a particular String.
     */
    public static class ByProviderNameMatcher extends BaseMatcher<Query[]> {
        private final static long serialVersionUID = 0L;
        private String providerName;

        ByProviderNameMatcher(String providerName) {
            this.providerName = providerName;
        }

        @Override
        public boolean matches(Object o) {
            if (o == null) {
                return false;
            }

            Query[] queries = (Query[]) o;
            for (Query current : queries) {
                try {
                    if (!(current instanceof ByProviderName)) {
                        continue;
                    }

                    List<String> values = (List<String>) FieldUtils.readField(current, "orParameters", true);
                    if (values != null && values.contains(this.providerName)) {
                        return true;
                    }
                }
                catch (ReflectiveOperationException ignored) {}

            }
            return false;
        }

        @Override
        public void describeTo(Description description) {
        }
    }

}
