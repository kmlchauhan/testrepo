package com.theplatform.web.tv.gws.service.contentresolution.episodes;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.repository.ProgramRepository;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.*;

import static org.fest.assertions.api.Assertions.assertThat;

public class LegacyEpisodesHelperTest {

    ProgramRepository programRepository;
    LegacyEpisodesHelper legacyEpisodesHelper;

    @BeforeMethod
    public void initializeProgramRepository() {
        programRepository = new ProgramRepository(SiriusObjectType.fromFriendlyName("Program"), 20);
        legacyEpisodesHelper = new LegacyEpisodesHelper(programRepository);
    }

    @Test
    public void testOneEpisode() {
        CRSProgram episode = EpisodeFactory.create();

        programRepository.put(episode);

        assertThat(legacyEpisodesHelper.getEpisodes(crsUri(episode), 0, 0, true)).isEmpty();
        assertThat(legacyEpisodesHelper.getEpisodes(crsUri(episode), 0, 0, false)).hasSize(1);
    }

    @Test
    public void testSeries() {
        List<CRSProgram> series = EpisodeFactory.createSeries(3, 12);
        List<CRSProgram> someOtherSeries = EpisodeFactory.createSeries(2, 20);

        List<CRSProgram> randomizedSeries = new ArrayList<>(series);
        Collections.shuffle(randomizedSeries, new Random(42));

        loadSeries(randomizedSeries);
        loadSeries(someOtherSeries);

        Muri firstEpisodeId = crsUri(series.get(0));
        Muri lastEpisodeId = crsUri(series.get(series.size() - 1));

        assertThat(legacyEpisodesHelper.getEpisodes(firstEpisodeId, Integer.MAX_VALUE, Integer.MAX_VALUE, false))
                .hasSize(series.size());

        assertThat(legacyEpisodesHelper.getEpisodes(firstEpisodeId, 3, 5, true))
                .isEqualTo(series.subList(1, 6));

        assertThat(legacyEpisodesHelper.getEpisodes(lastEpisodeId, 3, 5, false))
                .isEqualTo(series.subList(series.size() - 4, series.size()));
    }

    void loadSeries(Collection<CRSProgram> series) {
        for (CRSProgram episode : series) {
            programRepository.put(episode);
        }
    }

    Muri crsUri(CRSProgram crsProgram) {
        return new Muri("", crsProgram.getId());
    }
}
