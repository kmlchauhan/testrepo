package com.theplatform.web.tv.gws;

import com.theplatform.web.tv.gws.sirius.model.CRSProductContext;

import java.util.ArrayList;
import java.util.List;

public class UnitTestHelper {
    protected static final String QAM_PRODUCT_CONTEXT_TITLE = "QAM";
    protected static final String HSD_PRODUCT_CONTEXT_TITLE = "HSD-Video";
    protected static final String CDVR_PRODUCT_CONTEXT_TITLE = "cDVR";
    protected static final String CTV_PRODUCT_CONTEXT_TITLE = "cTV";

    protected static final long QAM_ID =  7000000000000000174l;
    protected static final long HSD_ID = 6000000000000000174l;
    protected static final long CDVR_ID = 5000000000000000174l;
    protected static final long CTV_ID = 4000000000000000174l;

    protected static List<CRSProductContext> ALL_PRODUCT_CONTEXT = new ArrayList<CRSProductContext>();

    static CRSProductContext PRODUCT_CONTEXT_QAM;
    static CRSProductContext PRODUCT_CONTEXT_HSD;
    static CRSProductContext PRODUCT_CONTEXT_CDVR;
    static CRSProductContext PRODUCT_CONTEXT_CTV;

    static {
        PRODUCT_CONTEXT_QAM = new CRSProductContext();
        PRODUCT_CONTEXT_QAM.setTitle(QAM_PRODUCT_CONTEXT_TITLE);
        PRODUCT_CONTEXT_QAM.setId(QAM_ID);
        ALL_PRODUCT_CONTEXT.add(PRODUCT_CONTEXT_QAM);

        PRODUCT_CONTEXT_HSD = new CRSProductContext();
        PRODUCT_CONTEXT_HSD.setTitle(HSD_PRODUCT_CONTEXT_TITLE);
        PRODUCT_CONTEXT_HSD.setId(HSD_ID);
        ALL_PRODUCT_CONTEXT.add(PRODUCT_CONTEXT_HSD);

        PRODUCT_CONTEXT_CDVR = new CRSProductContext();
        PRODUCT_CONTEXT_CDVR.setTitle(CDVR_PRODUCT_CONTEXT_TITLE);
        PRODUCT_CONTEXT_CDVR.setId(CDVR_ID);
        ALL_PRODUCT_CONTEXT.add(PRODUCT_CONTEXT_CDVR);

        PRODUCT_CONTEXT_CTV = new CRSProductContext();
        PRODUCT_CONTEXT_CTV.setTitle(CTV_PRODUCT_CONTEXT_TITLE);
        PRODUCT_CONTEXT_CTV.setId(CTV_ID);
        ALL_PRODUCT_CONTEXT.add(PRODUCT_CONTEXT_CTV);
    }
    
}

