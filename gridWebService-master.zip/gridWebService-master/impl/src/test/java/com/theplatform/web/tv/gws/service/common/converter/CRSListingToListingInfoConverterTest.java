package com.theplatform.web.tv.gws.service.common.converter;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.data.tv.linear.api.data.objects.AiringType;
import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.web.tv.combine.commons.MerlinService;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.sirius.repository.GameRepository;
import com.theplatform.web.tv.gws.sirius.repository.LinearTagAssociationRepository;
import com.theplatform.web.tv.gws.sirius.repository.ProgramRepository;
import com.theplatform.web.tv.gws.service.common.util.GridUtils;
import com.theplatform.web.tv.gws.uri.UrnUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.*;

import static com.theplatform.web.tv.gws.TestUtil.MERLIN_ID_HELPER;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.*;

@Test(groups = { "unit-tests" })
public class CRSListingToListingInfoConverterTest {

    private CRSListingToListingInfoConverter crsListingToListingInfoConverter;

    private CRSProgram program1;
    private CRSProgram program2;
    private CRSProgram program3;


    private ProgramRepository programRepository;
    private LinearTagAssociationRepository linearTagAssociationRepository;
    private GameRepository gameRepository;

    private static final Long[] tagsCorrectOrder = {8888L, 9999L};

    @SuppressWarnings("unchecked")
    public CRSListingToListingInfoConverterTest() {
        SiriusObjectTypeTestUtil.unitTestInitialization();

        crsListingToListingInfoConverter = new CRSListingToListingInfoConverter();
        crsListingToListingInfoConverter.setMerlinIdHelper(MERLIN_ID_HELPER);
        CRSProgramToProgramInfoConverter crsProgramToProgramInfoConverter = new CRSProgramToProgramInfoConverter();
        crsProgramToProgramInfoConverter.setMerlinIdHelper(MERLIN_ID_HELPER);
        crsListingToListingInfoConverter.setCrsProgramToProgramInfoConverter(crsProgramToProgramInfoConverter);
        programRepository = new ProgramRepository(SiriusObjectType.fromFriendlyName("Program"), 10);
        crsListingToListingInfoConverter.setProgramRepository(programRepository);
        gameRepository = new GameRepository(SiriusObjectType.fromFriendlyName("Game"));
        crsListingToListingInfoConverter.setGameRepository(gameRepository);
        linearTagAssociationRepository = new LinearTagAssociationRepository(SiriusObjectType.fromFriendlyName("LinearTagAssociation"));
        crsListingToListingInfoConverter.setLinearTagAssociationRepository(linearTagAssociationRepository);
    }

    @BeforeMethod
    public void initPrograms() {
        program1 = new CRSProgram();
        program2 = new CRSProgram();
        program3 = new CRSProgram();

        program1.setCategory(ProgramCategory.Other);
        program1.setType(ProgramType.Movie);
        program1.setGridTitle("Dave 3D");
        program1.setId(21111);
        program1.setTitle("Dave Three Dee");

        program2.setCategory(ProgramCategory.Children);
        program2.setType(ProgramType.Episode);
        program2.setGridTitle("Dave 2D");
        program2.setId(22222);
        program2.setTitle("Dave Two Dee");
        program2.setSeriesId(123l);
        program2.setEpisodeTitle("Episode Title");

        program3.setCategory(ProgramCategory.Other);
        program3.setType(ProgramType.SeriesMaster);
        program3.setGridTitle("Star Wars");
        program3.setId(20000);
        program3.setTitle("Star Wars IV");

        programRepository.put(program1.getId(), program1);
        programRepository.put(program2.getId(), program2);
        programRepository.put(program3.getId(), program3);

    }

    // CRSListing
    public void testMapCRSListingToListingInfoInGrid() {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(new Date());
        calendar.set(Calendar.MINUTE, 0);
        Date startTime = stripSeconds(calendar.getTimeInMillis());
        calendar.set(Calendar.MINUTE, 30);
        Date endTime = stripSeconds(calendar.getTimeInMillis());

        List<CRSListing> crsListings = getCRSListings();
        List<ListingInfo> listingInfos = crsListingToListingInfoConverter.convert(crsListings, startTime, endTime, null);

        assertThat(listingInfos).hasSameSizeAs(crsListings);
        for (int i = 0; i < crsListings.size(); i++) {
            validateCRS(crsListings.get(i), listingInfos.get(i), startTime, endTime);
            validateCRSTimeInWindow(listingInfos.get(i), 20);
        }

    }

    public void testMapCRSListingToListingInfoOffStartOfGrid() {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(new Date());
        calendar.set(Calendar.MINUTE, 9);
        Date startTime = stripSeconds(calendar.getTimeInMillis());
        calendar.set(Calendar.MINUTE, 30);
        Date endTime = stripSeconds(calendar.getTimeInMillis());

        List<CRSListing> crsListings = getCRSListings();
        List<ListingInfo> listingInfos = crsListingToListingInfoConverter.convert(crsListings, startTime, endTime, null);

        assertThat(listingInfos).hasSameSizeAs(crsListings);
        for (int i = 0; i < crsListings.size(); i++) {
            validateCRS(crsListings.get(i), listingInfos.get(i), startTime, endTime);
            validateCRSTimeInWindow(listingInfos.get(i), 16);
        }

    }

    public void testMapCRSListingToListingInfoOffEndOfGrid() {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(new Date());
        calendar.set(Calendar.MINUTE, 0);
        Date startTime = stripSeconds(calendar.getTimeInMillis());
        calendar.set(Calendar.MINUTE, 20);
        Date endTime = stripSeconds(calendar.getTimeInMillis());

        List<CRSListing> crsListings = getCRSListings();
        List<ListingInfo> listingInfos = crsListingToListingInfoConverter.convert(crsListings, startTime, endTime, null);

        assertThat(listingInfos).hasSameSizeAs(crsListings);
        for (int i = 0; i < crsListings.size(); i++) {
            validateCRS(crsListings.get(i), listingInfos.get(i), startTime, endTime);
            validateCRSTimeInWindow(listingInfos.get(i), 15);
        }
    }

    public void testMapCRSListingNullProgram() {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(new Date());
        calendar.set(Calendar.MINUTE, 0);
        Date startTime = stripSeconds(calendar.getTimeInMillis());
        calendar.set(Calendar.MINUTE, 20);
        Date endTime = stripSeconds(calendar.getTimeInMillis());

        List<CRSListing> crsListings = getCRSListings();
        this.programRepository.delete(crsListings.get(2).getProgramId());
        List<ListingInfo> listingInfos = crsListingToListingInfoConverter.convert(crsListings, startTime, endTime, null);

        assertThat(listingInfos).hasSameSizeAs(crsListings);
        for (int i = 0; i < crsListings.size(); i++) {
            validateCRS(crsListings.get(i), listingInfos.get(i), startTime, endTime);
            validateCRSTimeInWindow(listingInfos.get(i), 15);
        }

    }

    public void testSportsListing() {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(new Date());
        calendar.set(Calendar.MINUTE, 0);
        Date startTime = stripSeconds(calendar.getTimeInMillis());
        calendar.set(Calendar.MINUTE, 30);
        Date endTime = stripSeconds(calendar.getTimeInMillis());

        List<CRSListing> listings = getCRSListings();

        CRSGame game = new CRSGame(1, Arrays.asList(listings.get(0).getId()),true);
        gameRepository.put(game.getId(), game);

        List<ListingInfo> listingInfos = crsListingToListingInfoConverter.convert(listings, startTime, endTime, null);

        assertThat(listingInfos).hasSameSizeAs(listings);

        ListingInfo sportsListing = listingInfos.get(0);
        ListingInfo otherListing = listingInfos.get(1);

        assertThat(sportsListing.getAutoextendable()).as("Sports listing's autoextendable property").isEqualTo(true);
        assertThat(sportsListing.getExtendableEntityId()).isNotNull();

        assertThat(otherListing.getAutoextendable()).as("Other listing's autoextendable property").isEqualTo(false);
        assertThat(otherListing.getExtendableEntityId()).isNull();
    }

    private List<CRSListing> getCRSListings() {
        List<CRSRating> crsRatings = getCRSRatings();


        CRSListing listing1 = new CRSListing();
        CRSListing listing2 = new CRSListing();
        CRSListing listing0 = new CRSListing();

        Calendar calendar = new GregorianCalendar();
        calendar.setTime(new Date());
        calendar.set(Calendar.MINUTE, 5);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date startTime = calendar.getTime();
        calendar.set(Calendar.MINUTE, 25);
        Date endTime = calendar.getTime();

        listing0.setId(10000);
        listing0.setCrsAiringType(AiringType.Repeat.name());
        listing0.setCaptionType("CC");
        listing0.setStartTime(startTime.getTime());
        listing0.setEndTime(endTime.getTime());
        listing0.setHdLevel("720p");
        listing0.setPayPerView(false);
        listing0.setDescriptiveVideoService(false);
        listing0.setProgramId(22222l);
        listing0.setStationId(33333);
        listing0.setContentRatings(null);

        listing1.setId(11111);
        listing1.setCrsAiringType(AiringType.Live.name());
        listing1.setCaptionType("CC");
        listing1.setStartTime(startTime.getTime());
        listing1.setEndTime(endTime.getTime());
        listing1.setHdLevel("1080p");
        listing1.setPayPerView(true);
        listing1.setDescriptiveVideoService(true);
        listing1.setProgramId(program1.getId());
        listing1.setStationId(31111);
        listing1.setContentRatings( new CRSRating[]{crsRatings.get(0)});
        listing1.setSeriesId(program3.getId());
        listing1.setAudioType("1111AudioType");
        listing1.setSap(true);
        listing1.setSubjectToBlackout(true);
        listing1.setSubtitled(true);
        listing1.setThreeD(true);
        listing1.setCci("11111CCI");
        listing1.setDvrProgramId(1001);
        listing1.setDvrSeriesId(2001);

        CRSTagAssociation crsTagAssociation_0 = new CRSTagAssociation(100L, tagsCorrectOrder[1], listing1.getId());
        linearTagAssociationRepository.put(crsTagAssociation_0);
        CRSTagAssociation crsTagAssociation_1 = new CRSTagAssociation(101L, tagsCorrectOrder[0], listing1.getId());
        linearTagAssociationRepository.put(crsTagAssociation_1);

        listing2.setId(12222);
        listing2.setCrsAiringType(AiringType.New.name());
        listing2.setCaptionType("CCC");
        listing2.setStartTime(startTime.getTime());
        listing2.setEndTime(endTime.getTime());
        listing2.setHdLevel("720p");
        listing2.setPayPerView(false);
        listing2.setDescriptiveVideoService(false);
        listing2.setProgramId(program1.getId());
        listing2.setStationId(32222);
        listing2.setContentRatings( crsRatings.toArray(new CRSRating[crsRatings.size()]));
        listing2.setSeriesId(program2.getId());

        return Arrays.asList(listing0, listing1, listing2);
    }

    private List<CRSRating> getCRSRatings() {
        List<CRSRating> crsRatings = new ArrayList<CRSRating>();

        CRSRating crsRating1 = new CRSRating("star wars", "PG", new String[]{"c3p0", "r2d2"});
        crsRatings.add(crsRating1);

        CRSRating crsRating2 = new CRSRating("terminator", "R", new String[]{"t-800"});
        crsRatings.add(crsRating2);

        return crsRatings;
    }

    private void validateCRSTimeInWindow(ListingInfo listingInfo, int expectedInWindowMinutes) {
        assertThat(listingInfo.getInWindowMinutes()).isEqualTo(expectedInWindowMinutes);
    }

    private void validateCRS(CRSListing listing
            , ListingInfo listingInfo
            , Date gridStartTime
            , Date gridEndTime) {

        CRSProgram crsProgram = listing.getProgramId() != null ? programRepository.get(listing.getProgramId()) : null;
        CRSProgram crsSeries  = listing.getSeriesId() != null  ? programRepository.get(listing.getSeriesId()) : null;

        assertEquals(listingInfo.getStartTime().getTime(), listing.getStartTime());
        assertEquals(listingInfo.getEndTime().getTime(), listing.getEndTime());
        assertEquals(listingInfo.getAiringType(), AiringType.valueOf(listing.getCrsAiringType()));
        assertEquals(listingInfo.getCaptionType(), listing.getCaptionType());
        assertEquals(listingInfo.getHdLevel(), listing.getHdLevel());
        assertEquals(listingInfo.getPayPerView(), listing.getPayPerView());
        assertEquals(listingInfo.getDescriptiveVideoService(), listing.getDescriptiveVideoService());
        assertEquals(listingInfo.getThreeD(), listing.getThreeD());
        assertEquals(listingInfo.getCci(), listing.getCci());
        assertEquals(listingInfo.getDvrProgramId(), listing.getDvrProgramId());
        assertEquals(listingInfo.getDvrSeriesId(), listing.getDvrSeriesId());
        // Check the tags
        if (CollectionUtils.isEmpty(linearTagAssociationRepository.getTagIds(listing.getId()))){
            assertNull(listingInfo.getTagIds());
        } else{
            Long actualTagIds[] = ArrayUtils.toObject(Muri.getIdsAsArray(listingInfo.getTagIds()));
            assertEquals(actualTagIds, tagsCorrectOrder);
        }

        assertEquals(listingInfo.getAudioType(), listing.getAudioType());
        if (listing.getSeriesId()==null){
            assertNull(listingInfo.getSeriesInfo());
        }else{
            assertEquals( new Long(listingInfo.getSeriesInfo().getProgramId().getId()), listing.getSeriesId());
        }
        assertEquals(listingInfo.getShowingType(), listing.getShowingType());
        assertEquals(listingInfo.getSap(), listing.getSap());
        assertEquals(listingInfo.getSubjectToBlackout(), listing.getSubjectToBlackout());
        assertEquals(listingInfo.getSubtitled(), listing.getSubtitled());
        assertEquals(listingInfo.getThreeD(), listing.getThreeD());

        // Check Rating
        CRSRating[] crsRatings = listing.getContentRatings();
        if (listing.getContentRatings()==null){
            assertNull(listingInfo.getContentRatings());
        }else{
            assertEquals( listingInfo.getContentRatings().size(), listing.getContentRatings().length,  "The CRSListing and Info Object have different numbers of ratings.");
            String previousScheme = null;           // To check order
            for ( Rating rating : listingInfo.getContentRatings()){
                boolean success = false;
                for (CRSRating crsRating : listing.getContentRatings()){
                    if (rating.getScheme().equals(crsRating.getScheme())){
                        assertEquals(rating.getRating(), crsRating.getRating());
                        assertEquals(rating.getScheme(), crsRating.getScheme());
                        assertEquals(rating.getSubRatings().length, crsRating.getSubRatings().length);
                        for (int j = 0; j < crsRating.getSubRatings().length; j++) {
                            assertEquals(rating.getSubRatings()[j], crsRating.getSubRatings()[j]);
                        }
                        // Check order
                        if (previousScheme != null){
                            int order = previousScheme.compareTo(rating.getScheme());
                            assertEquals( order, -1, "Ratings are in the wrong order.  Should be ascending by scheme.");
                        }
                        previousScheme = rating.getScheme();
                        success=true;
                        break;
                    }
                }
                if (!success){
                    fail("Unable to find rating in ListingInfo with scheme.  The Ratings do not match.");
                }

            }

        }

        // Check Program
        ProgramInfo programInfo = listingInfo.getProgramInfo();
        validatePrograms( programInfo, crsProgram);

        // Check Series
        ProgramInfo seriesInfo = listingInfo.getSeriesInfo();
        validatePrograms( seriesInfo, crsSeries);

        Date startTime = new Date(listing.getStartTime());
        Date endTime = new Date(listing.getEndTime());

        if (startTime.before(gridStartTime))
            startTime = GridUtils.roundDateDownToMinute(gridStartTime);
        if (endTime.after(gridEndTime))
            endTime = gridEndTime;

        Assert.assertTrue(listingInfo.getDescriptiveVideoService() == (listing.getDescriptiveVideoService() != null ? listing
                .getDescriptiveVideoService() : false));
    }

    private void validatePrograms( ProgramInfo programInfo, CRSProgram crsProgram){
        if (crsProgram == null) {
            Assert.assertNull(programInfo);
        } else {
            assertEquals(programInfo.getCategory(), crsProgram.getCategory().getFriendlyName());
            assertThat(programInfo.getType()).isEqualTo(crsProgram.getType().getFriendlyName());
            assertEquals(programInfo.getGridTitle(), crsProgram.getGridTitle());
            assertEquals(programInfo.getTitle(), crsProgram.getTitle());
            assertEquals(programInfo.getSportsSubtitle(), crsProgram.getSportsSubtitle());
            if(crsProgram.getSeriesId() != null)
                assertThat(programInfo.getSeriesId())
                        .isEqualTo(UrnUtil.generateUrn(crsProgram.getSeriesId(), MerlinService.ENTITY, MerlinEntityType.PROGRAM));
            assertThat(programInfo.getEpisodeTitle()).isEqualTo(crsProgram.getEpisodeTitle());
        }
    }



    public Date stripSeconds(long time) {
        long diff = time % 60000;
        return new Date(time - diff);
    }


}
