package com.theplatform.web.tv.gws;

import com.theplatform.web.tv.gws.uri.IdForm;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;

/**
 * Created by jcoelho on 7/29/14.
 */
public class TestUtil {

    public static final String BASE_URL = "http://test.com";
    public static final String LINEAR_BASE_URL = BASE_URL + "/linearDataService/";
    public static final String ENTITY_BASE_URL = BASE_URL + "/entityDataService/";
    public static final String OFFER_BASE_URL = BASE_URL + "/offerDataService/";
    public static final String LOCATION_BASE_URL = BASE_URL + "/locationDataService/";
    public static final String SPORTS_BASE_URL = BASE_URL + "/sportsDataService/";

    public static final MerlinIdHelper MERLIN_ID_HELPER = MerlinIdHelper.withDefaultIdForm(ENTITY_BASE_URL, LINEAR_BASE_URL, OFFER_BASE_URL, LOCATION_BASE_URL, SPORTS_BASE_URL, IdForm.URN);

}
