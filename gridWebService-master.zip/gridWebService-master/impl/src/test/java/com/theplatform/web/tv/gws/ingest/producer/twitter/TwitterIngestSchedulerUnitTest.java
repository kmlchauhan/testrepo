package com.theplatform.web.tv.gws.ingest.producer.twitter;

import com.comcast.merlin.sirius.ingest.IngestMode;
import com.theplatform.web.tv.GridException;

import org.mockito.Mockito;
import org.testng.annotations.Test;

public class TwitterIngestSchedulerUnitTest {

    @Test
    public void testRun() throws GridException {
        TwitterSettings settings = new TwitterSettings();
        settings.setEnabled(true);

        TwitterMBean mockMBean = Mockito.mock(TwitterMBean.class);
        TwitterIngester mockIngester = Mockito.mock(TwitterIngester.class);

        TwitterIngestScheduler scheduler = new TwitterIngestScheduler();
        scheduler.setSettings(settings);
        scheduler.setMbean(mockMBean);
        scheduler.setIngester(mockIngester);

        // check that it doesn't run when it hasn't been started
        scheduler.run();
        Mockito.verifyZeroInteractions(mockIngester);

        // check that it doesn't run when it's disabled
        Mockito.reset(mockIngester);
        settings.setEnabled(false);
        scheduler.start(IngestMode.LEADER);
        Mockito.verifyZeroInteractions(mockIngester);

        // check that it runs when started
        Mockito.reset(mockIngester);
        settings.setEnabled(true);
        scheduler.start(IngestMode.LEADER);
        scheduler.run();
        Mockito.verify(mockIngester).runTwitterIngest();

        // check that after it's stopped...
        Mockito.reset(mockIngester);
        scheduler.stop();

        // ... that the stats are reset
        Mockito.verify(mockMBean).clearStats();

        // ... and that it doesn't run
        scheduler.run();
        Mockito.verifyZeroInteractions(mockIngester);
    }
}
