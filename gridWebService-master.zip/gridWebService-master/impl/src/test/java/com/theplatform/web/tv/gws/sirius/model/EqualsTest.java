package com.theplatform.web.tv.gws.sirius.model;


import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;



public class EqualsTest {

    @Test
    public void test() {
        CRSListing listing1 = new CRSListing(1);
        CRSListing listing1a = new CRSListing(1);
        CRSListing listing2 = new CRSListing(2);

        assertEquals(listing1, listing1a);
        assertFalse(listing1.equals(listing2));

        CRSProgram program1 = new CRSProgram(1);
        assertFalse(listing1.equals(program1));
    }
}
