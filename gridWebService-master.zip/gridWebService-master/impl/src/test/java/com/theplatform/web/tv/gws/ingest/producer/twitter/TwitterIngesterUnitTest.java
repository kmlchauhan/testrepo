package com.theplatform.web.tv.gws.ingest.producer.twitter;

import com.theplatform.web.tv.GridException;
import com.comcast.merlin.sirius.ingest.Event;
import com.comcast.merlin.sirius.ingest.EventDispatcher;
import com.theplatform.web.tv.gws.ingest.producer.twitter.json.TwitterTrendingResponse;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.mockito.InOrder;
import org.mockito.Mockito;
import org.testng.annotations.Test;

public class TwitterIngesterUnitTest {

    @Test
    public void testRunTwitterIngest() throws GridException {
        TwitterMBean mockMBean = Mockito.mock(TwitterMBean.class);

        // mock TwitterClient that returns a TwitterTrendingResponse
        TwitterTrendingResponse response = new TwitterTrendingResponse();
        TwitterClient mockTwitterClient = Mockito.mock(TwitterClient.class);
        Mockito.when(mockTwitterClient.fetchTrendingResponses()).thenReturn(response);

        // mock mapper that returns a CRSTrendingPrograms when the response from the mock TwitterClient is passed in
        CRSTrendingPrograms trendingPrograms = new CRSTrendingPrograms();
        final TwitterResponseToCRSTrendingPrograms mapper = Mockito.mock(TwitterResponseToCRSTrendingPrograms.class);
        Mockito.when(mapper.map(response)).thenReturn(trendingPrograms);

        // ScoreEvaluator and EventDispatcher don't do anything but are used to verify ordering
        ScoreEvaluator mockScoreEvaluator = Mockito.mock(ScoreEvaluator.class);
        EventDispatcher dispatcher = Mockito.mock(EventDispatcher.class);


        // new TwitterIngester.  note that Spring implements this method for us when the context is started but
        // we need to implement it ourselves for unit testing.
        TwitterIngester ingester = new TwitterIngester() {
            @Override
            protected TwitterResponseToCRSTrendingPrograms newTwitterToCrsMapper() {
                return mapper;
            }
        };

        // wire up the mocks
        ingester.setMbean(mockMBean);
        ingester.setScoreEvaluator(mockScoreEvaluator);
        ingester.setEventDispatcher(dispatcher);
        ingester.setTwitterClient(mockTwitterClient);

        // call the ingester
        ingester.runTwitterIngest();

        // verify call ordering
        InOrder order = Mockito.inOrder(mockMBean, mockTwitterClient, mapper, mockScoreEvaluator, dispatcher);
        order.verify(mockMBean).incrementExecutionCount();
        order.verify(mockMBean).setLastExecutionTime();
        order.verify(mockTwitterClient).fetchTrendingResponses();
        order.verify(mapper).map(response);
        order.verify(mockScoreEvaluator).updateTrendingPrograms(trendingPrograms);
        order.verify(dispatcher).publish(Mockito.argThat(new EventMatcher(trendingPrograms)));
    }

    private static class EventMatcher extends BaseMatcher<Event> {
        private CRSTrendingPrograms expectedTrendingPrograms;

        public EventMatcher(CRSTrendingPrograms expectedTrendingPrograms) {
            this.expectedTrendingPrograms = expectedTrendingPrograms;
        }

        @Override
        public boolean matches(Object o) {
            if (o instanceof Event) {
                Event event = (Event) o;
                return expectedTrendingPrograms == event.getCrsDataObject();
            }
            return false;
        }

        @Override
        public void describeTo(Description description) {
        }
    };
}
