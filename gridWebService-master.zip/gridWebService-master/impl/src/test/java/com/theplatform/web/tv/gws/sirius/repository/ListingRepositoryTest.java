package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.data.tv.linear.api.data.objects.Listing;
import com.theplatform.web.tv.gws.sirius.model.CRSListing;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Collection;
import java.util.Date;

public class ListingRepositoryTest {

    private static long counter = 0;
    private static final long HALF_HOUR = 1800000;

    @BeforeClass
    public void registerSiriusObjectType() {
        SiriusObjectType.register("Listing", Listing.class, MerlinEntityType.LISTING);
        SiriusObjectType.register("Program", Program.class, MerlinEntityType.PROGRAM);
    }

    @Test
    public void searchTest(){
        ListingRepository listingRepository = new ListingRepository(SiriusObjectType.fromFriendlyName("Listing"));

        // No Listings in window.
        Collection<CRSListing> searchResult = listingRepository.getListings(50, new Date(HALF_HOUR), new Date(5 * HALF_HOUR));
        Assert.assertEquals( searchResult.size(), 0);

        // Add a listing to the beginning of windwow
        CRSListing listing = generateListing( 50, 1, HALF_HOUR, HALF_HOUR * 2);
        listingRepository.put(listing.getId(), listing);                                                                  // Listing 30-60
        searchResult = listingRepository.getListings(50, new Date(HALF_HOUR), new Date(5 * HALF_HOUR));     // Window 30 - 150
        Assert.assertEquals(listingRepository.getByStationId(50l).size(), 1);
        Assert.assertEquals(searchResult.size(), 1);

        // Add a listing to the end of windwow
        listing = generateListing( 50, 1, HALF_HOUR * 4, HALF_HOUR * 5);
        listingRepository.put(listing.getId(), listing);                                                                  // Listing 120 - 150
        searchResult = listingRepository.getListings(50, new Date(HALF_HOUR), new Date(5 * HALF_HOUR));     // Window 30 - 150
        Assert.assertEquals(listingRepository.getByStationId(50l).size(), 2);
        Assert.assertEquals(searchResult.size(), 2);

        // Add a listing mid windwow
        listing = generateListing( 50, 1, HALF_HOUR * 2, HALF_HOUR * 3);
        listingRepository.put(listing.getId(), listing);                                                                  // Listing 60 - 90
        searchResult = listingRepository.getListings(50, new Date(HALF_HOUR), new Date(5 * HALF_HOUR));     // Window 30 - 150
        Assert.assertEquals(listingRepository.getByStationId(50l).size(), 3);
        Assert.assertEquals(searchResult.size(), 3);

        // Add an out-of-window listing.  Greater than window
        listing = generateListing( 50, 1, 5 * HALF_HOUR, 6 * HALF_HOUR);
        listingRepository.put(listing.getId(), listing);                                                                  //Listing 150 - 180
        searchResult = listingRepository.getListings(50, new Date(HALF_HOUR), new Date(5 * HALF_HOUR));     // Window 30 - 150
        Assert.assertEquals(listingRepository.getByStationId(50l).size(), 4);
        Assert.assertEquals(searchResult.size(), 3);

        // Add an out-of-window listing.  Less than window
        listing = generateListing( 50, 1, 0, HALF_HOUR);
        listingRepository.put(listing.getId(), listing);                                                                  // Window  0 - 30
        searchResult = listingRepository.getListings(50, new Date(HALF_HOUR), new Date(5 * HALF_HOUR));     // Window 30 - 150
        Assert.assertEquals(listingRepository.getByStationId(50l).size(), 5);
        Assert.assertEquals(searchResult.size(), 3);
    }

    @Test
    public void listingCountTest(){
        ListingRepository listingRepository = new ListingRepository(SiriusObjectType.fromFriendlyName("Listing"));

        CRSListing listing = generateListing( 1, 1, 0, HALF_HOUR);
        listingRepository.put(listing.getId(), listing);
        Assert.assertEquals(listingRepository.getByStationId(1l).size(), 1);

        listing = generateListing( 1, 2, 0, HALF_HOUR * 2);
        listingRepository.put(listing.getId(), listing);
        Assert.assertEquals(listingRepository.getByStationId(1l).size(), 2);

        // Remove Existing
        listing = generateListing(listing.getId(), 1, 2, 0, HALF_HOUR * 2);
        listingRepository.delete(listing.getId());
        Assert.assertEquals(listingRepository.getByStationId(1l).size(), 1);
    }


    // A listing without a Program is possible.  We should be able to add it and search by it.  Also, remove it.
    @Test
    public void nullProgramTest(){
        ListingRepository listingRepository = new ListingRepository(SiriusObjectType.fromFriendlyName("Listing"));

        CRSListing listing = generateListing( 1, 100, 0, HALF_HOUR);
        listing.setProgramId(null);                                                                // null program
        listingRepository.put(listing.getId(), listing);
        Assert.assertEquals(listingRepository.getByStationId(1l).size(), 1);

        Collection<CRSListing> searchResult = listingRepository.getListings(1, new Date(0), new Date(4 * HALF_HOUR));
        Assert.assertEquals( searchResult.size(), 1);

        // Remove Existing
        listing = generateListing(listing.getId(), 1, 2, 0, 2 * HALF_HOUR);
        listingRepository.delete(listing.getId());
        Assert.assertEquals(listingRepository.getByStationId(1l).size(), 0);
    }


    private CRSListing generateListing(long listingId, long stationId, long programId, long start, long end) {
        return generateListing(listingId, stationId, programId, new Date(start), new Date(end));
    }
    private CRSListing generateListing(long stationId, long programId, long start, long end) {
        return generateListing(stationId, programId, new Date(start), new Date(end));
    }
    private CRSListing generateListing(long stationId, long programId, Date start, Date end) {
        return generateListing(counter++, stationId, programId, start, end);
    }

    private CRSListing generateListing(long listingId, long stationId, long programId, Date start, Date end) {

        CRSProgram crsProgram = new CRSProgram();
        crsProgram.setId(programId);
        crsProgram.setTitle("Title-" + programId);
        crsProgram.setGridTitle("GridTitle-" + programId);
        crsProgram.setCategory(ProgramCategory.Movie);

        CRSListing crsListing = new CRSListing();
        crsListing.setId(listingId);
        crsListing.setStationId(stationId);
        crsListing.setStartTime(start.getTime());
        crsListing.setEndTime(end.getTime());
        crsListing.setCrsAiringType("Live" );
        crsListing.setCaptionType("CaptionType-" + listingId);
        crsListing.setHdLevel("HdLevel-" + listingId);
        crsListing.setProgramId(crsProgram.getId());

        return crsListing;
    }

}
