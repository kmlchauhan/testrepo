package com.theplatform.web.tv.gws.sirius.repository.utils;

import com.theplatform.web.tv.gws.sirius.model.CRSChannel;
import org.fest.assertions.api.Assertions;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

public class OpenSetSecondaryIndexUnitTest {

    @Test
    public void testPutGet() {
        Object obj1 = new Object();
        Object obj2 = new Object();
        OpenSetSecondaryIndex<Object> index = new OpenSetSecondaryIndex<>();

        index.put(Long.valueOf(1l), obj1);
        index.put(Long.valueOf(2l), obj2);

        assertTrue(index.getByIndexKey(Long.valueOf(1l)).contains(obj1));
        assertTrue(index.getByIndexKey(1l).contains(obj1));

        assertTrue(index.getByIndexKey(Long.valueOf(2l)).contains(obj2));
        assertTrue(index.getByIndexKey(2l).contains(obj2));
    }

    @Test
    public void testGet_nullSafety() {
        OpenSetSecondaryIndex<Object> index = new OpenSetSecondaryIndex<>();
        Assertions.assertThat(index.getByIndexKey(null)).isEmpty();
        Assertions.assertThat(index.getByIndexKey(1L)).isEmpty();
    }

    @Test
    public void testRemove_nullSafety() {
        OpenSetSecondaryIndex<Object> index = new OpenSetSecondaryIndex<>();
        index.remove(1L, null);
        index.remove(2L, new Object());
        index.put(3L, new Object());
        index.remove(3L, null);
    }

    @Test
    public void testRemove_noOrphanedKeys() {
        OpenSetSecondaryIndex<CRSChannel> locationIndex = new OpenSetSecondaryIndex();

        CRSChannel crsChannel1 =createChannel(9001L,9000L);
        CRSChannel crsChannel2 =createChannel(1001L,1000L);
        CRSChannel crsChannel3 =createChannel(1002L,1000L);

        Assertions.assertThat( locationIndex.getKeys() ).isEmpty();

        locationIndex.put( crsChannel1.getLocationId(), crsChannel1 );
        locationIndex.put( crsChannel2.getLocationId(), crsChannel2 );
        locationIndex.put( crsChannel3.getLocationId(), crsChannel3 );
        Assertions.assertThat( locationIndex.getKeys().size() ).isEqualTo(2);
        Assertions.assertThat( locationIndex.getKeys() ).contains( 1000L, 9000L);

        locationIndex.remove( crsChannel2.getLocationId(),crsChannel2);
        Assertions.assertThat( locationIndex.getKeys().size() ).isEqualTo(2);
        Assertions.assertThat( locationIndex.getKeys() ).contains( 1000L, 9000L);

        locationIndex.remove(crsChannel3.getLocationId(), crsChannel3);
        Assertions.assertThat( locationIndex.getKeys().size()).isEqualTo(1);    // Only 1 !!! - We should NOT include the orphanned key
        Assertions.assertThat( locationIndex.getKeys() ).contains( 9000L);

    }

    private CRSChannel createChannel(long channalId, long locationId){
        CRSChannel crsChannel = new CRSChannel();
        crsChannel.setId(channalId);
        crsChannel.setLocationId(locationId);
        return crsChannel;
    }



}

