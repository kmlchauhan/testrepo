package com.theplatform.web.tv.gws.ingest.dispatcher.serialization;


import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.serializer.ProgramSerializer;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ProgramFactoryTest {

    @Test
    public void test() throws InvalidProtocolBufferException {
        CRSProgram program = new CRSProgram();
        program.setAdult(Boolean.TRUE);
        program.setCategory(ProgramCategory.Other);
        program.setEpisodeTitle("foo");
        program.setGridTitle("foo grid title");
        program.setSeriesId(2L);
        program.setSportsSubtitle("sports subtitle");
        program.setTagIds(new long[]{3L, 4L});
        program.setTitle("title");
        program.setType(ProgramType.Movie);

        ProgramSerializer factory = new ProgramSerializer(SiriusObjectType.fromFriendlyName("Program"));
        CRSProgram actual
                = factory.unmarshallPayload(factory.marshallPayload(program).toByteArray());

        Assert.assertEquals(actual.getAdult(), program.getAdult());
        Assert.assertEquals(actual.getCategory(), program.getCategory());
        Assert.assertEquals(actual.getEpisodeTitle(), program.getEpisodeTitle());
        Assert.assertEquals(actual.getGridTitle(), program.getGridTitle());
        Assert.assertEquals(actual.getSeriesId(), program.getSeriesId());
        Assert.assertEquals(actual.getSportsSubtitle(), program.getSportsSubtitle());
        Assert.assertEquals(actual.getTagIds(), program.getTagIds());
        Assert.assertEquals(actual.getTitle(), program.getTitle());
        Assert.assertEquals(actual.getType(), program.getType());
    }
}
