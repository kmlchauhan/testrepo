package com.theplatform.web.tv.gws.service.common.converter;

import com.google.common.collect.Lists;
import com.theplatform.web.tv.contentresolution.api.objects.CompanyAssociationInfo;
import com.theplatform.web.tv.gws.TestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSCompany;
import com.theplatform.web.tv.gws.sirius.model.CRSStationCompany;
import com.theplatform.web.tv.gws.sirius.repository.CompanyRepository;
import junit.framework.Assert;
import org.mockito.Mockito;
import org.testng.annotations.Test;

public class CRSStationCompanyToCompanyAssociationConverterTest {

    @Test
    public void convertValidateOrder(){
        CRSStationCompany one = createCrsStationCompany(5558050156527740123l, 500l, 500l, "Association");
        CRSStationCompany two = createCrsStationCompany(200l, 300l, 600l, "Association");
        CRSStationCompany three = createCrsStationCompany(300l, 600l, 300l, "Association");
        CRSStationCompany four = createCrsStationCompany(400l, 400l, 400l, "Association");
        CRSStationCompany five = createCrsStationCompany(32447696123l, 600l, 600l, "Association");

        CompanyRepository companyRepository = Mockito.mock(CompanyRepository.class);
        CRSCompany crsCompany = new CRSCompany(100);
        crsCompany.setTitle("The Company");
        Mockito.when(companyRepository.get(Mockito.anyLong())).thenReturn(crsCompany);


        CRSStationCompanyToCompanyAssociationConverter converter = new CRSStationCompanyToCompanyAssociationConverter();
        converter.setCompanyRepository(companyRepository);
        java.util.List<CompanyAssociationInfo> companyAssociationInfos = converter.convert( Lists.newArrayList(three, one, two, five, four), TestUtil.MERLIN_ID_HELPER);

        CompanyAssociationInfo previous = null;
        for (CompanyAssociationInfo companyAssociationInfo : companyAssociationInfos){
            if (previous != null){
                Assert.assertTrue(previous.getStationCompanyId().getId() < companyAssociationInfo.getStationCompanyId().getId());
            }
            previous = companyAssociationInfo;
        }


    }

    private CRSStationCompany createCrsStationCompany( long id, long stationId, long companyId, String type){
        CRSStationCompany sca = new CRSStationCompany(id);
        sca.setCompanyId(companyId);
        sca.setStationId(stationId);
        sca.setAssociationType(type);
        return sca;
    }


}