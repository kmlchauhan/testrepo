package com.theplatform.web.tv.gws.service.contentresolution;

import com.comcast.compass.availability.common.domain.Availabilities;
import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.module.exception.BadParameterException;
import com.theplatform.web.tv.combine.commons.MerlinService;
import com.theplatform.web.tv.gws.uri.UrnUtil;
import com.theplatform.web.tv.gws.sirius.repository.MerlinDAO;
import com.theplatform.web.tv.gws.service.common.logic.ScopedAvailabilities;
import com.theplatform.web.tv.gws.service.common.logic.Scope;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * Created by jcoelho on 6/23/13.
 */
public class ContentResolutionValidatorTest {

    private static final URI NON_REGION_AVAILABILITY_TAG_URI = UrnUtil.generateUrn(1234L, MerlinService.LINEAR, MerlinEntityType.STATION).toUri();

    @Mock
    private MerlinDAO merlinDao;
    private ContentResolutionHelper testedObject;

    @BeforeClass
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        testedObject = new ContentResolutionHelper();
        testedObject.setMerlinDAO(merlinDao);
    }

    @Test(expectedExceptions = BadParameterException.class)
    public void validateContentNullAvailabilityResolution_expectBadParameterException() {
        testedObject.validateAvailabilityResolution(ScopedAvailabilities.create(null));
    }

    @Test(expectedExceptions = BadParameterException.class)
    public void validateContentAvailabilityResolutionMissingRegionTag_expectBadParameterException() {

        AvailabilityResolution availabilityResolutionMisingRegionOrTag = new AvailabilityResolution();
        List<Availabilities> availabilityGroups = new ArrayList<Availabilities>();
        Availabilities a1 = new Availabilities();
        a1.setScope(Scope.STREAM.name());
        List<URI> availabilityIds = new ArrayList<URI>();
        availabilityIds.add(NON_REGION_AVAILABILITY_TAG_URI);
        a1.setAvailabilityIds(availabilityIds);
        availabilityGroups.add(a1);
        availabilityResolutionMisingRegionOrTag.setAvailabilityGroups(availabilityGroups);
        ScopedAvailabilities scopedAvailabilities = ScopedAvailabilities.create(availabilityResolutionMisingRegionOrTag);
        testedObject.validateAvailabilityResolution(scopedAvailabilities);
    }

}
