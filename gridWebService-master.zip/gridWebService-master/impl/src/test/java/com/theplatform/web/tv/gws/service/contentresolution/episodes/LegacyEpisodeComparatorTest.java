package com.theplatform.web.tv.gws.service.contentresolution.episodes;

import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

public class LegacyEpisodeComparatorTest {

    private static final LegacyEpisodeComparator comparator = new LegacyEpisodeComparator();

    @Test
    public void testSeasonNumberPrimacy() {
        CRSProgram e2 = EpisodeFactory.create();
        CRSProgram e1 = EpisodeFactory.create(e2.getSeriesId());

        e1.setTvSeasonNumber(1);
        e2.setTvSeasonNumber(2);

        e1.setTvSeasonEpisodeNumber(11);
        e2.setTvSeasonEpisodeNumber(1);

        // need to make sure we're not getting the correct ordering due to
        // the Comparator's fallback comparison on ids
        assertThat(e1.getId()).isGreaterThan(e2.getId());

        assertThat(comparator.compare(e1, e2)).isNegative();
        assertThat(comparator.compare(e2, e1)).isPositive();
    }

    @Test
    public void testEpisodeNumberNoSeasonNumber() {
        CRSProgram e2 = EpisodeFactory.create();
        CRSProgram e1 = EpisodeFactory.create(e2.getSeriesId());

        e1.setTvSeasonEpisodeNumber(1);
        e2.setTvSeasonEpisodeNumber(2);

        // need to make sure we're not getting the correct ordering due to
        // the Comparator's fallback comparison on ids
        assertThat(e1.getId()).isGreaterThan(e2.getId());

        assertThat(comparator.compare(e1, e2)).isNegative();
    }

    @Test
    public void testEpisodeNumberSameSeasonNumber() {
        CRSProgram e2 = EpisodeFactory.create();
        CRSProgram e1 = EpisodeFactory.create(e2.getSeriesId());

        e1.setTvSeasonNumber(3);
        e2.setTvSeasonNumber(3);

        e1.setTvSeasonEpisodeNumber(2);
        e2.setTvSeasonEpisodeNumber(1);

        // need to make sure we're not getting the correct ordering due to
        // the Comparator's fallback comparison on ids
        assertThat(e1.getId()).isGreaterThan(e2.getId());

        assertThat(comparator.compare(e1, e2)).isPositive();
    }

    @Test
    public void testEpisodeTitle() {
        CRSProgram e2 = EpisodeFactory.create();
        CRSProgram e1 = EpisodeFactory.create(e2.getSeriesId());

        e1.setEpisodeTitle("Season 1 Episode 2");
        e2.setEpisodeTitle("Season 1 Episode 4");

        // need to make sure we're not getting the correct ordering due to
        // the Comparator's fallback comparison on ids
        assertThat(e1.getId()).isGreaterThan(e2.getId());

        assertThat(comparator.compare(e1, e2)).isNegative();
    }

    @Test
    public void testIdTiebreaker() {
        CRSProgram e1 = EpisodeFactory.create();
        CRSProgram e2 = EpisodeFactory.create(e1.getSeriesId());

        e1.setTvSeasonNumber(1);
        e2.setTvSeasonNumber(1);

        assertThat(e1.getId()).isLessThan(e2.getId());

        assertThat(comparator.compare(e1, e2)).isNegative();
    }

    @Test(expectedExceptions = {IllegalArgumentException.class})
    public void testMustBeEpisodes() {
        CRSProgram e1 = EpisodeFactory.create();
        CRSProgram e2 = EpisodeFactory.create(e1.getSeriesId());

        e2.setType(ProgramType.Advertisement);

        comparator.compare(e1, e2);
    }

    @Test(expectedExceptions = {IllegalArgumentException.class})
    public void testMustBeSameSeries() {
        CRSProgram e1 = EpisodeFactory.create();
        CRSProgram e2 = EpisodeFactory.create();

        comparator.compare(e1, e2);
    }

    @Test
    public void testEpisodesWithSeasonNumbersComeBeforeThoseWithout() {
        CRSProgram e2 = EpisodeFactory.create();
        CRSProgram e1 = EpisodeFactory.create(e2.getSeriesId());

        e1.setTvSeasonNumber(1);
        e1.setTvSeasonEpisodeNumber(3);

        e2.setTvSeasonEpisodeNumber(2);

        // need to make sure we're not getting the correct ordering due to
        // the Comparator's fallback comparison on ids
        assertThat(e1.getId()).isGreaterThan(e2.getId());

        assertThat(comparator.compare(e1, e2)).isNegative();
        assertThat(comparator.compare(e2, e1)).isPositive();
    }

    @Test
    public void testEpisodesWithEpisodeNumbersComeBeforeThoseWithout() {
        CRSProgram e2 = EpisodeFactory.create();
        CRSProgram e1 = EpisodeFactory.create(e2.getSeriesId());

        e1.setTvSeasonNumber(1);
        e2.setTvSeasonNumber(1);

        e1.setTvSeasonEpisodeNumber(1);

        // need to make sure we're not getting the correct ordering due to
        // the Comparator's fallback comparison on ids
        assertThat(e1.getId()).isGreaterThan(e2.getId());

        assertThat(comparator.compare(e1, e2)).isNegative();
        assertThat(comparator.compare(e2, e1)).isPositive();
    }

    @Test
    public void testEpisodesWithTitlesComeBeforeThoseWithout() {
        CRSProgram e2 = EpisodeFactory.create();
        CRSProgram e1 = EpisodeFactory.create(e2.getSeriesId());

        e1.setEpisodeTitle("Season 1; Episode 2");

        // need to make sure we're not getting the correct ordering due to
        // the Comparator's fallback comparison on ids
        assertThat(e1.getId()).isGreaterThan(e2.getId());

        assertThat(comparator.compare(e1, e2)).isNegative();
        assertThat(comparator.compare(e2, e1)).isPositive();
    }

    @Test
    public void testPartNumberIsTieBreaker() {
        CRSProgram e2 = EpisodeFactory.create();
        CRSProgram e1 = EpisodeFactory.create(e2.getSeriesId(), 1, 1);

        e2.setTvSeasonNumber(e1.getTvSeasonNumber());
        e2.setTvSeasonEpisodeNumber(e1.getTvSeasonEpisodeNumber());

        e1.setPartNumber(2);
        e2.setPartNumber(1);

        // need to make sure we're not getting the correct ordering due to
        // the Comparator's fallback comparison on ids
        assertThat(e1.getId()).isGreaterThan(e2.getId());

        assertThat(comparator.compare(e1, e2)).isPositive();
        assertThat(comparator.compare(e2, e1)).isNegative();
    }

    @Test
    public void testEpisodesWithPartNumbersComeBeforeThoseWithout() {
        CRSProgram e2 = EpisodeFactory.create();
        CRSProgram e1 = EpisodeFactory.create(e2.getSeriesId(), 1, 1);

        e2.setTvSeasonNumber(e1.getTvSeasonNumber());
        e2.setTvSeasonEpisodeNumber(e1.getTvSeasonEpisodeNumber());

        e1.setPartNumber(1);
        e2.setPartNumber(null);

        // need to make sure we're not getting the correct ordering due to
        // the Comparator's fallback comparison on ids
        assertThat(e1.getId()).isGreaterThan(e2.getId());

        assertThat(comparator.compare(e1, e2)).isNegative();
        assertThat(comparator.compare(e2, e1)).isPositive();
    }
}
