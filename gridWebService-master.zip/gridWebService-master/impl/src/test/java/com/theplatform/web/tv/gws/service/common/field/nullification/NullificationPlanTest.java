package com.theplatform.web.tv.gws.service.common.field.nullification;

import com.theplatform.web.tv.gws.service.common.field.descriptor.ApiClassDescriptor;
import org.apache.commons.collections4.CollectionUtils;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;

import static com.theplatform.web.tv.gws.service.common.field.FieldFilterTestClasses.*;
import static org.fest.assertions.api.Assertions.assertThat;

public class NullificationPlanTest {

    private Primitives runPrimitivesPlan(NullificationMode type, String fields) {
        ApiClassDescriptor descriptor = ApiClassDescriptor.forClass(Primitives.class);
        SelectedProperties properties = new SelectedProperties(type, fields);
        NullificationPlan plan = new NullificationPlan(descriptor, properties);

        Primitives primitives = new Primitives();
        primitives.setObjectInt(1);
        primitives.setPrimitiveInt(2);
        plan.nullifyFields(primitives);

        return primitives;
    }

    @Test
    public void testPrimitives_primitiveSkippedWhenExplicitlyNullified() {
        Primitives primitives = runPrimitivesPlan(NullificationMode.NULLIFY_SELECTED_PROPERTIES, "objectInt,primitiveInt");
        assertThat(primitives.getObjectInt()).isNull();
    }

    @Test
    public void testPrimitives_primitiveSkippedWhenOmitted() {
        Primitives primitives = runPrimitivesPlan(NullificationMode.PRESERVE_SELECTED_PROPERTIES, "objectInt");
        assertThat(primitives.getObjectInt()).isNotNull();
    }

    @Test
    public void testPrimitiveArray() {
        ApiClassDescriptor descriptor = ApiClassDescriptor.forClass(PrimitiveArray.class);
        SelectedProperties properties = new SelectedProperties(NullificationMode.NULLIFY_SELECTED_PROPERTIES, "primitiveArray");
        NullificationPlan plan = new NullificationPlan(descriptor, properties);

        PrimitiveArray primitiveArray = new PrimitiveArray();
        primitiveArray.setPrimitiveArray(new int[] {1, 2});

        plan.nullifyFields(primitiveArray);
        assertThat(primitiveArray.getPrimitiveArray()).isNull();
    }

    private Nested1 runNested1Plan(NullificationMode type, String props) {
        Nested3 nested3 = new Nested3();
        nested3.setNested3Prop("foo");

        Nested2 nested2 = new Nested2();
        nested2.setNested2Prop("foo");
        nested2.setNested3(nested3);

        Nested1 nested1 = new Nested1();
        nested1.setNested1Prop("foo");
        nested1.setNested2(nested2);

        ApiClassDescriptor descriptor = ApiClassDescriptor.forClass(Nested1.class);
        SelectedProperties properties = new SelectedProperties(type, props);
        NullificationPlan plan = new NullificationPlan(descriptor, properties);
        plan.nullifyFields(nested1);

        return nested1;
    }

    @Test
    public void testNestedProperties_nullifyNestedSimpleProperty() {
        Nested1 nested1 = runNested1Plan(NullificationMode.NULLIFY_SELECTED_PROPERTIES, "nested2.nested3.nested3Prop");

        assertThat(nested1.getNested1Prop()).isNotNull();
        assertThat(nested1.getNested2()).isNotNull();
        assertThat(nested1.getNested2().getNested2Prop()).isNotNull();
        assertThat(nested1.getNested2().getNested3()).isNotNull();
        assertThat(nested1.getNested2().getNested3().getNested3Prop()).isNull();
    }

    @Test
    public void testNestedProperties_preserveNestedSimpleProperty() {
        Nested1 nested1 = runNested1Plan(NullificationMode.PRESERVE_SELECTED_PROPERTIES, "nested2.nested3.nested3Prop");

        assertThat(nested1.getNested1Prop()).isNull();
        assertThat(nested1.getNested2()).isNotNull();
        assertThat(nested1.getNested2().getNested2Prop()).isNull();
        assertThat(nested1.getNested2().getNested3()).isNotNull();
        assertThat(nested1.getNested2().getNested3().getNested3Prop()).isNotNull();
    }

    @Test
    public void testNestedProperties_nullifyNestedObjectProperty() {
        Nested1 nested1 = runNested1Plan(NullificationMode.NULLIFY_SELECTED_PROPERTIES, "nested2.nested3");

        assertThat(nested1.getNested1Prop()).isNotNull();
        assertThat(nested1.getNested2()).isNotNull();
        assertThat(nested1.getNested2().getNested2Prop()).isNotNull();
        assertThat(nested1.getNested2().getNested3()).isNull();
    }

    @Test
    public void testNestedProperties_preserveNestedObjectProperty() {
        Nested1 nested1 = runNested1Plan(NullificationMode.PRESERVE_SELECTED_PROPERTIES, "nested2.nested3");

        assertThat(nested1.getNested1Prop()).isNull();
        assertThat(nested1.getNested2()).isNotNull();
        assertThat(nested1.getNested2().getNested2Prop()).isNull();
        assertThat(nested1.getNested2().getNested3()).isNotNull();
        assertThat(nested1.getNested2().getNested3().getNested3Prop()).isNotNull();
    }

    private Collection2 buildCollection2() {
        Collection2 collection2 = new Collection2();
        collection2.setCollection2Prop("foo");
        collection2.setStringList(Collections.singletonList("foo"));
        collection2.setItemList(Collections.singletonList(new Item("foo")));
        return collection2;
    }


    private Collection1 runCollection1Plan(NullificationMode type, String props) {
        Collection1 collection1 = new Collection1();
        collection1.setCollection2(buildCollection2());
        collection1.setCollection2Array(new Collection2[] {buildCollection2()});
        collection1.setCollection2List(Collections.singletonList(buildCollection2()));
        collection1.setItemCollection(Collections.singleton(new Item("foo")));
        collection1.setItemList(Collections.singletonList(new Item("foo")));
        collection1.setStringList(Arrays.asList("foo", "bar"));

        ApiClassDescriptor descriptor = ApiClassDescriptor.forClass(Collection1.class);
        SelectedProperties properties = new SelectedProperties(type, props);
        NullificationPlan plan = new NullificationPlan(descriptor, properties);
        plan.nullifyFields(collection1);

        return collection1;
    }

    @Test
    public void testCollections_memberPropsNullified() {
        Collection1 collection1 = runCollection1Plan(
            NullificationMode.NULLIFY_SELECTED_PROPERTIES,
            "itemCollection.itemProp,collection2Array.collection2Prop,collection2List.collection2Prop"
        );

        // stuff that shouldn't have been nullified
        assertThat(collection1.getCollection2()).isNotNull();
        assertThat(collection1.getItemList()).isNotNull();
        assertThat(collection1.getStringList()).isNotNull();

        // should have a single property nullified

        assertThat(collection1.getItemCollection()).hasSize(1);
        Item collectionMember = CollectionUtils.extractSingleton(collection1.getItemCollection());
        assertThat(collectionMember.getItemProp()).isNull();

        assertThat(collection1.getCollection2Array()).hasSize(1);
        Collection2 arrayMember = collection1.getCollection2Array()[0];
        assertThat(arrayMember.getCollection2Prop()).isNull();
        assertThat(arrayMember.getItemList()).isNotNull();
        assertThat(arrayMember.getStringList()).isNotNull();
    }

    @Test
    public void testCollections_memberPropsPreserved() {
        Collection1 collection1 = runCollection1Plan(
            NullificationMode.PRESERVE_SELECTED_PROPERTIES,
            "itemCollection.itemProp,collection2Array.collection2Prop,collection2List.collection2Prop"
        );

        // stuff that should have been nullified
        assertThat(collection1.getCollection2()).isNull();
        assertThat(collection1.getItemList()).isNull();
        assertThat(collection1.getStringList()).isNull();

        // should have a single property preserved

        assertThat(collection1.getItemCollection()).hasSize(1);
        Item collectionMember = CollectionUtils.extractSingleton(collection1.getItemCollection());
        assertThat(collectionMember.getItemProp()).isNotNull();

        assertThat(collection1.getCollection2Array()).hasSize(1);
        Collection2 arrayMember = collection1.getCollection2Array()[0];
        assertThat(arrayMember.getCollection2Prop()).isNotNull();
        assertThat(arrayMember.getItemList()).isNull();
        assertThat(arrayMember.getStringList()).isNull();

        assertThat(collection1.getCollection2List()).hasSize(1);
        Collection2 listMember = CollectionUtils.extractSingleton(collection1.getCollection2List());
        assertThat(listMember.getCollection2Prop()).isNotNull();
        assertThat(listMember.getItemList()).isNull();
        assertThat(listMember.getStringList()).isNull();
    }

    @Test
    public void testCollections_nestedCollectionsNullified() {
        Collection1 collection1 = runCollection1Plan(
            NullificationMode.NULLIFY_SELECTED_PROPERTIES,
            "collection2List.itemList.itemProp"
        );

        assertThat(collection1.getCollection2List()).hasSize(1);
        Collection2 listMember = CollectionUtils.extractSingleton(collection1.getCollection2List());
        assertThat(listMember.getCollection2Prop()).isNotNull();
        assertThat(listMember.getStringList()).isNotNull();
        assertThat(listMember.getItemList()).hasSize(1);

        Item item = CollectionUtils.extractSingleton(listMember.getItemList());
        assertThat(item.getItemProp()).isNull();
    }

    @Test
    public void testCollections_nestedCollectionsPreserved() {
        Collection1 collection1 = runCollection1Plan(
            NullificationMode.PRESERVE_SELECTED_PROPERTIES,
            "collection2List.itemList.itemProp"
        );

        assertThat(collection1.getCollection2List()).hasSize(1);
        Collection2 listMember = CollectionUtils.extractSingleton(collection1.getCollection2List());
        assertThat(listMember.getCollection2Prop()).isNull();
        assertThat(listMember.getStringList()).isNull();
        assertThat(listMember.getItemList()).hasSize(1);

        Item item = CollectionUtils.extractSingleton(listMember.getItemList());
        assertThat(item.getItemProp()).isNotNull();
    }

    private NullificationPlan buildInheritancePlan(NullificationMode type, String props) {
        ApiClassDescriptor descriptor = ApiClassDescriptor.forClass(RootInheritance.class);
        SelectedProperties properties = new SelectedProperties(type, props);
        return new NullificationPlan(descriptor, properties);
    }

    @Test
    public void testInheritance_nullifyInterface() {
        NullificationPlan plan = buildInheritancePlan(NullificationMode.NULLIFY_SELECTED_PROPERTIES, "interfaceObject.baz");

        Extension1 extension1 = new Extension1();
        extension1.setFoo(1);
        extension1.setBar("bar");
        RootInheritance root = new RootInheritance();
        root.setInterfaceObject(extension1);

        plan.nullifyFields(root);

        assertThat(extension1.getFoo()).isNotNull();
        assertThat(extension1.getBar()).isNotNull();
    }

    @Test
    public void testInheritance_preserveInterface() {
        NullificationPlan plan = buildInheritancePlan(NullificationMode.PRESERVE_SELECTED_PROPERTIES, "interfaceObject.foo,interfaceObject.baz");

        Extension1 extension1 = new Extension1();
        extension1.setFoo(1);
        extension1.setBar("bar");
        RootInheritance root = new RootInheritance();
        root.setInterfaceObject(extension1);

        plan.nullifyFields(root);

        assertThat(extension1.getFoo()).isNotNull();
        assertThat(extension1.getBar()).isNull();
    }

    @Test
    public void testInheritance_preserveClass() {
        NullificationPlan plan = buildInheritancePlan(NullificationMode.PRESERVE_SELECTED_PROPERTIES, "baseObject.foo,baseObject.other");

        Extension2 extension2 = new Extension2();
        extension2.setFoo(1);
        extension2.setBar("bar");
        extension2.setBaz("baz");
        RootInheritance root = new RootInheritance();
        root.setBaseObject(extension2);

        plan.nullifyFields(root);

        assertThat(extension2.getFoo()).isNotNull();
        assertThat(extension2.getBar()).isNull();
        assertThat(extension2.getBaz()).isNull();
    }
}
