package com.theplatform.web.tv.gws.ingest.dispatcher.serialization;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.sirius.model.CRSLocator;
import com.theplatform.web.tv.gws.sirius.model.CRSStream;
import com.theplatform.web.tv.gws.sirius.serializer.StreamSerializer;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashSet;
import java.util.Set;

public class StreamFactoryTest {

    @Test
    public void testStreamFactoryNoLocators() throws InvalidProtocolBufferException {
        CRSStream stream = new CRSStream();
        stream.setId(1234L);
        stream.setStationId(1234L);
		stream.setPreferredRMType("Default");
		StreamSerializer streamFactory = new StreamSerializer(SiriusObjectType.fromFriendlyName("Stream"));

        CRSStream retrievedStream
                = streamFactory.unmarshallPayload(streamFactory.marshallPayload(stream).toByteArray());
        
        Assert.assertEquals(stream, retrievedStream);
    }
    
    @Test
    public void testStreamFactoryOneLocator() throws InvalidProtocolBufferException {
    	
    	CRSLocator locator1 = new CRSLocator();
    	locator1.setFormat("test format");
    	locator1.setLocatorURI("locator uri");
    	locator1.setDigicableId(1234);
    	locator1.setWidth(1234);
    	locator1.setHeight(1234);
    	locator1.setBitrate(1234L);
    	locator1.setProtectionScheme("protection scheme");
    	locator1.setCodec("codec");
    	
    	CRSLocator locator2 = new CRSLocator();
    	locator2.setFormat("test format2");
    	locator2.setLocatorURI("locator uri2");
    	locator2.setDigicableId(2);
    	locator2.setWidth(2);
    	locator2.setHeight(2);
    	locator2.setBitrate(2222L);
    	locator2.setProtectionScheme("protection scheme2");
    	locator2.setCodec("codec2");
    	
    	Set<CRSLocator> locators = new HashSet<CRSLocator>();
    	locators.add(locator1);
    	locators.add(locator2);
    	
        CRSStream stream = new CRSStream();
        stream.setId(1234L);
        stream.setStationId(1234L);
		stream.setPreferredRMType("Default");

        StreamSerializer streamFactory = new StreamSerializer(SiriusObjectType.fromFriendlyName("Stream"));
        CRSStream retrievedStream
                = streamFactory.unmarshallPayload(streamFactory.marshallPayload(stream).toByteArray());
        
        Assert.assertEquals(stream, retrievedStream);
    }
    
    @Test
    public void testStreamFactoryMultipleLocators() throws InvalidProtocolBufferException {
    	
    	CRSLocator locator1 = new CRSLocator();
    	locator1.setFormat("test format");
    	locator1.setLocatorURI("locator uri");
    	locator1.setDigicableId(1234);
    	locator1.setWidth(1234);
    	locator1.setHeight(1234);
    	locator1.setBitrate(1234L);
    	locator1.setProtectionScheme("protection scheme");
    	locator1.setCodec("codec");
    	
    	CRSLocator locator2 = new CRSLocator();
    	locator2.setFormat("test format2");
    	locator2.setLocatorURI("locator uri2");
    	locator2.setDigicableId(2);
    	locator2.setWidth(2);
    	locator2.setHeight(2);
    	locator2.setBitrate(2222L);
    	locator2.setProtectionScheme("protection scheme2");
    	locator2.setCodec("codec2");
    	
    	Set<CRSLocator> locators = new HashSet<CRSLocator>();
    	locators.add(locator1);
    	locators.add(locator2);
    	
        CRSStream stream = new CRSStream();
        stream.setId(1234L);
        stream.setStationId(1234L);
		stream.setPreferredRMType("Default");

        StreamSerializer streamFactory = new StreamSerializer(SiriusObjectType.fromFriendlyName("Stream"));
        CRSStream retrievedStream
                = streamFactory.unmarshallPayload(streamFactory.marshallPayload(stream).toByteArray());
        
        Assert.assertEquals(stream, retrievedStream);
    }
	
}
