package com.theplatform.web.tv.gws;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.commons.job.api.data.objects.ServiceState;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.data.tv.linear.api.data.objects.*;
import com.theplatform.data.tv.offer.api.data.objects.AvailabilityTag;
import com.theplatform.data.tv.offer.api.data.objects.ContentAvailability;
import com.theplatform.data.tv.offer.api.data.objects.ProductContext;
import com.theplatform.data.tv.partner.commons.api.data.objects.Partner;
import com.theplatform.data.tv.sports.api.data.objects.Game;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.web.tv.contentresolution.api.objects.TrendingProgram;

/**
 * Created by pdwinnell on 6/13/17.
 */
public class SiriusObjectTypeTestUtil {

    public static void unitTestInitialization(){

        SiriusObjectType.register("AvailabilityTag", AvailabilityTag.class, MerlinEntityType.AVAILABILITYTAG);
        SiriusObjectType.register("Channel", Channel.class, MerlinEntityType.CHANNEL);
        SiriusObjectType.register("Company", Company.class, MerlinEntityType.COMPANY);
        SiriusObjectType.register("ContentAvailability", ContentAvailability.class, MerlinEntityType.CONTENTAVAILABILITY);
        SiriusObjectType.register("EntityTag", Tag.class, MerlinEntityType.TAG);
        SiriusObjectType.register("Game", Game.class, MerlinEntityType.GAME);
        SiriusObjectType.register("Listing", Listing.class, MerlinEntityType.LISTING);
        SiriusObjectType.register("LinearTagAssociation", TagAssociation.class, MerlinEntityType.TAGASSOCIATION);
        SiriusObjectType.register("Locator", Locator.class, MerlinEntityType.LOCATOR);
        SiriusObjectType.register("Location", Location.class, MerlinEntityType.LOCATION);
        SiriusObjectType.register("Partner", Partner.class, MerlinEntityType.PARTNER);
        SiriusObjectType.register("Program", Program.class, MerlinEntityType.PROGRAM);
        SiriusObjectType.register("ProductContext", ProductContext.class, MerlinEntityType.PRODUCTCONTEXT);
        SiriusObjectType.register("ServiceState", ServiceState.class, MerlinEntityType.SERVICESTATE);
        SiriusObjectType.register("Station", Station.class, MerlinEntityType.STATION);
        SiriusObjectType.register("Stream", Stream.class, MerlinEntityType.STREAM);
        SiriusObjectType.register("StationCompany", StationCompany.class, MerlinEntityType.STATIONCOMPANY);

        SiriusObjectType.registerNonMerlinObjectType("TrendingPrograms");
    }


}
