package com.theplatform.web.tv.gws.service.common.converter;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;
import com.theplatform.web.tv.gws.SiriusObjectTypeTestUtil;
import com.theplatform.web.tv.gws.sirius.model.CRSStation;
import com.theplatform.web.tv.gws.sirius.model.CRSTagAssociation;
import com.theplatform.web.tv.gws.sirius.repository.LinearCollectionRepository;
import com.theplatform.web.tv.gws.sirius.repository.LinearTagAssociationRepository;
import com.theplatform.web.tv.gws.sirius.repository.StationCompanyRepository;
import com.theplatform.web.tv.gws.uri.IdForm;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.mockito.Mockito;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

public class CRSStationToStationInfoConverterTest {

    public static final String LINEAR_BASE_URL = "http://test.com/linearDataService";
    private static final Long STATION_ID = 100117l;

    private static int idCount = 100;

    private MerlinIdHelper merlinIdHelper = MerlinIdHelper.withDefaultIdForm(null,LINEAR_BASE_URL,null, null, null, IdForm.URN);

    private CRSStationToStationInfoConverter converter;
    private LinearTagAssociationRepository linearTagAssociationRepository;
    private StationCompanyRepository stationCompanyRepository;
    private CRSStationCompanyToCompanyAssociationConverter crsStationCompanyToCompanyAssociationConverter;

    private static final Long[] tagsCorrectOrder = {8888L, 9999L};

    @BeforeMethod
    public void setup(){
        SiriusObjectTypeTestUtil.unitTestInitialization();

        stationCompanyRepository = Mockito.mock(StationCompanyRepository.class);
        crsStationCompanyToCompanyAssociationConverter = Mockito.mock(CRSStationCompanyToCompanyAssociationConverter.class);

        converter = new CRSStationToStationInfoConverter();
        converter.setStationCompanyRepository(stationCompanyRepository);
        converter.setCrsStationCompanyToCompanyAssociationConverter(crsStationCompanyToCompanyAssociationConverter);
        linearTagAssociationRepository = new LinearTagAssociationRepository(SiriusObjectType.fromFriendlyName("LinearTagAssociation"));
        converter.setLinearTagAssociationRepository(linearTagAssociationRepository);
    }


    @Test
    public void convert_verifyFields() {
        CRSStation crsStation = createCRSStation();
        populateStationTags(linearTagAssociationRepository, tagsCorrectOrder, crsStation.getId());
        StationInfo stationInfo = converter.convert( crsStation, merlinIdHelper, null);
        assertAllButStreamsEqual( stationInfo, crsStation);
        Assert.assertEquals( stationInfo.getStream(), null);
    }

    @Test
    public void convert_verifyNoRecorderManager() {
        CRSStation crsStation = createCRSStation();
        populateStationTags(linearTagAssociationRepository, tagsCorrectOrder, crsStation.getId());

        StationInfo stationInfo = converter.convert( crsStation, merlinIdHelper, null);
        assertAllButStreamsEqual(stationInfo, crsStation);
        Assert.assertEquals( stationInfo.getRecorderManager(), null);
    }

    @Test
    public void convert_verifyRecorderManager() {
        String recorderManager = "comcast:RecorderManager:cdvr-c-rmID-ncs01";
        CRSStation crsStation = createCRSStation();
        populateStationTags(linearTagAssociationRepository, tagsCorrectOrder, crsStation.getId());
        StationInfo stationInfo = converter.convert( crsStation, merlinIdHelper, recorderManager);
        assertAllButStreamsEqual( stationInfo, crsStation);
        Assert.assertEquals( stationInfo.getRecorderManager(), recorderManager);
    }

    private void assertAllButStreamsEqual(StationInfo stationInfo, CRSStation crsStation){
        Assert.assertEquals( stationInfo.getStationId().getId(),  crsStation.getId());
        Assert.assertEquals( stationInfo.getCallsign(), crsStation.getCallSign());
        Assert.assertEquals( stationInfo.getTimeZone(), crsStation.getTimeZone());
        Assert.assertEquals( stationInfo.getExpirationDate().getTime(), crsStation.getExpirationDate());
        Assert.assertEquals( stationInfo.getTransientAssociatedStationId().getId(),  crsStation.getAssociatedStationId());
        Assert.assertEquals( stationInfo.getLanguage(), crsStation.getLanguage());
        Assert.assertEquals( stationInfo.getOtaChannelNumber(), new Integer(crsStation.getOtaChannelNumber()));
        Assert.assertEquals( stationInfo.getPayPerView(), crsStation.getPayPerView());
        Assert.assertEquals( stationInfo.getShortName(), crsStation.getShortName());
        Assert.assertEquals( stationInfo.getVod(), crsStation.getVod());

        // Check the tags
        if (CollectionUtils.isEmpty(linearTagAssociationRepository.getTagIds(stationInfo.getStationId().getId()))){
            // Station return an empty array for null
            assertEquals(stationInfo.getTagIds().size(),0);
        } else{
            Long actualTagIds[] = ArrayUtils.toObject(Muri.getIdsAsArray(stationInfo.getTagIds()));
            assertEquals(actualTagIds, tagsCorrectOrder);
        }
    }

    protected static void populateStationTags(LinearTagAssociationRepository linearTagAssociationRepository, Long[] tagsCorrectOrder, long stationId) {
        CRSTagAssociation crsTagAssociation_0 = new CRSTagAssociation(100L, tagsCorrectOrder[1], stationId);
        linearTagAssociationRepository.put(crsTagAssociation_0);
        CRSTagAssociation crsTagAssociation_1 = new CRSTagAssociation(101L, tagsCorrectOrder[0], stationId);
        linearTagAssociationRepository.put(crsTagAssociation_1);

    }

    protected static CRSStation createCRSStation(){
        CRSStation crsStation = new CRSStation();
        crsStation.setId(++idCount);
        crsStation.setCallSign("AMC");
        crsStation.setTimeZone("America/New_York");
        crsStation.setExpirationDate(System.currentTimeMillis());
        crsStation.setAssociatedStationId(STATION_ID);
        crsStation.setLanguage("ESP");
        crsStation.setOtaChannelNumber(++idCount);
        crsStation.setPayPerView(true);
        crsStation.setShortName("AMC Television");
        crsStation.setVod(true);
        crsStation.setEmergencyAlertSystemType("AlwaysDisplay");
        crsStation.setDigicableId(++idCount);
        crsStation.setOnScreenCallSign("Station_OCS");
        return crsStation;
    }


}
