package com.theplatform.web.tv.gws.service.common.aop.stats;

/**
 * Created by jcoelho on 5/22/13.
 */
public class TestClass {
    @CollectStats
    public void testMethod() {
        this.privateTestMethod();
    }

    @CollectStats
    public void privateTestMethod() {

    }

    @CollectStats(prefix = "Prefix")
    public void testMethod2() {
        this.privateTestMethod();
    }
}
