package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.CreditProto;
import com.theplatform.web.tv.gws.sirius.model.CRSCredit;

public class CreditSerializer extends AbstractSiriusObjectSerializer<CRSCredit> {

    public CreditSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    protected CRSCredit unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        CreditProto.CreditMessage.Builder message = CreditProto.CreditMessage.newBuilder().mergeFrom(bytes);
        CRSCredit crsCredit = new CRSCredit();
        crsCredit.setId(message.getId());
        crsCredit.setPersonId(message.getPersonId());
        crsCredit.setProgramId(message.getProgramId());
        return crsCredit;
    }

    @Override
    public ByteString marshallPayload(CRSCredit credit) {
        CreditProto.CreditMessage.Builder builder = CreditProto.CreditMessage.newBuilder();
        builder.setId(credit.getId());
        builder.setProgramId(credit.getProgramId());
        builder.setPersonId(credit.getPersonId());
        return builder.build().toByteString();
    }


}
