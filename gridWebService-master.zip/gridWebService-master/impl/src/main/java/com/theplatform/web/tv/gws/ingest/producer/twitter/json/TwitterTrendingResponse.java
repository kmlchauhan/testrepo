package com.theplatform.web.tv.gws.ingest.producer.twitter.json;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Collection-like wrapper for all of the {@link TwitterItem TwitterItems} parsed from a single JSON document.
 */
public class TwitterTrendingResponse implements Iterable<TwitterItem> {
    private final List<TwitterItem> items;

    public TwitterTrendingResponse() {
        this.items = new ArrayList<>();
    }

    public TwitterTrendingResponse(int size) {
        this.items = new ArrayList<>(size);
    }

    public List<TwitterItem> getItems() {
        return items;
    }

    void addItem(TwitterItem twitterItem) {
        this.items.add(twitterItem);
    }

    public int size() {
        return items.size();
    }

    @Override
    public Iterator<TwitterItem> iterator() {
        return items.iterator();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TwitterTrendingResponse)) return false;

        TwitterTrendingResponse response = (TwitterTrendingResponse) o;

        return items.equals(response.items);

    }

    @Override
    public int hashCode() {
        return items.hashCode();
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TwitterTrendingResponse{");
        sb.append("items=").append(items);
        sb.append('}');
        return sb.toString();
    }
}
