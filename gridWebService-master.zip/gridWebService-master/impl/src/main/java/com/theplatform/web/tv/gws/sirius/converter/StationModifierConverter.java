package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.linear.api.data.objects.RelatedStation;
import com.theplatform.data.tv.linear.api.data.objects.StationModifier;
import com.theplatform.web.tv.gws.sirius.model.CRSStationModifier;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class StationModifierConverter extends AbstractDataObjectConverter<StationModifier, CRSStationModifier> {

    @Override
    public CRSStationModifier convert(StationModifier stationModifier) {
        CRSStationModifier crsStationModifier = new CRSStationModifier(LocalUriConverter.convertUriToID(stationModifier.getId()));
        crsStationModifier.setStationId(LocalUriConverter.convertUriToID(stationModifier.getStationId()));
        crsStationModifier.setOwnerId(LocalUriConverter.convertUriToID(stationModifier.getOwnerId()));
        Map<String,Set<Long>> relatedStationsLookup = new HashMap<>();
        if (stationModifier.getRelatedStations()!=null) {
            for (RelatedStation relatedStation : stationModifier.getRelatedStations()) {
                if (!relatedStationsLookup.containsKey(relatedStation.getType())) {
                    relatedStationsLookup.put(relatedStation.getType(), new HashSet<Long>());
                }
                relatedStationsLookup.get(relatedStation.getType()).add(LocalUriConverter.convertUriToID(relatedStation.getStationId()));
            }
        }
        crsStationModifier.setRelatedStations(relatedStationsLookup);

        return crsStationModifier;
    }

}
