package com.theplatform.web.tv.gws.service.common.field.nullification;

import com.theplatform.web.tv.gws.service.common.field.descriptor.ApiClassDescriptor;
import com.theplatform.web.tv.gws.service.common.field.descriptor.ApiPropertyDescriptor;
import com.theplatform.web.tv.gws.service.common.field.nullification.operations.*;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A series of operations applied to a root "info" object to nullify unwanted properties.  The goal of this class
 * is to do as much work as possible at creation time to make the actual nullification operations fast.
 */
public class NullificationPlan {
    private final static Logger log = LoggerFactory.getLogger(NullificationPlan.class);

    /**
     * Nullification operations built from the properties {@link #selectedProperties selected by the caller}.  Note that
     * inverting {@link NullificationMode#PRESERVE_SELECTED_PROPERTIES} (determining which properties <i>should</i> be nullified)
     * is handled by the constructor.  This is simply the array of operations that needs to be executed.
     * <br><br>
     * Performance note: using an array instead of a List prevents the allocation of an Iterator instance when we loop
     * over the operations.  Sounds small but it adds up due to how frequently this class is called.
     */
    private final PropertyOperation[] operations;

    private final SelectedProperties selectedProperties;

    /**
     * Create a plan that nullifies/preserves the selected properties.
     * @param rootDescriptor ApiClassDescriptor for the root "info" object
     * @param selectedProperties properties to be nullified or preserved
     */
    public NullificationPlan(ApiClassDescriptor rootDescriptor, SelectedProperties selectedProperties) {
        this.selectedProperties = selectedProperties;

        if (log.isTraceEnabled()) {
            log.trace("Building NullificationPlan for {}", rootDescriptor.getType());
        }

        List<PropertyOperation> operations = new ArrayList<>();
        for (ApiPropertyDescriptor child : rootDescriptor.getChildren()) {
            PropertyOperation childOperation = build(child);
            if (childOperation != null) {
                operations.add(childOperation);
            }
        }

        this.operations = new PropertyOperation[operations.size()];
        operations.toArray(this.operations);
    }

    /**
     * Called when a property is {@link SelectedProperties#included(String) included}.
     * @param descriptor a descriptor for the property
     * @return a NullifyProperty instance or null if no operation should be applied
     */
    private PropertyOperation propertyMatched(ApiPropertyDescriptor descriptor) {

        // if the goal is to nullify a selected set of properties, create a NullifyProperty operation
        // since this property is in the set of properties that should be nullified.
        if (selectedProperties.getNullificationMode() == NullificationMode.NULLIFY_SELECTED_PROPERTIES) {
            if (log.isTraceEnabled()) {
                log.trace("Property {} will be nullified because it was matched", descriptor.getPath());
            }
            return new NullifyProperty(descriptor);
        }
        return null;
    }

    /**
     * Called when a property is {@link SelectedProperties#included(String) not included} and none
     * of {@link SelectedProperties#childrenIncluded(String) its children are included}.
     * @param descriptor a descriptor for the property
     * @return a NullifyProperty instance or null if no operation should be applied
     */
    private PropertyOperation propertyNotMatched(ApiPropertyDescriptor descriptor) {

        // if the goal is to preserve a selected set of properties, create a NullifyProperty operation
        // since this property wasn't in the set of properties that should be preserved.
        if (selectedProperties.getNullificationMode() == NullificationMode.PRESERVE_SELECTED_PROPERTIES) {
            if (log.isTraceEnabled()) {
                log.trace("Property {} will be nullified because it was not matched", descriptor.getPath());
            }

            return new NullifyProperty(descriptor);
        }
        return null;
    }

    private List<PropertyOperation> buildChildren(ApiPropertyDescriptor descriptor) {
        List<PropertyOperation> childOperations = new ArrayList<>();
        for (ApiPropertyDescriptor child : descriptor.getChildren()) {
            PropertyOperation childOperation = build(child);
            if (childOperation != null) {
                childOperations.add(childOperation);
            }
        }
        return childOperations;
    }

    /**
     * Create a {@link DelegateByType} that dispatches to the correct PropertyOperation based on the value
     * of the property that is encountered at runtime.  For example, if the ApiPropertyDescriptor is for a property
     * of type BaseFoo and both Foo1 and Foo2 extend BaseFoo, the returned DelegateByType instance will choose
     * which operations to execute based on whether the value of the property is a BaseFoo instance, Foo1 instance, or
     * Foo2 instance.
     *
     * @param descriptor descriptor for the property
     * @param operation PropertyOperation for the base type
     * @return a DelegateByType instance
     */
    private PropertyOperation delegateByType(ApiPropertyDescriptor descriptor, PropertyOperation operation) {
        if (log.isTraceEnabled()) {
            log.trace("Property {} has subtypes", descriptor.getPath());
        }

        // build a PropertyOperation for every possible subtype
        Map<Class<?>, PropertyOperation> map = new Object2ObjectOpenHashMap<>(descriptor.getSubTypes().values().size());
        for (ApiPropertyDescriptor subTypeDescriptor : descriptor.getSubTypes().values()) {
            List<PropertyOperation> subTypeChildOps = buildChildren(subTypeDescriptor);
            if (!subTypeChildOps.isEmpty()) {
                PropertyOperation subTypeOp = new ApplyOperations(subTypeChildOps);
                map.put(subTypeDescriptor.getType(), subTypeOp);
            }
        }

        return new DelegateByType(operation, map);
    }

    /**
     * Build a PropertyOperation that nullifies the select property, traverses the children of the property, or does nothing (null
     * return value).
     * @param descriptor an ApiPropertyDescriptor instance
     * @return a PropertyOperation or null if no operation should be performed on the property
     */
    private PropertyOperation build(ApiPropertyDescriptor descriptor) {
        // this ApiPropertyDescriptor was directly included, either to preserve it or nullify it
        if (selectedProperties.included(descriptor.getPath())) {
            return propertyMatched(descriptor);
        }
        // descendants of this property are included
        else if (selectedProperties.childrenIncluded(descriptor.getPath())) {
            if (log.isTraceEnabled()) {
                log.trace("Children of {} are included", descriptor.getPath());
            }

            // build children first
            List<PropertyOperation> childOperations = buildChildren(descriptor);

            if (childOperations.isEmpty() && !descriptor.hasSubtypes()) {
                return null;
            }

            PropertyOperation traverser = new ApplyOperations(childOperations);

            if (descriptor.hasSubtypes()) {
                traverser = delegateByType(descriptor, traverser);
            }

            return new ReadValue(descriptor, traverser);
        }
        // this property was not included.  in PRESERVE_SELECTED_PROPERTIES we need to nullify the property.  in
        // NULLIFY_SELECTED_PROPERTIES we don't need to do anything
        else {
            return propertyNotMatched(descriptor);
        }
    }

    /**
     * Apply a pre-computed list of nullification operations to the target.  The target should be an instance of the
     * {@link ApiClassDescriptor type used to create this instance}.
     * @param target possibly null target
     */
    public void nullifyFields(Object target) {
        if (target == null) {
            return;
        }

        for (PropertyOperation current : this.operations) {
            current.apply(target);
        }
    }
}
