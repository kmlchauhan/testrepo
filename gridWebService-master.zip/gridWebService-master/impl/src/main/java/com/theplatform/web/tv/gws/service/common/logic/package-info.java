/**
 * Business logic related to availabilities, product contexts, streams, and locators.
 */
package com.theplatform.web.tv.gws.service.common.logic;