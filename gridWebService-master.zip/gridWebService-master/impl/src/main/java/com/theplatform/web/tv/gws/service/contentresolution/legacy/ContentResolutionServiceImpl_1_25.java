package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import com.theplatform.web.tv.contentresolution.api.objects.episodes.EpisodeMap;
import com.theplatform.web.tv.gws.service.common.converter.CRSProgramToProgramInfoConverter;
import com.theplatform.web.tv.gws.service.contentresolution.ContentResolutionServiceImpl;
import com.theplatform.web.tv.gws.service.contentresolution.episodes.LegacyEpisodesHelper;

import javax.jws.WebParam;
import java.util.Date;
import java.util.List;

public class ContentResolutionServiceImpl_1_25 extends ContentResolutionServiceImpl_1_26
        implements ContentResolutionService_1_25 {

    protected final ApiObjectVisitor visitor;

    public ContentResolutionServiceImpl_1_25() {
        visitor = DataObjectTranslator_1_25.INSTANCE;
    }

    /**
     * Returns a list of Channel infos
     *
     *
     * @param availabilityResolution
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     * @param byStreamStatus Or query with status separated by pipes "|" (e.g: "Production|Staging")
     *
     * @return
     * @throws GridException
     */
    @Override
    public ChannelInfoCollection resolveChannels(
            @WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
            @WebParam(name = "fields") String fields,
            @WebParam(name = "byStreamStatus") String byStreamStatus,
            @WebParam(name = "filterAdult") Boolean filterAdult) throws GridException{
        ChannelInfoCollection channelInfoCollection = super.resolveChannels( availabilityResolution, fields, byStreamStatus, filterAdult);
        channelInfoCollection.accept(visitor);
        return channelInfoCollection;
    }


    /**
     * Return the channels for a stream scoped to the provided availabilities.
     * @param availabilityResolution
     * @param streamId
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     * @return
     */
    @Override
    public ChannelInfoCollection resolveChannelsByStreamId(
            @WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
            @WebParam(name = "streamId") Long streamId,
            @WebParam(name = "fields") String fields,
            @WebParam(name = "filterAdult") Boolean filterAdult) throws GridException{
        ChannelInfoCollection channelInfoCollection = super.resolveChannelsByStreamId( availabilityResolution, streamId, fields, filterAdult);
        channelInfoCollection.accept(visitor);
        return channelInfoCollection;
    }

    /**
     * returns a grid object including a header, channels, and listing
     *
     * If only a subset of the channels are desired, rowStart and rowEnd can be
     * used to "paginate" the grid.
     *
     * @param availabilityResolution
     *            the availability resolution retrieved from the availability resolution service
     * @param numGridUnits
     *            an Integer for number of grid units
     * @param gridUnitWidth
     *            an Integer for the width of the grid unit
     * @param offset
     *            an Integer representing the offset
     * @param timeZone
     *            a String containing the timezone
     * @param categories
     *            A String[] containing program categories
     * @param companyIds
     *            a Long[] containing the company ids
     * @param stationTagIds
     *            a Long[] containing the stationTagIds
     * @param locatorFormats
     *            a String[] containing locator formats
     * @param hd
     *            a Boolean representing high def
     * @param rowStart
     *            starting index of grid rows to return. Defaults to 1.
     * @param rowEnd
     *            ending index of grid rows to return. Default is unbounded
     *            (null).
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     *
     * @return the grid
     * @throws GridException
     *             general grid exception
     */
    @Override
    public Grid getGrid(
                 @WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                 @WebParam(name = "numGridUnits") Integer numGridUnits,
                 @WebParam(name = "gridUnitWidth") Integer gridUnitWidth,
                 @WebParam(name = "offset") Integer offset,
                 @WebParam(name = "timeZone") String timeZone,
                 @WebParam(name = "categories") String[] categories,
                 @WebParam(name = "companyIds") Long[] companyIds,
                 @WebParam(name = "stationTagIds") Long[] stationTagIds,
                 @WebParam(name = "locatorFormats") String[] locatorFormats,
                 @WebParam(name = "hd") Boolean hd,
                 @WebParam(name = "rowStart") Integer rowStart,
                 @WebParam(name = "rowEnd") Integer rowEnd,
                 @WebParam(name = "programTagIds") Long[] programTagIds,
                 @WebParam(name = "fields") String fields)
            throws GridException{
        Grid grid = super.getGrid(
                availabilityResolution,
                numGridUnits,
                gridUnitWidth,
                offset,
                timeZone,
                categories,
                companyIds,
                stationTagIds,
                locatorFormats,
                hd,
                rowStart,
                rowEnd,
                programTagIds,
                fields
                );
        grid.accept(visitor);
        return grid;
    }

    /**
     * Returns a grid object including a header, channels, and listing. This API
     * assumes the time range specified by startDate and endDate specifies a
     * whole number of grid units. This API is designed to enable cache warming.
     * The client should favor sending in a grid model over this API.
     *
     * If only a subset of the channels are desired, rowStart and rowEnd can be
     * used to "paginate" the grid.
     *
     * @param availabilityResolution
     *            the availability resolution retrieved from the availability resolution service
     * @param startTime
     *            a Date
     * @param numGridUnits
     *            an Integer
     * @param gridUnitWidth
     *            an Integer
     * @param timeZone
     *            ???
     * @param categories
     *            A String[] containing program categories
     * @param companyIds
     *            a Long[] containing the company ids
     * @param stationTagIds
     *            a Long[] containing the stationTagIds
     * @param locatorFormats
     *            a String[] containing locator formats
     * @param hd
     *            a Boolean representing high def
     * @param rowStart
     *            starting index of grid rows to return. Defaults to 1.
     * @param rowEnd
     *            ending index of grid rows to return. Default is unbounded
     *            (null).
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     *
     * @return the grid
     * @throws GridException
     *             general grid exception
     */
    @Override
    public Grid getGridByDate(
            @WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
            @WebParam(name = "startTime") Date startTime,
            @WebParam(name = "numGridUnits") Integer numGridUnits,
            @WebParam(name = "gridUnitWidth") Integer gridUnitWidth,
            @WebParam(name = "timeZone") String timeZone,
            @WebParam(name = "categories") String[] categories,
            @WebParam(name = "companyIds") Long[] companyIds,
            @WebParam(name = "stationTagIds") Long[] stationTagIds,
            @WebParam(name = "locatorFormats") String[] locatorFormats,
            @WebParam(name = "hd") Boolean hd,
            @WebParam(name = "rowStart") Integer rowStart,
            @WebParam(name = "rowEnd") Integer rowEnd,
            @WebParam(name = "programTagIds") Long[] programTagIds,
            @WebParam(name = "fields") String fields)
            throws GridException{
        Grid grid = super.getGridByDate(
                availabilityResolution,
                startTime,
                numGridUnits,
                gridUnitWidth,
                timeZone,
                categories,
                companyIds,
                stationTagIds,
                locatorFormats,
                hd,
                rowStart,
                rowEnd,
                programTagIds,
                fields
        );
        grid.accept(visitor);
        return grid;
    }

    /**
     * Returns StationInfos for a given list of station ids
     * @param stationIds the ids of stations to find and return
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     * @return a list of listing infos
     */
    @Override
    public List<StationInfo> getStationsById(@WebParam(name = "stationIds") Muri[] stationIds,
                                             @WebParam(name = "fields") String fields) throws GridException{
        List<StationInfo> stationInfos = super.getStationsById( stationIds, fields);
        visitor.visitEach(stationInfos);
        return stationInfos;
    }

    @Override
    public List<ChannelInfo> getChannelsById(@WebParam(name = "channelIds") Muri[] channelIds,
                                             @WebParam(name = "fields") String fields) throws GridException{
        List<ChannelInfo> channelInfos = super.getChannelsById( channelIds, fields);
        visitor.visitEach(channelInfos);
        return channelInfos;

    }

    // Begin - Originally Backend APIs

    @Override
    public ChannelInfoCollection getChannelsByAvailabilityId( @WebParam(name = "channelsAvailabilityId") Muri channelsAvailabilityId) throws GridException{
        ChannelInfoCollection channelInfoCollection = super.getChannelsByAvailabilityId( channelsAvailabilityId);
        channelInfoCollection.accept(visitor);
        return channelInfoCollection;
    }

    /**
     * Find Locators matching region
     *
     * @param region
     * @return
     */
    public LocatorInfoCollection getLocatorsByRegion(@WebParam(name = "region") String region) throws GridException{
        LocatorInfoCollection locatorInfoCollection = super.getLocatorsByRegion( region);
        locatorInfoCollection.accept(visitor);
        return locatorInfoCollection;
    }


    // End - Originally Backend APIs






}
