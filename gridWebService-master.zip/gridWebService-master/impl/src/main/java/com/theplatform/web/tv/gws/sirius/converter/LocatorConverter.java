package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.linear.api.data.objects.Locator;
import com.theplatform.web.tv.gws.sirius.model.CRSLocator;

public class LocatorConverter extends AbstractDataObjectConverter<Locator, CRSLocator> {

    @Override
    public CRSLocator convert(Locator dataObject) {
        CRSLocator locator = new CRSLocator();

        locator.setId(LocalUriConverter.convertUriToID(dataObject.getId()));
        locator.setOwnerId(LocalUriConverter.convertUriToID(dataObject.getOwnerId()));
        locator.setFormat(dataObject.getFormat());
        locator.setProtectionScheme(dataObject.getProtectionScheme());
        locator.setBitrate(dataObject.getBitrate());
        locator.setCodec(dataObject.getCodec());
        locator.setDigicableId(dataObject.getDigiCableId());
        locator.setHeight(dataObject.getHeight());
        locator.setStationId(LocalUriConverter.convertUriToID(dataObject.getStationId()));
        locator.setWidth(dataObject.getWidth());
        locator.setQuality(dataObject.getQuality());
        locator.setStreamId(LocalUriConverter.convertUriToID(dataObject.getStreamId()));
        locator.setType(dataObject.getType());
        locator.setProvider(dataObject.getProvider());
        locator.setExternalStreamId(dataObject.getExternalStreamId());
        locator.setPlayerConfig(dataObject.getPlayerConfig());

        if (dataObject.getLocatorURI() != null) {
            locator.setLocatorURI(dataObject.getLocatorURI().toString());
        }
        locator.setNamespaceId(LocalUriConverter.convertUriToID(dataObject.getNamespaceId()));

        return locator;
    }


}
