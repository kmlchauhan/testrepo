package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSStreamNamespace;
import com.theplatform.web.tv.gws.sirius.model.CRSTag;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;

import java.util.Map;

/**
 * @author Segun Abimbola (oabimb200)
 * 2/05/18
 */
public class StreamNamespaceRepository extends LongObjectRepository<CRSStreamNamespace> {

    public StreamNamespaceRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    protected void addToIndexes(CRSStreamNamespace crsStreamNamespace) {

    }

    @Override
    protected void removeFromIndexes(CRSStreamNamespace crsStreamNamespace) {

    }
}
