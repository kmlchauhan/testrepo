/**
 * Repositories for storing, indexing, and retrieving {@link com.theplatform.web.tv.gws.sirius.model.CRSDataObject CRS objects}
 * using various in-memory data structures (Maps, Sets).  This package and the
 * {@link com.theplatform.web.tv.gws.sirius.model model package} are the bridge between the {@link com.theplatform.web.tv.gws.ingest ingest package}
 * (which processes data from external systems) and the {@link com.theplatform.web.tv.gws.service service package} (which uses
 * data received from external systems to service HTTP requests).
 */
package com.theplatform.web.tv.gws.sirius.repository;