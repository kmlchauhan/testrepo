package com.theplatform.web.tv.gws.ingest.consumer.notifier.model;


import com.comcast.merlin.sirius.ingest.Action;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class NotificationListing extends CRSNotification {

    private long startTime;

    public NotificationListing(Action action, long id){
        super( SiriusObjectType.fromFriendlyName("Listing"), id, action);
    }

    public NotificationListing(){}

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }
}
