package com.theplatform.web.tv.gws.sirius.model;


import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSCredit extends LongDataRepoObject {

    long programId;
    long personId;

    public CRSCredit(){
        super( SiriusObjectType.fromFriendlyName("Credit") );
    }

    public long getProgramId() {
        return programId;
    }

    public void setProgramId(long programId) {
        this.programId = programId;
    }

    public long getPersonId() {
        return personId;
    }

    public void setPersonId(long personId) {
        this.personId = personId;
    }
}
