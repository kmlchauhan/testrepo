package com.theplatform.web.tv.gws.service.contentresolution.legacy;


public class ContentResolutionServiceImpl_1_23 extends ContentResolutionServiceImpl_1_24
                                               implements ContentResolutionService_1_23 {


}
