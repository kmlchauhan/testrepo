package com.theplatform.web.tv.gws.service.common.field.descriptor;

import com.theplatform.web.tv.gws.service.common.field.FieldFilterCache;

import java.util.Collections;
import java.util.List;

/**
 * Describes the properties of a top-level API ("info") class.  A "top-level" Class is one that is returned by
 * {@link com.theplatform.web.tv.contentresolution.api.ContentResolutionService} or {@link com.theplatform.web.tv.backend.api.BackendService}.
 * <br><br>
 * This class and {@link ApiPropertyDescriptor} are wrappers around the {@link java.beans.PropertyDescriptor JavaBean API}.  By design,
 * the reflective information encapsulated in this class is separate from choosing which fields of an object are nullified.  This allows
 * instances of this class to be reused in different nullification scenarios.
 */
public class ApiClassDescriptor {
    protected final Class<?> type;
    protected final List<ApiPropertyDescriptor> children;

    ApiClassDescriptor(Class<?> type, List<ApiPropertyDescriptor> children) {
        this.type = type;
        if (children != null) {
            this.children = Collections.unmodifiableList(children);
        }
        else {
            this.children = Collections.emptyList();
        }
    }

    public Class<?> getType() {
        return type;
    }

    /**
     * Child properties of this property or an empty List if this descriptor has no children.
     * @return an immutable List (never null).
     */
    public List<ApiPropertyDescriptor> getChildren() {
        return this.children;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ApiClassDescriptor{");
        sb.append("children=").append(children);
        sb.append('}');
        return sb.toString();
    }

    private final static FieldFilterCache<Class<?>, ApiClassDescriptor> cache = new FieldFilterCache<>();

    /**
     * Retrieve an ApiClassDescriptor for the specified Class.  If a previously constructed instance is available
     * it will be returned.  Otherwise, a new instance will be created.
     * @param clazz non-null Class
     * @return an ApiClassDescriptor
     */
    public static ApiClassDescriptor forClass(Class<?> clazz) {
        ApiClassDescriptor descriptor = cache.get(clazz);

        if (descriptor == null) {
            descriptor = new ApiClassDescriptorBuilder(clazz).build();
            cache.put(clazz, descriptor);
        }

        return descriptor;
    }
}
