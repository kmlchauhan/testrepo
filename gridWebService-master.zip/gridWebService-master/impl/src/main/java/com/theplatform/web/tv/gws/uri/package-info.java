/**
 * Supporting classes used by {@link com.theplatform.web.tv.gws.service services} to convertIpLocator from the long id
 * format used by {@link com.theplatform.web.tv.gws.sirius.model.LongDataObject model classes} to the various URI
 * formats expected by external clients.
 */
package com.theplatform.web.tv.gws.uri;