package com.theplatform.web.tv.gws.sirius.model;

import org.apache.commons.lang.StringUtils;

import java.util.HashMap;
import java.util.Map;

public class CRSRating {
    private final String scheme;
    private final String rating;
    private final String[] subRatings;

    public CRSRating(String scheme, String rating, String[] subRatings) {
        this.scheme = scheme;
        this.rating = rating;
        this.subRatings = subRatings;
    }

    public String getScheme() {
        return scheme;
    }

    public String getRating() {
        return rating;
    }

    public String[] getSubRatings() {
        return subRatings;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((scheme == null) ? 0 : scheme.hashCode());
        result = prime * result
                + ((rating == null) ? 0 : rating.hashCode());
        result = prime * result
                + ((subRatings == null) ? 0 : subRatings.hashCode());

        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;

        CRSRating other = (CRSRating) obj;
        if (scheme == null) {
            if (other.scheme != null)
                return false;
        } else if (!scheme.equals(other.scheme))
            return false;
        if (rating == null) {
            if (other.rating != null)
                return false;
        } else if (!rating.equals(other.rating))
            return false;
        if (subRatings == null) {
            if (other.subRatings != null)
                return false;
        } else if (!subRatings.equals(other.subRatings))
            return false;

        return true;
    }

    private final static Map<String, CRSRating> INSTANCES = new HashMap<>();

    public static CRSRating getInstance(String scheme, String rating, String[] subratings) {

        String subratingString = null;
        if (subratings != null)
            subratingString = StringUtils.join(subratings);

        String key = scheme + rating + subratingString;

        synchronized (INSTANCES) {
            if (!INSTANCES.containsKey(key)) {
                String internedScheme = null;
                if (scheme != null)
                    internedScheme = scheme.intern();

                String internedRating = null;
                if (rating != null)
                    internedRating = rating.intern();

                String[] subratingsIntern = null;
                if (subratings!=null){
                    subratingsIntern = new String[subratings.length];
                    for(int i=0; i<subratings.length; i++){
                        subratingsIntern[i]=subratings[i].intern();
                    }
                }

                CRSRating crsRating = new CRSRating(internedScheme, internedRating, subratingsIntern);
                INSTANCES.put(key, crsRating);
            }
        }

        return INSTANCES.get(key);
    }
}
