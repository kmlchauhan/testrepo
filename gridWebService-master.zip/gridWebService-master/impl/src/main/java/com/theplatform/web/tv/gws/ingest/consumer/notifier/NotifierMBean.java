package com.theplatform.web.tv.gws.ingest.consumer.notifier;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.contrib.stats.RollingAverage;
import com.theplatform.contrib.stats.StatsCollector;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;

@ManagedResource
public class NotifierMBean {


    private static final String PREFIX = "notification.";
    private Map<SiriusObjectType, String>  statsCollectorKey;

    private final StatsCollector statsCollector;


    public NotifierMBean(){
        statsCollector = StatsCollector.getInstance();
        statsCollectorKey = new HashMap();
    }


    public void notificationPublished(SiriusObjectType siriusObjectType, long messageDelay){
        statsCollector.record( lookupName(siriusObjectType), messageDelay);
    }

    @ManagedAttribute(description="Number of published notifications in the last 10 minutes")
    public Map<String,Integer> getPublishedNotifications_10_minutes() {
        return getPublishedNotifications(StatsCollector.TEN_MINUTES);
    }

    @ManagedAttribute(description="Number of published notifications in the last 1 hour")
    public Map<String,Integer>  getPublishedNotifications_1_hour() {
        return getPublishedNotifications(StatsCollector.ONE_HOUR);
    }

    @ManagedAttribute(description="Number of published notifications in the last 24 hours")
    public Map<String,Integer> getPublishedNotifications_1_day() {
        return getPublishedNotifications(StatsCollector.ONE_DAY);
    }

    private Map<String,Integer> getPublishedNotifications(RollingAverage.TimeFrame timeFrame) {
        Map<String,Integer> mapResponse = new HashMap<>();
        Map<String, SortedMap<RollingAverage.TimeFrame, RollingAverage.Report>> data =  statsCollector.reportAll();
        for (String key : data.keySet()){
            if (key.startsWith(PREFIX)){
                SortedMap<RollingAverage.TimeFrame, RollingAverage.Report> sortMap =  data.get(key);
                RollingAverage.Report report = sortMap.get(timeFrame);
                mapResponse.put(key, report.operations);
            }
        }
        return mapResponse;
    }



    private final String lookupName(SiriusObjectType siriusObjectType){
        String name = statsCollectorKey.get(siriusObjectType);
        if (name ==null){
            name = PREFIX+ siriusObjectType.getFriendlyName();
            statsCollectorKey.put(siriusObjectType, name);
        }
        return name;
    }


}
