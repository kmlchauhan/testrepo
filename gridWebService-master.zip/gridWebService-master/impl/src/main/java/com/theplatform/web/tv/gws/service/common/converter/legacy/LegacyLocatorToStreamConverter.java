package com.theplatform.web.tv.gws.service.common.converter.legacy;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.debug.CauseType;
import com.theplatform.web.tv.contentresolution.api.debug.WarningItem;
import com.theplatform.web.tv.contentresolution.api.debug.WarningType;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import com.theplatform.web.tv.gws.sirius.model.CRSStream;
import com.theplatform.web.tv.gws.sirius.repository.StreamRepository;
import com.theplatform.web.tv.gws.service.common.debug.DebugHelper;
import com.theplatform.web.tv.gws.service.common.util.DedupeUtil;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.util.*;

/**
 *  Used to convert from the 'new data model' (1.21+) to the earlier data model (<1.21)
 *
 */
public class LegacyLocatorToStreamConverter {
    private static Logger logger = LoggerFactory.getLogger(LegacyLocatorToStreamConverter.class);

    private StreamRepository streamRepository;
    private MerlinIdHelper merlinIdHelper;
    private DebugHelper debugHelper;

    private static final Comparator<StreamInfo> STREAM_ORDER = new Comparator<StreamInfo>() {
        public int compare(StreamInfo a, StreamInfo b) {
            int result = a.getStreamId().compareTo(b.getStreamId());
            return result;
        }
    };

    // FOR FRONT-END CALLS
    public StreamInfo convertIpAndNonIpLocators(ChannelInfo channelInfo){
        Muri stationId = channelInfo.getStationInfo().getStationId();
        List<LocatorInfo> locatorInfos = channelInfo.getLocators();

        // 1.1) Gath and convert all Locators
        // Note: Legacy did allow for a stream with no locator.
        List<LocatorInfo> legacyLocatorInfos = new ArrayList<>();
        if (locatorInfos!=null && locatorInfos.size()>0) {
            for (LocatorInfo locatorInfo : locatorInfos) {
                legacyLocatorInfos.add(createLegacyLocatorInfo(locatorInfo));
            }
        }

        // 2.1) Create identified Stream
        StreamInfo legacyStreamInfo = null;
        if (channelInfo.getBackwardsCompatibilityStreamId()!=0) {
            legacyStreamInfo = createStreamInfo(stationId, channelInfo.getBackwardsCompatibilityStreamId());
        }

        // 2.2) If still not found then try to find a default
        if (legacyStreamInfo==null){
            CRSStream crsStream = getDefaultCRSStream(stationId.getId());
            if (crsStream!=null) {
                legacyStreamInfo = createStreamInfo(stationId, crsStream.getId());
                debugHelper.logResponseWarning(WarningType.StreamWarning, CauseType.DefaultStream,
                        WarningItem.instance().setStationId(merlinIdHelper.createStationId(crsStream.getStationId()))
                                .setStreamId(merlinIdHelper.createStreamId(crsStream.getId())));
            }
        }

        // 3 Sort the LocatorInfos
        // This shouldn't be needed since we will maintain the same order of Locators which is already deterministically ordered.

        if (legacyStreamInfo != null ){
            // 4 Add all the locators to the StreamInfo.  If there are none, then leave as null.
            if (legacyLocatorInfos != null) {
                legacyStreamInfo.setLocators(legacyLocatorInfos);
            }

            // 5 Synthetic Channels will have a locator.external set to True which will need to be transferred to the Stream
            if ( locatorInfos!=null && locatorInfos.size()>0
                    && locatorInfos.get(0).getExternal() == Boolean.TRUE) {
                legacyStreamInfo.setExternal(true);
            }
        }

        return legacyStreamInfo;
    }


    // FOR BACKEND CALLS.  These should all be IP Locators
    public StreamInfoCollection convertLocatorInfoCollection(LocatorInfoCollection locatorInfoCollection){
        StreamInfoCollection streamInfoCollection = new StreamInfoCollection();

        if (locatorInfoCollection==null || locatorInfoCollection.getLocatorInfos()==null)
            return streamInfoCollection;

        // StreamId -> StreamInfo
        Map<Long,StreamInfo> streamIdToStreamInfo = new HashMap<>();
        for ( LocatorInfo locatorInfo : locatorInfoCollection.getLocatorInfos()){
            StreamInfo streamInfo = streamIdToStreamInfo.get(locatorInfo.getStreamId().getId());
            if (streamInfo == null){
                streamInfo = createStreamInfo( null, locatorInfo.getStreamId().getId());
                streamInfo.setLocators(new ArrayList<LocatorInfo>());
                streamIdToStreamInfo.put(locatorInfo.getStreamId().getId(), streamInfo);
            }
            LocatorInfo legacyLocatorInfo = createLegacyLocatorInfo(locatorInfo);
            streamInfo.getLocators().add(legacyLocatorInfo);
        }

        // I don't believe sorting is needed since the original order would be maintained
        List<StreamInfo> legacyStreamInfos = new ArrayList<>(streamIdToStreamInfo.values());

        // Sort for caching/ETag
        legacyStreamInfos.sort(STREAM_ORDER);

        // Set the Streams
        streamInfoCollection.setStreams(legacyStreamInfos);

        // Set verbose messages
        streamInfoCollection.setVerboseInfo(locatorInfoCollection.getVerboseInfo());

        return streamInfoCollection;
    }

    private LocatorInfo createLegacyLocatorInfo(LocatorInfo locatorInfo) {
        LocatorInfo legacy = new LocatorInfo();

        legacy.setLocatorId(locatorInfo.getLocatorId());
        legacy.setFormat(locatorInfo.getFormat());
        legacy.setLocatorUri(locatorInfo.getLocatorUri());
        legacy.setWidth(locatorInfo.getWidth());
        legacy.setHeight(locatorInfo.getHeight());
        legacy.setBitrate(locatorInfo.getBitrate());
        legacy.setCodec(locatorInfo.getCodec());
        legacy.setProtectionScheme(locatorInfo.getProtectionScheme());
        legacy.setProvider(locatorInfo.getProvider());
        legacy.setExternalStreamId(locatorInfo.getExternalStreamId());

        return legacy;
    }

    private StreamInfo createStreamInfo(Muri stationId, long streamId){
        CRSStream crsStream = streamRepository.get(streamId);
        if (stationId == null ){
            stationId = merlinIdHelper.createStationId(crsStream.getStationId());
        }

        StreamInfo streamInfo = new StreamInfo();
        streamInfo.setStreamId( merlinIdHelper.createStreamId(streamId) );
        streamInfo.setStatus( crsStream.getStatus() );
        streamInfo.setStationId( stationId );
        streamInfo.setExternal( crsStream.getExternal() );
        streamInfo.setIsDai( crsStream.getIsDai() );
        streamInfo.setIsDefault( crsStream.getIsDefault() );
        return streamInfo;
    }

    private CRSStream getDefaultCRSStream(long stationId) {
        Collection<CRSStream> list = streamRepository.getDefaultStreamByStationId(stationId);
        if (list == null) return null;
        CRSStream defaultCRSStream = null;
        for (CRSStream crsStream : list) {
            if (defaultCRSStream == null) {
                defaultCRSStream = crsStream;
            } else {    // If more than one, be deterministic.
                long precedentId, droppedId = 0;
                if (DedupeUtil.firstTakesPrecedence(crsStream.getId(), defaultCRSStream.getId())) {
                    precedentId = crsStream.getId();
                    droppedId = defaultCRSStream.getId();
                    defaultCRSStream = crsStream;
                }else{
                    precedentId = defaultCRSStream.getId();
                    droppedId = crsStream.getId();
                }
                debugHelper.logResponseWarning(WarningType.StreamWarning, CauseType.MultipleStreams,
                        WarningItem.instance().setStationId(merlinIdHelper.createStationId(crsStream.getStationId()))
                                .setStreamId(merlinIdHelper.createStreamId(precedentId))
                                .setAlternateId(merlinIdHelper.createStreamId(droppedId))
                );
            }
        }
        return defaultCRSStream;
    }

    @Required
    public void setStreamRepository(StreamRepository streamRepository) {
        this.streamRepository = streamRepository;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }

    @Required
    public void setDebugHelper(DebugHelper debugHelper) {
        this.debugHelper = debugHelper;
    }
}
