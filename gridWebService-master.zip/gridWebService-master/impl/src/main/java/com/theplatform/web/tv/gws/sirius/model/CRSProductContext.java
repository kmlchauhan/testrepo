package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSProductContext extends LongDataRepoObject {

    private String title;
    private String type;

    public CRSProductContext() {
        super( SiriusObjectType.fromFriendlyName("ProductContext"));
    }

    public CRSProductContext(long id) {
        super( SiriusObjectType.fromFriendlyName("ProductContext"), id);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = nullSafeIntern(type);
    }

}
