package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import org.apache.commons.lang3.ArrayUtils;

public class CRSLinearCollection extends LongDataRepoObject implements Comparable<CRSLinearCollection> {

    private long[] sdStationIds = new long[0];
    private long[] hdStationIds = new long[0];
    private long[] uhdStationIds = new long[0];

    public CRSLinearCollection() {
        super(SiriusObjectType.fromFriendlyName("LinearCollection"));
    }

    public CRSLinearCollection(long id) {
        super(SiriusObjectType.fromFriendlyName("LinearCollection"), id);
    }

    public long[] getSdStationIds() {
        return sdStationIds;
    }

    public void setSdStationIds(long[] sdStationIds) {
        this.sdStationIds = sdStationIds;
    }

    public long[] getHdStationIds() {
        return hdStationIds;
    }

    public void setHdStationIds(long[] hdStationIds) {
        this.hdStationIds = hdStationIds;
    }

    public long[] getUhdStationIds() {
        return uhdStationIds;
    }

    public void setUhdStationIds(long[] uhdStationIds) {
        this.uhdStationIds = uhdStationIds;
    }

    public long[] getStationIds() {
        long[] partial = ArrayUtils.addAll(sdStationIds, hdStationIds);
        return ArrayUtils.addAll(partial, uhdStationIds);
    }

    @Override
    public int compareTo(CRSLinearCollection o) {
        if (this.hashCode() > o.hashCode()) {
            return 1;
        }
        if (this.hashCode() < o.hashCode()) {
            return -1;
        }
        return 0;
    }
}
