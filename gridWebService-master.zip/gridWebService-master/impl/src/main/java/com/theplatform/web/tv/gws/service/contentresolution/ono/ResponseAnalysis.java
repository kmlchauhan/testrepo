package com.theplatform.web.tv.gws.service.contentresolution.ono;

import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.ProductContextInfo;
import com.theplatform.web.tv.gws.sirius.repository.ProductContextRepository;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;

import java.util.List;

class ResponseAnalysis {
    // Unique Set of CIM/PC found in response
    private LongSet tveProductContexts;
    // Station on the response containing a CIM/TVE PC.  We do not want to create a synth channel for these.
    private LongSet tveStations;

    public ResponseAnalysis(ProductContextRepository productContextRepository, List<ChannelInfo> channelInfos){
        tveProductContexts = new LongOpenHashSet();
        tveStations = new LongOpenHashSet();
        if (channelInfos==null) return;
        for (ChannelInfo channelInfo : channelInfos){
            for ( ProductContextInfo pcInfo : channelInfo.getProductContexts()){
                if ( productContextRepository.isTveProductContext(pcInfo.getId().getId())){
                    tveProductContexts.add(pcInfo.getId().getId());
                    tveStations.add(channelInfo.getStationInfo().getStationId().getId());
                }
            }
        }
    }

    /**
     * Set of all CIM/TVE PC in response
     */
    public LongSet getTveProductContexts() {
        return tveProductContexts;
    }

    /**
     * Does the response contain the stationId with a CIM/TVE PC?
     * If it does we do not want to create a synth channel.
     */
    public boolean containsTveStation(long stationId){
        return tveStations.contains(stationId);
    }
}
