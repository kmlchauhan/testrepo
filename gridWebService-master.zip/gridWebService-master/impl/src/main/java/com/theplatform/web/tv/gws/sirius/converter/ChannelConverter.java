package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.*;
import com.theplatform.data.persistence.translator.converter.*;
import com.theplatform.data.tv.linear.api.data.objects.*;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.sirius.repository.utils.CanonicalIdsFactory;
import org.springframework.beans.factory.annotation.*;

public class ChannelConverter extends AbstractDataObjectConverter<Channel, CRSChannel> {
    private CanonicalIdsFactory productContextCanonicalIdsFactory;

    @Override
    public CRSChannel convert(Channel channel) {
        CRSChannel crsChannel = new CRSChannel();
        crsChannel.setId(LocalUriConverter.convertUriToID(channel.getId()));
        crsChannel.setChannelNumber(channel.getChannelNumber());
        if (channel.getOnScreenCallsign() != null) {
            crsChannel.setOnScreenCallsign(channel.getOnScreenCallsign());
        }
        if (channel.getDigicableId() != null)
            crsChannel.setDigicableId(channel.getDigicableId());
        crsChannel.setLocationId(LocalUriConverter.convertUriToID(channel.getLocationId()));
        crsChannel.setStationId(LocalUriConverter.convertUriToID(channel.getStationId()));
        crsChannel.setOwnerId(LocalUriConverter.convertUriToID(channel.getOwnerId()));
        crsChannel.setSdv(channel.getSdv());
        crsChannel.setSdvTimeout(channel.getSdvTimeout());
        if (channel.getEmergencyAlertSystemType() != null) {
            crsChannel.setEmergencyAlertSystemType(channel.getEmergencyAlertSystemType());
        }
        if (channel.getIpDeliveryOnly() != null){
            crsChannel.setIpDeliveryOnly(channel.getIpDeliveryOnly());
        }
        crsChannel.setSortIndexPolicy(channel.getSortIndexPolicy());
        if (channel.getDisplayPolicies()!=null && channel.getDisplayPolicies().size()>0){
            crsChannel.setDisplayPolicies(channel.getDisplayPolicies().toArray(new String[channel.getDisplayPolicies().size()]));
        }
        crsChannel.setProductContexts(productContextCanonicalIdsFactory.create(channel.getProductContextIds()));

        return crsChannel;
    }

    @Required
    public void setProductContextCanonicalIdsFactory(CanonicalIdsFactory productContextCanonicalIdsFactory) {
        this.productContextCanonicalIdsFactory = productContextCanonicalIdsFactory;
    }
}
