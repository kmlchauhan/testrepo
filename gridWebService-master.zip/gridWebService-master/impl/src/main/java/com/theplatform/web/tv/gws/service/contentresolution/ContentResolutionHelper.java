package com.theplatform.web.tv.gws.service.contentresolution;

import com.comcast.compass.availability.common.domain.Availabilities;
import com.comcast.merlin.sirius.model.RepositoryObject;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.ListMultimap;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.contrib.stats.StatsCollector;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.module.exception.BadParameterException;
import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.contentresolution.api.debug.CauseType;
import com.theplatform.web.tv.contentresolution.api.debug.WarningItem;
import com.theplatform.web.tv.contentresolution.api.debug.WarningType;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.IdCollection;
import com.theplatform.web.tv.contentresolution.api.objects.ProductContextInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;
import com.theplatform.web.tv.gws.service.common.logic.*;
import com.theplatform.web.tv.gws.service.common.logic.productcontext.*;
import com.theplatform.web.tv.gws.service.common.logic.stream.*;
import com.theplatform.web.tv.gws.service.common.util.*;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.service.common.converter.CRSChannelToChannelInfoConverter;
import com.theplatform.web.tv.gws.service.common.converter.CRSProductContextToProductContextInfoConverter;
import com.theplatform.web.tv.gws.service.common.converter.CRSStationToStationInfoConverter;
import com.theplatform.web.tv.gws.service.common.debug.DebugHelper;
import com.theplatform.web.tv.gws.service.contentresolution.ono.TveSyntheticChannelHelper;
import com.theplatform.web.tv.gws.sirius.repository.*;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import com.theplatform.web.tv.gws.uri.UrnUtil;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import javax.annotation.Resource;
import java.net.URI;
import java.util.*;

import static com.theplatform.contrib.data.api.objects.Muri.getObjectId;
import static java.lang.System.currentTimeMillis;
import static java.util.Collections.sort;

public class ContentResolutionHelper {
    private static Logger logger = LoggerFactory.getLogger(ContentResolutionHelper.class);

    static protected StatsCollector statsCollector = StatsCollector.getInstance();

    private DebugHelper debugHelper;
    private MerlinDAO merlinDAO;

    private ChannelRepository channelRepository;
    private LocationRepository locationRepository;
    private ListingRepository listingRepository;
    private ProgramTeamAssociationRepository programTeamAssociationRepository;
    private CreditRepository creditRepository;
    private LongObjectRepository<CRSStation> stationRespository;

    private CRSChannelToChannelInfoConverter crsChannelToChannelInfoConverter;
    private CRSProductContextToProductContextInfoConverter crsProductContextToProductContextInfoConverter;
    private CRSStationToStationInfoConverter crsStationToStationInfoConverter;

    private OwnerUtil ownerUtil;

    private ProductContextLogic productContextLogic;

    private StreamLocatorLogic streamLogic;
    private LocatorLogic locatorLogic;

    private TveSyntheticChannelHelper tveSyntheticChannelHelper;

    private TveChannelPivotHelper tveChannelPivotHelper;
    private SortIndexHelper sortIndexHelper;

    private DynamicProperties dynamicProperties;

    @Resource
    private MerlinIdHelper merlinIdHelper;

    protected List<ChannelInfo> getChannelMap( ScopedAvailabilities scopedAvailabilities
            , Set<String> allowedStreamStatus) throws GridException {

        long getLocationToProductContextsMapStartTime = currentTimeMillis();
        Map<Long, Set<Long>> locationToProductContextsMap = getLocationToProductContextsMap(scopedAvailabilities);

        // Determine OwnerId
        long ownerId = ownerUtil.getOwnerId(scopedAvailabilities);

        MerlinIdHelper requestIdHelper = merlinIdHelper.forSingleThreadedUse();

        long loopStartTime = currentTimeMillis();
        List<ChannelInfo> channelInfos = new ArrayList<>();

        // Used to track company to comes before channels
        HashMultimap<Long, ChannelInfo> comesBeforeCompanyToChannelInfos = HashMultimap.create();
        for ( Long location : locationToProductContextsMap.keySet()){
            validateLocations(location);

            Collection<CRSChannel> channels =  channelRepository.getByLocationId(location);

            Set<Long> requestedProductContext = locationToProductContextsMap.get(location);
            for (CRSChannel channel : channels){
                Set<Long> productContexts = productContextLogic.getProductContextMapping(channel, requestedProductContext, ownerId);
                if ( !CollectionUtils.isEmpty(productContexts)){
                    long channelConvertStartTime = currentTimeMillis();
                    ChannelInfo channelInfo =
                            crsChannelToChannelInfoConverter.convert( channel,
                                    requestIdHelper,
                                    scopedAvailabilities.getAvailabilityResolution().getRecorderManager()
                            );

                    long productContextConvertStartTime = currentTimeMillis();
                    List<ProductContextInfo> productContextInfos =
                            crsProductContextToProductContextInfoConverter.convert(productContexts, requestIdHelper);

                    channelInfo.getStationInfo().setProductContextList(productContextInfos);

                    // Identify any channels for which we'll need to update the sortIndex. These are the Channels
                    // that "come before". Group the "Comes Before" channels by companyId to give us
                    // CompanyId->"Comes Before" channels[]
                    Long comesBeforeCompanyId = sortIndexHelper.getComesBeforeCompanyId(channelInfo);
                    if (comesBeforeCompanyId != null) {
                        comesBeforeCompanyToChannelInfos.put(comesBeforeCompanyId, channelInfo);
                    }

                    channelInfos.add(channelInfo);
                } else {
                    // This could be as a result of WarningType.ChannelDropped/CauseType.NoStationCA || ChannelDropped/PhaseII
                    if (debugHelper.isVerboseMode()) {
                        debugHelper.logResponseWarning(WarningType.ChannelDropped, CauseType.NoProductContext,
                                WarningItem.instance()
                                        .setChannelId(requestIdHelper.createChannelId(channel.getId()))
                                        .setStationId(requestIdHelper.createStationId(channel.getStationId()))
                        );
                    }
                }
            }
        }

        tveSyntheticChannelHelper.populateSyntheticChannels(channelInfos, scopedAvailabilities, requestIdHelper);

        // Special NHL/MLB/... Virtual OnDemand Logic.  Should be called once we have all Channels.  Probably best before we apply the Streams.
        sortIndexHelper.modifyNhlVirtualChannels( comesBeforeCompanyToChannelInfos, channelInfos, debugHelper);

        if (dynamicProperties.get(DynamicProperties.DynamicPropertiesEnum.LOCATOR_CA_ENABLED).equals("true")){
            // Add Locators based on new Locator CA Logic
            locatorLogic.modify( scopedAvailabilities, channelInfos, allowedStreamStatus, ownerId);
        } else {
            // Add Locators based on old Stream CA Logic
            streamLogic.modify( scopedAvailabilities, channelInfos, allowedStreamStatus, ownerId, true);
        }

        sortChannelInfos(channelInfos);

        // Channel Pivoting - Creates outOfHome References from TitleVI to TVE Channels
        tveChannelPivotHelper.populateOutOfHomeRelatedChannels( ownerId, MiscUtil.union(locationToProductContextsMap.values()), channelInfos);

        return channelInfos;
    }

    public List<CRSListing> getListingsByIds(String idType, Muri[] ids, Date startTime, Date endTime) {
        List<CRSListing> filteredListings = new LinkedList<>();

        for (Muri id : ids) {
            Collection<CRSListing> unfilteredListings = getListings(id, idType);
            for (CRSListing crsListing : unfilteredListings) {
                if ((startTime == null || startTime.getTime() < crsListing.getEndTime())
                        && (endTime == null || endTime.getTime() > crsListing.getStartTime())) {
                    filteredListings.add(crsListing);
                }
            }
        }

        return filteredListings;
    }

    public List<CRSListing> getListingsByIds(String idType, Muri[] ids, Date startTime, Date endTime, Muri[] stationIds) {
        Set<Long> longStationIds = new HashSet<>();
        List<CRSListing> unfilteredListings = getListingsByIds(idType, ids, startTime, endTime);
        List<CRSListing> filteredListings = new ArrayList<>();

        if (stationIds == null) return unfilteredListings;

        for (Muri stationId : stationIds) {
            longStationIds.add(stationId.getId());
        }

        for (CRSListing listing : unfilteredListings) {
            if (longStationIds.contains(listing.getStationId())) {
                filteredListings.add(listing);
            }
        }

        return filteredListings;
    }

    public IdCollection getStationIdsByIds(String idType, Muri[] ids, Date startTime, Date endTime) {
        Map<Long, Muri> stationMap = new HashMap<>();
        List<CRSListing> crsListings = getListingsByIds(idType, ids, startTime, endTime);

        for (CRSListing crsListing : crsListings) {
            if (!stationMap.containsKey(crsListing.getStationId())) {
                stationMap.put(crsListing.getStationId(), merlinIdHelper.createStationId(crsListing.getStationId()));
            }
        }

        IdCollection idCollection = new IdCollection();
        idCollection.setIds(new ArrayList<Muri>(stationMap.values()));
        return idCollection;
    }

    public List<StationInfo> getStationsByIds(Muri[] stationIds) {
        List<StationInfo> stationInfos = new ArrayList<>();
        CRSStation crsStation;
        for (Muri stationId : stationIds){
            crsStation = stationRespository.get(stationId.getId());
            if (crsStation != null) {
                stationInfos.add(crsStationToStationInfoConverter.convert( crsStation, merlinIdHelper,null));
            }
        }
        return stationInfos;
    }


    private List<CRSListing> getListings(Muri uri, String type){
        Collection<CRSListing> allListings;
        long id = uri.getId();

        if (type.equalsIgnoreCase("series")){
            allListings = listingRepository.getBySeriesId(id);
        } else if (type.equalsIgnoreCase("program")){
            allListings = listingRepository.getByProgramId(id);
        }  else if (type.equalsIgnoreCase("person") || type.equalsIgnoreCase("sportsteam")){
            Collection<Long> programIds;
            if (type.equalsIgnoreCase("person")){
                // Person
                programIds = creditRepository.getProgramIds(id);
            }else{
                // Sports Team
                programIds = programTeamAssociationRepository.getProgramIds(id);
            }
            allListings = new HashSet<>();
            for (Long programId : programIds) {
                Collection<CRSListing> listings = listingRepository.getByProgramId(programId);
                allListings.addAll(listings);
            }
        }else {
            throw new IllegalArgumentException("Invalid idType.  Please pass in \"series\",\"person\",\"program\", or \"sportsteam\".");
        }

        List<CRSListing> sorted = new ArrayList<>(allListings);
        Collections.sort(sorted);

        return sorted;
    }

    /**
     *  Create a mapping from Location to N ProductContexts from a given request.
     */
    private Map<Long, Set<Long>> getLocationToProductContextsMap(ScopedAvailabilities scopedAvailabilities) {
        Map<Long, Set<Long>> locationToPcsMap = new HashMap<>();

        List<Availabilities> stationAvailabilities = scopedAvailabilities.getStationAvailabilities();
        for (Availabilities availabilities : stationAvailabilities) {
            List<URI> availabilityIds = availabilities.getAvailabilityIds();
            URI productContext = availabilities.getProductContext();
            validateProductContext(productContext);
            for (URI location : availabilityIds) {
                Long locationId = Muri.getObjectId(location);
                if (!locationToPcsMap.containsKey(locationId)){
                    locationToPcsMap.put( locationId, new HashSet<Long>());
                }
                locationToPcsMap.get(locationId).add( Muri.getObjectId(productContext) );
            }
        }
        return locationToPcsMap;
    }

    private void sortChannelInfos(List<ChannelInfo> channelInfoList) {
        sort(channelInfoList, CRSChannelToChannelInfoConverter.CHANNEL_ORDER);
    }

    static protected List<ChannelInfo> filterOutChannelInfosByTags(List<ChannelInfo> channelInfos, CRSTag... tag) {
        ValidateUtil.notNull(channelInfos, "ChannelInfo List");

        if (tag == null)
            return channelInfos;

        Set<Long> tags = new HashSet<>();
        for (CRSTag crsTag : tag)
            tags.add(crsTag.getId());

        List<ChannelInfo> filtered = new ArrayList<>();
        for (ChannelInfo channelInfo : channelInfos) {

            boolean found = false;
            for (Muri muri : channelInfo.getStationInfo().getTagIds())
                if (tags.contains(muri.getId()))
                    found = true;
            if (!found)
                filtered.add(channelInfo);
        }
        return filtered;
    }


    private void validateProductContext(URI urn) {
        List<CRSProductContext> fetchedProductContext = merlinDAO.retrieveProductContext(Arrays.asList(getObjectId(urn)));
        if (CollectionUtils.isEmpty(fetchedProductContext)) {
            throw new BadParameterException("ProductContext provided not found: " + urn);
        }
    }

    private void validateLocations(Long location) {
        if (locationRepository.get(location)==null){
            logger.warn("CRS Validation.  UnknownLocationParameter=" + location);
            throw new BadParameterException("Unknown Location provided: " + location);
        }
    }

    protected void validateAvailabilityResolution(ScopedAvailabilities scopedAvailabilities) {

        ValidateUtil.notNull(scopedAvailabilities.getAvailabilityResolution(), "availabilityResolution");

        // validate availability tags
        for (Availabilities availabilities : scopedAvailabilities.getStreamAvailabilities()) {
            for (URI urn : availabilities.getAvailabilityIds()) {
                MerlinEntityType objectType = UrnUtil.getUrnEntityType(urn.toString());
                List<Long> ids = Arrays.asList(getObjectId(urn));
                List<? extends RepositoryObject> objects = null;
                if (MerlinEntityType.AVAILABILITYTAG.equals(objectType)) {
                    objects = merlinDAO.retrieveAvailabilityTag(ids);
                } else if (MerlinEntityType.LOCATION.equals(objectType)) {
                    objects = merlinDAO.retrieveLocations(ids);
                } else {
                    throw new BadParameterException("An availabilityId of scope STREAM not of type Region, AvailabilityTag, or Location: " + urn);
                }
                if (objects.size() == 0) {
                    debugHelper.logRequestWarning(WarningType.InvalidObject, CauseType.AvailabilityNotFound,
                            WarningItem.instance().setAvailabilityId(Muri.create(urn))
                    );
                }
            }

        }
    }


    @Required
    public void setMerlinDAO(MerlinDAO merlinDAO) {
        this.merlinDAO = merlinDAO;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    @Required
    public void setCrsChannelToChannelInfoConverter(CRSChannelToChannelInfoConverter crsChannelToChannelInfoConverter) {
        this.crsChannelToChannelInfoConverter = crsChannelToChannelInfoConverter;
    }

    @Required
    public void setCrsProductContextToProductContextInfoConverter(CRSProductContextToProductContextInfoConverter crsProductContextToProductContextInfoConverter) {
        this.crsProductContextToProductContextInfoConverter = crsProductContextToProductContextInfoConverter;
    }

    @Required
    public void setCrsStationToStationInfoConverter(CRSStationToStationInfoConverter crsStationToStationInfoConverter) {
        this.crsStationToStationInfoConverter = crsStationToStationInfoConverter;
    }

    @Required
    public void setProductContextLogic(ProductContextLogic productContextLogic) {
        this.productContextLogic = productContextLogic;
    }

    @Required
    public void setOwnerUtil(OwnerUtil ownerUtil) {
        this.ownerUtil = ownerUtil;
    }

    @Required
    public void setLocationRepository(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }

    @Required
    public void setStreamLogic(StreamLocatorLogic streamLogic) {
        this.streamLogic = streamLogic;
    }

    @Required
    public void setLocatorLogic(LocatorLogic locatorLogic) {
        this.locatorLogic = locatorLogic;
    }

    @Required
    public void setListingRepository(ListingRepository listingRepository) {
        this.listingRepository = listingRepository;
    }

    @Required
    public void setProgramTeamAssociationRepository(ProgramTeamAssociationRepository programTeamAssociationRepository) {
        this.programTeamAssociationRepository = programTeamAssociationRepository;
    }

    @Required
    public void setCreditRepository(CreditRepository creditRepository) {
        this.creditRepository = creditRepository;
    }

    @Required
    public void setStationRespository(LongObjectRepository<CRSStation> stationRespository) {
        this.stationRespository = stationRespository;
    }

    @Required
    public void setDebugHelper(DebugHelper debugHelper) {
        this.debugHelper = debugHelper;
    }

    @Required
    public void setTveChannelPivotHelper(TveChannelPivotHelper tveChannelPivotHelper) {
        this.tveChannelPivotHelper = tveChannelPivotHelper;
    }

    @Required
    public void setTveSyntheticChannelHelper(TveSyntheticChannelHelper tveSyntheticChannelHelper) {
        this.tveSyntheticChannelHelper = tveSyntheticChannelHelper;
    }

    @Required
    public void setSortIndexHelper(SortIndexHelper sortIndexHelper) {
        this.sortIndexHelper = sortIndexHelper;
    }

    @Required
    public void setDynamicProperties(DynamicProperties dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }

}
