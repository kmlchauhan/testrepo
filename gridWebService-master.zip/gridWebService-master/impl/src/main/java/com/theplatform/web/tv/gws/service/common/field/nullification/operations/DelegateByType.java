package com.theplatform.web.tv.gws.service.common.field.nullification.operations;

import java.util.Map;

/**
 * Choose and apply a PropertyOperation based on the runtime type of the target object.
 */
public class DelegateByType implements PropertyOperation {
    private final PropertyOperation baseOperation;
    private final Map<Class<?>, PropertyOperation> operations;

    public DelegateByType(PropertyOperation baseOperation, Map<Class<?>, PropertyOperation> operations) {
        this.baseOperation = baseOperation;
        this.operations = operations;
    }

    @Override
    public void apply(Object target) {
        PropertyOperation next = this.operations.get(target.getClass());
        if (next == null) {
            next = this.baseOperation;
        }

        next.apply(target);
    }
}
