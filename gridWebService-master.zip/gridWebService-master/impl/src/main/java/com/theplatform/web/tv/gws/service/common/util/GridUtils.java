package com.theplatform.web.tv.gws.service.common.util;

import com.theplatform.contrib.client.SharedCacheDataServiceClient;
import com.theplatform.contrib.stats.StatsCollector;
import com.theplatform.data.api.client.DataService;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.module.exception.BadParameterException;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * User: mmattozzi Date: 12/8/11 Time: 2:28 PM
 */
public class GridUtils {
    public static final int MINUTES_IN_ONE_DAY = 1440;
    private static final String TIME_FORMAT = "h:mm a";
    private static Logger logger = LoggerFactory.getLogger(GridUtils.class);

    protected static StatsCollector statsCollector = StatsCollector.getInstance();

    public static List<Muri> extractStationIds(List<ChannelInfo> channelInfos) {
        List<Muri> stationIds = new ArrayList<Muri>();

        for (ChannelInfo channelInfo : channelInfos) {
            stationIds.add(channelInfo.getStationInfo().getStationId());
        }

        return stationIds;
    }



    static public String getDataServiceObjectName(DataService<?> dataService) {
        if (dataService instanceof SharedCacheDataServiceClient) {
            return ((SharedCacheDataServiceClient<?>) dataService).getDataObjectClass().getSimpleName();
        } else if (dataService instanceof DataServiceClient) {
            return ((DataServiceClient<?>) dataService).getDataObjectClass().getSimpleName();
        } else {
            return "Unknown";
        }
    }

    static public Date rollBackToStartOfGridUnit(Date date, Integer gridUnitWidth) throws BadParameterException {
        if (0 != MINUTES_IN_ONE_DAY % gridUnitWidth)
            throw new BadParameterException("gridUnitWidth must divide evenly into the total minutes in a day");

        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);

        int minuteOfDay = (calendar.get(Calendar.HOUR_OF_DAY) * 60) + calendar.get(Calendar.MINUTE);
        int minutesToSubtract = minuteOfDay % gridUnitWidth;

        if (0 != minutesToSubtract) {
            int hoursToSubtract = minutesToSubtract / 60;
            minutesToSubtract = minutesToSubtract - (hoursToSubtract * 60);

            calendar.add(Calendar.HOUR_OF_DAY, -hoursToSubtract);
            calendar.add(Calendar.MINUTE, -minutesToSubtract);
            calendar.set(Calendar.MILLISECOND, 0);
        }

        // increment date by one second to exclude endTimes that end on the grid's startTime
        calendar.set(Calendar.SECOND, 1);

        return calendar.getTime();
    }

    static public Date rollForwardToNextGridUnit(Date date, Integer gridUnitWidth) throws BadParameterException {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(GridUtils.rollBackToStartOfGridUnit(date, gridUnitWidth));

        // if a roll back occurred, roll forward one grid unit
        if (date.getTime() - calendar.getTime().getTime() > 0) {
            int hoursToAdd = gridUnitWidth / 60;
            int minutesToAdd = gridUnitWidth - (hoursToAdd * 60);

            calendar.add(Calendar.HOUR_OF_DAY, hoursToAdd);
            calendar.add(Calendar.MINUTE, minutesToAdd);
        }

        // set rolled back second back to 0
        calendar.set(Calendar.SECOND, 0);

        return calendar.getTime();
    }

    static public TimeZone getTimeZone(String id, String defaultId) {
        if (null == id)
            id = defaultId;

        TimeZone timeZone = TimeZone.getTimeZone(id);

        if (timeZone.getID().equals("GMT") && !id.equals("GMT"))
            timeZone = TimeZone.getTimeZone(defaultId);

        return timeZone;
    }

    static public String getTime(Date date, TimeZone timeZone) {
        DateTime utcTime = new DateTime(date);
        DateTime converted = utcTime.withZone(DateTimeZone.forTimeZone(timeZone));
        SimpleDateFormat formatter = new SimpleDateFormat(TIME_FORMAT);
        formatter.setTimeZone(DateTimeZone.forTimeZone(timeZone).toTimeZone());
        return formatter.format(converted.toDate());
    }

    static public Date roundDateDownToMinute(Date date) {
        long time = date.getTime();
        long diff = time % 60000;
        return new Date(time - diff);
    }

    public static Long getIdFromURIString(String CRSUri) {
        if (CRSUri == null)
            return null;

        if (CRSUri.startsWith("merlin:")) {
            return Long.parseLong(CRSUri.substring(7));
        }

        int index = CRSUri.lastIndexOf('/');
        String numberOnly = CRSUri.substring(index + 1);
        return Long.parseLong(numberOnly);
    }

}
