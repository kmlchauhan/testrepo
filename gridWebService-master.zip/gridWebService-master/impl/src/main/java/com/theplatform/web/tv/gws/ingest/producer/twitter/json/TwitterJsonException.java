package com.theplatform.web.tv.gws.ingest.producer.twitter.json;

import com.theplatform.web.tv.GridException;

/**
 * Thrown when a fatal error was encountered parsing JSON from Twitter.
 */
public class TwitterJsonException extends GridException {

    public TwitterJsonException(String message) {
        super(message);
    }

    public TwitterJsonException(String message, Throwable cause) {
        super(message, cause);
    }

    public TwitterJsonException(Throwable cause) {
        super(cause);
    }
}
