package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.web.tv.gws.sirius.model.CRSTagAssociation;

import static com.theplatform.data.persistence.translator.converter.LocalUriConverter.convertUriToID;

/**
 * @author jcoelho
 * @since 6/9/15.
 */
public class TagAssociationConverter extends AbstractDataObjectConverter<TagAssociation, CRSTagAssociation> {

    @Override
    public CRSTagAssociation convert(TagAssociation dataObject) {
        return new CRSTagAssociation(
                convertUriToID(dataObject.getId()),
                convertUriToID(dataObject.getTagId()),
                convertUriToID(dataObject.getEntityId()));
    }

}
