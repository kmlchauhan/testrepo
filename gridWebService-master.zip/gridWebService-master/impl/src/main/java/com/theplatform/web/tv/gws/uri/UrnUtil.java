package com.theplatform.web.tv.gws.uri;

import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.module.exception.BadParameterException;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.combine.commons.DataObjectURI;
import com.theplatform.web.tv.combine.commons.InvalidDataObjectURIException;
import com.theplatform.web.tv.combine.commons.MerlinService;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

public class UrnUtil {
    private static final String FIELD_SEPARATOR = ":";
    public static final String URN_PREFIX = "merlin" + FIELD_SEPARATOR;

    private static String[] urnV3Lookup = new String[MerlinEntityType.values().length];

    /**
     * Package local method that creates an URN using the supplied StringBuilder.
     * @param dataObjectId
     * @param service
     * @param objectName
     * @param strBuilder
     * @return
     */
    static Muri generateUrn(long dataObjectId, MerlinService service, MerlinEntityType objectName, StringBuilder strBuilder) {
        notNull(objectName, "objectName");

        String strUri;
        String prefix = urnV3Lookup[objectName.ordinal()];
        if (prefix==null){
            strBuilder.append(URN_PREFIX).append(service).append(FIELD_SEPARATOR).append(objectName).append(FIELD_SEPARATOR);
            prefix=strBuilder.toString().toLowerCase();
            urnV3Lookup[objectName.ordinal()] = prefix;
            strBuilder.setLength(0);
        }
        strUri = strBuilder.append(prefix).append(dataObjectId).toString();

        return new Muri(strUri, dataObjectId);
    }

    public static Muri generateUrn(long dataObjectId, MerlinService service, MerlinEntityType objectName) {
        StringBuilder strBuilder = new StringBuilder(50);
        return generateUrn(dataObjectId, service, objectName, strBuilder);
    }

    public static Muri generateUrn(URI id) {
        try{
            DataObjectURI dataObjectUri = DataObjectURI.create(id);
            return generateUrn(dataObjectUri.getObjectId(), dataObjectUri.getService(), dataObjectUri.getEntityType());
        }catch (InvalidDataObjectURIException exc){
            throw new BadParameterException("Unable to create URN. Bad dataObjectUri: " + id);
        }
    }

    public static String getUrnService(Muri urn) {
        try{
            String tokens[] = urn.toString().split(FIELD_SEPARATOR);
            return tokens[tokens.length-3];
        }catch (Exception exc){
            throw new BadParameterException(exc.getMessage());
        }
    }

    public static List<Muri> convertUrns(List<Muri> urns){
        return convertUrns(urns, null);
    }
    public static List<Muri> convertUrns(List<Muri> urns, MerlinService serviceOverride){
        List<Muri> convertedUrns = new ArrayList<Muri>(urns.size());
        for (Muri urn : urns){
            convertedUrns.add( convertUrn( urn, serviceOverride) );
        }
        return convertedUrns;
    }

    @Deprecated
    public static Muri convertUrn(Muri urn){
        return convertUrn(urn, null);
    }
    public static Muri convertUrn(Muri urn, MerlinService serviceOverride){
        if (urn==null) return null;
        String tokens[] = urn.toString().split(FIELD_SEPARATOR);
        if (tokens.length<4) return urn;         // Unfortunately, ARS is sending us nonstandard URNs (e.g. RecorderMananager).  Just leave them as-is
        urn = handleAmbiguousUrnVersion1(urn, serviceOverride);

        Long id = urn.getId();
        String merlinEntityType = tokens[tokens.length-2];
        MerlinService merlinService = serviceOverride;

        // No specified merlinService override and v2 or v3 then attempt to use specified service
        if (merlinService==null && (tokens.length==5 || tokens[0].equals("merlin"))){
            merlinService = MerlinService.valueFromServiceName(tokens[tokens.length-3]);
        }

        // Service is still, derive it from entity type
        if (merlinService==null){
            MerlinEntityType type = MerlinEntityType.valueOfNoCase(tokens[tokens.length-2]);
            merlinService = MerlinService.valueFromMerlinEntityType(type);
        }

        return new Muri("merlin" + FIELD_SEPARATOR + merlinService.getServiceName().toLowerCase() + FIELD_SEPARATOR + merlinEntityType.toLowerCase() + FIELD_SEPARATOR + id, id);
    }

    private static String properMerlinEntityTypeCase(String merlinEntityType){
        return MerlinEntityType.valueOfNoCase(merlinEntityType).getTypeString();
    }

    /**
     * Promote the URN v1 to v2 using service override.
     */
    private static Muri handleAmbiguousUrnVersion1(Muri urn, MerlinService serviceOverride){
        String tokens[] = urn.toString().split(":");
        if (serviceOverride!=null && tokens.length==4  && tokens[0].equalsIgnoreCase("comcast")){
            return new Muri("comcast" + FIELD_SEPARATOR + "merlin" + FIELD_SEPARATOR + serviceOverride.getServiceName() + FIELD_SEPARATOR + tokens[2] + FIELD_SEPARATOR + tokens[3]);
        }else{
            return urn;
        }
    }

    private static void notNull(Object o, String objectName) throws BadParameterException{
        if (o == null)
            throw new BadParameterException(objectName + " is required");
    }

    public static MerlinEntityType getUrnEntityType(String urn) {
        if (urn == null) throw new BadParameterException("urn is required");
        try {
            String tokens[] = urn.split(FIELD_SEPARATOR);
            return MerlinEntityType.valueOfNoCase(tokens[tokens.length - 2]);
        } catch (Exception exc) {
            throw new BadParameterException("The following URN parameter is malformed: " + urn);
        }
    }

    public static MerlinEntityType getUrnEntityType(Muri urn) {
        if (urn == null) throw new BadParameterException("urn is required");
        return getUrnEntityType(urn.toString());
    }

    public static MerlinEntityType getUrnEntityType(URI urn) {
        if (urn == null) throw new BadParameterException("urn is required");
        return getUrnEntityType(urn.toString());
    }
}
