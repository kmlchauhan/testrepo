package com.theplatform.web.tv.gws.ingest.maintainer;

import com.comcast.merlin.sirius.ingest.Event;
import com.comcast.merlin.sirius.ingest.maintainer.LongDataRepoMaintainer;
import com.comcast.merlin.sirius.ingest.producer.dataservice.DataObjectReceiver;
import com.comcast.merlin.sirius.ingest.producer.dataservice.client.ClientFacade;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.credit.ByProgramId;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.web.tv.gws.sirius.model.CRSCredit;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.repository.CreditRepository;
import com.theplatform.web.tv.gws.sirius.repository.ProgramRepository;

public class CreditRepositoryMaintainer extends LongDataRepoMaintainer<CRSCredit> {
    private final CreditRepository creditRepository;
    private final ProgramRepository programRepository;
    private final SiriusObjectType programSiriusObjectType;

    protected CreditRepositoryMaintainer(DataObjectReceiver dataObjectReceiver, ClientFacade creditClientFacade,
                                         CreditRepository creditRepository, ProgramRepository programRepository) {
        super(dataObjectReceiver, creditClientFacade);

        this.creditRepository = creditRepository;
        this.programRepository = programRepository;
        this.programSiriusObjectType = programRepository.getType();
    }

    @Override
    protected boolean shouldIngest(CRSCredit credit) {
        return programRepository.containsKey(credit.getProgramId());
    }

    @Override
    @SuppressWarnings({"unchecked"})
    protected void consumeOtherPut(Event event) {
        validateOtherEvent(event);

        CRSProgram program = (CRSProgram) event.getCrsDataObject();
        long programId = program.getId();

        // only need to ingest Credits for new programs
        if (programRepository.containsKey(programId)) return;

        Feed<Credit> feed = (Feed<Credit>) clientFacade.getAll(new ByProgramId(programId), retryOptions);
        ingest(feed);
    }

    @Override
    protected void consumeOtherDelete(Event event) {
        validateOtherEvent(event);

        Long programId = Long.valueOf(event.getKey().getId());

        for (CRSCredit crsCredit : creditRepository.getCredits(programId)) {
            egest(crsCredit.getId(), programId);
        }
    }

    private void validateOtherEvent(Event event) {
        SiriusObjectType eventType = event.getCrsObjectType();

        if (!eventType.equals(programSiriusObjectType)) {
            throw new IllegalArgumentException("Unexpected event type: " + eventType);
        }
    }
}
