package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.ListingProto.ListingMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSListing;
import com.theplatform.web.tv.gws.sirius.model.CRSRating;

import java.util.List;

public class ListingSerializer extends AbstractSiriusObjectSerializer<CRSListing> {

    public ListingSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSListing unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        ListingMessage.Builder message = ListingMessage.newBuilder().mergeFrom(bytes);

        CRSListing listing = new CRSListing(message.getId());

        if (message.hasStationId()) {
            listing.setStationId(message.getStationId());
        }
        if (message.hasStartDate()) {
            listing.setStartTime(message.getStartDate());
        }
        if (message.hasEndDate()) {
            listing.setEndTime(message.getEndDate());
        }
        if (message.hasAiringType()) {
            listing.setCrsAiringType(message.getAiringType().intern());
        }
        if (message.hasCaptionType()) {
            listing.setCaptionType(message.getCaptionType().intern());
        }
        if (message.hasHdLevel()) {
            listing.setHdLevel(message.getHdLevel().intern());
        }
        if (message.hasQuality()){
            listing.setQuality(message.getQuality());
        }
        if (message.hasColorDepth()){
            listing.setColorDepth(message.getColorDepth().intern());
        }
        if (message.hasPayPerView()) {
            listing.setPayPerView(message.getPayPerView());
        }
        if (message.hasDescriptiveVideoService()) {
            listing.setDescriptiveVideoService(message.getDescriptiveVideoService());
        }
        if (message.hasProgramId()) {
            listing.setProgramId(message.getProgramId());
        }
        if (message.hasSeriesId()){
            listing.setSeriesId(message.getSeriesId());
        }
        if (message.hasAudioType()){
            listing.setAudioType(message.getAudioType().intern());
        }
        if (message.hasShowingType()){
            listing.setShowingType(message.getShowingType().intern());
        }
        if (message.hasSap()){
            listing.setSap(message.getSap());
        }
        if (message.hasSubjectToBlackout()){
            listing.setSubjectToBlackout(message.getSubjectToBlackout());
        }
        if (message.hasSubtitled()){
            listing.setSubtitled(message.getSubtitled());
        }
        if (message.hasThreeD()){
            listing.setThreeD(message.getThreeD());
        }
        if (message.hasCci()){
            listing.setCci(message.getCci().intern());
        }
        if (message.hasDvrProgramId()){
            listing.setDvrProgramId(message.getDvrProgramId());
        }
        if (message.hasDvrSeriesId()){
            listing.setDvrSeriesId(message.getDvrSeriesId());
        }
        // Content Rating
        List<ListingMessage.ContentRatingMessage> messageContentRatings = message.getContentRatingsList();
        if (!messageContentRatings.isEmpty()){
            CRSRating[] contentRatings = new CRSRating[messageContentRatings.size()];
            for(int i=0; i<messageContentRatings.size(); i++){
                ListingMessage.ContentRatingMessage contentRating = messageContentRatings.get(i);
                String scheme = null;
                if (contentRating.hasScheme()) {
                    scheme = contentRating.getScheme();
                }

                String ratingString = null;
                if (contentRating.hasRating()) {
                    ratingString = contentRating.getRating();
                }

                String[] subratings = null;
                if (contentRating.getSubRatingsList() != null && contentRating.getSubRatingsCount() > 0) {

                    subratings = new String[contentRating.getSubRatingsCount()];
                    contentRating.getSubRatingsList().toArray(subratings);
                }
                CRSRating rating = CRSRating.getInstance(scheme, ratingString, subratings);
                contentRatings[i] = rating;
            }
            listing.setContentRatings(contentRatings);
        }

        return listing;
    }

    @Override
    public ByteString marshallPayload( CRSListing listing) {
        ListingMessage.Builder payload = ListingMessage.newBuilder();
        payload.setId(listing.getId());
        payload.setStationId(listing.getStationId());
        payload.setStartDate(listing.getStartTime());
        payload.setEndDate(listing.getEndTime());
        if (listing.getCrsAiringType() != null)
            payload.setAiringType(listing.getCrsAiringType());
        if (listing.getCaptionType() != null)
            payload.setCaptionType(listing.getCaptionType());
        if (listing.getHdLevel() != null)
            payload.setHdLevel(listing.getHdLevel());
        if (listing.getQuality() != null)
            payload.setQuality(listing.getQuality());
        if (listing.getColorDepth() != null)
            payload.setColorDepth(listing.getColorDepth());
        if (listing.getPayPerView() != null)
            payload.setPayPerView(listing.getPayPerView());
        if (listing.getDescriptiveVideoService() != null)
            payload.setDescriptiveVideoService(listing.getDescriptiveVideoService());
        if(listing.getProgramId() != null)
            payload.setProgramId(listing.getProgramId());

        if(listing.getSeriesId() != null)
            payload.setSeriesId(listing.getSeriesId());
        if(listing.getAudioType() != null)
            payload.setAudioType(listing.getAudioType());
        if(listing.getShowingType() != null)
            payload.setShowingType(listing.getShowingType());
        if(listing.getSap() != null)
            payload.setSap(listing.getSap());
        if(listing.getSubjectToBlackout() != null)
            payload.setSubjectToBlackout(listing.getSubjectToBlackout());
        if(listing.getSubtitled() != null)
            payload.setSubtitled(listing.getSubtitled());
        if(listing.getThreeD() != null)
            payload.setThreeD(listing.getThreeD());
        if(listing.getCci() != null)
            payload.setCci(listing.getCci());
        if(listing.getDvrProgramId() != null)
            payload.setDvrProgramId(listing.getDvrProgramId());
        if(listing.getDvrSeriesId() != null)
            payload.setDvrSeriesId(listing.getDvrSeriesId());
        // Content Rating
        if (listing.getContentRatings()!=null && listing.getContentRatings().length>0){
            for (CRSRating crsRating : listing.getContentRatings()){
                ListingMessage.ContentRatingMessage.Builder contentRatingBuilder = ListingMessage.ContentRatingMessage.newBuilder();
                if (crsRating.getScheme() != null)
                    contentRatingBuilder.setScheme(crsRating.getScheme().intern());
                if (crsRating.getRating() != null)
                    contentRatingBuilder.setRating(crsRating.getRating().intern());
                if (crsRating.getSubRatings() != null) {
                    for (String subRating : crsRating.getSubRatings()) {
                        contentRatingBuilder.addSubRatings(subRating);
                    }
                }
                payload.addContentRatings(contentRatingBuilder.build());
            }
        }
        return payload.build().toByteString();
    }

}
