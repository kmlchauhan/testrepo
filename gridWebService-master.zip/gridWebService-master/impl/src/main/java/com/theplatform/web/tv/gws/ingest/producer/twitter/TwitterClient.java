package com.theplatform.web.tv.gws.ingest.producer.twitter;


import com.theplatform.web.tv.gws.ingest.producer.twitter.json.TwitterError;
import com.theplatform.web.tv.gws.ingest.producer.twitter.json.TwitterJsonParser;
import com.theplatform.web.tv.gws.ingest.producer.twitter.json.TwitterTrendingResponse;
import com.theplatform.web.tv.GridException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.*;
import org.apache.http.client.fluent.Form;
import org.apache.http.client.fluent.Request;
import org.apache.http.message.BasicHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;


/**
 * Client for Twitter's TV API that uses Apache Http Components.  Note that this
 * class is <strong>NOT</strong> threadsafe.
 */
public class TwitterClient {
    private final static int RATE_LIMIT_EXCEEDED = 429;

    private final Logger log = LoggerFactory.getLogger(getClass());

    // dependencies
    private TwitterJsonParser jsonParser;
    private TwitterMBean mbean;

    // settings
    private String apiKey;
    private String apiSecret;
    private String tokenUrl;
    private String metricsUrl;
    private int connectTimeoutMs;
    private int socketTimeoutMs;
    private HttpHost proxy;

    // internal state
    private String bearerToken;

    /**
     * Create an HTTP Authorization header based on the API key and API secret
     * @return a Base64 encoded Basic Authorization header
     */
    protected Header apiKeyBasicAuth() {
        String unencoded = this.apiKey + ":" + this.apiSecret;
        byte[] unencodedBytes = unencoded.getBytes(StandardCharsets.UTF_8);
        byte[] base64EncodedBytes = Base64.encodeBase64(unencodedBytes);
        String base64EncodedString = new String(base64EncodedBytes, StandardCharsets.UTF_8);
        return new BasicHeader(HttpHeaders.AUTHORIZATION, "Basic " + base64EncodedString);
    }

    /**
     * Convert an HttpResponse to a String, closing the underlying InputStream
     * @param response non-null response
     * @return String representation of the response
     * @throws IOException if the content could not be extracted from the response
     */
    protected String responseToString(HttpResponse response) throws IOException {
        try (InputStream stream = response.getEntity().getContent()) {
            return IOUtils.toString(stream);
        }
    }

    /**
     * Build an exception using the provided response code, and if possible, the details
     * extracted from the JSON.
     * @param code HTTP error code
     * @param json possibly null JSON string
     * @return a GridException containing at a minimum, a human readable message and the HTTP status code.
     * @see TwitterJsonParser#parseErrorsResponse(String)
     */
    protected GridException buildException(int code, String json) {
        mbean.incrementHttpErrorResponse();

        StringBuilder sb = new StringBuilder(256)
            .append("Request to Twitter failed - HTTP ")
            .append(code);

        // see if the response is JSON that contains an error description
        List<TwitterError> errors = jsonParser.parseErrorsResponse(json);
        if (!errors.isEmpty()) {
            sb.append(": ")
                .append(StringUtils.join(errors, ", "));
        }

        return new GridException(sb.toString());
    }

    /**
     * Retrieve a bearer token using the {@link TwitterSettings#apiKey apiKey} and {@link TwitterSettings#apiSecret}.
     * Note that the bearer token is valid forever.
     * @throws IOException if the HTTP request could not be executed
     * @throws GridException if the HTTP request was executed but a non-200 code was returned
     */
    protected void fetchOAuth2BearerToken() throws IOException, GridException {

        if (log.isDebugEnabled()) {
            log.debug("Requesting Bearer token from Twitter");
        }

        // send the request
        Form login = Form.form().add("grant_type", "client_credentials");
        HttpResponse response = Request.Post(tokenUrl)
            .viaProxy(proxy)
            .bodyForm(login.build())
            .connectTimeout(connectTimeoutMs)
            .socketTimeout(socketTimeoutMs)
            .addHeader(apiKeyBasicAuth())
            .execute()
            .returnResponse();

        // get the code and response body
        int code = response.getStatusLine().getStatusCode();
        String json = responseToString(response);

        // extract and save the bearer token
        if (code == HttpStatus.SC_OK) {
            mbean.incrementHttpOkResponse();
            this.bearerToken = jsonParser.parseAuthResponse(json);

            if (log.isDebugEnabled()) {
                log.debug("Successfully retrieved Bearer token");
            }
        }
        else if (code == HttpStatus.SC_METHOD_FAILURE || code == RATE_LIMIT_EXCEEDED) {
            mbean.incrementRateLimitExceeded();
            throw buildException(code, json);
        }
        else {
            throw buildException(code, json);
        }
    }

    /**
     * Retrieve the trending items JSON from Twitter and map the JSON to a <code>TwitterTrendingResponse</code>.
     * <b>Note that this method assumes that the {@link #bearerToken} has already been set.</b>
     * @return TwitterTrendingResponse parsed from the JSON
     * @throws IOException if the HTTP request could not be executed
     * @throws GridException if the HTTP request was executed but a non-200 code was returned
     */
    protected TwitterTrendingResponse fetchTrendingResponsesInternal() throws IOException, GridException {
        if (log.isDebugEnabled()) {
            log.debug("Requesting trending items from Twitter");
        }

        BasicHeader bearerAuth = new BasicHeader(HttpHeaders.AUTHORIZATION, "Bearer " + bearerToken);

        // send the request
        HttpResponse httpResponse = Request.Get(metricsUrl)
            .viaProxy(proxy)
            .connectTimeout(connectTimeoutMs)
            .socketTimeout(socketTimeoutMs)
            .addHeader(bearerAuth)
            .execute()
            .returnResponse();

        // get the code and response body
        int code = httpResponse.getStatusLine().getStatusCode();
        String json = responseToString(httpResponse);

        if (code == HttpStatus.SC_OK) {
            mbean.incrementHttpOkResponse();

            if (log.isDebugEnabled()) {
                log.debug("Successfully retrieved trending items");
            }

            return jsonParser.parseTrendingResponse(json);
        }
        else {
            throw buildException(code, json);
        }
    }

    /**
     * Retrieve the trending items JSON from Twitter and map the JSON to a <code>TwitterTrendingResponse</code>.
     * @return a TwitterTrendingResponse, most likely containing one or more TwitterItems
     * @throws GridException if the required HTTP requests failed to execute or returned non-200 responses
     */
    public TwitterTrendingResponse fetchTrendingResponses() throws GridException {
        try {
            // get an OAuth2 Bearer token
            if (bearerToken == null) {
                fetchOAuth2BearerToken();
            }

            // use the token to hit another URL that returns the trending items
            return fetchTrendingResponsesInternal();
        }
        catch (IOException e) {
            throw new GridException(e);
        }
    }

    @Required
    public void setJsonParser(TwitterJsonParser jsonParser) {
        this.jsonParser = jsonParser;
    }

    @Required
    public void setMbean(TwitterMBean mbean) {
        this.mbean = mbean;
    }

    @Required
    public void setSettings(TwitterSettings settings) {
        this.apiKey = settings.getApiKey();
        this.apiSecret = settings.getApiSecret();
        this.tokenUrl = settings.getTokenURL();
        this.metricsUrl = settings.getMetricsURL();
        this.connectTimeoutMs = settings.getConnectTimeoutMs();
        this.socketTimeoutMs = settings.getSocketTimeoutMs();

        if (StringUtils.isNotBlank(settings.getProxyHost()) && settings.getProxyPort() != null) {
            this.proxy = new HttpHost(settings.getProxyHost(), settings.getProxyPort());
        }
    }
}
