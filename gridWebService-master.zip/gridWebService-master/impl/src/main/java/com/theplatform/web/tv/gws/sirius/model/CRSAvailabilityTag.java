package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSAvailabilityTag extends LongDataRepoObject {

    private boolean national;
    private long ownerId;

    public CRSAvailabilityTag() {
        super( SiriusObjectType.fromFriendlyName("AvailabilityTag"));
    }

    public CRSAvailabilityTag(long id) {
        super( SiriusObjectType.fromFriendlyName("AvailabilityTag"), id);
    }

    public boolean getNational() {
        return national;
    }

    public void setNational(boolean national) {
        this.national = national;
    }

    public long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(long ownerId) {
        this.ownerId = ownerId;
    }
}
