package com.theplatform.web.tv.gws.ingest.consumer.notifier;

import com.comcast.merlin.sirius.ingest.Event;
import com.comcast.merlin.sirius.model.RepositoryObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.web.tv.gws.ingest.consumer.notifier.check.Check;
import com.theplatform.web.tv.gws.ingest.consumer.notifier.model.CRSNotification;
import com.theplatform.web.tv.gws.ingest.consumer.notifier.model.NotificationConverter;
import com.theplatform.web.tv.gws.ingest.consumer.notifier.publisher.Publisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.util.List;
import java.util.Map;

public class Notifier {
    private static final Logger LOGGER = LoggerFactory.getLogger(Notifier.class);

    private Publisher publisher;
    private SequenceTracker sequenceTracker;
    private Map<SiriusObjectType, NotificationConverter> notificationConverters;
    private Map<SiriusObjectType, Check> publishCheck;
    private NotifierMBean notifierMBean;


    public void publish(Event event) {
        if (notificationConverters.containsKey(event.getCrsObjectType()) && sequenceTracker.isNotifiableEvent(event)){
            // 1- Checks
            RepositoryObject repositoryDataObject = event.getCrsDataObject();
            if (publishCheck.containsKey(event.getCrsObjectType())){
                if ( ! publishCheck.get(event.getCrsObjectType()).shouldPublish(event)){
                    // Failed check - do not not notify
                    LOGGER.info("Task=AwsPublisher Event=DroppedNotification id={} sequence={}", event.getKey().getId(), event.getSequence());
                    return;
                }
            }

            // 2- Convert *
            NotificationConverter notificationConverter = notificationConverters.get(event.getCrsObjectType());
            List<CRSNotification> notifications = notificationConverter.convert( Long.parseLong(event.getKey().getId()), repositoryDataObject, event.getAction(), event.getSequence());

            for (CRSNotification notificationObject : notifications) {
                // 3- Publish *
                int attempts = 0;
                while (true) {
                    attempts++;
                    try {
                        publisher.publish(notificationObject);
                        break;
                    } catch (Throwable throwable) {
                        LOGGER.error("Task=AwsPublisher Error=FailedToPublish id={} SourceId={} Type={}", event.getKey().getId(), notificationObject.getSourceId(), event.getCrsObjectType().getFriendlyName(), throwable);
                        long delay = ((long) Math.pow(2, attempts + 1) * 1000L);
                        try {
                            Thread.sleep(delay);
                        } catch (Exception e) {
                        }
                        ;
                    }

                }
                Long messageDelay = (event.getSiriusCreateTimestamp() != null && event.getSiriusCreateTimestamp() > 0) ? System.currentTimeMillis() - event.getSiriusCreateTimestamp() : null;
                LOGGER.info("Task=AwsPublisher Event=NotificationPublished ID={} SourceId={} NotificationId={} Type={} Action={} MessageDelay={} ", event.getKey().getId(), notificationObject.getSourceId(), notificationObject.getNotificationId(), notificationObject.getType(), notificationObject.getMethod(), messageDelay);
                notifierMBean.notificationPublished(event.getCrsObjectType(), messageDelay);
            }
        }
    }

    public void tickle(long objectId) throws Exception{
        SiriusObjectType siriusObjectType = SiriusObjectType.fromDataObjectId(objectId);
        if (siriusObjectType==null) {
            throw new Exception("We do not recognize the object type on " + objectId );
        }else if (!notificationConverters.containsKey(siriusObjectType)){
            throw new Exception("We do not support publishing notifications for object type " + siriusObjectType.getFriendlyName() + " on " + objectId );
        }

// TODO Implement - Possibly create a put/delete event and share some of the same logic as publish but without the checks


    }

    @Required
    public void setPublisher(Publisher publisher) {
        this.publisher = publisher;
    }

    @Required
    public void setSequenceTracker(SequenceTracker sequenceTracker) {
        this.sequenceTracker = sequenceTracker;
    }

    @Required
    public void setNotificationConverters(Map<SiriusObjectType, NotificationConverter> notificationConverters) {
        this.notificationConverters = notificationConverters;
    }

    @Required
    public void setPublishCheck(Map<SiriusObjectType, Check> publishCheck) {
        this.publishCheck = publishCheck;
    }

    @Required
    public void setNotifierMBean(NotifierMBean notifierMBean) {
        this.notifierMBean = notifierMBean;
    }
}
