package com.theplatform.web.tv.gws.service.contentresolution;

import com.comcast.compass.availability.common.domain.Availabilities;
import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.gws.sirius.model.CRSProductContext;
import com.theplatform.web.tv.gws.sirius.repository.ChannelRepository;
import com.theplatform.web.tv.gws.sirius.repository.ProductContextRepository;
import com.theplatform.web.tv.gws.service.common.logic.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.net.URI;
import java.util.Iterator;
import java.util.List;

/**
 * This class modifies the request to be backwards compatible.
 *
 * Station Scoped Availabilities with Tagging PC containing Tagging Locations will be updated
 * to have the Locations of the first TitleVI identified.
 *
 */
public class AvailabilitiesResolutionModifier {
    private static Logger logger = LoggerFactory.getLogger(AvailabilitiesResolutionModifier.class);

    private ChannelRepository channelRepository;
    private ProductContextRepository productContextRepository;


    public void modify(AvailabilityResolution availabilityResolution){
        if (availabilityResolution==null || availabilityResolution.getAvailabilityGroups()==null) return;
        // Get the first non-cDVR/non-cTV Locations
        Iterator<Availabilities> iterAvailabilities = availabilityResolution.getAvailabilityGroups().iterator();
        List<URI> nonTaggingLocations = null;
        while (iterAvailabilities.hasNext()){
            Availabilities availabilities = iterAvailabilities.next();
            if (Scope.STATION.name().equalsIgnoreCase(availabilities.getScope())){
                URI pcUri = availabilities.getProductContext();
                if (pcUri != null){
                    long id = Muri.getObjectId(pcUri);
                    CRSProductContext productContext = productContextRepository.get(id);
                    // Non-Tagging PC
                    if (productContext  != null && !channelRepository.isTaggingProductContext(Muri.getObjectId(pcUri))){
                        nonTaggingLocations = availabilities.getAvailabilityIds();
                        break;
                    }
                }
            }
        }

        // Replace any Tagging locations on Station Scope Availabilities with TitleVI
        iterAvailabilities = availabilityResolution.getAvailabilityGroups().iterator();
        if (nonTaggingLocations != null){
            while (iterAvailabilities.hasNext()){
                Availabilities availabilities = iterAvailabilities.next();
                if (Scope.STATION.name().equalsIgnoreCase(availabilities.getScope())){
                    URI pcUri = availabilities.getProductContext();
                    if (pcUri != null
                            && channelRepository.isTaggingProductContext(Muri.getObjectId(pcUri))
                            && containsTaggingLocations(availabilities.getAvailabilityIds())){
                        logger.warn("CRS AvailabilitiesResolutionModifier.  Tagging Locations Provided. ");
                        availabilities.setAvailabilityIds(nonTaggingLocations);
                    }
                }
            }
        }
    }

    private boolean containsTaggingLocations(List<URI> locations){
        for (URI location : locations){
            if (channelRepository.isTaggingLocation(Muri.getObjectId(location))) return true;
        }
        return false;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    @Required
    public void setProductContextRepository(ProductContextRepository productContextRepository) {
        this.productContextRepository = productContextRepository;
    }
}
