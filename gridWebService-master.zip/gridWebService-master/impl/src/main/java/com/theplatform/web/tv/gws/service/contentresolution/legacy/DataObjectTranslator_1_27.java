package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.theplatform.web.tv.contentresolution.api.objects.ApiObjectVisitor;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.contentresolution.api.objects.LocatorInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;

public class DataObjectTranslator_1_27 extends ApiObjectVisitor {
    public final static DataObjectTranslator_1_27 INSTANCE = new DataObjectTranslator_1_27();

    @Override
    public void visitLocatorInfo(LocatorInfo locatorInfo) {
        locatorInfo.setPlayerConfig(null);
    }

    @Override
    public void visitListingInfo(ListingInfo listingInfo){
        listingInfo.setColorDepth(null);
    }
}
