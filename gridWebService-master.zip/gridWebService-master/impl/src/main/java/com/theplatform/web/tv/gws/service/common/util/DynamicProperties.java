package com.theplatform.web.tv.gws.service.common.util;

import com.theplatform.web.tv.gws.sirius.repository.ServiceStateRepository;

import java.util.Map;

public class DynamicProperties {

    private ServiceStateRepository serviceStateRepository;
    private Map<String, String> baseProperties;

    public DynamicProperties(ServiceStateRepository serviceStateRepository, Map<String, String> baseProperties){
        this.serviceStateRepository = serviceStateRepository;
        this.baseProperties = baseProperties;
    }

    @Deprecated
    public String get(String property){
        if (serviceStateRepository.getProperty(property)!=null){
            return serviceStateRepository.getProperty(property);
        } else {
            return baseProperties.get(property);
        }
    }

    public String get(DynamicPropertiesEnum dynamicPropertiesEnum){
        return get(dynamicPropertiesEnum.getProperty());
    }

    public enum DynamicPropertiesEnum{

        GRACENOTE_LOCATION_FILTER("gridWebService.gracenote.location.filter.enabled"),
        LOCATOR_CA_ENABLED("gridWebService.locatorca.enabled"),
        NEWLOGIC_CHANNEL_PRODUCTCONTEXT_ENABLED("gridWebService.newproductcontextlogic.productContext.channels.enabled"),
        NOTIFIER_ACK_ENABLED("gridWebService.notifier.ack.enabled"),
        ONO_SYNTHETIC_ENABLED("gridWebService.ono.synthetic.enabled"),
        PHASE2_CDVR_ENABLED("gridWebService.newproductcontextlogic.phase2.ctv.enabled"),
        PHASE2_CTV_ENABLED("gridWebService.newproductcontextlogic.phase2.cdvr.enabled"),
        TWITTER_TRENDING_API_ENABLED("gridWebService.contentResolution.twitter.api.enabled")
        ;

        private String property;

        DynamicPropertiesEnum(String property){
            this.property = property;
        }

        public String getProperty() {
            return property;
        }
    }




}
