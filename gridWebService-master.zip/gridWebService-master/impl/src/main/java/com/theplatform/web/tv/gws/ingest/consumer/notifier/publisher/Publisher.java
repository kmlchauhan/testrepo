package com.theplatform.web.tv.gws.ingest.consumer.notifier.publisher;

import com.theplatform.web.tv.gws.ingest.consumer.notifier.model.CRSNotification;

public interface Publisher {
    public boolean publish( CRSNotification CRSNotification);
}
