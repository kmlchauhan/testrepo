package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.LocationProto.LocationMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSLocation;

/**
 * Factory that converts Location protobufs to CRSLocations and visa-versa.
 * 
 */
public class LocationSerializer extends AbstractSiriusObjectSerializer<CRSLocation> {

    public LocationSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSLocation unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        LocationMessage.Builder message = LocationMessage.newBuilder().mergeFrom(bytes);

        CRSLocation location = new CRSLocation(message.getId());

        if (message.hasProductContextId()) {
            location.setProductContextId(message.getProductContextId());
        }

        if (message.hasOwnerId()){
            location.setOwnerId(message.getOwnerId());
        }
        if (message.hasSource()) {
            location.setSource(message.getSource());
        }
        return location;
    }

    @Override
    public ByteString marshallPayload(CRSLocation location) {
        LocationMessage.Builder builder = LocationMessage.newBuilder();

        builder.setId(location.getId());
        if (location.getProductContextId()!=null) builder.setProductContextId(location.getProductContextId());
        builder.setOwnerId(location.getOwnerId());
        if (location.getSource() != null) {
            builder.setSource(location.getSource());
        }

        return builder.build().toByteString();
    }


}
