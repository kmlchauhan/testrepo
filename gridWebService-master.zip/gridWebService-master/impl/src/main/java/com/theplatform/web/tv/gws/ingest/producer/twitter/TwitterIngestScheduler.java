package com.theplatform.web.tv.gws.ingest.producer.twitter;

import com.comcast.merlin.sirius.ingest.EventProducer;
import com.comcast.merlin.sirius.ingest.IngestMode;
import com.comcast.merlin.sirius.ingest.dispatcher.SiriusIngester;
import org.apache.commons.lang3.concurrent.BasicThreadFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Schedule the TwitterIngester to run with a fixed delay between runs.  This scheduler
 * receives start/stop commands from {@link SiriusIngester SiriusIngester}
 * and disables the ingester accordingly.
 */
public class TwitterIngestScheduler implements EventProducer, Runnable {
    private final static String TWITTER_THREAD_NAME = "Twitter-generator-%d";
    private final static long INITIAL_DELAY_SECONDS = 10;

    private final Logger log = LoggerFactory.getLogger(getClass());

    // dependencies
    private TwitterIngester ingester;
    private TwitterSettings settings;
    private TwitterMBean mbean;

    // internal state
    private ScheduledExecutorService scheduler;
    private AtomicBoolean started = new AtomicBoolean();


    @PostConstruct
    public void startup() {
        log.info("Starting Twitter threadpool");

        // run the job in a single thread.  the termination of one run and the start of the next
        // is guaranteed to be X seconds apart.
        BasicThreadFactory factory =  new BasicThreadFactory.Builder().namingPattern(TWITTER_THREAD_NAME).build();
        scheduler = Executors.newSingleThreadScheduledExecutor(factory);
        scheduler.scheduleWithFixedDelay(this, INITIAL_DELAY_SECONDS, settings.getRefreshIntervalSeconds(), TimeUnit.SECONDS);
    }

    @PreDestroy
    public void shutdown() {
        log.info("Stopping Twitter threadpool");
        scheduler.shutdown();
        log.info("Twitter threadpool stopped");
    }

    @Override
    public void run() {

        try
        {
            // for simplicity, the scheduled task always runs but it doesn't always kick off the ingester
            if (settings.isEnabled() && started.get()) {
                ingester.runTwitterIngest();;
            }
        }
        catch (Exception e) {
            log.error("Failed to update trending programs from Twitter", e);
        }
    }

    // handle master change and start/stop notifications by toggling a boolean variable

    @Override
    public void start(IngestMode mode) {

        // the twitter ingester doesn't run in bulk mode
        if (mode == IngestMode.BULK || mode == IngestMode.SLAVE) {
            log.info("{} mode enabled, skipping Twitter ingester", mode);
            return;
        }

        log.info("Starting Twitter ingester");
        started.set(true);
    }

    @Override
    public void stop() {
        log.info("Stopping Twitter ingester");
        started.set(false);
        mbean.clearStats();
    }

    @Override
    public boolean isRunning() {
        return started.get();
    }

    @Required
    public void setIngester(TwitterIngester ingester) {
        this.ingester = ingester;
    }

    @Required
    public void setSettings(TwitterSettings settings) {
        this.settings = settings;
    }

    @Required
    public void setMbean(TwitterMBean mbean) {
        this.mbean = mbean;
    }
}
