package com.theplatform.web.tv.gws.ingest.producer.twitter;


import com.google.common.collect.Lists;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.id.api.client.MerlinSourceClient;
import com.theplatform.data.tv.id.api.client.query.merlinsource.ByEntityType;
import com.theplatform.data.tv.id.api.client.query.merlinsource.ByNativeProviderId;
import com.theplatform.data.tv.id.api.client.query.merlinsource.ByProviderName;
import com.theplatform.data.tv.id.api.data.objects.MerlinSource;
import com.theplatform.data.tv.id.api.fields.MerlinSourceField;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms;
import com.theplatform.web.tv.gws.ingest.producer.twitter.json.AlternateIdSource;
import com.theplatform.web.tv.gws.ingest.producer.twitter.json.TwitterItem;
import com.theplatform.web.tv.gws.ingest.producer.twitter.json.TwitterTrendingResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.net.URI;
import java.util.*;

/**
 * Maps TwitterTrendingResponse + TwitterItems (received from Twitter in JSON format) to CRSTrendingPrograms + CRSTrendingProgram.
 * Performs filtering based on {@link TwitterSettings#getScoreCutoff() scoreCuttoff}.  Note that this class is stateful
 * and a new instance should be used for each TwitterTrendingResponse that is processed.
 */
class TwitterResponseToCRSTrendingPrograms {
    private final static int ID_BATCH_SIZE = 50;
    private final static String[] MERLIN_SOURCE_FIELDS = new String[] {MerlinSourceField.merlinId.getLocalName(), MerlinSourceField.providerName.getLocalName(), MerlinSourceField.nativeProviderId.getLocalName()};

    private final Logger log = LoggerFactory.getLogger(getClass());

    // dependencies
    private MerlinSourceClient merlinSourceClient;
    private MerlinIdHelper idHelper;
    private TwitterSettings settings;
    private TwitterMBean mbean;

    // internal state below...

    /**
     * JSON response received from Twitter.
     */
    private TwitterTrendingResponse response;


    /**
     * Nested Map that holds TwitterItems (actual JSON response from Twitter) by source (TVGUIDE, TMS)
     * and nativeId.  For example:
     * <pre>
     *
     *   {
     *      "Rovi": {
     *          "1234": item,
     *          "4567": otherItem
     *      },
     *      "TMS": {
     *          "789": thirdItem,
     *          "1123": fourthItem
     *      }
     *  }
     * </pre>
     */
    private Map<AlternateIdSource, Map<String, TwitterItem>> nativeIdsToTwitterItems = new HashMap<>();

    /**
     * Our eventual return value.  The goal of this class is to populate this List and return it as
     * part of a CRSTrendingPrograms.
     */
    private List<CRSTrendingProgram> trendingPrograms;

    /**
     * Add a TwitterItem to {@link #nativeIdsToTwitterItems} by source and nativeId.  The TwitterItem
     * is expected to have at least one id from the provided source.  If more than one alternateId
     * for the source exists only the first one is used.
     * @param source non-null source.
     * @param item non-null item.
     */
    protected void mapBySourceAndNativeId(AlternateIdSource source, TwitterItem item) {

        // for whatever reason the Twitter JSON allows for multiple IDs from the same source.  just use the first id.
        String nativeId = item.getFirstAlternateId(source);

        // possibly log a message if there is more than one ID from a specific provider
        if (log.isDebugEnabled() && item.hasMultipleExternalIds(source)) {
            log.debug("Twitter item {} has multiple {} ids, using {}", item, source.getMerlinSourceProviderName(), nativeId);
        }

        // get the map of nativeId => TwitterItem for the current AlternateIdSource.
        Map<String, TwitterItem> providerNativeIdToItems = nativeIdsToTwitterItems.get(source);

        // initialize the Map if it doesn't exist
        if (providerNativeIdToItems == null) {
            providerNativeIdToItems = new HashMap<>();
            nativeIdsToTwitterItems.put(source, providerNativeIdToItems);
        }

        // store by source + nativeId
        providerNativeIdToItems.put(nativeId, item);
    }

    /**
     * Map the TwitterItems in the {@link #response} by source and nativeId/alternateId.  TwitterItems
     * with a tweetCount less than the scoring threshold are skipped.
     */
    protected void mapTwitterItems() {
        for (TwitterItem item : response) {

            // skip items that don't meet the scoring threshold
            if (item.getTweetCount() < settings.getScoreCutoff()) {
                continue;
            }

            // loop over our known alternate ID sources in preferred order
            for (AlternateIdSource currentSource : AlternateIdSource.values()) {

                // if the TwitterItem has at least one id from the current external source
                if (item.hasAlternateIds(currentSource)) {
                    mapBySourceAndNativeId(currentSource, item);
                    break;
                }
            }
        }
    }

    /**
     * Perform some sanity checks on the results returned from idDataService.  Specifically, that
     *
     * <ul>
     *     <li>MerlinSource.providerName matches AlternateIdSource.merlinSourceProviderName</li>
     *     <li>the MerlinSource has not already been processed</li>
     *     <li>MerlinSource.nativeProviderId was part of the search</li>
     * </ul>
     * @param source the source used to query idDataService
     * @param expectedNativeProviderIds the native provider ids that are expected in the MerlinSource
     * @param merlinSource the MerlinSource returned from idDataService Feed
     * @return true if the sanity check passes
     */
    protected boolean sanityCheckMerlinSource(AlternateIdSource source, List<String> expectedNativeProviderIds, MerlinSource merlinSource) {
        String expectedProviderName = source.getMerlinSourceProviderName();
        String actualProviderName = merlinSource.getProviderName();
        String actualNativeProviderId = merlinSource.getNativeProviderId();

        boolean success = false;
        if (!expectedProviderName.equals(actualProviderName)) {
            log.warn("idDataService returned a MerlinSource with an unexpected providerName (expected {} but got {})", expectedProviderName, actualProviderName);
        }
        else if (!this.nativeIdsToTwitterItems.get(source).containsKey(actualNativeProviderId)) {
            if (expectedNativeProviderIds.contains(actualNativeProviderId)) {
                log.warn("idDataService returned a duplicate MerlinSource for providerName = {}, nativeProviderId = {}", expectedProviderName, actualNativeProviderId);
            }
            else {
                log.warn("idDataService returned an unexpected MerlinSource.  found nativeProviderId = {}, was expecting one of {}", actualNativeProviderId, expectedNativeProviderIds);
            }
        }
        else {
            success = true;
        }

        return success;
    }

    /**
     * Execute a batch of ID lookups for a single provider/source.
     * <ul>
     *     <li>The lookups are executed in a single batch.</li>
     *     <li>Results from the lookup are associated back to TwitterItems using {@link MerlinSource#getNativeProviderId()}
     *         and {@link #nativeIdsToTwitterItems}.</li>
     *     <li>Information from the original TwitterItem (again, stored in {@link MerlinSource#getNativeProviderId()}) is merged
     *         with the Merlin ID and added to {@link #trendingPrograms} as a new CRSTrendingProgram.</li>
     * </ul>
     * @param source non-null source
     * @param idLookups one or more lookups.
     */
    protected void executeIdLookupBatch(AlternateIdSource source, List<String> idLookups) {
        Query[] query = new Query[]{
            new ByEntityType(MerlinEntityType.PROGRAM.getTypeString()),
            new ByProviderName(source.getMerlinSourceProviderName()),
            new ByNativeProviderId(idLookups)
        };
        Range range = new Range(1, idLookups.size());

        Feed<MerlinSource> idFeed = merlinSourceClient.getAll(MERLIN_SOURCE_FIELDS, query, /* sort order */ null, range, /* count */ false);
        for (MerlinSource merlinSource : idFeed.getEntries()) {

            if (!sanityCheckMerlinSource(source, idLookups, merlinSource)) {
                continue;
            }

            // extract the Merlin Program ID
            URI merlinIdUrn = merlinSource.getMerlinId();
            long id = Muri.getObjectId(merlinIdUrn);

            // We searched using a batch of nativeIds.  Using the nativeId contained in the current
            // idDataService result, get the associated TwitterItem.
            String nativeId = merlinSource.getNativeProviderId();
            TwitterItem item = this.nativeIdsToTwitterItems.get(source).get(nativeId);

            // create a new CRSTrendingProgram using the Program ID returned from idDataService
            // and the score (tweet count) returned by Twitter
            CRSTrendingProgram trendingProgram = new CRSTrendingProgram();
            trendingProgram.setProgramId(id);
            trendingProgram.setScore(item.getTweetCount());
            this.trendingPrograms.add(trendingProgram);

            // remove as we go so we have a list of unprocessed items at the end
            this.nativeIdsToTwitterItems.get(source).remove(nativeId);
        }
    }

    /**
     * Execute Merlin ID lookups for all providers and all items in {@link #nativeIdsToTwitterItems}.  This method is a wrapper
     * around {@link #executeIdLookupBatch(AlternateIdSource, List)} that breaks the lookup tasks into batches of size {@link #ID_BATCH_SIZE}.
     */
    protected void executeIdLookups() {

        // process the nested Map of AlternateIdSource => nativeProviderId => TwitterItem.  loop over each map
        //      {
        //          Rovi1.1:  { nativeIds => TwitterItems}
        //          TMS: { nativeIds => TwitterItems}
        //      }
        //
        // convertIpLocator the inner map from something like this:
        //      {
        //          "1234": item,
        //          "4567": otherItem
        //      }
        //
        // to a list like this:
        //      ["1234", "4567"]
        //
        // and then perform a MerlinSource lookup for each nativeProviderId

        for (Map.Entry<AlternateIdSource, Map<String, TwitterItem>> entry : nativeIdsToTwitterItems.entrySet()) {
            AlternateIdSource jsonSource = entry.getKey();
            Map<String, TwitterItem> currentNativeIdToItems = entry.getValue();

            // all of the nativeIds for the current AlternateIdSource
            List<String> nativeIds = new ArrayList<>(currentNativeIdToItems.size());
            nativeIds.addAll(currentNativeIdToItems.keySet());

            // split the big list into more manageable chunks
            List<List<String>> subLists = Lists.partition(nativeIds, ID_BATCH_SIZE);

            if (log.isDebugEnabled()) {

                // for example, "Mapping 247 TVGUIDE IDs to Merlin IDs in 5 batches of 50"
                log.debug("Mapping {} {} IDs to Merlin IDs in {} batches of {}",
                    nativeIds.size(),
                    jsonSource.getMerlinSourceProviderName(),
                    subLists.size(),
                    ID_BATCH_SIZE
                );
            }

            // process each chunk
            for (List<String> currentChunk : subLists) {
                executeIdLookupBatch(jsonSource, currentChunk);
            }

            // at this point, the Map of nativeId => TwitterItem for the current AlternateIdSource should be empty.
            // if it's not, it means some of the items retrieved from Twitter weren't matched to MerlinSources
            if (!currentNativeIdToItems.isEmpty()) {
                mbean.addFailedIdLookups(jsonSource, currentNativeIdToItems.keySet());
            }
        }
    }

    /**
     * Convert a TwitterTrendingResponse JSON object into a CRSTrendingPrograms instance.  Note that this
     * method uses idDataService to match TwitterItems to programs.  TwitterItems that cannot be resolved
     * to a Merlin program ID are skipped and logged.  Additionally, TwitterItems that are below
     * the {@link TwitterSettings#getScoreCutoff() scoreCutoff} are not mapped.
     * @param response non-null response
     * @return the response mapped to a CRSTrendingPrograms with all ids translated to Merlin ids
     */
    public CRSTrendingPrograms map(TwitterTrendingResponse response) {
        this.trendingPrograms = new ArrayList<>(response.getItems().size());
        this.response = response;

        // bucket by provider => nativeProviderId => TwitterItem
        mapTwitterItems();

        // execute lookups for each provider => nativeProviderId pair and
        // create a CRSTrendingProgram for each MerlinSource + TwitterItem
        executeIdLookups();

        // build a CRSTrendingPrograms
        CRSTrendingPrograms programs = new CRSTrendingPrograms();
        programs.setPrograms(this.trendingPrograms);
        Date now = new Date();
        programs.setRetrievedTime(now.getTime());
        programs.setTimeToLive(settings.getRefreshIntervalSeconds());
        return programs;
    }

    @Required
    public void setMerlinSourceClient(MerlinSourceClient merlinSourceClient) {
        this.merlinSourceClient = merlinSourceClient;
    }

    @Required
    public void setIdHelper(MerlinIdHelper idHelper) {
        this.idHelper = idHelper;
    }

    @Required
    public void setSettings(TwitterSettings settings) {
        this.settings = settings;
    }

    @Required
    public void setMbean(TwitterMBean mbean) {
        this.mbean = mbean;
    }


}
