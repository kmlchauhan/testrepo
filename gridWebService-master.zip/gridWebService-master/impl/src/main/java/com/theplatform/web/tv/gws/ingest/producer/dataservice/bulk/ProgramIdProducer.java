package com.theplatform.web.tv.gws.ingest.producer.dataservice.bulk;

import com.comcast.merlin.sirius.ingest.producer.dataservice.bulk.parallel.IdConsumer;
import com.comcast.merlin.sirius.ingest.producer.dataservice.bulk.parallel.IdProducer;
import com.comcast.merlin.sirius.ingest.stats.GuavaStopwatchFacade;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.web.tv.gws.sirius.repository.ListingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Set;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Produces programIds from the ListingRepository
 */
public class ProgramIdProducer implements IdProducer {
    private static final Logger logger = LoggerFactory.getLogger(ProgramIdProducer.class);

    private final ListingRepository listingRepository;
    private Collection<IdConsumer> idConsumers;

    public ProgramIdProducer(ListingRepository listingRepository) {
        this.listingRepository = listingRepository;
    }

    @Override
    public Long call() {
        GuavaStopwatchFacade stopwatch = GuavaStopwatchFacade.createStarted();
        Set<Long> programIds = listingRepository.getAllProgramIds();
        long count = programIds.size();

        for (Long id : programIds) {
            logger.debug("Produced {} from listingRepository", id);
            for (IdConsumer idConsumer: idConsumers) {
                idConsumer.consume(id);
            }
        }

        // submit final batch of ids that were consumed
        for (IdConsumer idConsumer : idConsumers) {
            idConsumer.submitBatch();
        }

        logger.info("Task=EndpointBulker Entity={} Event=CompletedStreamingId Count={} Time={} ",
                    getSiriusObjectType().getFriendlyName(), count, stopwatch.getElapsedMillis());

        return count;
    }

    @Override
    public void setIdConsumers(Collection<IdConsumer> idConsumers) {
        this.idConsumers = idConsumers;
    }

    @Override
    public SiriusObjectType getSiriusObjectType() {
        return SiriusObjectType.fromDataServiceObjectClass(Program.class);
    }

    @Override
    public void setExecutor(ThreadPoolExecutor executor) {
        // not needed
    }
}
