package com.theplatform.web.tv.gws.sirius.converter;


import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.web.tv.gws.sirius.model.CRSCredit;

public class CreditConverter extends AbstractDataObjectConverter<Credit, CRSCredit> {

    @Override
    public CRSCredit convert(Credit credit) {
        CRSCredit crsCredit = new CRSCredit();

        crsCredit.setId(LocalUriConverter.convertUriToID(credit.getId()));
        if (credit.getProgramId()!=null){
            crsCredit.setProgramId(LocalUriConverter.convertUriToID(credit.getProgramId()));
        }
        if (credit.getPersonId()!=null){
            crsCredit.setPersonId(LocalUriConverter.convertUriToID(credit.getPersonId()));
        }

        return crsCredit;
    }

}