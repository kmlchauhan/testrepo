package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.tv.partner.commons.api.data.objects.Partner;
import com.theplatform.web.tv.gws.sirius.model.CRSPartner;

public class PartnerConverter extends AbstractDataObjectConverter<Partner, CRSPartner> {

    @Override
    public CRSPartner convert(Partner partner) {
        CRSPartner crsPartner = new CRSPartner();
        crsPartner.setId(Muri.getObjectId(partner.getId()));
        crsPartner.setTitle(partner.getTitle());

        if (partner.getInternalAccountId() != null){
            crsPartner.setInternalAccountId( Muri.getObjectId(partner.getInternalAccountId()));
        }
        if (partner.getParentPartnerId() != null){
            crsPartner.setParentPartnerId( Muri.getObjectId(partner.getParentPartnerId()));
        }
        if (partner.getPartnerType() != null){
            crsPartner.setPartnerType( partner.getPartnerType().name() );
        }
        if (partner.getNationalAvailabilityTag() != null){
            crsPartner.setNationalAvailabilityTag( Muri.getObjectId(partner.getNationalAvailabilityTag()) );
        }

        return crsPartner;
    }

}
