package com.theplatform.web.tv.gws.service.common.field;

public class FieldFilteringException extends RuntimeException {
    public FieldFilteringException(String message) {
        super(message);
    }

    public FieldFilteringException(String message, Throwable cause) {
        super(message, cause);
    }

    public FieldFilteringException(Throwable cause) {
        super(cause);
    }
}
