package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.repository.utils.OpenSetSecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.SecondaryIndex;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ProgramRepository extends LongObjectRepository<CRSProgram> {

    private final Map<Long, Long> episodeIdToSeriesId = new ConcurrentHashMap<>();
    private final SecondaryIndex<Long, CRSProgram> seriesIdToEpisodes = new OpenSetSecondaryIndex<>();

    public ProgramRepository( SiriusObjectType siriusObjectType, int expectedPrograms) {
        super(siriusObjectType, expectedPrograms);
    }

    public Long getSeriesId(long episodeId) {
        return episodeIdToSeriesId.get(episodeId);
    }

    public Collection<CRSProgram> getEpisodes(long seriesId) {
        return seriesIdToEpisodes.getByIndexKey(seriesId);
    }

    @Override
    protected void addToIndexes(CRSProgram program) {
        if (program.isEpisode() && program.getSeriesId() != null) {
            episodeIdToSeriesId.put(program.getId(), program.getSeriesId());
            seriesIdToEpisodes.put(program.getSeriesId(), program);
        }
    }

    @Override
    protected void removeFromIndexes(CRSProgram program) {
        if (program.isEpisode() && program.getSeriesId() != null) {
            episodeIdToSeriesId.remove(program.getId());
            seriesIdToEpisodes.remove(program.getSeriesId(), program);
        }
    }
}
