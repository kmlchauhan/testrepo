package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.tv.linear.api.data.objects.LinearCollection;
import com.theplatform.data.tv.linear.api.data.objects.LinearCollectionType;
import com.theplatform.web.tv.gws.sirius.model.CRSLinearCollection;

import java.net.URI;
import java.util.Map;
import java.util.Set;

public class LinearCollectionConverter extends AbstractDataObjectConverter<LinearCollection, CRSLinearCollection> {

    @Override
    public CRSLinearCollection convert(LinearCollection linearCollection) {
        if (!LinearCollectionType.VideoQualityVariants.name().equals(linearCollection.getType())) {
            throw new IllegalArgumentException("Unexpected LinearCollectionType: " + linearCollection.getType());
        }

        Map<String, Set<URI>> linearIdMap = linearCollection.getLinearIdMap();

        if (linearIdMap == null) return null;

        long[] sdStationIds = Muri.getObjectIdsAsArray(linearIdMap.get("SD"));
        long[] hdStationIds = Muri.getObjectIdsAsArray(linearIdMap.get("HD"));
        long[] uhdStationIds = Muri.getObjectIdsAsArray(linearIdMap.get("UHD"));

        if (sdStationIds.length == 0 && hdStationIds.length == 0 && uhdStationIds.length == 0) return null;

        CRSLinearCollection repoObject = new CRSLinearCollection(Muri.getObjectId(linearCollection));
        repoObject.setSdStationIds(sdStationIds);
        repoObject.setHdStationIds(hdStationIds);
        repoObject.setUhdStationIds(uhdStationIds);

        return repoObject;
    }
}
