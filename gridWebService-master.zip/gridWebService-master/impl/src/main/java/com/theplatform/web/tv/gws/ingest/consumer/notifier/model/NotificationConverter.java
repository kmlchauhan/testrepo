package com.theplatform.web.tv.gws.ingest.consumer.notifier.model;


import com.comcast.merlin.sirius.ingest.Action;
import com.comcast.merlin.sirius.model.RepositoryObject;

import java.util.List;

public interface NotificationConverter <T extends RepositoryObject, K extends CRSNotification>{
    List<K> convert(long id, T crsDataObject, Action action, Long sequence);
}
