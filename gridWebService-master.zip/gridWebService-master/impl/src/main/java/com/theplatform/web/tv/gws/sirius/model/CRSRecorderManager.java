package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSRecorderManager extends LongDataRepoObject {

    private String type;
    private Long regionId;
    private String nativeId;

    public CRSRecorderManager() {
        super( SiriusObjectType.fromFriendlyName("RecorderManager"));
    }

    public CRSRecorderManager(long id) {
        super( SiriusObjectType.fromFriendlyName("RecorderManager"), id);
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getRegionId() {
        return regionId;
    }

    public void setRegionId(Long regionId) {
        this.regionId = regionId;
    }

    public String getNativeId() {
        return nativeId;
    }

    public void setNativeId(String nativeId) {
        this.nativeId = nativeId;
    }

}
