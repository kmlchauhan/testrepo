package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSTagAssociation;
import com.theplatform.web.tv.gws.sirius.repository.utils.SortedSetSecondaryIndex;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author jcoelho
 * @since 6/9/15.
 */
public class LinearTagAssociationRepository extends LongObjectRepository<CRSTagAssociation> {
    private SortedSetSecondaryIndex<Long,Long> associationLookup = new SortedSetSecondaryIndex<>();      // Object Entity ID -> N Tag Associations


    public LinearTagAssociationRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    protected void addToIndexes(CRSTagAssociation crsTagAssociation) {
        associationLookup.put( crsTagAssociation.getObjectId(), crsTagAssociation.getTagId());
    }

    @Override
    protected void removeFromIndexes(CRSTagAssociation crsTagAssociation) {
        associationLookup.remove( crsTagAssociation.getObjectId(), crsTagAssociation.getTagId());
    }

    public Collection<Long> getTagIds(long entityId){
        Collection<Long>  ids = associationLookup.getByIndexKey(entityId);
        if (associationLookup.getByIndexKey(entityId).size()>1){
            return new ArrayList(ids);
        }else{
            return associationLookup.getByIndexKey(entityId);
        }
    }


}
