package com.theplatform.web.tv.gws.ingest.consumer.notifier.publisher;

import com.amazonaws.handlers.AsyncHandler;
import com.amazonaws.services.sns.AmazonSNSAsyncClient;
import com.amazonaws.services.sns.model.CreateTopicResult;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.comcast.merlin.sirius.ingest.dispatcher.Stop;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.web.tv.gws.ingest.consumer.notifier.SequenceTracker;
import com.theplatform.web.tv.gws.ingest.consumer.notifier.model.CRSNotification;
import com.theplatform.web.tv.gws.service.common.util.DynamicProperties;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.util.HashMap;
import java.util.Map;

/**
 * AWS SNS Notifications
 */
public class AwsPublisher implements Publisher {
    private static Logger LOGGER = LoggerFactory.getLogger(AwsPublisher.class);

    public static final String ATTRIBUTE_OBJECT_TYPE = "object_type";

    private AmazonSNSAsyncClient amazonSNSClient;

    private SequenceTracker sequenceTracker;

    private boolean notificationNode;

    private DynamicProperties dynamicProperties;


    // Map from Notification Type to SNS Topic Name
    private Map<SiriusObjectType,String> notificationTopic;
    // Map from Notification Type to SNS Topic ARN
    private Map<SiriusObjectType,String> notificationTopicArn;

    public void init(){
        if (!notificationNode) return;
        notificationTopicArn = new HashMap();
        String topicArn = null;
        for(SiriusObjectType type: notificationTopic.keySet()){
            String topicName = notificationTopic.get(type);
            try{
                CreateTopicResult createTopicResult = amazonSNSClient.createTopic(topicName);     // Idempotent
                topicArn = createTopicResult.getTopicArn();

                notificationTopicArn.put(type, topicArn);

                LOGGER.info("Task=AwsPublisher Event=VerifyTopic Type={} TopicName={} TopicArn={}", type.getFriendlyName(), topicName, topicArn);
            }catch (Exception exc){
                LOGGER.error("Task=AwsPublisher Error=FailedToVerifyTopic Type={} TopicName={} TopicArn={}", type.getFriendlyName(), topicName, topicArn,  exc);
                Stop.instance().stop("Failed to initialize connection to AWS SNS.");
            }
        }
    }

    @Override
    public boolean publish( CRSNotification crsNotification) {
        String topicArn = notificationTopicArn.get(crsNotification.getSiriusObjectType());
        if (topicArn == null){
            LOGGER.error("Task=AwsPublisher Error=MissingTopicARN Type={} TopicArn={} Attempting to publish to SNS and was unable to find ARN for Topic.  Check Configuration.", crsNotification.getType(), topicArn);
            Stop.instance().stop("Could not find Topic's ARN for topic: {}", crsNotification.getSiriusObjectType());
        }
        ObjectMapper mapper = new ObjectMapper();
        String json = null;
        try{
            json = mapper.writeValueAsString(crsNotification);
        }catch(Exception exc){
            LOGGER.info("Task=AwsPublisher Error=FailedToPublish Type={} TopicArn={} ", crsNotification.getType(), topicArn, exc);
            return false;
        }
        String sourceId = (crsNotification.getSourceId() != null) ? crsNotification.getSourceId() : "";
        PublishRequest publishRequest = new PublishRequest(topicArn, json, sourceId);

        // Type Attribute.
        MessageAttributeValue objectType
                = new MessageAttributeValue().withDataType("String").withStringValue(crsNotification.getType());
        publishRequest.addMessageAttributesEntry(ATTRIBUTE_OBJECT_TYPE, objectType);

        if (dynamicProperties.get(DynamicProperties.DynamicPropertiesEnum.NOTIFIER_ACK_ENABLED).equals("true")){
            amazonSNSClient.publishAsync(publishRequest, new AsyncPublishResponse(crsNotification));
        }else{
            amazonSNSClient.publishAsync(publishRequest);
        }

        return true;
    }

    @Required
    public void setAmazonSNSClient(AmazonSNSAsyncClient amazonSNSClient) {
        this.amazonSNSClient = amazonSNSClient;
    }

    @Required
    public void setNotificationTopic(Map<SiriusObjectType, String> notificationTopic) {
        this.notificationTopic = notificationTopic;
    }

    @Required
    public void setNotificationNode(boolean notificationNode) {
        this.notificationNode = notificationNode;
    }

    @Required
    public void setSequenceTracker(SequenceTracker sequenceTracker) {
        this.sequenceTracker = sequenceTracker;
    }

    @Required
    public void setDynamicProperties(DynamicProperties dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }

    private class AsyncPublishResponse implements AsyncHandler<PublishRequest, PublishResult>{
        private CRSNotification crsNotification;

        public AsyncPublishResponse(CRSNotification crsNotification){
            this.crsNotification = crsNotification;
        }

        @Override
        public void onError(Exception e) {
            LOGGER.error("Task=AwsPublisher Error=AckFailed SourceId={} NotificationId={} Type={} TimeToRespond={}", crsNotification.getSourceId(),  crsNotification.getNotificationId(), crsNotification.getType(), (System.currentTimeMillis()-crsNotification.getTimestamp()), e);
        }

        @Override
        public void onSuccess(PublishRequest request, PublishResult publishResult) {
            LOGGER.info("Task=AwsPublisher Event=Ack SourceId={} Id={} NotificationId={} Type={} TimeToAck={}", crsNotification.getSourceId(),  crsNotification.getId(), crsNotification.getNotificationId(), crsNotification.getType(), (System.currentTimeMillis()-crsNotification.getTimestamp()));
            sequenceTracker.updateSequence(crsNotification.getSourceSiriusObjectType(), crsNotification.getSourceSequence());
        }
    }


}
