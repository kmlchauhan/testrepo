package com.theplatform.web.tv.gws.sirius.repository.utils;

import java.lang.annotation.*;
import java.util.concurrent.*;

/**
 * A {@code CanonicalObject} is an object where there exists 1 version of an object for a specific set of field values.
 * For example, an {@link CanonicalIds} consists of a set of longs. Only 1 instance of an object should exist for the
 * set longs.
 * {@code CanonicalObject}s implements the {@link #equals(Object)} method to <b>only</b> to reference checking.
 * Instances of these objects can only be created via the a CanonicalObject Factory (for example
 * {@link CanonicalIdsFactory}) for the specified type.
 *
 * Ported from DaveS's code in Tim.
 */
abstract class CanonicalObject {
    /**
     * We generate a random hashcode that should give a good hashcode distribution for all objects
     */
    private final int hashCode = ThreadLocalRandom.current().nextInt(Integer.MIN_VALUE, Integer.MAX_VALUE);

    @Documented
    @Target({ElementType.CONSTRUCTOR, ElementType.METHOD, ElementType.TYPE})
    @Retention(RetentionPolicy.SOURCE)
    @interface FactoryPrivate {

    }

    @Override
    public final boolean equals(Object other) {
        return this == other;
    }

    @Override
    public final int hashCode() {
        return hashCode;
    }
}
