package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSGame;
import com.theplatform.web.tv.gws.sirius.repository.utils.OpenSetSecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.SecondaryIndex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

public class GameRepository extends LongObjectRepository<CRSGame> {
    private final static Logger logger = LoggerFactory.getLogger(GameRepository.class);
    private SecondaryIndex<Long, CRSGame> listingIndex;

    public GameRepository(SiriusObjectType siriusObjectType) {
        this(siriusObjectType, 1024);
    }

    public GameRepository( SiriusObjectType siriusObjectType, int expected) {
        super(siriusObjectType, expected);
        listingIndex = new OpenSetSecondaryIndex<>(4096);
    }

    @Override
    protected void addToIndexes(CRSGame game) {
        for (Long listingId : game.getListingIds()) {
            listingIndex.put(listingId, game);
        }
    }

    @Override
    protected void removeFromIndexes(CRSGame game) {
        for (Long listingId : game.getListingIds()) {
            listingIndex.remove(listingId, game);
        }
    }

    public CRSGame getByListingId(long listingId) {
        Collection<CRSGame> games = listingIndex.getByIndexKey(listingId);
        if (games.size() == 0) {
            return null;
        } else if (games.size() > 1) {
            logger.warn("Multiple games for listing {}: {}", listingId, games);
        }
        for (CRSGame game : games ){
            if (game.isLiveCoverageAvailable()) return game;
        }
        return null;

    }
}
