package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.tv.entity.api.data.objects.TagType;

/**
 * @author jcoelho
 * @since 6/8/15.
 */
public class CRSTag extends LongDataRepoObject {

    private String title;
    private TagType type;

    public CRSTag(long id, String title, TagType type) {
        super( SiriusObjectType.fromFriendlyName("EntityTag"), id);
        setTitle(title);
        setType(type);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public TagType getType() {
        return type;
    }

    public void setType(TagType type) {
        this.type = type;
    }
}
