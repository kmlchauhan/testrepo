package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSServiceState extends LongDataRepoObject implements Comparable<CRSServiceState>{
    private String service;
    private String context;
    private String state;

    public CRSServiceState(){
        super( SiriusObjectType.fromFriendlyName("ServiceState"));
    }

    public CRSServiceState(long id){
        super( SiriusObjectType.fromFriendlyName("ServiceState"), id);
    }

    /**
     * The service the State is related to.  We would only care about 'gridWebService'
     *
     */
    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    /**
     * The CRS property we are modifying
     */
    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    /**
     * The value of the
     */
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public int compareTo(CRSServiceState crsServiceState) {
        if (this.hashCode() > crsServiceState.hashCode()) {
            return 1;
        }
        if (this.hashCode() < crsServiceState.hashCode()) {
            return -1;
        }
        return 0;
    }


}
