package com.theplatform.web.tv.gws.service.contentresolution.episodes;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.repository.ProgramRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LegacyEpisodesHelper {

    private final ProgramRepository programRepository;

    private static final LegacyEpisodeComparator episodeComparator = new LegacyEpisodeComparator();

    public LegacyEpisodesHelper(ProgramRepository programRepository) {
        this.programRepository = programRepository;
    }

    public List<CRSProgram> getEpisodes(Muri episodeId, long previousEpisodeCount, long nextEpisodeCount, boolean excludeProvidedEpisode) {
        Long seriesId = programRepository.getSeriesId(episodeId.getId());

        if (seriesId == null) return Collections.emptyList();

        List<CRSProgram> allEpisodes = new ArrayList<>(programRepository.getEpisodes(seriesId));

        Collections.sort(allEpisodes, episodeComparator);

        int providedEpisodeIndex = allEpisodes.indexOf(new CRSProgram(episodeId.getId()));

        if (providedEpisodeIndex < 0) {
            throw new IllegalStateException(episodeId + " is in episodeToSeriesId index, but not in Program repository");
        }

        if (excludeProvidedEpisode) {
            allEpisodes.remove(providedEpisodeIndex);
        }

        int fromIndex = (int) Math.max(0, providedEpisodeIndex - previousEpisodeCount);
        int toIndex = (int) Math.min(allEpisodes.size(),
                                     providedEpisodeIndex + nextEpisodeCount + (excludeProvidedEpisode ? 0 : 1));

        List<CRSProgram> crsPrograms = allEpisodes.subList(fromIndex, toIndex);

        return crsPrograms;
    }
}
