package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.contentresolution.api.objects.ApiObjectVisitor;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfoCollection;
import com.theplatform.web.tv.contentresolution.api.objects.Grid;
import com.theplatform.web.tv.contentresolution.api.objects.IdCollection;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.contentresolution.api.objects.LocatorInfoCollection;
import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;
import com.theplatform.web.tv.contentresolution.api.objects.TrendingPrograms;
import com.theplatform.web.tv.contentresolution.api.objects.episodes.EpisodeMap;
import com.theplatform.web.tv.gws.service.common.field.FieldFilterUtil;
import com.theplatform.web.tv.gws.service.contentresolution.ContentResolutionServiceImpl;

import java.util.Date;
import java.util.List;

/**
 * @author Segun Abimbola (oabimb200)
 * 11/15/17
 */
public class ContentResolutionServiceImpl_1_27 extends ContentResolutionServiceImpl_1_28 implements ContentResolutionService_1_27{
    private static final String INCLUDE_ALWAYS = "verboseInfo";
    protected final ApiObjectVisitor visitor = DataObjectTranslator_1_27.INSTANCE;

    @Override
    public ChannelInfoCollection resolveChannels(AvailabilityResolution availabilityResolution, String fields, String byStreamStatus, Boolean filterAdult) throws GridException {
        ChannelInfoCollection channelInfoCollection = super.resolveChannels(availabilityResolution, null, byStreamStatus, filterAdult);
        channelInfoCollection.accept(visitor);
        FieldFilterUtil.filterFields(channelInfoCollection, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return channelInfoCollection;
    }

    @Override
    public ChannelInfoCollection resolveChannelsByStreamId(AvailabilityResolution availabilityResolution, Long streamId, String fields, Boolean filterAdult) throws GridException {
        ChannelInfoCollection channelInfoCollection = super.resolveChannelsByStreamId(availabilityResolution, streamId, null, filterAdult);
        channelInfoCollection.accept(visitor);
        FieldFilterUtil.filterFields(channelInfoCollection, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return channelInfoCollection;
    }

    @Override
    public Grid getGrid(AvailabilityResolution availabilityResolution, Integer numGridUnits, Integer gridUnitWidth, Integer offset, String timeZone, String[] categories, Long[] companyIds, Long[] stationTagIds, String[] locatorFormats, Boolean hd, Integer rowStart, Integer rowEnd, Long[] programTagIds, String fields) throws GridException {
        Grid grid = super.getGrid(availabilityResolution, numGridUnits, gridUnitWidth, offset, timeZone, categories, companyIds, stationTagIds, locatorFormats, hd, rowStart, rowEnd, programTagIds, null);
        grid.accept(visitor);
        FieldFilterUtil.filterFields(grid, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return grid;
    }

    @Override
    public Grid getGridByDate(AvailabilityResolution availabilityResolution, Date startTime, Integer numGridUnits, Integer gridUnitWidth, String timeZone, String[] categories, Long[] companyIds, Long[] stationTagIds, String[] locatorFormats, Boolean hd, Integer rowStart, Integer rowEnd, Long[] programTagIds, String fields) throws GridException {
        Grid gridByDate = super.getGridByDate(availabilityResolution, startTime, numGridUnits, gridUnitWidth, timeZone, categories, companyIds, stationTagIds, locatorFormats, hd, rowStart, rowEnd, programTagIds, null);
        gridByDate.accept(visitor);
        FieldFilterUtil.filterFields(gridByDate, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return gridByDate;
    }

    @Override
    public List<ListingInfo> getListings(Long stationId, Integer numGridUnits, Integer gridUnitWidth, Integer offset, Long[] programTagIds, String fields) {
        List<ListingInfo> listings = super.getListings(stationId, numGridUnits, gridUnitWidth, offset, programTagIds, null);
        visitor.visitEach(listings);
        FieldFilterUtil.filterFields(listings, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return listings;
    }

    @Override
    public List<ListingInfo> getListingsByDate(Long stationId, Date startTime, Date endTime, Integer gridUnitWidth, Long[] programTagIds, String fields) {
        List<ListingInfo> listingsByDate = super.getListingsByDate(stationId, startTime, endTime, gridUnitWidth, programTagIds, null);
        visitor.visitEach(listingsByDate);
        FieldFilterUtil.filterFields(listingsByDate, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return listingsByDate;
    }

    @Override
    public List<ListingInfo> getListingsById(List<Muri> listingIds, Long[] programTagIds, String fields) throws GridException {
        List<ListingInfo> listingsById = super.getListingsById(listingIds, programTagIds, null);
        visitor.visitEach(listingsById);
        FieldFilterUtil.filterFields(listingsById, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return listingsById;
    }

    @Override
    public IdCollection getStationsBySeriesId(Muri[] seriesIds, Date startTime, Date endTime) {
        IdCollection stationsBySeriesId = super.getStationsBySeriesId(seriesIds, startTime, endTime);
        return stationsBySeriesId;
    }

    @Override
    public IdCollection getStationsBySportsTeamId(Muri[] sportsTeamIds, Date startTime, Date endTime) {
        IdCollection stationsBySportsTeamId = super.getStationsBySportsTeamId(sportsTeamIds, startTime, endTime);
        return stationsBySportsTeamId;
    }

    @Override
    public IdCollection getStationsByPersonId(Muri[] personIds, Date startTime, Date endTime) {
        IdCollection stationsByPersonId = super.getStationsByPersonId(personIds, startTime, endTime);
        return stationsByPersonId;
    }

    @Override
    public List<StationInfo> getStationsById(Muri[] stationIds, String fields) throws GridException {
        List<StationInfo> stationsById = super.getStationsById(stationIds, null);
        visitor.visitEach(stationsById);
        FieldFilterUtil.filterFields(stationsById, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return stationsById;
    }

    @Override
    public List<ListingInfo> getListingsBySeriesId(Muri[] seriesIds, Date startTime, Date endTime, Muri[] stationIds, Long[] programTagIds, String fields) {
        List<ListingInfo> listingsBySeriesId = super.getListingsBySeriesId(seriesIds, startTime, endTime, stationIds, programTagIds, null);
        visitor.visitEach(listingsBySeriesId);
        FieldFilterUtil.filterFields(listingsBySeriesId, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return listingsBySeriesId;
    }

    @Override
    public List<ListingInfo> getListingsBySportsTeamId(Muri[] sportsTeamIds, Date startTime, Date endTime, Muri[] stationIds, Long[] programTagIds, String fields) {
        List<ListingInfo> listingsBySportsTeamId = super.getListingsBySportsTeamId(sportsTeamIds, startTime, endTime, stationIds, programTagIds, null);
        visitor.visitEach(listingsBySportsTeamId);
        FieldFilterUtil.filterFields(listingsBySportsTeamId, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return listingsBySportsTeamId;
    }

    @Override
    public List<ListingInfo> getListingsByPersonId(Muri[] personIds, Date startTime, Date endTime, Muri[] stationIds, Long[] programTagIds, String fields) {
        List<ListingInfo> listingsByPersonId = super.getListingsByPersonId(personIds, startTime, endTime, stationIds, programTagIds, null);
        visitor.visitEach(listingsByPersonId);
        FieldFilterUtil.filterFields(listingsByPersonId, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return listingsByPersonId;
    }

    @Override
    public TrendingPrograms getTrendingPrograms(String fields) throws GridException {
        TrendingPrograms trendingPrograms = super.getTrendingPrograms(fields);
        trendingPrograms.accept(visitor);
        return trendingPrograms;
    }

    @Override
    public EpisodeMap getEpisodes(Muri[] episodeIds, Integer previousEpisodeCount, Integer nextEpisodeCount, Boolean excludeProvidedEpisodes, String fields) throws GridException {
        EpisodeMap episodes = super.getEpisodes(episodeIds, previousEpisodeCount, nextEpisodeCount, excludeProvidedEpisodes, fields);
        return episodes;
    }

    @Override
    public List<ProgramInfo> getProgramsById(Muri[] programIds, String fields) {
        List<ProgramInfo> programsById = super.getProgramsById(programIds, null);
        visitor.visitEach(programsById);
        FieldFilterUtil.filterFields(programsById, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return programsById;
    }

    @Override
    public List<ChannelInfo> getChannelsById(Muri[] channelIds, String fields) throws GridException {
        List<ChannelInfo> channelsById = super.getChannelsById(channelIds, null);
        visitor.visitEach(channelsById);
        FieldFilterUtil.filterFields(channelsById, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return channelsById;
    }

    @Override
    public IdCollection getChannelAvailabilityIds() throws GridException {
        IdCollection channelAvailabilityIds = super.getChannelAvailabilityIds();
        return channelAvailabilityIds;
    }

    @Override
    public ChannelInfoCollection getChannelsByAvailabilityId(Muri channelsAvailabilityId) throws GridException {
        ChannelInfoCollection channelsByAvailabilityId = super.getChannelsByAvailabilityId(channelsAvailabilityId);
        channelsByAvailabilityId.accept(visitor);
        return channelsByAvailabilityId;
    }

    @Override
    public LocatorInfoCollection getLocatorsByRegion(String region) throws GridException {
        LocatorInfoCollection locatorsByRegion = super.getLocatorsByRegion(region);
        locatorsByRegion.accept(visitor);
        return locatorsByRegion;
    }

}


