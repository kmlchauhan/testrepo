package com.theplatform.web.tv.gws.ingest.consumer.notifier.check;

import com.comcast.merlin.sirius.ingest.Event;
import com.comcast.merlin.sirius.model.LongDataRepoObject;


public interface Check<T extends LongDataRepoObject> {

    public  boolean shouldPublish(Event<T> event);
}
