package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.contrib.data.api.objects.ContentId;
import com.theplatform.contrib.data.api.objects.ContentIdType;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.tv.offer.api.data.objects.ContentAvailability;
import com.theplatform.web.tv.gws.sirius.model.CRSContentAvailability;
import com.theplatform.web.tv.gws.sirius.repository.utils.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;

public class ContentAvailabilityConverter extends AbstractDataObjectConverter<ContentAvailability, CRSContentAvailability> {
    private static final Logger logger = LoggerFactory.getLogger(ContentAvailabilityConverter.class);

    private CanonicalIdsFactory productContextCanonicalIdsFactory;

    @Override
    public CRSContentAvailability convert(ContentAvailability contentAvailability) {
        if (contentAvailability == null)
            return null;
        ContentId contentId = contentAvailability.getContentId();

        if (contentId == null)
            throw new IllegalArgumentException("Content Id is missing on contentAvailability - " + contentAvailability);

        CRSContentAvailability crsContentAvailability = new CRSContentAvailability();

        if (ContentIdType.Stream.equals(contentId.getType())){          // Avoiding using enum ordinals
            crsContentAvailability.setContentType(CRSContentAvailability.CONTENT_TYPE_STREAM);
        } else if (ContentIdType.Station.equals(contentId.getType())){
            crsContentAvailability.setContentType(CRSContentAvailability.CONTENT_TYPE_STATION);
        }else if (ContentIdType.Locator.equals(contentId.getType())) {
            crsContentAvailability.setContentType(CRSContentAvailability.CONTENT_TYPE_LOCATOR);
        }else {
            logger.info("Discarding CA since it is neither Station, Locator nor Stream - " + contentAvailability);
            return null;
        }
        crsContentAvailability.setId(Muri.getObjectId(contentAvailability.getId()));
        crsContentAvailability.setAvailabilityId(Muri.getObjectId(contentAvailability.getAvailabilityId()));
        crsContentAvailability.setContentId(Muri.getObjectId(contentAvailability.getContentId().getId()));
        crsContentAvailability.setOwnerId(Muri.getObjectId(contentAvailability.getOwnerId()));

        crsContentAvailability.setProductContextIds(productContextCanonicalIdsFactory.create(contentAvailability.getProductContexts()));

        return crsContentAvailability;
    }

    @Required
    public void setProductContextCanonicalIdsFactory(CanonicalIdsFactory productContextCanonicalIdsFactory) {
        this.productContextCanonicalIdsFactory = productContextCanonicalIdsFactory;
    }

}
