/**
 * Nullify properties on "info"/DTO objects.
 */
package com.theplatform.web.tv.gws.service.common.field;