package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.offer.api.data.objects.ProductContext;
import com.theplatform.web.tv.gws.sirius.model.CRSProductContext;

public class ProductContextConverter extends AbstractDataObjectConverter<ProductContext, CRSProductContext> {

    @Override
    public CRSProductContext convert(ProductContext productContext) {
        CRSProductContext crsProductContext = new CRSProductContext();
        crsProductContext.setId(LocalUriConverter.convertUriToID(productContext.getId()));
        crsProductContext.setTitle(productContext.getTitle());
        crsProductContext.setType(productContext.getType());
        return crsProductContext;
    }

}
