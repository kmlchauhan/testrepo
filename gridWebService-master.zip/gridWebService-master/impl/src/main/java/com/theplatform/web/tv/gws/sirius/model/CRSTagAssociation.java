package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

/**
 * @author jcoelho
 * @since 6/8/15.
 */
public class CRSTagAssociation extends LongDataRepoObject implements Comparable<CRSTagAssociation> {

    private long objectId;
    private long tagId;

    public CRSTagAssociation(Long id, Long tagId, Long entityId) {
        super( SiriusObjectType.fromFriendlyName("LinearTagAssociation"), id);
        setTagId(tagId);
        setObjectId(entityId);
    }

    public long getTagId() {
        return tagId;
    }

    public void setTagId(long tagId) {
        this.tagId = tagId;
    }

    public long getObjectId() {
        return objectId;
    }

    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    @Override
    public int compareTo(CRSTagAssociation crsTagAssociation) {
        if (this.hashCode() > crsTagAssociation.hashCode()) {
            return 1;
        }else if (this.hashCode() < crsTagAssociation.hashCode()) {
            return -1;
        }
        return 0;
    }



}
