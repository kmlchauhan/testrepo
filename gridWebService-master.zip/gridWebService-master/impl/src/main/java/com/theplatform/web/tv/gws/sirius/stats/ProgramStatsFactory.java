package com.theplatform.web.tv.gws.sirius.stats;

import com.comcast.merlin.data.notification.count.*;
import com.comcast.merlin.sirius.ingest.*;
import com.comcast.merlin.sirius.ingest.consumer.replay.*;
import com.comcast.merlin.sirius.ingest.dispatcher.*;
import com.comcast.merlin.sirius.ingest.producer.dataservice.*;
import com.comcast.merlin.sirius.ingest.producer.dataservice.notification.*;
import com.comcast.merlin.sirius.ingest.stats.*;
import com.comcast.merlin.sirius.model.*;
import com.comcast.merlin.sirius.repository.*;
import com.google.common.collect.Sets;
import com.theplatform.web.tv.gws.ingest.maintainer.ProgramRepositoryMaintainer;
import com.theplatform.web.tv.gws.sirius.repository.*;
import java.io.*;
import java.net.*;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;

/**
 *  The Program Repo is now based on the distinct Programs in the Listing repo we cannot use the default StatsFactory
 *  for gap reporting.  This class will compare the count Programs in the Program repo to the count of distinct
 *  Program Ids in the Listing Repo.
 *
 */
public class ProgramStatsFactory extends AbstractStatsFactory{
    private static final Logger logger = LoggerFactory.getLogger(ProgramStatsFactory.class);

    private final SiriusObjectType siriusObjectType;
    private final ProgramRepository programRepository;
    private final ListingRepository listingRepository;
    private final NotificationCountClient notificationCountClient;
    private final DataServiceNotificationListener dataServiceNotificationListener;
    private final DataObjectReceiverImpl dataObjectReceiver;
    private final SiriusEventDispatcher siriusEventDispatcher;
    private final NotificationRepositoryWriter notificationRepositoryWriter;
    private final ProgramRepositoryMaintainer maintainer;

    private NotificationSequenceRepository notificationSequenceRepository;


    public ProgramStatsFactory(SiriusObjectType siriusObjectType,
                               ProgramRepository programRepository,
                               ListingRepository listingRepository,
                               DataServiceNotificationListener dataServiceNotificationListener,
                               DataObjectReceiverImpl dataObjectReceiver,
                               SiriusEventDispatcher siriusEventDispatcher,
                               NotificationRepositoryWriter notificationRepositoryWriter,
                               ProgramRepositoryMaintainer maintainer) throws URISyntaxException{
        this.siriusObjectType = siriusObjectType;
        this.programRepository = programRepository;
        this.listingRepository = listingRepository;
        this.dataServiceNotificationListener = dataServiceNotificationListener;
        this.dataObjectReceiver = dataObjectReceiver;
        this.siriusEventDispatcher = siriusEventDispatcher;
        this.notificationRepositoryWriter = notificationRepositoryWriter;
        this.maintainer = maintainer;

        String baseUrl = dataServiceNotificationListener.getNotificationClient().getBaseUrl();
        notificationCountClient = new NotificationCountClient(baseUrl, siriusObjectType.getMerlinEntityType());
    }

    @Override
    public SiriusObjectType getSiriusObjectType() {
        return siriusObjectType;
    }

    @Override
    public GapSummary getGapSummary() throws IOException {
        DsCount dsCount = getDsCount(true);
        NotificationSequenceRepoObject siriusNotificationSequence = notificationSequenceRepository.get(siriusObjectType);
        long since = siriusNotificationSequence.getNotificationSequenceId();
        NotificationCounts notificationCounts = notificationCountClient.getCount(since,true);

        GapSummary gapSummary = new GapSummary();
        gapSummary.setSequence(siriusNotificationSequence.getNotificationSequenceId());
        gapSummary.setObjectType(siriusObjectType);

        Long dataServiceCount = dsCount.getDataService();
        Long repositoryCount = dsCount.getRepo();
        Long pendingCreates = notificationCounts.getCreates();
        Long pendingUpdates = notificationCounts.getUpdates();
        Long pendingDeletes = notificationCounts.getDeletes();

        gapSummary.setDataServiceCount(dataServiceCount);
        gapSummary.setRepositoryCount(repositoryCount);
        // The gap will not take into account sequence numbers
        gapSummary.setGap(repositoryCount - dataServiceCount);

        gapSummary.setPendingCreates(pendingCreates);
        gapSummary.setPendingUpdates(pendingUpdates);
        gapSummary.setPendingDeletes(pendingDeletes);

        return gapSummary;
    }

    @Override
    public IngestStat getIngestStats(boolean includeDataService, IngestMode ingestMode) {
        IngestStat ingestStat = new IngestStat(siriusObjectType);
        ingestStat.setCounts(getDsCount(includeDataService));

        // slave nodes never run listeners and will always have null/zero values for all stats
        if (ingestMode != IngestMode.SLAVE) {
            ingestStat.setNotificationListener(dataServiceNotificationListener.getStats());
            ingestStat.setDataObjectReceiver(dataObjectReceiver.getStats().get(siriusObjectType));
            ingestStat.setMaintainer(maintainer.getStats());
        }

        ingestStat.setDispatcher(siriusEventDispatcher.getStats().getPerObjectTypeStats().get(siriusObjectType));
        ingestStat.setNotificationRepoWriter(notificationRepositoryWriter.getStats().get(siriusObjectType));

        return ingestStat;
    }

    private DsCount getDsCount(boolean includeDataService) {
        DsCount dsCountObject = new DsCount();

        long programRepoSize = programRepository.size();
        dsCountObject.setRepo(programRepoSize);

        if (includeDataService) {
            Set<Long> programIdsReferencedByListings = listingRepository.getAllProgramIds();
            long dsCount = (long) programIdsReferencedByListings.size();

            dsCountObject.setDataService(dsCount);
            logger.debug("dsCount: {}; programRepoSize: {}", dsCount, programRepoSize);

            if (programRepoSize != dsCount) {
                Set<Long> programIds = new HashSet<>(programRepository.keys());

                if (programRepoSize > dsCount) {
                    Sets.SetView<Long> difference = Sets.difference(programIds, programIdsReferencedByListings);
                    logger.warn("More programs in repo than expected: {}", difference);
                } else {
                    Sets.SetView<Long> difference = Sets.difference(programIdsReferencedByListings, programIds);
                    logger.warn("Programs found missing from repo: {}", difference);
                }
            }
        }
        return dsCountObject;
    }

    // Unfortunately this could not be fed in the constructor so I had to autowire it in.  A bit kludgey :/
    @Autowired
    public void setNotificationSequenceRepository(NotificationSequenceRepository notificationSequenceRepository){
        this.notificationSequenceRepository = notificationSequenceRepository;
    }


}
