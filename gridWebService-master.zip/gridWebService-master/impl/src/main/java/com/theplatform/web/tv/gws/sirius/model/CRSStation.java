package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

public class CRSStation extends LongDataRepoObject {

    private String title;
    private String callSign;
    private String onScreenCallSign;
    private String timeZone;
    private long expirationDate;
    private long associatedStationId;
    private String language;
    private int otaChannelNumber;
    private Boolean payPerView;
    private String shortName;
    private Boolean vod;
    private int digicableId;
    private String emergencyAlertSystemType;
    private String hdLevel;
    private String colorDepth;
    private String quality;
    private Map<String, Long> qualityVariants = new HashMap<>();

    public CRSStation() {
        super( SiriusObjectType.fromFriendlyName("Station"));
    }

    public CRSStation(long id) {
        super( SiriusObjectType.fromFriendlyName("Station"), id);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCallSign() {
        return callSign;
    }

    public void setCallSign(String callSign) {
        this.callSign = callSign;
    }

    public String getOnScreenCallSign() {
        return onScreenCallSign;
    }

    public void setOnScreenCallSign(String onScreenCallSign) {
        if (this.shortName != null && this.shortName.equals(onScreenCallSign)) {
            this.onScreenCallSign = this.shortName;
        }
        else {
            this.onScreenCallSign = onScreenCallSign;
        }

    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = nullSafeIntern(timeZone);
    }

    public long getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(long expirationDate) {
        this.expirationDate = expirationDate;
    }

    public long getAssociatedStationId() {
        return associatedStationId;
    }

    public void setAssociatedStationId(long associatedStationId) {
        this.associatedStationId = associatedStationId;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = nullSafeIntern(language);
    }

    public int getOtaChannelNumber() {
        return otaChannelNumber;
    }

    public void setOtaChannelNumber(int otaChannelNumber) {
        this.otaChannelNumber = otaChannelNumber;
    }

    public Boolean getPayPerView() {
        return payPerView;
    }

    public void setPayPerView(Boolean payPerView) {
        this.payPerView = payPerView;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        if (this.onScreenCallSign != null && this.onScreenCallSign.equals(shortName)) {
            this.shortName = this.onScreenCallSign;
        }
        else {
            this.shortName = shortName;
        }
    }

    public Boolean getVod() {
        return vod;
    }

    public void setVod(Boolean vod) {
        this.vod = vod;
    }

    public int getDigicableId() {
        return digicableId;
    }

    public void setDigicableId(int digicableId) {
        this.digicableId = digicableId;
    }

    public String getEmergencyAlertSystemType() {
        return emergencyAlertSystemType;
    }

    public void setEmergencyAlertSystemType(String emergencyAlertSystemType) {
        this.emergencyAlertSystemType = nullSafeIntern(emergencyAlertSystemType);
    }

    public String getHdLevel() {
        return hdLevel;
    }

    public void setHdLevel(String hdLevel) {
        this.hdLevel = hdLevel;
    }

    public String getColorDepth() {
        return colorDepth;
    }

    public void setColorDepth(String colorDepth) {
        this.colorDepth = colorDepth;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public Map<String, Long> getQualityVariants() {
        return qualityVariants;
    }

    public void setQualityVariants(Map<String, Long> qualityVariants) {
        this.qualityVariants = qualityVariants;
    }
}
