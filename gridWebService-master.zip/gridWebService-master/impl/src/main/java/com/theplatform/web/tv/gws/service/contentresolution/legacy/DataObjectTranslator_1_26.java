package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.theplatform.web.tv.contentresolution.api.objects.ApiObjectVisitor;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;

public class DataObjectTranslator_1_26 extends ApiObjectVisitor {
    public final static DataObjectTranslator_1_26 INSTANCE = new DataObjectTranslator_1_26();

    @Override
    public void visitStationInfo(StationInfo stationInfo) {
        stationInfo.setAssociatedStationId(stationInfo.getTransientAssociatedStationId());

        if (stationInfo.getQuality() != null){
            String quality = stationInfo.getQuality();

            switch (quality){
                case "SD": {
                    stationInfo.setHd(false);
                    stationInfo.setUhd(false);
                    break;
                }
                case "HD" : {
                    stationInfo.setHd(true);
                    stationInfo.setUhd(false);
                    break;
                }
                case "UHD": {
                    stationInfo.setHd(false);
                    stationInfo.setUhd(true);
                    break;
                }
                default:
                    //do nothing
            }
        }
        stationInfo.setQuality(null);
        stationInfo.setQualityVariants(null);
    }

    @Override
    public void visitListingInfo(ListingInfo listingInfo) {
        listingInfo.setQuality(null);
    }
}
