package com.theplatform.web.tv.gws.service.common.field.descriptor;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.*;

/**
 * Describes a single JavaBean property of an API ("info") class.  ApiPropertyDescriptors are arranged in a parent/child
 * hierarchy and identified by the {@link #getPath() OGNL path} from the containing ApiClassDescriptor.
 */
public class ApiPropertyDescriptor extends ApiClassDescriptor {


    private final String path;
    private final Map<Class<?>, ApiPropertyDescriptor> subTypes;

    private final Method readMethod;
    private final Method writeMethod;

    private final boolean collectionType;
    private final boolean listType;
    private final boolean arrayType;

    protected ApiPropertyDescriptor(Class<?> type, String path,  List<ApiPropertyDescriptor> children, PropertyDescriptor descriptor) {
        this(type, path, null, children, descriptor);
    }

    protected ApiPropertyDescriptor(Class<?> type, String path,  Map<Class<?>, ApiPropertyDescriptor> subTypes, List<ApiPropertyDescriptor> children, PropertyDescriptor descriptor) {
        super(type, children);
        this.path = path;

        if (MapUtils.isNotEmpty(subTypes)) {
            this.subTypes = Collections.unmodifiableMap(new HashMap<>(subTypes));
        }
        else {
            this.subTypes = Collections.emptyMap();
        }

        // these are lazily initialized by PropertyDescriptor.  grab a reference to force initialization
        // now and make future calls to this instance slightly faster.
        this.readMethod = descriptor.getReadMethod();
        this.writeMethod = descriptor.getWriteMethod();

        // minor optimization.  this prevents security security checks and makes calls to invoke() slightly faster
        this.readMethod.setAccessible(true);
        this.writeMethod.setAccessible(true);

        this.collectionType = Collection.class.isAssignableFrom(this.readMethod.getReturnType());
        this.listType = List.class.isAssignableFrom(this.readMethod.getReturnType());
        this.arrayType = this.readMethod.getReturnType().isArray();
    }

    /**
     * The type of the property.  For generics/parameterized types (Collections) returns the type contained
     * with the Collection rather than List.class or Collection.class.
     * @return the type (never null)
     */
    @Override
    public Class<?> getType() {
        return type;
    }

    /**
     * Full path to this property relative to the root class.  For example, "channels.stationInfo.stationId".
     * @return OGNL style property path
     */
    public String getPath() {
        return path;
    }

    /**
     * Whether the {@link #getType() type} of this property has subclasses
     * @return true if the type represents a Class that is subclasses or an interface that is implemented by another Class
     */
    public boolean hasSubtypes() {
        return !this.subTypes.isEmpty();
    }

    /**
     * If this descriptor {@link #hasSubtypes() has subtypes} a Map of descriptors for the subtypes
     * @return a Map (never null)
     */
    public Map<Class<?>, ApiPropertyDescriptor> getSubTypes() {
        return subTypes;
    }

    /**
     * The Method used to read the property.
     * @return a Method (never null)
     */
    public Method getReadMethod() {
        return readMethod;
    }

    /**
     * The Method used to write to the property.
     * @return a Method (never null)
     */
    public Method getWriteMethod() {
        return writeMethod;
    }

    /**
     * Whether the {@link #getReadMethod() read Method} returns a {@link Collection}.
     * @return true if the read Method returns a Collection
     */
    public boolean isCollectionType() {
        return collectionType;
    }

    /**
     * Whether the {@link #getReadMethod() read Method} returns a {@link List}.
     * @return true if the read Method returns a List
     */
    public boolean isListType() {
        return listType;
    }

    /**
     * Whether the {@link #getReadMethod() read Method} returns an array.
     * @return true if the read Method returns an array
     */
    public boolean isArrayType() {
        return this.arrayType;
    }

    /**
     * Append the string representation of this instance to the specified StringBuilder
     * @param depth depth from the root descriptor (used to indent the String)
     * @param sb StringBuilder to append
     */
    private void toStringInternal(int depth, StringBuilder sb) {
        String indent = StringUtils.repeat(" ", depth * 4);
        sb.append("\n").append(indent).append("ApiPropertyDescriptor {path = ").append(path);

        if (!children.isEmpty()) {
            sb.append(", children=[");
            int childDepth = depth + 1;

            for (int i = 0; i < children.size(); i++) {
                ApiPropertyDescriptor child = children.get(i);
                child.toStringInternal(childDepth, sb);

                if (i != children.size() - 1) {
                    sb.append(',');
                }
            }
            sb.append("\n").append(indent).append("]");
        }

        if (!subTypes.isEmpty()) {
            sb.append(", subTypes = ").append(subTypes);
        }

        sb.append("}");
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        toStringInternal(0, sb);
        return sb.toString();
    }
}
