package com.theplatform.web.tv.gws.ingest.producer.twitter.json;


import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;

/**
 * A TwitterItem that represents a program.  At a minimum, it includes one or
 * more ids from one or more sources and a title.
 */
public class TwitterItem {
    private final ListMultimap<AlternateIdSource, String> alternateIds;
    private int tweetCount;
    private String title;
    private String showTitle;

    public TwitterItem() {
        alternateIds = ArrayListMultimap.create(4, 2);
    }

    public ListMultimap<AlternateIdSource, String> getAlternateIds() {
        return alternateIds;
    }

    /**
     * Check if this TwitterItem has at least one id from the specified source
     * @param source non-null source
     * @return true if there are one or more ids from the specified source
     */
    public boolean hasAlternateIds(AlternateIdSource source) {
        return  alternateIds.containsKey(source) && !alternateIds.get(source).isEmpty();
    }

    /**
     * Check if this TwitterItem has <b>more than one</b> id from the specified source
     * @param source non-null source
     * @return true if there are more than one ids from the specified source
     */
    public boolean hasMultipleExternalIds(AlternateIdSource source) {
        return alternateIds.containsKey(source) && alternateIds.get(source).size() > 1;
    }

    /**
     * Get the first id (determined by appearance in the JSON) from the specified source.
     * @param source non-null source
     * @return the first id from the source that appears in the JSON or null if no ids from the
     *  source were in the JSON
     */
    public String getFirstAlternateId(AlternateIdSource source) {
        if (hasAlternateIds(source)) {
            return alternateIds.get(source).get(0);
        }
        else {
            return null;
        }
    }

    public int getTweetCount() {
        return tweetCount;
    }

    public void setTweetCount(int tweetCount) {
        this.tweetCount = tweetCount;
    }

    /**
     * The title of the program.
     * @return a String or null if no value was found in the JSON
     */
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * The title of the series
     * @return a String or null if no value was found in the JSON
     */
    public String getShowTitle() {
        return showTitle;
    }

    public void setShowTitle(String showTitle) {
        this.showTitle = showTitle;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TwitterItem)) return false;

        TwitterItem that = (TwitterItem) o;

        if (tweetCount != that.tweetCount) return false;
        if (!alternateIds.equals(that.alternateIds)) return false;
        if (title != null ? !title.equals(that.title) : that.title != null) return false;
        return !(showTitle != null ? !showTitle.equals(that.showTitle) : that.showTitle != null);

    }

    @Override
    public int hashCode() {
        int result = alternateIds.hashCode();
        result = 31 * result + tweetCount;
        result = 31 * result + (title != null ? title.hashCode() : 0);
        result = 31 * result + (showTitle != null ? showTitle.hashCode() : 0);
        return result;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TwitterItem{");
        sb.append("alternateIds=").append(alternateIds);
        sb.append(", tweetCount=").append(tweetCount);
        sb.append(", title='").append(title).append('\'');
        sb.append(", showTitle='").append(showTitle).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
