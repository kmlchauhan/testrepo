package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSServiceState;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 *  We are using Job ServiceState to store config file overrides.
 *      ServiceState.service=We will ignore anything that is not 'gridWebService'
 *      ServiceState.context=Property
 *      ServiceState.state=Value
 *
 *
 */
public class ServiceStateRepository extends LongObjectRepository<CRSServiceState> {
    private static final String GRID_WEBSERVICE = "gridWebService";

    private Map<String,String> propertyLookup = new HashMap<>();

    public ServiceStateRepository(SiriusObjectType siriusObjectType) {
        super( siriusObjectType, 1_000);
    }

    @Override
    protected void removeFromIndexes(CRSServiceState serviceState) {
        if (!serviceState.getService().equalsIgnoreCase(GRID_WEBSERVICE)) return;
        propertyLookup.remove(serviceState.getContext());
    }

    @Override
    protected void addToIndexes(CRSServiceState serviceState) {
        if (!serviceState.getService().equalsIgnoreCase(GRID_WEBSERVICE)) return;
        propertyLookup.put(serviceState.getContext(), serviceState.getState());
    }

    /**
     * Note: You cannot call this from the browser because it cuts everything off the property after the first
     * dot.  Doesn't seem to be an easy way around this. e.g. cacheControl.getListingsById becomes cacheControl
     * You need to call the repository with the actual id
     *
     *
     * @param property Name of the property
     * @return Value if it has been overriden.  Otherwise null.
     */
    public String getProperty(String property){
        return propertyLookup.get(property);
    }

    public Collection<CRSServiceState> getProperties(String service){
        Collection<CRSServiceState> properties = new ArrayList<>();
        for (CRSServiceState serviceState : this.map.values() ){
            if (serviceState.getService().equals(service)){
                properties.add(serviceState);
            }
        }
        return properties;
    }
}
