package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.api.annotation.WebServiceVersion;
import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import com.theplatform.web.tv.contentresolution.api.objects.episodes.EpisodeMap;

import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.Date;
import java.util.List;

@WebServiceVersion("1.25")
@WebService(name = "contentResolution", targetNamespace = "http://xml.theplatform.com/tv/web/AvailabilityResolution")
public interface ContentResolutionService_1_25 {

    /**
     * Returns a list of Channel infos
     *
     *
     * @param availabilityResolution
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     * @param byStreamStatus Or query with status separated by pipes "|" (e.g: "Production|Staging")
     *
     * @return
     * @throws GridException
     */
    ChannelInfoCollection resolveChannels(
            @WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
            @WebParam(name = "fields") String fields,
            @WebParam(name = "byStreamStatus") String byStreamStatus,
            @WebParam(name = "filterAdult") Boolean filterAdult) throws GridException;


    /**
     * Return the channels for a stream scoped to the provided availabilities.
     * @param availabilityResolution
     * @param streamId
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     * @return
     */
    ChannelInfoCollection resolveChannelsByStreamId(
            @WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
            @WebParam(name = "streamId") Long streamId,
            @WebParam(name = "fields") String fields,
            @WebParam(name = "filterAdult") Boolean filterAdult) throws GridException;

    /**
     * returns a grid object including a header, channels, and listing
     *
     * If only a subset of the channels are desired, rowStart and rowEnd can be
     * used to "paginate" the grid.
     *
     * @param availabilityResolution
     *            the availability resolution retrieved from the availability resolution service
     * @param numGridUnits
     *            an Integer for number of grid units
     * @param gridUnitWidth
     *            an Integer for the width of the grid unit
     * @param offset
     *            an Integer representing the offset
     * @param timeZone
     *            a String containing the timezone
     * @param categories
     *            A String[] containing program categories
     * @param companyIds
     *            a Long[] containing the company ids
     * @param stationTagIds
     *            a Long[] containing the stationTagIds
     * @param locatorFormats
     *            a String[] containing locator formats
     * @param hd
     *            a Boolean representing high def
     * @param rowStart
     *            starting index of grid rows to return. Defaults to 1.
     * @param rowEnd
     *            ending index of grid rows to return. Default is unbounded
     *            (null).
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     *
     * @return the grid
     * @throws GridException
     *             general grid exception
     */
    Grid getGrid(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                 @WebParam(name = "numGridUnits") Integer numGridUnits,
                 @WebParam(name = "gridUnitWidth") Integer gridUnitWidth, @WebParam(name = "offset") Integer offset,
                 @WebParam(name = "timeZone") String timeZone, @WebParam(name = "categories") String[] categories,
                 @WebParam(name = "companyIds") Long[] companyIds, @WebParam(name = "stationTagIds") Long[] stationTagIds,
                 @WebParam(name = "locatorFormats") String[] locatorFormats, @WebParam(name = "hd") Boolean hd,
                 @WebParam(name = "rowStart") Integer rowStart, @WebParam(name = "rowEnd") Integer rowEnd,
                 @WebParam(name = "programTagIds") Long[] programTagIds,
                 @WebParam(name = "fields") String fields)
            throws GridException;

    /**
     * Returns a grid object including a header, channels, and listing. This API
     * assumes the time range specified by startDate and endDate specifies a
     * whole number of grid units. This API is designed to enable cache warming.
     * The client should favor sending in a grid model over this API.
     *
     * If only a subset of the channels are desired, rowStart and rowEnd can be
     * used to "paginate" the grid.
     *
     * @param availabilityResolution
     *            the availability resolution retrieved from the availability resolution service
     * @param startTime
     *            a Date
     * @param numGridUnits
     *            an Integer
     * @param gridUnitWidth
     *            an Integer
     * @param timeZone
     *            ???
     * @param categories
     *            A String[] containing program categories
     * @param companyIds
     *            a Long[] containing the company ids
     * @param stationTagIds
     *            a Long[] containing the stationTagIds
     * @param locatorFormats
     *            a String[] containing locator formats
     * @param hd
     *            a Boolean representing high def
     * @param rowStart
     *            starting index of grid rows to return. Defaults to 1.
     * @param rowEnd
     *            ending index of grid rows to return. Default is unbounded
     *            (null).
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     *
     * @return the grid
     * @throws GridException
     *             general grid exception
     */
    Grid getGridByDate(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                       @WebParam(name = "startTime") Date startTime,
                       @WebParam(name = "numGridUnits") Integer numGridUnits,
                       @WebParam(name = "gridUnitWidth") Integer gridUnitWidth, @WebParam(name = "timeZone") String timeZone,
                       @WebParam(name = "categories") String[] categories, @WebParam(name = "companyIds") Long[] companyIds,
                       @WebParam(name = "stationTagIds") Long[] stationTagIds,
                       @WebParam(name = "locatorFormats") String[] locatorFormats, @WebParam(name = "hd") Boolean hd,
                       @WebParam(name = "rowStart") Integer rowStart, @WebParam(name = "rowEnd") Integer rowEnd,
                       @WebParam(name = "programTagIds") Long[] programTagIds,
                       @WebParam(name = "fields") String fields)
            throws GridException;

    /**
     * Returns listings in-window based on the specified grid model and station
     * id ordered by start time.
     *
     * @param stationId
     *            a Long
     * @param numGridUnits
     *            the number of grid units
     * @param gridUnitWidth
     *            the grid unit width
     * @param offset
     *            the offset
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "programInfo,programId,programInfo.title" will include only the programIds and title fields.
     * @return a list of listing infos
     * @throws GridException
     *             general grid exception
     */
    List<ListingInfo> getListings(@WebParam(name = "stationId") Long stationId,
                                  @WebParam(name = "numGridUnits") Integer numGridUnits,
                                  @WebParam(name = "gridUnitWidth") Integer gridUnitWidth, @WebParam(name = "offset") Integer offset,
                                  @WebParam(name = "programTagIds") Long[] programTagIds,
                                  @WebParam(name = "fields") String fields)
            throws GridException;

    /**
     * Returns listings in the specified time window for the specified station
     * ordered by start time
     *
     * @param stationId
     *            a Long
     * @param startTime
     *            a Date
     * @param endTime
     *            a Date
     * @param gridUnitWidth
     *            the grid unit width
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "programInfo,programId,programInfo.title" will include only the programIds and title fields.
     * @return a list of listing infos
     * @throws GridException
     *             general grid exception
     */
    List<ListingInfo> getListingsByDate(@WebParam(name = "stationId") Long stationId,
                                        @WebParam(name = "startTime") Date startTime, @WebParam(name = "endTime") Date endTime,
                                        @WebParam(name = "gridUnitWidth") Integer gridUnitWidth, @WebParam(name = "programTagIds") Long[] programTagIds,
                                        @WebParam(name = "fields") String fields) throws GridException;

    /**
     * Returns listings for a given list of ids
     * @param listingIds the listing ids to find and return
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     * @return a list of listing infos
     */
    List<ListingInfo> getListingsById(@WebParam(name = "listingIds") List<Muri> listingIds,
                                      @WebParam(name = "programTagIds") Long[] programTagIds,
                                      @WebParam(name = "fields") String fields) throws GridException;

    /**
     * Find all Stations airing the provided series within the provided timeframe.
     *
     * Example
     *     _seriesIds[0]=merlin:entity:program:8456220604370545112
     *     _seriesIds[1]=merlin:entity:program:8966735346904572112
     *     _startTime=1464563520000
     *     _endTime=1464563530000
     *  This will first identify all Listings that are part of one of the two series and are wholly or partly within
     *  the startTime and endTime.  The unique station ids of these listings will be sorted and returned.
     *
     * @param seriesIds ids of Programs of type SeriesMaster
     * @param startTime Optional start time of range
     * @param endTime Optional end time of range
     * @return an IdCollection of Station ids
     */
    public IdCollection getStationsBySeriesId(@WebParam(name = "seriesIds") Muri[] seriesIds,
                                              @WebParam(name = "startTime") Date startTime,
                                              @WebParam(name = "endTime") Date endTime);

    /**
     * Find all Stations airing Programs that involve the provided SportsTeams.
     *
     * @param sportsTeamIds ids of SportsTeams
     * @param startTime Optional start time of range
     * @param endTime Optional end time of range
     * @return an IdCollection of Station ids
     * @see #getStationsBySeriesId(Muri[], java.util.Date, java.util.Date)
     */
    public IdCollection getStationsBySportsTeamId(@WebParam(name = "sportsTeamIds") Muri[] sportsTeamIds,
                                                  @WebParam(name = "startTime") Date startTime,
                                                  @WebParam(name = "endTime") Date endTime);

    /**
     * Find all Stations airing Programs that involve the Persons (Credits).
     *
     * @param personIds ids of People
     * @param startTime Optional start time of range
     * @param endTime Optional end time of range
     * @return an IdCollection of Station ids
     * @see #getStationsByPersonId(Muri[], java.util.Date, java.util.Date)
     */
    public IdCollection getStationsByPersonId(@WebParam(name = "personIds") Muri[] personIds,
                                              @WebParam(name = "startTime") Date startTime,
                                              @WebParam(name = "endTime") Date endTime);


    /**
     * Returns StationInfos for a given list of station ids
     * @param stationIds the ids of stations to find and return
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     * @return a list of listing infos
     */
    List<StationInfo> getStationsById(@WebParam(name = "stationIds") Muri[] stationIds,
                                      @WebParam(name = "fields") String fields) throws GridException;

    /**
     * Find all Listings for episodes of the provided series.
     *
     * Optionally, only return Listings that are on the provided stations, or are wholly or partly within
     * the provided startTime and endTime.
     *
     * @param seriesIds ids of Programs of type SeriesMaster
     * @param startTime Optional start time of range
     * @param endTime Optional end time of range
     * @param stationIds Optional filter by Stations
     * @param fields Optional comma-delimited list of fields to include in the response
     * @return
     */
    List<ListingInfo> getListingsBySeriesId(@WebParam(name = "seriesIds") Muri[] seriesIds,
                                            @WebParam(name = "startTime") Date startTime,
                                            @WebParam(name = "endTime") Date endTime,
                                            @WebParam(name = "stationIds") Muri[] stationIds,
                                            @WebParam(name = "programTagIds") Long[] programTagIds,
                                            @WebParam(name = "fields") String fields);

    /**
     * Find all Listings that involve the provided SportsTeams.
     *
     * Optionally, only return Listings that are on the provided stations, or are wholly or partly within
     * the provided startTime and endTime.
     *
     * @param sportsTeamIds ids of SportsTeams
     * @param startTime Optional start time of range
     * @param endTime Optional end time of range
     * @param stationIds Optional filter by Stations
     * @param fields Optional comma-delimited list of fields to include in the response
     * @return a list of ListingInfo objects
     */
    List<ListingInfo> getListingsBySportsTeamId(@WebParam(name="sportsTeamIds") Muri[] sportsTeamIds,
                                                @WebParam(name = "startTime") Date startTime,
                                                @WebParam(name = "endTime") Date endTime,
                                                @WebParam(name="stationIds") Muri[] stationIds,
                                                @WebParam(name = "programTagIds") Long[] programTagIds,
                                                @WebParam(name = "fields") String fields);

    /**
     * Find all Listings for episodes of the provided Persons(Credit).
     *
     * Optionally, only return Listings that are on the provided stations, or are wholly or partly within
     * the provided startTime and endTime.
     *
     * @param personIds ids of Programs of type SeriesMaster
     * @param startTime Optional start time of range
     * @param endTime Optional end time of range
     * @param stationIds Optional filter by Stations
     * @param fields Optional comma-delimited list of fields to include in the response
     * @return
     */
    List<ListingInfo> getListingsByPersonId(@WebParam(name = "personIds") Muri[] personIds,
                                            @WebParam(name = "startTime") Date startTime,
                                            @WebParam(name = "endTime") Date endTime,
                                            @WebParam(name = "stationIds") Muri[] stationIds,
                                            @WebParam(name = "programTagIds") Long[] programTagIds,
                                            @WebParam(name = "fields") String fields);

    /**
     * Returns programs that are currently trending on social media.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     * @return A trending programs object that contains a list of trending programs sorted by score (rank)
     * @throws GridException
     */
    TrendingPrograms getTrendingPrograms(@WebParam(name = "fields") String fields) throws GridException;

    /**
     * Given an episode id, return the episodes that precede and/or follow it.
     *
     * Optionally, return the given episode as well.
     *
     * This method supports batching by accepting multiple episode ids and returning a map keyed on them.
     *
     * @param episodeIds The set of episode Program IDs. Must be non-null and contain at least one ID.
     * @param previousEpisodeCount Optional number of episodes to return that precede the set passed in
     *                             Default: infinity
     * @param nextEpisodeCount Optional number of episodes to return that follow the set passed in
     *                         Default: infinity
     * @param excludeProvidedEpisodes Optional whether to exclude the episodes in episodeIds from the returned Lists
     *                                Default: false
     * @param fields Optional comma-delimited list of fields to include in the response
     */
    EpisodeMap getEpisodes(@WebParam(name = "episodeIds") Muri[] episodeIds,
                           @WebParam(name = "previousEpisodeCount") Integer previousEpisodeCount,
                           @WebParam(name = "nextEpisodeCount") Integer nextEpisodeCount,
                           @WebParam(name = "excludeProvidedEpisodes") Boolean excludeProvidedEpisodes,
                           @WebParam(name = "fields") String fields)
            throws GridException;


    List<ProgramInfo> getProgramsById( @WebParam(name = "programIds") Muri[] programIds
            , @WebParam(name = "fields") String fields)
            throws GridException;

    List<ChannelInfo> getChannelsById(@WebParam(name = "channelIds") Muri[] channelIds,
                                      @WebParam(name = "fields") String fields) throws GridException;

    // Begin - Originally Backend APIs

    /**
     * Returns a list of ChannelAvailability Location Ids
     *
     * @return
     * @throws com.theplatform.web.tv.GridException
     */
    IdCollection getChannelAvailabilityIds() throws GridException;

    ChannelInfoCollection getChannelsByAvailabilityId(
            @WebParam(name = "channelsAvailabilityId") Muri channelsAvailabilityId) throws GridException;;

    /**
     * Find Locators matching region
     *
     * @param region
     * @return
     */
    LocatorInfoCollection getLocatorsByRegion(@WebParam(name = "region") String region) throws GridException;



    // End - Originally Backend APIs



}
