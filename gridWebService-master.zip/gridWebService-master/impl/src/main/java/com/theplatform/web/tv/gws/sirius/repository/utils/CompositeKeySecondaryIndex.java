package com.theplatform.web.tv.gws.sirius.repository.utils;

import java.util.Set;

public interface CompositeKeySecondaryIndex<K1, K2, V> {
    void put(K1 indexValue1, K2 indexValue2, V object);

    /**
     * Remove an object from the index
     */
    void remove(K1 indexValue1, K2 indexValue2, V object);

    /**
     * Remove all
     */
    void removeAll(K1 indexValue1, K2 indexValue2);

    /**
     * Returns all the objects associated with a key,
     * or empty set if nothing is associated.
     */
    Set<V> getByIndexKey(K1 indexValue1, K2 indexValue2);
}
