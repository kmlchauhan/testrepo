package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.contentresolution.api.annotation.ResolveChannelsValidation;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import com.theplatform.web.tv.gws.service.common.aop.stats.CollectStats;
import com.theplatform.web.tv.gws.service.common.field.FieldFilterUtil;

import javax.jws.WebParam;
import java.util.Date;
import java.util.List;

public class ContentResolutionServiceImpl_1_18 extends LegacyContentResolutionServiceImpl<ContentResolutionServiceImpl_1_19> implements ContentResolutionService_1_18  {
    private static final String INCLUDE_ALWAYS = "verboseInfo";;

    protected final ApiObjectVisitor visitor;

    public ContentResolutionServiceImpl_1_18() {
        visitor = DataObjectTranslator_1_18.INSTANCE;
    }

    @CollectStats
    @ResolveChannelsValidation
    @Override
    public ChannelInfoCollection resolveChannels(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                                                 @WebParam(name = "mainImageTypeGroup") Muri mainImageTypeGroup,
                                                 @WebParam(name = "fields") String fields,
                                                 @WebParam(name = "byStreamStatus") String byStreamStatus,
                                                 @WebParam(name = "filterAdult") Boolean filterAdult) throws GridException {
        ChannelInfoCollection collection = contentResolutionService.resolveChannels(availabilityResolution, mainImageTypeGroup, null, byStreamStatus, filterAdult);
        collection.accept(visitor);
        FieldFilterUtil.filterFields(collection, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return collection;
    }

    @Override
    public ChannelInfoCollection resolveChannelsByStreamId(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                                                           @WebParam(name = "streamId") Long streamId,
                                                           @WebParam(name = "fields") String fields,
                                                           @WebParam(name = "filterAdult") Boolean filterAdult) throws GridException {
        ChannelInfoCollection collection = contentResolutionService.resolveChannelsByStreamId(availabilityResolution, streamId, null, filterAdult);
        collection.accept(visitor);
        FieldFilterUtil.filterFields(collection, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return collection;
    }

    @Override
    public Grid getGrid(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                        @WebParam(name = "mainImageTypeGroup") Muri mainImageTypeGroup,
                        @WebParam(name = "numGridUnits") Integer numGridUnits,
                        @WebParam(name = "gridUnitWidth") Integer gridUnitWidth,
                        @WebParam(name = "offset") Integer offset,
                        @WebParam(name = "timeZone") String timeZone,
                        @WebParam(name = "categories") String[] categories,
                        @WebParam(name = "companyIds") Long[] companyIds,
                        @WebParam(name = "stationTagIds") Long[] stationTagIds,
                        @WebParam(name = "locatorFormats") String[] locatorFormats,
                        @WebParam(name = "hd") Boolean hd,
                        @WebParam(name = "rowStart") Integer rowStart,
                        @WebParam(name = "rowEnd") Integer rowEnd,
                        @WebParam(name = "programTagIds") Long[] programTagIds,
                        @WebParam(name = "fields") String fields) throws GridException {
        Grid grid = contentResolutionService.getGrid(availabilityResolution, mainImageTypeGroup, numGridUnits, gridUnitWidth, offset, timeZone, categories, companyIds, stationTagIds, locatorFormats, hd, rowStart, rowEnd, programTagIds, null);
        grid.accept(visitor);
        FieldFilterUtil.filterFields( grid, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return grid;
    }

    @Override
    public Grid getGridByDate(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                              @WebParam(name = "mainImageTypeGroup") Muri mainImageTypeGroup,
                              @WebParam(name = "startTime") Date startTime,
                              @WebParam(name = "numGridUnits") Integer numGridUnits,
                              @WebParam(name = "gridUnitWidth") Integer gridUnitWidth,
                              @WebParam(name = "timeZone") String timeZone,
                              @WebParam(name = "categories") String[] categories,
                              @WebParam(name = "companyIds") Long[] companyIds,
                              @WebParam(name = "stationTagIds") Long[] stationTagIds,
                              @WebParam(name = "locatorFormats") String[] locatorFormats,
                              @WebParam(name = "hd") Boolean hd,
                              @WebParam(name = "rowStart") Integer rowStart,
                              @WebParam(name = "rowEnd") Integer rowEnd,
                              @WebParam(name = "programTagIds") Long[] programTagIds,
                              @WebParam(name = "fields") String fields) throws GridException {
        Grid grid = contentResolutionService.getGridByDate(availabilityResolution, mainImageTypeGroup, startTime, numGridUnits, gridUnitWidth, timeZone, categories, companyIds, stationTagIds, locatorFormats, hd, rowStart, rowEnd, programTagIds, null);
        grid.accept(visitor);
        FieldFilterUtil.filterFields( grid, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return grid;
    }

    @Override
    public List<ListingInfo> getListings(@WebParam(name = "stationId") Long stationId,
                                         @WebParam(name = "numGridUnits") Integer numGridUnits,
                                         @WebParam(name = "gridUnitWidth") Integer gridUnitWidth,
                                         @WebParam(name = "offset") Integer offset,
                                         @WebParam(name = "programTagIds") Long[] programTagIds,
                                         @WebParam(name = "fields") String fields) throws GridException {
        List<ListingInfo> listingInfos = contentResolutionService.getListings(stationId, numGridUnits, gridUnitWidth, offset, programTagIds, null);
        visitor.visitEach(listingInfos);
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);
        return listingInfos;
    }

    @Override
    public List<ListingInfo> getListingsByDate(@WebParam(name = "stationId") Long stationId,
                                               @WebParam(name = "startTime") Date startTime,
                                               @WebParam(name = "endTime") Date endTime,
                                               @WebParam(name = "gridUnitWidth") Integer gridUnitWidth,
                                               @WebParam(name = "programTagIds") Long[] programTagIds,
                                               @WebParam(name = "fields") String fields) throws GridException {
        List<ListingInfo> listingInfos = contentResolutionService.getListingsByDate( stationId, startTime, endTime, gridUnitWidth, programTagIds, null);
        visitor.visitEach(listingInfos);
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);
        return listingInfos;
    }

    @Override
    public List<ListingInfo> getListingsById(@WebParam(name = "listingIds") List<Muri> listingIds,
                                             @WebParam(name = "programTagIds") Long[] programTagIds,
                                             @WebParam(name = "fields") String fields) throws GridException {
        List<ListingInfo> listingInfos = contentResolutionService.getListingsById( listingIds, programTagIds, null);
        visitor.visitEach(listingInfos);
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);
        return listingInfos;
    }

    @Override
    public TrendingPrograms getTrendingPrograms(@WebParam(name = "fields") String fields) throws GridException {
        TrendingPrograms programs = contentResolutionService.getTrendingPrograms(null);
        programs.accept(visitor);
        FieldFilterUtil.filterFields(programs, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return programs;
    }
}
