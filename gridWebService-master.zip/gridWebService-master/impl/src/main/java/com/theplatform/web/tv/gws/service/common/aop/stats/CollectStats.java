package com.theplatform.web.tv.gws.service.common.aop.stats;

/**
 * Created by jcoelho on 5/22/13.
 */
@java.lang.annotation.Target({java.lang.annotation.ElementType.METHOD})
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@java.lang.annotation.Inherited
@java.lang.annotation.Documented
public @interface CollectStats {
    String prefix() default "";
}
