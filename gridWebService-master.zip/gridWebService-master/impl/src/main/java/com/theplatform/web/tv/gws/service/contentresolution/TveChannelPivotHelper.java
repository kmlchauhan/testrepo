package com.theplatform.web.tv.gws.service.contentresolution;

import com.comcast.merlin.sirius.ingest.dispatcher.Stop;
import com.theplatform.data.tv.offer.api.data.objects.ProductContextType;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.ProductContextInfo;
import com.theplatform.web.tv.gws.sirius.repository.PartnerRepository;
import com.theplatform.web.tv.gws.sirius.repository.ProductContextRepository;
import com.theplatform.web.tv.gws.sirius.repository.StationModifierRepository;
import com.theplatform.web.tv.gws.service.common.util.MiscUtil;
import org.springframework.beans.factory.annotation.Required;

import java.util.*;

/**
 * Background
 * The StationModifier Endpoint contains 'OutOfHome' references from stationId to relatedStations.stationId.  There
 * can only be one OutOfHome Reference.
 *
 *  For any TitleVI or CTV PC Type Channel returned attempt to identify a related TVE Channel using the logic below.  The TitleVI/CTV
 *  Channel's channelInfo.outOfHomeChannelId field should be populated with the related TVE Channel if it exists.
 *  Logic:
 *      1.    If TitleVI/CTV PC Type channel's stationId is found in the StationModifier endpoint where relatedStation.type = OutOfHome
 *            and is mapped to a stationId that is found in one of the response's TVE channels, use that
 *      2.    If TitleVI/CTV PC Type channel's stationId is found in one of the the response's TVE channels, use that
 *      3.    If TitleVI/CTV PC Type channel's associatedStationId is found in one of the the response's TVE channels, use that
 *  Note:
 *      + If there are multiple TVE channels for that station, return the one with the smallest number.
 *      + A Channel with TitleVI/CTV and TVE PCs can reference itself.
 *
 */
public class TveChannelPivotHelper {
    private StationModifierRepository stationModifierRepository;
    private ProductContextRepository productContextRepository;
    private PartnerRepository partnerRepository;

    private boolean usePartnerInheritance;
    private long comcastOwnerId;

    /**
     * 1.	If TitleVI/CTV PC Type channel's stationId is found in the StationModifier endpoint and is mapped to a
     *      stationId that is found in one of the response's TVE channels, use that
     * 2.	If TitleVI/CTV PC Type channel's stationId is in the StationModifier map and the channel's StationId is
     *      found in one of the the response's TVE channels, use that  (Note this is not using the
     *      stationmodifiers mapped stationId)
     * 3.	If TitleVI/CTV PC Type channel's stationId is in the StationModifier map and the channel's
     *      associatedStationId is found in one of the the response's TVE channels, use that (Note this is not using
     *      the stationmodifiers mapped stationId)
     *
     * @param ownerId Owner Id of the Requestor
     * @param requestedProductContext  A set of Station-Scoped ProductContext from the original request.
     * @param channelInfos  An ORDERED list of ChannelInfos
     */
    public void populateOutOfHomeRelatedChannels( long ownerId
                                                , Set<Long> requestedProductContext
                                                , List<ChannelInfo> channelInfos){
        // If the original request does not contain TVE AND (TitleVI or CTV PC Type) then short-circuit.
        if (!containsProductContextType(requestedProductContext, ProductContextType.TVE) ||
                !(containsProductContextType(requestedProductContext, ProductContextType.TitleVI) || containsProductContextType(requestedProductContext, ProductContextType.CTV))) {
            return;
        }

        // Create a map of Station Id -> TVE Channels
        Map< Long, ChannelInfo> tveStationIdToChannelInfo = new HashMap<>(100);
        for( ChannelInfo channelInfo : channelInfos){
            if (containsProductContextTypeInfo(channelInfo.getProductContexts(), ProductContextType.TVE)){
                // In case there are multiple TVE Channels with the same Station Id
                long stationId = channelInfo.getStationInfo().getStationId().getId();
                if (tveStationIdToChannelInfo.containsKey(stationId)){
                    // Deterministic - Use the lowest of the Channel IDs
                    long originalChannelId = tveStationIdToChannelInfo.get(stationId).getChannelId().getId();
                    long newChannelId = channelInfo.getChannelId().getId();
                    if (newChannelId<originalChannelId){
                        tveStationIdToChannelInfo.put( stationId, channelInfo);
                    }
                } else {
                    tveStationIdToChannelInfo.put( stationId ,channelInfo);
                }
            }
        }

        for( ChannelInfo channelInfo : channelInfos){
            if (containsProductContextTypeInfo(channelInfo.getProductContexts(), ProductContextType.TitleVI)
                    || containsProductContextType(requestedProductContext, ProductContextType.CTV)){

                Long relatedStationId = stationModifierRepository.getOutOfHomeStationId( channelInfo.getStationInfo().getStationId().getId(), ownerId);
                // Hierarchy - If enabled and no StationModifier attempt to find a Comcast one.
                if ( relatedStationId==null
                        && comcastOwnerId!=ownerId
                        && usePartnerInheritance){
                    Long parentOwnerId = getParentPartnerOwnerId(ownerId);
                    if (parentOwnerId != null)
                        relatedStationId = stationModifierRepository.getOutOfHomeStationId( channelInfo.getStationInfo().getStationId().getId(), parentOwnerId);
                }

                if (relatedStationId != null && tveStationIdToChannelInfo.containsKey(relatedStationId)){
                    ChannelInfo relatedChannelInfo = tveStationIdToChannelInfo.get(relatedStationId);
                    channelInfo.setOutOfHomeChannelId(relatedChannelInfo.getChannelId());
                } else if (tveStationIdToChannelInfo.containsKey(channelInfo.getStationInfo().getStationId().getId())){
                    ChannelInfo relatedChannelInfo = tveStationIdToChannelInfo.get(channelInfo.getStationInfo().getStationId().getId());
                    channelInfo.setOutOfHomeChannelId(relatedChannelInfo.getChannelId());
                } else if ( channelInfo.getStationInfo().getTransientAssociatedStationId()!=null &&
                            tveStationIdToChannelInfo.containsKey(channelInfo.getStationInfo().getTransientAssociatedStationId().getId())){
                    ChannelInfo relatedChannelInfo = tveStationIdToChannelInfo.get(channelInfo.getStationInfo().getTransientAssociatedStationId().getId());
                    channelInfo.setOutOfHomeChannelId(relatedChannelInfo.getChannelId());
                }
            }
        }
    }

    private boolean containsProductContextTypeInfo(Collection<ProductContextInfo> productContexts, ProductContextType  productContextType){
        for (ProductContextInfo productContextInfo: productContexts){
            if ( productContextInfo.getType().equals(productContextType.name())){
                return true;
            }
        }
        return false;
    }


    private boolean containsProductContextType(Collection<Long> productContexts, ProductContextType  productContextType){
        for(long productContext : productContexts){
            if (productContextRepository.isProductContextOfType(productContext, productContextType)){
                return true;
            }
        }
        return false;
    }

    private Long getParentPartnerOwnerId(long ownerId){

        return partnerRepository.getParentOwnerId(ownerId);
    }

    @Required
    public void setStationModifierRepository(StationModifierRepository stationModifierRepository) {
        this.stationModifierRepository = stationModifierRepository;
    }

    @Required
    public void setProductContextRepository(ProductContextRepository productContextRepository) {
        this.productContextRepository = productContextRepository;
    }
    @Required
    public void setPartnerRepository(PartnerRepository partnerRepository) {
        this.partnerRepository = partnerRepository;
    }

    @Required
    public void setUsePartnerInheritance(boolean usePartnerInheritance) {
        this.usePartnerInheritance = usePartnerInheritance;
    }

    @Required
    public void setCombineOwnerId(String combineOwnerId) {
        Long id = MiscUtil.longFromCombineOwnerId(combineOwnerId);
        if (id==null){
            Stop.instance().stop("Unable to find Owner Id in: " + combineOwnerId);
        } else {
            comcastOwnerId=id;
        }
    }
}
