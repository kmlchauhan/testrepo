package com.theplatform.web.tv.gws.service.contentresolution;

import com.theplatform.data.tv.linear.api.data.objects.StreamStatus;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class ContentResolutionDefaults {

    public static final String DEFAULT_TIME_ZONE = "UTC"; // coordinated universal time
    public static final long DEFAULT_GRID_TIME_RANGE = 3; // three hours
    public static final int DEFAULT_NUM_GRID_UNITS = 6; // six units to be displayed on grid
    public static final int DEFAULT_GRID_UNIT_WIDTH = 30; // on unit = 30 minutes of time
    public static final int DEFAULT_GRID_OFFSET = 0; // offset the grid by 0 units
    public static final Set<String> DEFAULT_STREAM_STATUS_SET = new HashSet<String>(Arrays.asList(StreamStatus.Production.toString()));

    
}
