package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.ProductContextProto.ProductContextMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSProductContext;

/**
 * Factory that converts ProductContext protobufs to CRSProductContexts and visa-versa.
 * 
 */
public class ProductContextSerializer extends AbstractSiriusObjectSerializer<CRSProductContext> {

    public ProductContextSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSProductContext unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        ProductContextMessage.Builder message = ProductContextMessage.newBuilder().mergeFrom(bytes);

        CRSProductContext productContext = new CRSProductContext(message.getId());

        if (message.hasTitle())
            productContext.setTitle(message.getTitle());

        if (message.hasType())
            productContext.setType(message.getType().intern());

        return productContext;
    }

    @Override
    public ByteString marshallPayload(  CRSProductContext productContext) {
        ProductContextMessage.Builder builder = ProductContextMessage.newBuilder();

        builder.setId(productContext.getId());
        builder.setTitle(productContext.getTitle());
        builder.setType(productContext.getType());

        return builder.build().toByteString();
    }

}