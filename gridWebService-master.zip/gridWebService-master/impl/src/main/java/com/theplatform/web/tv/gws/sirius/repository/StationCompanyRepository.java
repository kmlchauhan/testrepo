package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.google.common.collect.HashMultimap;
import com.theplatform.web.tv.gws.sirius.model.CRSStationCompany;
import com.theplatform.web.tv.gws.sirius.repository.utils.OpenSetSecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.SecondaryIndex;

import java.util.Collection;

public class StationCompanyRepository extends LongObjectRepository<CRSStationCompany> {
    protected final SecondaryIndex<Long, CRSStationCompany> stationToStationCompanyIndex;

    private HashMultimap<Long,Long> stationToCompanyMap;



    public StationCompanyRepository(SiriusObjectType siriusObjectType) {
        super( siriusObjectType, 28_000);
        stationToStationCompanyIndex = new OpenSetSecondaryIndex<>();
        stationToCompanyMap = HashMultimap.create(28_000,1);
    }

    @Override
    protected void addToIndexes(CRSStationCompany crsStationCompany) {
        stationToStationCompanyIndex.put(crsStationCompany.getStationId(), crsStationCompany);
        stationToCompanyMap.put( crsStationCompany.getStationId(), crsStationCompany.getCompanyId());
    }

    @Override
    protected void removeFromIndexes(CRSStationCompany crsStationCompany) {
        stationToStationCompanyIndex.remove( crsStationCompany.getStationId(), crsStationCompany);
        stationToCompanyMap.remove( crsStationCompany.getStationId(), crsStationCompany.getCompanyId());
    }

    public Collection<CRSStationCompany> getStationCompanyByStationId(long stationId){
        return stationToStationCompanyIndex.getByIndexKey(stationId);
    }

    public boolean relationShipExists(long stationId, long companyId){
        return stationToCompanyMap.get(stationId).contains(companyId);
    }



}
