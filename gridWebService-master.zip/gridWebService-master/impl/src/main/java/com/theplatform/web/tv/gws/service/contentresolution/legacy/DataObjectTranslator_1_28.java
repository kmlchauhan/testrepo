package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.theplatform.web.tv.contentresolution.api.objects.*;

public class DataObjectTranslator_1_28 extends ApiObjectVisitor {
    public final static DataObjectTranslator_1_28 INSTANCE = new DataObjectTranslator_1_28();

    @Override
    public void visitLocatorInfo(LocatorInfo locatorInfo) {
        locatorInfo.setNamespaceId(null);
        locatorInfo.setNamespaceTitle(null);
    }

    @Override
    public void visitChannelInfo(ChannelInfo channelInfo) {
        channelInfo.setOwnerId(null);
    }
    
}
