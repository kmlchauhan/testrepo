package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.linear.api.data.objects.Station;
import com.theplatform.web.tv.gws.sirius.model.CRSStation;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StationConverter extends AbstractDataObjectConverter<Station, CRSStation> {

    @Override
    public CRSStation convert(Station station) {
        CRSStation crsStation = new CRSStation();
        crsStation.setId(LocalUriConverter.convertUriToID(station.getId()));
        if (station.getAssociatedStationId() != null)
            crsStation.setAssociatedStationId(LocalUriConverter.convertUriToID(station.getAssociatedStationId()));
        crsStation.setCallSign(station.getCallsign());
        if (station.getDigicableId() != null)
            crsStation.setDigicableId(station.getDigicableId());
        if (station.getExpirationDate() != null)
            crsStation.setExpirationDate(station.getExpirationDate().getTime());
        if (station.getLanguage() != null)
            crsStation.setLanguage(station.getLanguage());
        if (station.getOnScreenCallsign() != null)
            crsStation.setOnScreenCallSign(station.getOnScreenCallsign());
        if (station.getOtaChannelNumber() != null)
            crsStation.setOtaChannelNumber(station.getOtaChannelNumber());
        if (station.getPayPerView() != null)
            crsStation.setPayPerView(station.getPayPerView());
        if (station.getShortName() != null)
            crsStation.setShortName(station.getShortName());
        if (station.getTimeZone() != null)
            crsStation.setTimeZone(station.getTimeZone());
        if (station.getTitle() != null)
            crsStation.setTitle(station.getTitle());
        if (station.getVod() != null)
            crsStation.setVod(station.getVod());
        if (station.getEmergencyAlertSystemType() != null)
            crsStation.setEmergencyAlertSystemType(station.getEmergencyAlertSystemType());
        if (station.getHdLevel() != null)
            crsStation.setHdLevel(station.getHdLevel());
        if (station.getColorDepth() != null)
            crsStation.setColorDepth(station.getColorDepth());
        if (station.getQuality() != null)
            crsStation.setQuality(station.getQuality());
        if (station.getQualityVariants() != null){
            Map<String, Long> qualityVariants = new HashMap<>();
            for (Map.Entry<String, URI> entry : station.getQualityVariants().entrySet()){
                qualityVariants.put(entry.getKey(), LocalUriConverter.convertUriToID(entry.getValue()));
            }
            crsStation.setQualityVariants(qualityVariants);
        }

        return crsStation;
    }

    private List<Long> toLongIds(List<URI> uris) {
        List<Long> ids = new ArrayList<>(uris.size());
        for (URI uri : uris) {
            ids.add(LocalUriConverter.convertUriToID(uri));
        }
        Collections.sort(ids);          // For ETags
        return ids;
    }

}
