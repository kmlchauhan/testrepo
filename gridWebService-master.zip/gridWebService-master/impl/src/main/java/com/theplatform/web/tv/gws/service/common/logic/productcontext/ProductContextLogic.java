package com.theplatform.web.tv.gws.service.common.logic.productcontext;

import com.google.common.collect.*;
import com.theplatform.data.tv.offer.api.data.objects.*;
import com.theplatform.web.tv.contentresolution.api.debug.*;
import com.theplatform.web.tv.gws.service.common.debug.*;
import com.theplatform.web.tv.gws.service.common.util.*;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.sirius.repository.*;
import com.theplatform.web.tv.gws.uri.*;
import org.apache.commons.lang.*;
import org.springframework.beans.factory.annotation.*;

import java.util.*;

public class ProductContextLogic {
    private DebugHelper debugHelper;
    private MerlinIdHelper merlinIdHelper;

    private ChannelRepository channelRepository;
    private ContentAvailabilityRepository contentAvailabilityRepository;
    private AvailabilityTagRepository availabilityTagRepository;
    private ProductContextRepository productContextRepository;

    // Phase II Owner Ids
    private PartnerRepository partnerRepository;

    private DynamicProperties dynamicProperties;

    /**
     *  Used for requesting ALL productContexts for a given Channel.
     */
    public Set<Long>  getProductContextMapping( CRSChannel channel, Long ownerId){
        return getProductContextMapping( channel, null, ownerId);
    }

    /**
     *  Used for requesting specific productContexts for a given Channel.
     */
    public Set<Long> getProductContextMapping( CRSChannel channel,
                                             Set<Long> productContextsRequested,
                                             Long ownerId){
        boolean channelProductContextEnabled = dynamicProperties.get(DynamicProperties.DynamicPropertiesEnum.NEWLOGIC_CHANNEL_PRODUCTCONTEXT_ENABLED).equals("true");
        return getProductContextMapping( channel, productContextsRequested, ownerId, channelProductContextEnabled);
    }

    /**
     * 1) If channelProductContextEnabled AND Channel PCs are non-empty then NO fallback logic will be used even
     *      if the Station-scope ProductContext is not in Channel.productContextIds
     * 2) Else we check (station/location) CAs ProductContext
     * 3) If #2 results in no match OR none matching the requested ProductContext then we check the
     *      Station/National CAs ProductContext.
     *
     * @param channel
     * @param productContextsRequested
     * @param ownerId
     * @param channelProductContextEnabled
     * @return
     */
    private Set<Long> getProductContextMapping( CRSChannel channel,
                           Set<Long> productContextsRequested,
                           Long ownerId,
                           boolean channelProductContextEnabled) {
        Set<Long> identifiedProductContexts = new HashSet<>();

        long channelId = channel.getId();
        long stationId = channel.getStationId();
        long locationId = channel.getLocationId();

        // Retrieve ProductContexts from channel if allowed
        if (channelProductContextEnabled) {
            CRSChannel crsChannel = channelRepository.get(channelId);
            if (crsChannel != null ) {
                identifiedProductContexts.addAll(crsChannel.getProductContexts());
            }
        }

        // Channel Logic Not Enabled OR Channel had no ProductContexts
        if (identifiedProductContexts.size() == 0) {
            // Attempt Location/CA Based Product Context Lookup
            Set<CRSContentAvailability> cas = contentAvailabilityRepository.getContentAvailabilitysByLocationAndStation(locationId, stationId, ownerId);
            if (cas != null) {
                for (CRSContentAvailability ca : cas) {
                    if (ca.getProductContextIds() != null) identifiedProductContexts.addAll( ca.getProductContextIds());
                }
            }

            Long nationalAvailabilityTagId = getNationalAvailabilityId(ownerId);
            if (nationalAvailabilityTagId != null){
                // If no PC (Frontend)then apply National if not found
                if (identifiedProductContexts.size() == 0 || (productContextsRequested != null && Sets.intersection(identifiedProductContexts, productContextsRequested).size() == 0)) {
                    Set<CRSContentAvailability> nationalCas = contentAvailabilityRepository.getContentAvailabilitysByLocationAndStation(nationalAvailabilityTagId, stationId, ownerId);
                    if (nationalCas != null) {
                        for (CRSContentAvailability ca : nationalCas) {
                            if (ca.getProductContextIds() != null) identifiedProductContexts.addAll(ca.getProductContextIds());
                        }
                    }
                }
            }
        }

        // null is a request for all ProductContext
        if (productContextsRequested == null) {
            return identifiedProductContexts;
        } else {
            Set<Long> matchingProductContext = Sets.intersection(identifiedProductContexts, productContextsRequested);
            Set<Long> appliedProductContext = new HashSet(matchingProductContext);
            if (appliedProductContext.size() > 0) {
                // New Phase II Check - if Comcast/ChildrenOfComcast then strip out cTV or cDVR not on the Whitelist
                phase2Check( appliedProductContext, channelId, stationId, ownerId);
            }
            if (debugHelper.isVerboseMode()) {
                Set<Long> requestNotFoundProductContext = Sets.difference(productContextsRequested, identifiedProductContexts);
                if (requestNotFoundProductContext.size() > 0) {
                    long[] notFound = ArrayUtils.toPrimitive(requestNotFoundProductContext.toArray(new Long[requestNotFoundProductContext.size()]));
                    debugHelper.logResponseWarning(WarningType.ProductContextDropped, CauseType.NoStationCA,
                            WarningItem.instance().setStationId(merlinIdHelper.createStationId(stationId))
                                    .setProductContextIds(merlinIdHelper.createProductContextIds(notFound))
                                    .setChannelId(merlinIdHelper.createChannelId(channelId)));
                }
            }
            return appliedProductContext;
        }
    }

    /**
     * The New Phase II check
     *
     * @param productContexts Set of ProductContext.  This will be modified by removing PCs
     * @param channelId      For verbose logging purposes only
     * @param stationId       Used to check if on the whitelist
     * @param ownerId         The Owner Id - We will only appy this logic for Comcast and its Children
     */
    private void phase2Check(Set<Long> productContexts, Long channelId, Long stationId, Long ownerId){
        if ( ! partnerRepository.isComcastOwnerId(ownerId)) return;

        if ( dynamicProperties.get(DynamicProperties.DynamicPropertiesEnum.PHASE2_CTV_ENABLED).equals("true") &&  !contentAvailabilityRepository.isCtvStation(stationId)) {
            removeProductContext(productContexts, ProductContextType.CTV.name(), channelId, stationId);
        }

        if ( dynamicProperties.get(DynamicProperties.DynamicPropertiesEnum.PHASE2_CDVR_ENABLED).equals("true") && !contentAvailabilityRepository.isCdvrStation(stationId)) {
            removeProductContext(productContexts, ProductContextType.CDVR.name(), channelId, stationId);
        }

    }

    private void removeProductContext(Set<Long> productContexts, String productContextType, Long channelId, Long stationId){

        Iterator<Long> productContextInfoIter = productContexts.iterator();
        while (productContextInfoIter.hasNext()) {
            Long productContextId = productContextInfoIter.next();
            CRSProductContext crsProductContext = productContextRepository.get(productContextId);
            if (crsProductContext == null) continue;
            if (crsProductContext.getType().equals(productContextType)) {
                productContextInfoIter.remove();
                // Log the dropped PC and one entry for each channel.
                debugHelper.logResponseWarning( WarningType.ProductContextDropped, CauseType.PhaseII,
                            WarningItem.instance()
                                    .setChannelId(merlinIdHelper.createChannelId(channelId))
                                    .addProductContextId(merlinIdHelper.createProductContextId(crsProductContext.getId()))
                                    .setStationId(merlinIdHelper.createStationId(stationId))
                );
            }
        }

    }

    /**
     *  Return the National AvailabilityTag ID for the given Owner.  null will be returned if there is none.
     */
    private Long getNationalAvailabilityId(long ownerId){
        CRSAvailabilityTag crsContentAvailability = availabilityTagRepository.getNationalAvailabilityTag(ownerId);
        if (crsContentAvailability==null){
            return null;
        } else {
            return crsContentAvailability.getId();
        }
    }

    @Required
    public void setContentAvailabilityRepository(ContentAvailabilityRepository contentAvailabilityRepository) {
        this.contentAvailabilityRepository = contentAvailabilityRepository;
    }

    @Required
    public void setAvailabilityTagRepository(AvailabilityTagRepository availabilityTagRepository) {
        this.availabilityTagRepository = availabilityTagRepository;
    }

    @Required
    public void setProductContextRepository(ProductContextRepository productContextRepository) {
        this.productContextRepository = productContextRepository;
    }
    
    @Required
    public void setDebugHelper(DebugHelper debugHelper) {
        this.debugHelper = debugHelper;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }

    @Required
    public void setPartnerRepository(PartnerRepository partnerRepository) {
        this.partnerRepository = partnerRepository;
    }

    @Required
    public void setDynamicProperties(DynamicProperties dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }
}
