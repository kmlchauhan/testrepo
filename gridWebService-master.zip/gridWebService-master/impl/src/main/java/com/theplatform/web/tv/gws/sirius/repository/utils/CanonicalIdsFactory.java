package com.theplatform.web.tv.gws.sirius.repository.utils;

import com.theplatform.contrib.data.api.objects.*;
import net.openhft.koloboke.collect.set.LongSet;
import net.openhft.koloboke.collect.set.hash.HashLongSets;

import java.net.*;
import java.util.*;
import java.util.stream.*;

/**
 * This class is a factory for creating {@link CanonicalIds}. This will reuse objects where possible. This is because
 * even though there may be millions of different objects that have a set of Ids, there often is  only be a small
 * number of unique combinations of product context ids. By pooling these objects we save <b>lots</b> of room.
 *
 */
public class CanonicalIdsFactory {
    private final CanonicalObjectCache<CacheKey, CanonicalIds> cache;

    public CanonicalIdsFactory() {
        cache = new CanonicalObjectCache<>(CanonicalIdsFactory.class, CacheKey::new);
    }

    /**
     * Get a reference to a CanonicalIds
     * @param uris null will be treated as an empty set
     * @return
     */
    public CanonicalIds create(Set<URI> uris) {
        List<Long> longIds = uris.stream().map(Muri::getObjectId).collect(Collectors.toList());
        return cache.getOrPopulateCache(
                (key) -> key.longIds = (longIds != null ? HashLongSets.newImmutableSet(longIds) : HashLongSets.newImmutableSet(new Long[]{})),
                (key) -> new CanonicalIds(key.longIds)
        );
    }

    /**
     * Get a reference to a CanonicalIds
     * @param longIds null will be treated as an empty set
     * @return
     */
    public CanonicalIds create(List<Long> longIds) {
        return cache.getOrPopulateCache(
                (key) -> key.longIds = (longIds!=null ? HashLongSets.newImmutableSet(longIds) : HashLongSets.newImmutableSet(new Long[]{})) ,
                (key) -> new CanonicalIds(key.longIds)
        );
    }

    private static final class CacheKey extends CanonicalObjectCache.CacheKey {

        private LongSet longIds;

        private CacheKey() {
        }

        private CacheKey(LongSet longIds) {
            this.longIds = longIds;
        }

        @Override
        protected CanonicalObjectCache.CacheKey duplicate() {
            return new CacheKey(this.longIds);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            CacheKey other = (CacheKey) o;

            return longIds.equals(other.longIds);

        }

        @Override
        public int hashCode() {
            return longIds.hashCode();
        }
    }

}

