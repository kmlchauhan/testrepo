package com.theplatform.web.tv.gws.sirius.repository;

import com.theplatform.web.tv.gws.service.common.aop.stats.CollectStats;
import com.theplatform.web.tv.gws.sirius.model.*;

import java.util.Date;
import java.util.List;
import java.util.Set;


public interface MerlinDAO {

    @CollectStats
    List<CRSLocation> retrieveLocations(List<Long> locationIds);

    @CollectStats
    List<CRSStation> retrieveStations(List<Long> stationUri);

    @CollectStats
    List<CRSStream> retrieveStreams(List<Long> streamIds, Set<String> allowedStreamStatus);

    @CollectStats
    List<CRSProductContext> retrieveProductContext(List<Long> productContextIds);

    @CollectStats
    List<CRSAvailabilityTag> retrieveAvailabilityTag(List<Long> availabilityTagIds);

    @CollectStats
    List<CRSListing> retrieveListings(List<Long> listingIds);

    @CollectStats
    List<CRSListing> retrieveListings(Long stationId, Date startTime, Date endTime);

}
