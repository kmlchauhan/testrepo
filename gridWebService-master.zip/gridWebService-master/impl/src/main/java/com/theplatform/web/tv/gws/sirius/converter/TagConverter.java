package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.IngestException;
import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.data.objects.TagType;
import com.theplatform.web.tv.gws.sirius.model.CRSTag;

import static com.theplatform.data.persistence.translator.converter.LocalUriConverter.convertUriToID;

/**
 * @author jcoelho
 * @since 6/9/15.
 */
public class TagConverter extends AbstractDataObjectConverter<Tag, CRSTag> {

    @Override
    public CRSTag convert(Tag tag) {

        if (tag.getType() != null) {
            if (tag.getId() == null){
                throw new IngestException("Id is null");
            }else{
                try{
                    return new CRSTag(convertUriToID(tag.getId()), tag.getTitle(), TagType.getByFriendlyName(tag.getType()));
                }catch(Throwable th){
                    th.getMessage();
                    throw new IngestException("Tag Type is not convertable");
                }

            }
        } else {
            throw new IngestException("Tag Type is null");
        }
    }

}
