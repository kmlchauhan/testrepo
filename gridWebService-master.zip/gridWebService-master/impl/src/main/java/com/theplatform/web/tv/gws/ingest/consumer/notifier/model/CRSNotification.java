package com.theplatform.web.tv.gws.ingest.consumer.notifier.model;

import com.comcast.merlin.sirius.ingest.Action;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import org.codehaus.jackson.annotate.JsonIgnore;

import java.util.UUID;

public abstract class CRSNotification {
    public static final String ATTRIBUTE_OBJECT_TYPE = "object_type";

    // Generated specifically each time a notification is generated.
    private String notificationId;

    private long id;
    private String method;
    private long timestamp;
    private String type;

    // Not in JSON
    private SiriusObjectType sourceSiriusObjectType;
    private Long sourceSequence;

    public CRSNotification(){}

    public CRSNotification(SiriusObjectType siriusObjectType, long id, Action action){
        notificationId = UUID.randomUUID().toString();
        this.id = id;
        type = siriusObjectType.getFriendlyName();
        method=action.name();
        timestamp=System.currentTimeMillis();
    }

    public final String getSourceId() {
        if (sourceSequence == null || sourceSiriusObjectType == null) {
            return null;
        } else {
            return sourceSiriusObjectType.getFriendlyName() + ":" + sourceSequence;
        }
    }

    public final long getTimestamp() {
        return timestamp;
    }

    public final String getNotificationId() {
        return notificationId;
    }

    public final String getType() {
        return type;
    }

    public final String getMethod() {
        return method;
    }

    public final  void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    public final  void setMethod(String method) {
        this.method = method;
    }

    public final  void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public final  void setType(String type) {
        this.type = type;
    }
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setSourceSiriusObjectType(SiriusObjectType sourceSiriusObjectType) {
        this.sourceSiriusObjectType = sourceSiriusObjectType;
    }

    public void setSourceSequence(Long sourceSequence) {
        this.sourceSequence = sourceSequence;
    }

    public void setSourceId(String sourceId) {
        if (sourceId == null) {
            sourceSequence = null;
            sourceSiriusObjectType = null;
        } else {
            String[] split = sourceId.split(":");
            if (split.length != 2) {
                throw new IllegalArgumentException("Invalid sourceId: " + sourceId);
            }

            sourceSiriusObjectType = SiriusObjectType.fromFriendlyName(split[0]);
            sourceSequence = Long.valueOf(split[1]);
        }
    }

    @JsonIgnore
    public SiriusObjectType getSourceSiriusObjectType() {
        return sourceSiriusObjectType;
    }

    @JsonIgnore
    public Long getSourceSequence() {
        return sourceSequence;
    }

    @JsonIgnore
    public SiriusObjectType getSiriusObjectType() {
        if (type==null) return  null;
        return SiriusObjectType.fromFriendlyName(type);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) return false;

        if (!getClass().isAssignableFrom(o.getClass())) return false;

        CRSNotification that = (CRSNotification) o;
        return notificationId.equals(that.getNotificationId());
    }

    @Override
    public int hashCode() {
        return notificationId.hashCode();
    }
}
