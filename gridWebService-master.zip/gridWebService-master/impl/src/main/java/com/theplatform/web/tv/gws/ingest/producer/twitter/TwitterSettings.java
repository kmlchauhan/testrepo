package com.theplatform.web.tv.gws.ingest.producer.twitter;


import org.apache.http.client.config.RequestConfig;

public class TwitterSettings {
    // general
    private boolean enabled;
    private int connectTimeoutMs = 10000;
    private int socketTimeoutMs = 10000;
    private String proxyHost;
    private Integer proxyPort;

    // auth stuff
    private String apiKey;
    private String apiSecret;
    private String tokenURL;

    // metrics
    private String metricsURL;
    private long refreshIntervalSeconds;
    private int topTrendThreshold;
    private int numberOfRankGroups;
    private int scoreCutoff;

    /**
     * Whether the ingester is enabled (defaults to false)
     * @return true if the ingester is enabled
     */
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * From the HTTP Components documentation: Determines the timeout in milliseconds until a
     * connection is established.  A timeout value of zero is interpreted as an infinite timeout.
     * <br><br>
     * Defaults to 10,000 milliseconds if not set.
     *
     * @see RequestConfig#getConnectTimeout()
     * @return a connection timeout in milliseconds, always greater than zero
     */
    public int getConnectTimeoutMs() {
        return connectTimeoutMs;
    }

    /**
     * Set the maximum time in milliseconds that the ingester will wait for an HTTP connection
     * to be established before throwing an exception.
     * @param connectTimeoutMs an integer greater than zero
     * @throws IllegalArgumentException if the connectTimeoutMs &lt;= 0
     */
    public void setConnectTimeoutMs(int connectTimeoutMs) {
        if (connectTimeoutMs <= 0) {
            throw new IllegalArgumentException("socketTimeoutMs must be greater than zero");
        }
        this.connectTimeoutMs = connectTimeoutMs;
    }


    /**
     * From the HTTP Components documentation:  Defines the socket timeout (<code>SO_TIMEOUT</code>)
     * in milliseconds, which is the timeout for waiting for data  or, put differently, a maximum
     * period inactivity between two consecutive data packets).
     * <br><br>
     * Defaults to 10,000 milliseconds if not set.
     *
     * @see RequestConfig#getSocketTimeout()
     * @return socket timeout in ms, always greater than zero
     */
    public int getSocketTimeoutMs() {
        return socketTimeoutMs;
    }

    /**
     * Set the maximum time in milliseconds that the ingester will wait for a socket connection
     * to be established before throwing an exception.
     * @param socketTimeoutMs an integer greater than zero
     * @throws IllegalArgumentException if the socketTimeoutMs &lt;= 0
     */
    public void setSocketTimeoutMs(int socketTimeoutMs) {
        if (socketTimeoutMs <= 0) {
            throw new IllegalArgumentException("socketTimeoutMs must be greater than zero");
        }
        this.socketTimeoutMs = socketTimeoutMs;
    }

    /**
     * API key which in conjunction with the {@link #getApiSecret() apiSecret} is used to retrieve
     * a "Bearer" token.
     * @return a longish alphanumeric string
     */
    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    /**
     * API secret which in conjunction with the {@link #getApiKey() apiKey} is used to retrieve
     * a "Bearer" token.
     * @return a longish alphanumeric string
     */
    public String getApiSecret() {
        return apiSecret;
    }

    public void setApiSecret(String apiSecret) {
        this.apiSecret = apiSecret;
    }

    /**
     * URL used to exchange API keys for a "Bearer" token.
     * @return an HTTP URL
     */
    public String getTokenURL() {
        return tokenURL;
    }

    public void setTokenURL(String tokenURL) {
        this.tokenURL = tokenURL;
    }

    /**
     * The full URL to the Twitter TV API
     * @return an HTTP URL
     */
    public String getMetricsURL() {
        return metricsURL;
    }

    public void setMetricsURL(String metricsURL) {
        this.metricsURL = metricsURL;
    }

    /**
     * Twitter polling interval, measured from the completion of one request to the start of the next request.
     * @return the polling interval (in seconds)
     */
    public long getRefreshIntervalSeconds() {
        return refreshIntervalSeconds;
    }

    public void setRefreshIntervalSeconds(long refreshIntervalSeconds) {
        this.refreshIntervalSeconds = refreshIntervalSeconds;
    }

    /**
     * Threshold (in terms of number of tweets) for a program to be considered "top trending"
     * @return non-zero integer
     */
    public int getTopTrendThreshold() {
        return topTrendThreshold;
    }

    public void setTopTrendThreshold(int topTrendThreshold) {
        this.topTrendThreshold = topTrendThreshold;
    }

    /**
     * The ingester divides programs into groups by tweet count percentile.
     * @return the number of groups used
     */
    public int getNumberOfRankGroups() {
        return numberOfRankGroups;
    }

    public void setNumberOfRankGroups(int numberOfRankGroups) {
        this.numberOfRankGroups = numberOfRankGroups;
    }

    /**
     * The ingester will ignore programs with a tweet count/score below this number.
     * @return minimum tweet count for a program retrieved from Twitter to be stored in Sirius.
     */
    public int getScoreCutoff() {
        return scoreCutoff;
    }

    public void setScoreCutoff(int scoreCutoff) {
        this.scoreCutoff = scoreCutoff;
    }

    public String getProxyHost() {
        return proxyHost;
    }

    public void setProxyHost(String proxyHost) {
        this.proxyHost = proxyHost;
    }

    public Integer getProxyPort() {
        return proxyPort;
    }

    public void setProxyPort(Integer proxyPort) {
        this.proxyPort = proxyPort;
    }
}
