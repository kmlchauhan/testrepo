package com.theplatform.web.tv.gws.service.common.aop.validation;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.web.tv.gws.service.common.logic.Scope;
import com.theplatform.web.tv.gws.service.common.logic.ScopedAvailabilities;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class ResolveChannelsValidationAspect extends ContentResolutionValidationAspect{

    @Before(
        "(" +
            "within(com.theplatform.web.tv.gws.service..*) " +
         ") && " +
        "@annotation(com.theplatform.web.tv.contentresolution.api.annotation.ResolveChannelsValidation)" +
        " && args(availabilityResolution,..)")
    public void validateRequest(AvailabilityResolution availabilityResolution) throws Throwable {
        ScopedAvailabilities scopedAvailabilities = ScopedAvailabilities.create(availabilityResolution);
        super.validateRequest(scopedAvailabilities);
        validateAvailabilitiesGroupHasScopes(scopedAvailabilities, Scope.STATION);
    }

}

