package com.theplatform.web.tv.gws.ingest.consumer.notifier.model;


import com.comcast.merlin.sirius.ingest.Action;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.tv.linear.api.data.objects.Listing;
import com.theplatform.web.tv.gws.sirius.model.CRSListing;
import com.theplatform.web.tv.gws.sirius.repository.ListingRepository;
import org.springframework.beans.factory.annotation.Required;

import java.util.Collections;
import java.util.List;

public class ListingNotificationConverter implements NotificationConverter<CRSListing, NotificationListing>{

    private ListingRepository listingRepository;

    @Override
    public List<NotificationListing> convert(long id, CRSListing crsListing, Action action, Long sequence) {
        NotificationListing notificationListing = new NotificationListing(action, id);

        notificationListing.setSourceSiriusObjectType(SiriusObjectType.fromDataServiceObjectClass(Listing.class));
        notificationListing.setSourceSequence(sequence);

        if (action.equals(Action.PUT)) {
            notificationListing.setStartTime(crsListing.getStartTime());
        }else{
            // Best effort attempt to determine the old startTime
            CRSListing oldCrsListing = listingRepository.get(id);
            if (oldCrsListing != null){
                notificationListing.setStartTime(oldCrsListing.getStartTime());
            }
        }
        return Collections.singletonList(notificationListing);
    }

    @Required
    public void setListingRepository(ListingRepository listingRepository) {
        this.listingRepository = listingRepository;
    }

}
