package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.linear.api.data.objects.Company;
import com.theplatform.web.tv.gws.sirius.model.CRSCompany;

public class CompanyConverter extends AbstractDataObjectConverter<Company, CRSCompany> {
    @Override
    public CRSCompany convert(Company dataObject) {
        CRSCompany crsCompany = new CRSCompany();

        crsCompany.setId(LocalUriConverter.convertUriToID(dataObject.getId()));
        crsCompany.setDisplayName(dataObject.getDisplayName());
        crsCompany.setTitle(dataObject.getTitle());
        return crsCompany;
    }
}
