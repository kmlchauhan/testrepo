package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSTag;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;

import java.util.Map;

/**
 * @author jcoelho
 * @since 6/8/15.
 */
public class TagRepository extends LongObjectRepository<CRSTag> {

    private Map<String, ObjectOpenHashSet<CRSTag>> tagTitleIndex = new Object2ObjectOpenHashMap<>();

    public TagRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    protected void addToIndexes(CRSTag crsTag) {
        String title = crsTag.getTitle();
        ObjectOpenHashSet crsTags = tagTitleIndex.get(title);
        if (crsTags == null)
            crsTags = new ObjectOpenHashSet();
        crsTags.add(crsTag);
        tagTitleIndex.put(title, crsTags);
    }

    @Override
    protected void removeFromIndexes(CRSTag crsTag) {
        ObjectOpenHashSet<CRSTag> crsTags = tagTitleIndex.get(crsTag.getTitle());
        if (crsTags != null)
            crsTags.remove(crsTag);

    }

    public CRSTag[] getCRSTTagsByTitle(String title) {
        ObjectOpenHashSet<CRSTag> crsTags = tagTitleIndex.get(title);
        if (crsTags != null)
            return crsTags.toArray(new CRSTag[crsTags.size()]);
        return null;
    }
}
