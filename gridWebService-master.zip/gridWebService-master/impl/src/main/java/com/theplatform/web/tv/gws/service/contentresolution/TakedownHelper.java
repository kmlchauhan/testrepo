package com.theplatform.web.tv.gws.service.contentresolution;

import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.LocatorInfo;
import com.theplatform.web.tv.contentresolution.api.objects.ProductContextInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;
import com.theplatform.web.tv.gws.sirius.model.CRSChannel;
import com.theplatform.web.tv.gws.sirius.model.CRSStation;
import com.theplatform.web.tv.gws.sirius.model.CRSStationTakedown;
import com.theplatform.web.tv.gws.sirius.repository.ChannelRepository;
import com.theplatform.web.tv.gws.sirius.repository.StationTakedownRepository;
import com.theplatform.web.tv.gws.service.common.converter.CRSStationToStationInfoConverter;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class TakedownHelper {
    private static Logger logger = LoggerFactory.getLogger(TakedownHelper.class);

    private ChannelRepository channelRepository;
    private LongObjectRepository<CRSStation> stationRepository;
    private StationTakedownRepository stationTakedownRepository;

    private CRSStationToStationInfoConverter crsStationToStationInfoConverter;
    private MerlinIdHelper merlinIdHelper;


    /**
     * @return
     */
    public List<ChannelInfo> takedownBlacklistedStations( long ownerId, List<ChannelInfo> originalChannelInfos){
        if (!shouldWeCheck(ownerId)){
            return originalChannelInfos;
        }

        List<ChannelInfo> updatedChannelInfos = new ArrayList<>(originalChannelInfos.size());
        for (ChannelInfo channelInfo : originalChannelInfos){
            CRSStationTakedown crsStationTakedown = getStationTakedown( ownerId, channelInfo);
            if (crsStationTakedown != null){
                ChannelInfo updatedChannelInfo = updateChannelInfo(channelInfo, crsStationTakedown.getPlaceholderStationId());
                if (updatedChannelInfo!=null){
                    updatedChannelInfos.add(updatedChannelInfo);
                } else {
                    logger.debug("Dropping no-programming channel: " + channelInfo.getChannelId());
                }
            }else{
                updatedChannelInfos.add(channelInfo);
            }

        }
        return updatedChannelInfos;
    }

    // Should we even bother checking (perf)?
    private boolean shouldWeCheck(long ownerId){
        if (stationTakedownRepository.getOwnersStationTakedown(ownerId)==null || stationTakedownRepository.getOwnersStationTakedown(ownerId).size()==0){
            return false;
        }
        for( CRSStationTakedown crsStationTakedown : stationTakedownRepository.getOwnersStationTakedown(ownerId)){
            if ( System.currentTimeMillis()>crsStationTakedown.getExpirationDate()){
                return true;
            }
        }
        return false;
    }

    /**
     *  Get CRSStationTakedown for a given Owner, Channel
     *
     */
    private CRSStationTakedown getStationTakedown( long ownerId, ChannelInfo channelInfo){
        long stationId = channelInfo.getStationInfo().getStationId().getId();


        Collection<CRSStationTakedown> crsStationTakedowns = stationTakedownRepository.getStationTakedown(ownerId, stationId);
        if (crsStationTakedowns==null) return null;

        CRSStationTakedown crsStationTakedown = null;
        for (CRSStationTakedown entry : crsStationTakedowns ){
            if (entry.getLocationId()==0 && System.currentTimeMillis()>entry.getExpirationDate()){
                crsStationTakedown=deterministicallyChoose(crsStationTakedown,entry);
            } else {
                CRSChannel crsChannel = channelRepository.get(channelInfo.getChannelId().getId());
                if (crsChannel==null) continue;             // Ok, not likely but could happen
                if (entry.getLocationId()==crsChannel.getLocationId() && System.currentTimeMillis()>entry.getExpirationDate() ){
                    crsStationTakedown=deterministicallyChoose(crsStationTakedown,entry);
                }
            }
        }
        return crsStationTakedown;
    }

    /**
     * Given two CRSStationTakedown pick the one that takes precedence.  One of the two values can be null.
     *
     * Order Of Precedence:
     * 1) The CRSStationTakedown with a LocationId takes precedence if the other doesn't
     * 2) Otherwise the one with the lowest CRSStationTakedown Id takes precedence.
     *
     * @param first A matching CRSStationTakedown or null
     * @param second A matching CRSStationTakedown or null
     * @return
     */
    private CRSStationTakedown deterministicallyChoose( CRSStationTakedown first, CRSStationTakedown second){
        if (first==null){
            return second;
        } else if (second==null){
            return first;
        } else {
            if (first.getLocationId()!=0 && second.getLocationId()!=0) {
                // Both have the stationId and locationId.  Take lowest Id
                if (first.getId()<second.getId()){
                    return first;
                } else {
                    return second;
                }
            } else if (first.getLocationId()!=0){
                return first;
            } else if (second.getLocationId()!=0){
                return second;
            } else{
                // Both have the stationId. Take lowest Id
                if (first.getId()<second.getId()){
                    return first;
                } else {
                    return second;
                }
            }
        }

    }

    /**
     * 1) Swap in the placeholder station
     * 2) Strip out all PC that are not of Type TitleVI
     * 3) Strip out all the QAM Locators
     *
     * @param channelInfo   Channel to be updated
     * @param placeholderStationId Station to swap in to the channel
     * @return
     */
    private ChannelInfo updateChannelInfo(ChannelInfo channelInfo, long placeholderStationId){
        CRSStation crsPlaceholderStation = stationRepository.get(placeholderStationId);
        if (crsPlaceholderStation==null){
            logger.error("Attempting to use no programming station.  Unable to find no prog station specified in config: " + placeholderStationId);
            return channelInfo;
        }

        // Create the base
        StationInfo placeholderStationInfo = crsStationToStationInfoConverter.convert(crsPlaceholderStation, merlinIdHelper, null);

        // 1) Add all TitleVI PCs from the original to the non-prog
        List<ProductContextInfo> newProductContextInfos = new ArrayList<>();
        placeholderStationInfo.setProductContextList(newProductContextInfos);
        for (ProductContextInfo productContextInfo : channelInfo.getStationInfo().getProductContextList()){
            if(productContextInfo.getType().equalsIgnoreCase("TitleVI")){
                newProductContextInfos.add(productContextInfo);
            }
        }
        // No, PCs (i.e. All were TitleVI) drop the channel
        if (placeholderStationInfo.getProductContextList().size()==0) return null;

        // 2) Remove all non-QAM Locators
        List<LocatorInfo> locatorInfos = channelInfo.getLocators();
        if (locatorInfos!=null) {     // Backend service channels wont have stream info
            Iterator<LocatorInfo> locatorInfoIterator = locatorInfos.iterator();
            while(locatorInfoIterator.hasNext()){
                LocatorInfo locatorInfo = locatorInfoIterator.next();
                if (!locatorInfo.getFormat().equalsIgnoreCase("QAM")) {
                    locatorInfoIterator.remove();
                }
            }
        }

        // Add in the placeholderStationInfo
        channelInfo.setStationInfo(placeholderStationInfo);

        return channelInfo;
    }


    @Required
    public void setStationRepository(LongObjectRepository<CRSStation> stationRepository) {
        this.stationRepository = stationRepository;
    }

    @Required
    public void setCrsStationToStationInfoConverter(CRSStationToStationInfoConverter crsStationToStationInfoConverter) {
        this.crsStationToStationInfoConverter = crsStationToStationInfoConverter;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }

    @Required
    public void setStationTakedownRepository(StationTakedownRepository stationTakedownRepository) {
        this.stationTakedownRepository = stationTakedownRepository;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }
}
