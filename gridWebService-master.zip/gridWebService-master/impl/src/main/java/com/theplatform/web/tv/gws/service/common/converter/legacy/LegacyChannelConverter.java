package com.theplatform.web.tv.gws.service.common.converter.legacy;

import com.theplatform.data.tv.offer.api.data.objects.ProductContextType;
import com.theplatform.web.tv.contentresolution.api.debug.CauseType;
import com.theplatform.web.tv.contentresolution.api.debug.WarningItem;
import com.theplatform.web.tv.contentresolution.api.debug.WarningType;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import com.theplatform.web.tv.gws.service.common.debug.DebugHelper;
import org.springframework.beans.factory.annotation.Required;

import java.util.Iterator;

/**
 *  Used to convert from the 'new data model' (1.21+) to the earlier data model (<1.21)
 *
 */
public class LegacyChannelConverter {

    private LegacyLocatorToStreamConverter legacyLocatorToStreamConverter;
    private DebugHelper debugHelper;

    public void convert(Grid grid) {
        convert(grid.getChannels().iterator());
        debugHelper.applyWarnings(grid);
    }

    public void convert(ChannelInfoCollection channelInfoCollection){
        convert(channelInfoCollection.getChannels().iterator());
        debugHelper.applyWarnings(channelInfoCollection);
    }

    private void convert(Iterator<ChannelInfo> channelInfoIterator) {
        while (channelInfoIterator.hasNext()){
            ChannelInfo channelInfo = channelInfoIterator.next();
            StreamInfo legacyStreamInfo = legacyLocatorToStreamConverter.convertIpAndNonIpLocators( channelInfo);

            // No Stream Check
            if (legacyStreamInfo==null){
                debugHelper.logResponseWarning(WarningType.ChannelDropped, CauseType.NoStreamCA,
                        WarningItem.instance().setStationId(channelInfo.getStationInfo().getStationId() )
                                .setChannelId(channelInfo.getChannelId()));
                channelInfoIterator.remove();
                continue;
            }

            // Default Stream Check - Remove any non-TitleVI
            //  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            //  Suffix Check - Any channel over number with a suffix of 900 is a Synthetic O&O Channel. They should NOT
            //  be subject to the 'default stream PC dropping logic'.  Skip over this.
            //  See also TveSyntheticChannelHelper
            //  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            if (legacyStreamInfo.getIsDefault() && channelInfo.getChannelId().getId()%1000 != 900){
                defaultStreamStripNonTitleVi(channelInfo);
            }

            // Drop the channel if all PC were stripped.
            if (channelInfo.getProductContexts().size()==0){
                debugHelper.logResponseWarning(WarningType.ChannelDropped, CauseType.NoProductContext,
                        WarningItem.instance().setStationId(channelInfo.getStationInfo().getStationId() )
                                .setChannelId(channelInfo.getChannelId()));
                channelInfoIterator.remove();
                continue;
            }

            // Strip out new data model's locators
            channelInfo.setLocators(null);

            // Apply legacy stream
            channelInfo.getStationInfo().setStream(legacyStreamInfo);

        }
    }

    /**
     * For channels using default streams, strip out any non-TitleVI PC
     */
    private void defaultStreamStripNonTitleVi(ChannelInfo channelInfo){

        Iterator<ProductContextInfo> productContextInfoIterator = channelInfo.getProductContexts().iterator();
        while (productContextInfoIterator.hasNext()) {
            ProductContextInfo productContextInfo = productContextInfoIterator.next();
            if (!productContextInfo.getType().equals(ProductContextType.TitleVI.toString())) {
                productContextInfoIterator.remove();
                debugHelper.logResponseWarning(WarningType.ProductContextDropped, CauseType.DefaultStream,
                        WarningItem.instance()
                                .addProductContextId(productContextInfo.getId())
                                .setStationId(channelInfo.getStationInfo().getStationId())
                                .setChannelId(channelInfo.getChannelId())
                );

            }
        }
    }


    @Required
    public void setLegacyLocatorToStreamConverter(LegacyLocatorToStreamConverter legacyLocatorToStreamConverter) {
        this.legacyLocatorToStreamConverter = legacyLocatorToStreamConverter;
    }

    @Required
    public void setDebugHelper(DebugHelper debugHelper) {
        this.debugHelper = debugHelper;
    }



}
