package com.theplatform.web.tv.gws.sirius.repository.utils;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Multimap;

/**
 * Utility methods for Sirius Repository classes, particularly
 * for managing secondary indices.
 *
 */
public class SiriusDataUtils {

    /**
     * Check that a Long is not null and greater than zero.
     *
     * @param value {@link Long}
     * @return boolean
     */
    public static boolean hasValue(Long value) {
        return value != null && value.longValue() > 0;
    }

    /**
     * Check that String is not blank.
     *
     * @param value {@link String}
     * @return boolean
     */
    public static boolean hasValue(String value) {
        return StringUtils.isNotBlank(value);
    }

    /**
     * Check that a object is not null, greater than zero (if Long) and
     * not blank (if String).
     *
     * @param value {@link Object}
     * @return boolean true if the object has a value
     */
    public static boolean hasValue(Object value) {

        if (value instanceof Long) {
            return SiriusDataUtils.hasValue((Long)value);
        }

        if (value instanceof String) {
            return SiriusDataUtils.hasValue((String)value);
        }

        return value != null;
    }

    /**
     * Removes existing data for key/value, then adds it back.
     *
     * This is necessary because:
     *   a) SetMultimaps will not overwrite an existing key/value entry
     *   b) We may override equals in a way such that objects which are different
     *      will still be equal (yep...)
     *
     * @param <K> key type
     * @param <V> value type
     * @param key key value
     * @param value value
     * @param multimap multimap to which the value will be added
     */
    public static <K, V> void addOrReplace(K key, V value, Multimap<K, V> multimap) {
        multimap.remove(key, value);
        multimap.put(key, value);
    }
}
