package com.theplatform.web.tv.gws.service.common.field.nullification.operations;

import java.util.Collection;

/**
 * Apply a Collection of PropertyOperations to a value.
 */
public class ApplyOperations implements PropertyOperation {

    protected final PropertyOperation[] operations;

    public ApplyOperations(Collection<PropertyOperation> operations) {
        this.operations = new PropertyOperation[operations.size()];
        operations.toArray(this.operations);
    }

    @Override
    public void apply(Object target) {
        for (PropertyOperation child : this.operations) {
            child.apply(target);
        }
    }
}
