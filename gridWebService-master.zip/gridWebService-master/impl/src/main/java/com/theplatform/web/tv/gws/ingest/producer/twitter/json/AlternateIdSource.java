package com.theplatform.web.tv.gws.ingest.producer.twitter.json;


import com.theplatform.data.tv.id.api.data.objects.MerlinSource;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Twitter includes multiple "alternate id sources" in the JSON response.  This class
 * bridges the Twitter-specific provider names with Merlin friendly provider names.
 */
public class AlternateIdSource {

    private static Set<AlternateIdSource> instances = new LinkedHashSet<>();


    private String jsonName;
    private String merlinProviderName;

    /**
     *  Set a collection of JSON Name to Merlin Provider Name Mappings
     */
    public static void init(String twitterSettings){
        String tokens[] = twitterSettings.split(",");
        if ( tokens.length % 2 != 0 ){
            throw new RuntimeException("The JsonProviderMappings propert should provide an even list of values.  Provide a comma delimited list of JSON Name to Merlin Provider Name Mappings.  e.g. Rovi1.1,TVGUIDE,Tms,TMS");
        }

        // Register the JSON Name to Merlin Provider Name Mapping
        for ( int i=0; i<tokens.length; i=i+2){
            register( tokens[i], tokens[i+1]);
        }
    }

    public static AlternateIdSource register(String jsonName, String merlinProviderName){
        AlternateIdSource alternateIdSource = new AlternateIdSource(jsonName, merlinProviderName);
        instances.add(alternateIdSource);
        return alternateIdSource;
    }

    private AlternateIdSource(String jsonName, String merlinProviderName) {
        this.jsonName  = jsonName;
        this.merlinProviderName = merlinProviderName;
    }

    /**
     * The name of the provider/AlternateIdSource as it appears in the JSON.  For example, "Rovi1.1".
     * @return String that appears in the JSON
     */
    public String getJsonName() {
        return jsonName;
    }

    /**
     * Internal Comcast name for the provider.  For example, "TVGUIDE".
     * @see MerlinSource#getProviderName()
     * @return String that corresponds to a MerlinSource providerName.
     */
    public String getMerlinSourceProviderName() {
        return merlinProviderName;
    }

    // Ordered
    public static Collection<AlternateIdSource> values(){
        return instances;
    }

    @Override
    public boolean equals(Object other){
        if (!(other instanceof AlternateIdSource))return false;
        return ( this.getJsonName().equals(((AlternateIdSource) other).getJsonName())
                && this.merlinProviderName.equals( ((AlternateIdSource) other).merlinProviderName));

    }

    @Override
    public int hashCode(){
        return jsonName.hashCode() * 3 + merlinProviderName.hashCode() * 7;
    }

}
