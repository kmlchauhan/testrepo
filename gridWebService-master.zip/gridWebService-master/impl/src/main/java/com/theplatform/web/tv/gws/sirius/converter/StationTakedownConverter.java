package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.linear.api.data.objects.StationTakedown;
import com.theplatform.web.tv.gws.sirius.model.CRSStationTakedown;

public class StationTakedownConverter extends AbstractDataObjectConverter<StationTakedown, CRSStationTakedown> {

    @Override
    public CRSStationTakedown convert(StationTakedown stationTakedown) {
        CRSStationTakedown crsStationTakedown = new CRSStationTakedown();
        crsStationTakedown.setId(LocalUriConverter.convertUriToID(stationTakedown.getId()));
        crsStationTakedown.setOwnerId(LocalUriConverter.convertUriToID(stationTakedown.getOwnerId()));
        crsStationTakedown.setExpirationDate(stationTakedown.getExpirationDate().getTime());
        crsStationTakedown.setStationId(Muri.getObjectId(stationTakedown.getStationId()));
        crsStationTakedown.setPlaceholderStationId(Muri.getObjectId(stationTakedown.getPlaceholderStationId()));
        if (stationTakedown.getLocationId()!=null){
            crsStationTakedown.setLocationId(Muri.getObjectId(stationTakedown.getLocationId()));
        }
        return crsStationTakedown;
    }

}
