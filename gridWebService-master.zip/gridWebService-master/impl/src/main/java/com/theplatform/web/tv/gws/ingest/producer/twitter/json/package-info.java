/**
 * Twitter JSON parser and document objects
 */
package com.theplatform.web.tv.gws.ingest.producer.twitter.json;