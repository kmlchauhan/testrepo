package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.data.tv.linear.api.data.objects.LocatorType;
import com.theplatform.web.tv.gws.sirius.model.CRSLocator;
import com.theplatform.web.tv.gws.sirius.repository.utils.JdkCollectionsCompositeKeySecondaryIndex;

import java.util.*;
import java.util.stream.*;

public class LocatorRepository extends LongObjectRepository<CRSLocator> {
    @Deprecated /* Only used by the old Stream Logic */
    private JdkCollectionsCompositeKeySecondaryIndex<Long,Long,CRSLocator> ipLocatorIndex;          // ownerId, streamId - (1-n) -> CRSLocator
    private JdkCollectionsCompositeKeySecondaryIndex<Long,Long,CRSLocator> onDemandLocatorIndex;    // ownerId, stationId - (1-n) -> CRSLocator

    public LocatorRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
        ipLocatorIndex = new JdkCollectionsCompositeKeySecondaryIndex<>();
        onDemandLocatorIndex = new JdkCollectionsCompositeKeySecondaryIndex<>();

    }

    private void addToIndex(JdkCollectionsCompositeKeySecondaryIndex<Long,Long,CRSLocator> index, Long ownerId, Long secondaryKey, CRSLocator crsLocator) {
        // internally builds a JdkCollectionsCompositeKeySecondaryIndex.CompositeKey instance.  unfortunately the
        // equals/hashCode methods of CompositeKey are NOT null safe
        if (ownerId == null || secondaryKey == null) {
            return;
        }

        index.put(ownerId, secondaryKey, crsLocator);
    }

    @Override
    public void addToIndexes(CRSLocator crsLocator) {
        if (LocatorType.LinearStream.name().equals(crsLocator.getType())) {  // AKA IP
            addToIndex(ipLocatorIndex, crsLocator.getOwnerId(), crsLocator.getStreamId(), crsLocator);
        }
        else if (LocatorType.OnDemand.name().equals(crsLocator.getType())) {
            addToIndex(onDemandLocatorIndex, crsLocator.getOwnerId(), crsLocator.getStationId(), crsLocator);
        }
    }

    private void removeFromIndex(JdkCollectionsCompositeKeySecondaryIndex<Long,Long,CRSLocator> index, Long ownerId, Long secondaryKey, CRSLocator crsLocator) {
        if (ownerId == null || secondaryKey == null) {
            return;
        }
        index.remove(ownerId, secondaryKey, crsLocator);
    }

    @Override
    public void removeFromIndexes(CRSLocator crsLocator) {
        if (LocatorType.LinearStream.name().equals(crsLocator.getType())) {  // AKA IP
            removeFromIndex(ipLocatorIndex, crsLocator.getOwnerId(), crsLocator.getStreamId(), crsLocator);
        }
        else if (LocatorType.OnDemand.name().equals(crsLocator.getType())) {
            removeFromIndex(onDemandLocatorIndex, crsLocator.getOwnerId(), crsLocator.getStationId(), crsLocator);
        }
    }

    private Set<CRSLocator> readSecondaryIndex(JdkCollectionsCompositeKeySecondaryIndex<Long,Long,CRSLocator> index, Long ownerId, Long secondaryKey) {

        if (ownerId == null || secondaryKey == null) {
            return null;
        }

        Set<CRSLocator> locators;
        long readStamp = super.lock.readLock();
        try {
            locators = index.getByIndexKey(ownerId, secondaryKey);
        }
        finally {
            super.lock.unlockRead(readStamp);
        }
        return locators;
    }

    /**
     * Get the IP Locator from Stream.  Note: we always use the Stream's Owner ID
     */
    @Deprecated    /* Only used by the old Stream Logic */
    public Set<CRSLocator> getIPLocators( Long ownerId, Long streamId) {
        return readSecondaryIndex(this.ipLocatorIndex, ownerId, streamId);
    }

    public Set<CRSLocator> getOnDemandLocators( Long ownerId, Long stationId) {
        return readSecondaryIndex(this.onDemandLocatorIndex, ownerId, stationId);
    }

}
