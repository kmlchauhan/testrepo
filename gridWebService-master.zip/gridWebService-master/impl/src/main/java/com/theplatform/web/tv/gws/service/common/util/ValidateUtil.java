package com.theplatform.web.tv.gws.service.common.util;

import com.theplatform.module.exception.BadParameterException;

import java.util.Date;

public class ValidateUtil {
    static public void notNull(Object o, String objectName) {
        if (o == null)
            throw new BadParameterException(objectName + " is required");
    }

    static public void notNull(long o, String objectName) {
        if (o == 0)
            throw new BadParameterException(objectName + " is required");
    }

    static public void validateDates(Date start, Date end) {
        if (start==null || end==null)return;

        if (start.getTime()>end.getTime()){
            throw new BadParameterException("Requested start and end dates conflict.  End date (" + end.getTime() +") occurs before start date (" + start.getTime() + ")");
        }

    }


}
