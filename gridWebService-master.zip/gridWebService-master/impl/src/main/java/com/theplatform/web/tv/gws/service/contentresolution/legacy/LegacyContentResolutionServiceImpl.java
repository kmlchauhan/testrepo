package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import org.springframework.aop.framework.Advised;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.annotation.Required;

import com.theplatform.contrib.web.service.BaseWebServiceImpl;

public class LegacyContentResolutionServiceImpl<T> extends BaseWebServiceImpl {

    protected T contentResolutionService;
    
    @SuppressWarnings("unchecked")
    @Required
    public void setContentResolutionService(Object contentResolutionService) {
        this.contentResolutionService = (T) this.getTargetObject(contentResolutionService);
    }

    private Object getTargetObject(Object proxy) {
        try {
            if(AopUtils.isJdkDynamicProxy(proxy)) {
                return getTargetObject(((Advised)proxy).getTargetSource().getTarget());
            }
        } catch (Exception e) {
            throw new RuntimeException("Error looking for proxy target", e);
        }
        return proxy; // expected to be cglib proxy then, which is simply a specialized class
    }
}
