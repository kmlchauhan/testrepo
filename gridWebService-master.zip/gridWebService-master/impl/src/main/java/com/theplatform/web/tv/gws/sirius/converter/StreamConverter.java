package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.linear.api.data.objects.Stream;
import com.theplatform.web.tv.gws.sirius.model.CRSStream;

public class StreamConverter extends AbstractDataObjectConverter<Stream, CRSStream> {

    @Override
    public CRSStream convert(Stream stream) {

        CRSStream crsStream = new CRSStream();
        crsStream.setId(LocalUriConverter.convertUriToID(stream.getId()));
        crsStream.setStationId(Muri.getObjectId(stream.getStationId()));
        crsStream.setOwnerId(Muri.getObjectId(stream.getOwnerId()));
        if (stream.getIsDefault()==null){
            crsStream.setIsDefault(false);
        }else{
            crsStream.setIsDefault(stream.getIsDefault());
        }
        crsStream.setStatus(stream.getStatus());
        crsStream.setExternal(stream.getExternal());
        crsStream.setTitle(stream.getTitle());
        if (stream.getIsDai()==null){
            crsStream.setIsDai(false);
        }else{
            crsStream.setIsDai(stream.getIsDai());
        }
        crsStream.setPreferredRMType(stream.getPreferredRMType());
        crsStream.setServiceZoneType(stream.getServiceZoneType());
        crsStream.setTravelRights(stream.getTravelRights());
        crsStream.setType(stream.getType());

        return crsStream;
    }

}
