package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.web.api.annotation.WebServiceVersion;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfoCollection;
import com.theplatform.web.tv.contentresolution.api.objects.Grid;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.contentresolution.api.objects.TrendingPrograms;

import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.Date;
import java.util.List;


@WebServiceVersion("1.19")
@WebService(name = "contentResolution", targetNamespace = "http://xml.theplatform.com/tv/web/AvailabilityResolution")
public interface ContentResolutionService_1_19 {

    /**
     * Returns a list of Channel infos
     *
     *
     * @param availabilityResolution
     * @param mainImageTypeGroup
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     * @param byStreamStatus Or query with status separated by pipes "|" (e.g: "Production|Staging")
     *
     * @return
     * @throws GridException
     */
    ChannelInfoCollection resolveChannels(
            @WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
            @WebParam(name = "mainImageTypeGroup") Muri mainImageTypeGroup,
            @WebParam(name = "fields") String fields,
            @WebParam(name = "byStreamStatus") String byStreamStatus,
            @WebParam(name = "filterAdult") Boolean filterAdult) throws GridException;


    /**
     * Return the channels for a stream scoped to the provided availabilities.
     * @param availabilityResolution
     * @param streamId
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     * @return
     */
    ChannelInfoCollection resolveChannelsByStreamId(
            @WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
            @WebParam(name = "streamId") Long streamId,
            @WebParam(name = "fields") String fields,
            @WebParam(name = "filterAdult") Boolean filterAdult) throws GridException;

    /**
     * returns a grid object including a header, channels, and listing
     *
     * If only a subset of the channels are desired, rowStart and rowEnd can be
     * used to "paginate" the grid.
     *
     * @param availabilityResolution
     *            the availability resolution retrieved from the availability resolution service
     * @param mainImageTypeGroup
     *            ???
     * @param numGridUnits
     *            an Integer for number of grid units
     * @param gridUnitWidth
     *            an Integer for the width of the grid unit
     * @param offset
     *            an Integer representing the offset
     * @param timeZone
     *            a String containing the timezone
     * @param categories
     *            A String[] containing program categories
     * @param companyIds
     *            a Long[] containing the company ids
     * @param stationTagIds
     *            a Long[] containing the stationTagIds
     * @param locatorFormats
     *            a String[] containing locator formats
     * @param hd
     *            a Boolean representing high def
     * @param rowStart
     *            starting index of grid rows to return. Defaults to 1.
     * @param rowEnd
     *            ending index of grid rows to return. Default is unbounded
     *            (null).
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     *
     * @return the grid
     * @throws GridException
     *             general grid exception
     */
    Grid getGrid(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                 @WebParam(name = "mainImageTypeGroup") Muri mainImageTypeGroup,
                 @WebParam(name = "numGridUnits") Integer numGridUnits,
                 @WebParam(name = "gridUnitWidth") Integer gridUnitWidth, @WebParam(name = "offset") Integer offset,
                 @WebParam(name = "timeZone") String timeZone, @WebParam(name = "categories") String[] categories,
                 @WebParam(name = "companyIds") Long[] companyIds, @WebParam(name = "stationTagIds") Long[] stationTagIds,
                 @WebParam(name = "locatorFormats") String[] locatorFormats, @WebParam(name = "hd") Boolean hd,
                 @WebParam(name = "rowStart") Integer rowStart, @WebParam(name = "rowEnd") Integer rowEnd,
                 @WebParam(name = "programTagIds") Long[] programTagIds,
                 @WebParam(name = "fields") String fields)
            throws GridException;

    /**
     * Returns a grid object including a header, channels, and listing. This API
     * assumes the time range specified by startDate and endDate specifies a
     * whole number of grid units. This API is designed to enable cache warming.
     * The client should favor sending in a grid model over this API.
     *
     * If only a subset of the channels are desired, rowStart and rowEnd can be
     * used to "paginate" the grid.
     *
     * @param availabilityResolution
     *            the availability resolution retrieved from the availability resolution service
     * @param mainImageTypeGroup
     *            ???
     * @param startTime
     *            a Date
     * @param numGridUnits
     *            an Integer
     * @param gridUnitWidth
     *            an Integer
     * @param timeZone
     *            ???
     * @param categories
     *            A String[] containing program categories
     * @param companyIds
     *            a Long[] containing the company ids
     * @param stationTagIds
     *            a Long[] containing the stationTagIds
     * @param locatorFormats
     *            a String[] containing locator formats
     * @param hd
     *            a Boolean representing high def
     * @param rowStart
     *            starting index of grid rows to return. Defaults to 1.
     * @param rowEnd
     *            ending index of grid rows to return. Default is unbounded
     *            (null).
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     *
     * @return the grid
     * @throws GridException
     *             general grid exception
     */
    Grid getGridByDate(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                       @WebParam(name = "mainImageTypeGroup") Muri mainImageTypeGroup,
                       @WebParam(name = "startTime") Date startTime,
                       @WebParam(name = "numGridUnits") Integer numGridUnits,
                       @WebParam(name = "gridUnitWidth") Integer gridUnitWidth, @WebParam(name = "timeZone") String timeZone,
                       @WebParam(name = "categories") String[] categories, @WebParam(name = "companyIds") Long[] companyIds,
                       @WebParam(name = "stationTagIds") Long[] stationTagIds,
                       @WebParam(name = "locatorFormats") String[] locatorFormats, @WebParam(name = "hd") Boolean hd,
                       @WebParam(name = "rowStart") Integer rowStart, @WebParam(name = "rowEnd") Integer rowEnd,
                       @WebParam(name = "programTagIds") Long[] programTagIds,
                       @WebParam(name = "fields") String fields)
            throws GridException;

    /**
     * Returns listings in-window based on the specified grid model and station
     * id ordered by start time.
     *
     * @param stationId
     *            a Long
     * @param numGridUnits
     *            the number of grid units
     * @param gridUnitWidth
     *            the grid unit width
     * @param offset
     *            the offset
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "programInfo,programId,programInfo.title" will include only the programIds and title fields.
     * @return a list of listing infos
     * @throws GridException
     *             general grid exception
     */
    List<ListingInfo> getListings(@WebParam(name = "stationId") Long stationId,
                                  @WebParam(name = "numGridUnits") Integer numGridUnits,
                                  @WebParam(name = "gridUnitWidth") Integer gridUnitWidth, @WebParam(name = "offset") Integer offset,
                                  @WebParam(name = "programTagIds") Long[] programTagIds,
                                  @WebParam(name = "fields") String fields)
            throws GridException;

    /**
     * Returns listings in the specified time window for the specified station
     * ordered by start time
     *
     * @param stationId
     *            a Long
     * @param startTime
     *            a Date
     * @param endTime
     *            a Date
     * @param gridUnitWidth
     *            the grid unit width
     * @param programTagIds
     *            the tagIds that should be returned in the ProgramInfos.  If no tagIds are specified, all
     *            of the tagIds associated with the ProgramInfo are returned.  Note that this parameter does not
     *            filter the ProgramInfos that are returned.  If a ProgramInfo does not have any of the specified
     *            tagIds, the ProgramInfo is returned in the response with an empty List of tagIds.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "programInfo,programId,programInfo.title" will include only the programIds and title fields.
     * @return a list of listing infos
     * @throws GridException
     *             general grid exception
     */
    List<ListingInfo> getListingsByDate(@WebParam(name = "stationId") Long stationId,
                                        @WebParam(name = "startTime") Date startTime, @WebParam(name = "endTime") Date endTime,
                                        @WebParam(name = "gridUnitWidth") Integer gridUnitWidth, @WebParam(name = "programTagIds") Long[] programTagIds,
                                        @WebParam(name = "fields") String fields) throws GridException;

    /**
     * Returns listings for a given list of ids
     * @param listingIds the listing ids to find and return
     * @return a list of listing infos
     */
    List<ListingInfo> getListingsById(@WebParam(name = "listingIds") List<Muri> listingIds,
                                      @WebParam(name = "programTagIds") Long[] programTagIds,
                                      @WebParam(name = "fields") String fields) throws GridException;

    /**
     * Returns programs that are currently trending on social media.
     * @param fields
     *            list of fields to include in the response. Default is all (null).
     *            E.g: "channels.number,channels.channelUrn" will include only the channels numbers and channelUrn fields.
     * @return A trending programs object that contains a list of trending programs sorted by score (rank)
     * @throws GridException
     */
    TrendingPrograms getTrendingPrograms(@WebParam(name = "fields") String fields) throws GridException;

}
