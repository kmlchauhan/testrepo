package com.theplatform.web.tv.gws.service.common.field;


import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.episodes.EpisodeMap;
import com.theplatform.web.tv.contentresolution.api.objects.EpisodesMap;
import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import com.theplatform.web.tv.contentresolution.api.objects.episodes.EpisodeSequence;
import com.theplatform.web.tv.contentresolution.api.objects.episodes.EquivalentEpisodes;
import com.theplatform.web.tv.gws.service.common.field.descriptor.ApiClassDescriptor;
import com.theplatform.web.tv.gws.service.common.field.nullification.NullificationPlan;
import com.theplatform.web.tv.gws.service.common.field.nullification.SelectedProperties;
import com.theplatform.web.tv.gws.service.common.field.nullification.NullificationMode;
import org.apache.commons.lang3.StringUtils;

import java.util.*;


/**
 * Util class for filter fields of a an object.
 * Field names follow the ognl notation (field.innerField.thirdLevelField)
 * 
 * @author gservente
 */
public class FieldFilterUtil {

    public static void filterFields(EpisodesMap episodesMap, String fieldsToInclude){
        if (episodesMap == null || episodesMap.getEpisodeIdToEpisodes()==null || StringUtils.isBlank(fieldsToInclude)) {
            return;
        }
        Map<Muri, ProgramInfo[]> episodeIdToEpisodes = episodesMap.getEpisodeIdToEpisodes();
        for (Muri muri :  episodeIdToEpisodes.keySet()){
            for (ProgramInfo programInfo : episodeIdToEpisodes.get(muri)){
                preserveFields(programInfo, null, fieldsToInclude);
            }
        }
    }

    public static void filterFields(EpisodeMap episodeMap, String fieldsToInclude) {
        if (episodeMap == null || episodeMap.getEpisodeIdToEpisodes() == null || StringUtils.isBlank(fieldsToInclude)) {
            return;
        }
        Map<Muri, EpisodeSequence> episodeIdToEpisodes = episodeMap.getEpisodeIdToEpisodes();
        for (EpisodeSequence episodeSequence :  episodeIdToEpisodes.values()) {
            if (episodeSequence != null) {
                for (EquivalentEpisodes equivalentEpisodes : episodeSequence.getEpisodes()) {
                    for (ProgramInfo programInfo : equivalentEpisodes.getEquivalentEpisodes()) {
                        preserveFields(programInfo, null, fieldsToInclude);
                    }
                }
            }
        }
    }

    /**
     * Invoke {@link #filterFields(Object, String, Boolean)} for each member of the Collection.  This method
     * does not validate the fields.
     * @param collection a non-null Collection
     * @param fieldsToInclude the fields that should be included/should not be nulled out.
     */
    @Deprecated
    public static void filterFieldsForEach(Collection<?> collection, String fieldsToInclude) {
        if (StringUtils.isNotBlank(fieldsToInclude)) {
            for (Object current : collection) {
                filterFields(current, fieldsToInclude, Boolean.FALSE);
            }
        }
    }

    @Deprecated
    public static void filterFields(Object target, String fields, Boolean validateFields) {
        preserveFields(target, null, fields);
    }

    @Deprecated
    public static void filterFields(Object target, String fields, Boolean validateFields, String forceInclude) {
        preserveFields(target, forceInclude, fields);
    }

    private final static FieldFilterCache<PlanCacheKey, NullificationPlan> planCache = new FieldFilterCache<>();

    /**
     * Nullify all properties that are not specifically included for preservation.  Note that if propsCsv
     * is null/blank this method is a no-op.
     *
     * @param target object to nullify
     * @param basePropsCsv properties that should always be preserved (comma delimited)
     * @param propsCsv user specified properties to preserve (comma delimited)
     */
    public static void preserveFields(Object target, String basePropsCsv, String propsCsv) {
        if (target == null || StringUtils.isBlank(propsCsv)) {
            return;
        }

        filterOrNullify(target, NullificationMode.PRESERVE_SELECTED_PROPERTIES, basePropsCsv, propsCsv);
    }

    /**
     * Nullify the specified properties, leaving other properties untouched.
     * @param target object to nullify
     * @param propsToNullifyCsv comma delimited properties to nullify
     */
    public static void nullifyFields(Object target, String propsToNullifyCsv) {
        if (target == null || StringUtils.isBlank(propsToNullifyCsv)) {
            return;
        }

        filterOrNullify(target, NullificationMode.NULLIFY_SELECTED_PROPERTIES, propsToNullifyCsv, null);
    }

    private static void filterOrNullify(Object target, NullificationMode type, String basePropsCsv, String propsCsv) {
        if (Collection.class.isAssignableFrom(target.getClass())) {
            Collection<?> collection = (Collection<?>) target;

            if (collection.isEmpty()) {
                return;
            }

            // get a plan based on the first member of the Collection (assumes that all members of the Collection
            // are of the same type).
            Object firstItem = collection.iterator().next();
            NullificationPlan plan = getPlan(firstItem.getClass(), type, basePropsCsv, propsCsv);

            // apply the plan to each member of the Collection
            for (Object item : collection) {
                plan.nullifyFields(item);
            }
        }
        else {
            NullificationPlan plan = getPlan(target.getClass(), type, basePropsCsv, propsCsv);
            plan.nullifyFields(target);
        }
    }

    /**
     * Get a NullificationPlan instance that nullifies or preserves the selected fields for the target Class
     * @param clazz root object type
     * @param mode inclusive or exclusive nullification
     * @param props1 For {@link NullificationMode#PRESERVE_SELECTED_PROPERTIES} the properties that should always be included.
     *               For {@link NullificationMode#NULLIFY_SELECTED_PROPERTIES} the properties that should be nullified.
     * @param prop2  For {@link NullificationMode#PRESERVE_SELECTED_PROPERTIES} the caller-specified properties to preserve (use
     *               null for For {@link NullificationMode#NULLIFY_SELECTED_PROPERTIES}).
     * @return a NullificationPlan
     */
    private static NullificationPlan getPlan(Class<?> clazz, NullificationMode mode, String props1, String prop2) {

        // check if we've already created a suitable NullificationPlan.  a PlanCacheKey is basically a holder for
        // the arguments to this method
        PlanCacheKey key = new PlanCacheKey(clazz, mode, props1, prop2);
        NullificationPlan plan = planCache.get(key);

        if (plan == null) {

            // get a descriptor for the target class.  the descriptor contains property information determined
            // via reflection.  descriptors are separate from NullificationPlans.  the same descriptor can be
            // used to build multiple plans (that nullify different properties) for the same class.
            ApiClassDescriptor rootDescriptor = ApiClassDescriptor.forClass(clazz);

            // convertIpLocator the CSV properties into a more accessible form
            SelectedProperties selectedProperties = new SelectedProperties(mode, props1, prop2);

            // build a plan that nullifies the right properties.  in PRESERVE_SELECTED_PROPERTIES mode it will nullify
            // all of the properties that weren't selected.  in NULLIFY_SELECTED_PROPERTIES mode it will nullify the
            // properties that were selected.
            plan = new NullificationPlan(rootDescriptor, selectedProperties);

            planCache.put(key, plan);
        }
        return plan;
    }
}
