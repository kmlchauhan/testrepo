package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.IngestException;
import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.tv.linear.api.data.objects.StreamNamespace;
import com.theplatform.web.tv.gws.sirius.model.CRSStreamNamespace;

import static com.theplatform.data.persistence.translator.converter.LocalUriConverter.convertUriToID;

/**
 * @author Segun Abimbola (oabimb200)
 * 2/05/18
 */
public class StreamNamespaceConverter extends AbstractDataObjectConverter<StreamNamespace, CRSStreamNamespace> {

    @Override
    public CRSStreamNamespace convert(StreamNamespace streamNamespace) {

        CRSStreamNamespace crsObject = new CRSStreamNamespace();
        crsObject.setId(convertUriToID(streamNamespace.getId()));
        crsObject.setTitle(streamNamespace.getTitle());
        return crsObject;
    }
}
