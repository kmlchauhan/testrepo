package com.theplatform.web.tv.gws.ingest.maintainer;

import com.comcast.merlin.sirius.ingest.Event;
import com.comcast.merlin.sirius.ingest.maintainer.LongDataRepoMaintainer;
import com.comcast.merlin.sirius.ingest.producer.dataservice.DataObjectReceiver;
import com.comcast.merlin.sirius.ingest.producer.dataservice.client.ClientFacade;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.web.tv.gws.sirius.model.CRSListing;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.repository.ListingRepository;
import com.theplatform.web.tv.gws.sirius.repository.ProgramRepository;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class ProgramRepositoryMaintainer extends LongDataRepoMaintainer<CRSProgram> {
    private final ProgramRepository programRepository;
    private final ListingRepository listingRepository;
    private final SiriusObjectType listingSiriusObjectType;

    protected ProgramRepositoryMaintainer(DataObjectReceiver dataObjectReceiver, ClientFacade programClientFacade,
                                          ProgramRepository programRepository, ListingRepository listingRepository) {
        super(dataObjectReceiver, programClientFacade);

        this.programRepository = programRepository;
        this.listingRepository = listingRepository;
        this.listingSiriusObjectType = listingRepository.getType();
    }

    @Override
    protected boolean shouldIngest(CRSProgram program) {
        long programId = program.getId();
        boolean shouldIngest = listingRepository.hasListingReferencing(program);

        if (!shouldIngest) {
            logger.debug("Not ingesting Program {} because no Listings are referencing it", programId);
        }
        return shouldIngest;
    }

    @Override
    protected void consumeOtherPut(Event event) {
        validateOtherEvent(event);

        CRSListing listing = (CRSListing) event.getCrsDataObject();
        long listingId = listing.getId();
        CRSListing oldListing = listingRepository.get(listingId);

        logger.debug("Processing listing: id={} programId={} seriesId={}",
                     listingId, listing.getProgramId(), listing.getSeriesId());

        Set<Long> programIdsToIngest = new HashSet<>(2);
        for (Long programId : Arrays.asList(listing.getProgramId(), listing.getSeriesId())) {
            if (programId != null && !programRepository.containsKey(programId)) {
                programIdsToIngest.add(programId);
            }
        }

        logger.debug("Ingesting Programs {} due to ingest of Listing {}",
                     programIdsToIngest, listingId);
        ingest(programIdsToIngest, listingId);

        egestReferencesIfNecessaryForUpdate(oldListing, listing);
    }

    @Override
    protected void consumeOtherDelete(Event event) {
        validateOtherEvent(event);

        long listingId = Long.parseLong(event.getKey().getId());
        CRSListing listingFromRepository = listingRepository.get(listingId);

        egestReferencesIfNecessaryForDelete(listingFromRepository);
    }

    private void egestReferencesIfNecessaryForUpdate(CRSListing oldListing, CRSListing updatedListing) {
        if (oldListing == null) return;

        Long oldProgramId = oldListing.getProgramId();
        Long oldSeriesId = oldListing.getSeriesId();
        Long updatedProgramId = updatedListing.getProgramId();
        Long updatedSeriesId = updatedListing.getSeriesId();

        // if the programId changed, then egest it if there will be no references to it after this update
        if (oldProgramId != null
                && !oldProgramId.equals(updatedProgramId)
                && !oldProgramId.equals(updatedSeriesId)
                && programRepository.containsKey(oldProgramId)
                && listingRepository.isOnlyListingReferencing(oldListing, oldProgramId)) {
            egest(oldProgramId, oldListing.getId());
        }

        // likewise for seriesId
        if (oldSeriesId != null
                && !oldSeriesId.equals(updatedSeriesId)
                && !oldSeriesId.equals(updatedProgramId)
                && programRepository.containsKey(oldSeriesId)
                && listingRepository.isOnlyListingReferencing(oldListing, oldSeriesId)) {
            egest(oldSeriesId, oldListing.getId());
        }
    }

    private void egestReferencesIfNecessaryForDelete(CRSListing listingFromRepository) {
        if (listingFromRepository == null) return;

        for (Long programId : Arrays.asList(listingFromRepository.getProgramId(), listingFromRepository.getSeriesId())) {
            if (programId != null
                    && programRepository.containsKey(programId)
                    && listingRepository.isOnlyListingReferencing(listingFromRepository, programId)) {
                egest(programId, listingFromRepository.getId());
            }
        }
    }

    private void validateOtherEvent(Event event) {
        SiriusObjectType eventType = event.getCrsObjectType();

        if (!eventType.equals(listingSiriusObjectType)) {
            throw new IllegalArgumentException("Unexpected event type: " + eventType);
        }
    }
}
