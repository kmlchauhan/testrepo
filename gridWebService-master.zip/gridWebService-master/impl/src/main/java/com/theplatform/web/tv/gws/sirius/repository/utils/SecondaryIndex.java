package com.theplatform.web.tv.gws.sirius.repository.utils;

import java.util.Collection;
import java.util.Set;

/**
 * Interface for secondary indexes. A secondary index maps a key to one or more values.
 * This is an interface so we could have implementations backed by different data structures.
 *
 * @param <K> value of the field being indexed
 * @param <V> object to index
 */
public interface SecondaryIndex<K, V> {

    public void put(K indexKey, V value);

    public void remove(K indexKey, V value);

    public Collection<V> getByIndexKey(K key);
    
    public Set<K> getKeys();

    public void removeAll(K indexValue);

}
