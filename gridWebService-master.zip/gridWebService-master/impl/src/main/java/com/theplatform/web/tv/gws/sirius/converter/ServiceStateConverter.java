package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.commons.job.api.data.objects.ServiceState;
import com.theplatform.web.tv.gws.sirius.model.CRSServiceState;

public class ServiceStateConverter extends AbstractDataObjectConverter<ServiceState, CRSServiceState> {

    @Override
    public CRSServiceState convert(ServiceState stationTakedown) {
        CRSServiceState crsServiceState = new CRSServiceState();
        crsServiceState.setId( Muri.getObjectId(stationTakedown.getId()) );
        crsServiceState.setService(stationTakedown.getService().toString());
        crsServiceState.setContext(stationTakedown.getContext().toString());
        crsServiceState.setState(stationTakedown.getState());
        return crsServiceState;
    }

}
