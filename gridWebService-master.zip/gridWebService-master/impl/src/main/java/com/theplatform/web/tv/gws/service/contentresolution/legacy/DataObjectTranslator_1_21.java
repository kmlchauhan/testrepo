package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.theplatform.web.tv.contentresolution.api.objects.ApiObjectVisitor;
import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;

public class DataObjectTranslator_1_21 extends ApiObjectVisitor {
    public final static DataObjectTranslator_1_21 INSTANCE = new DataObjectTranslator_1_21();

    @Override
    public void visitProgramInfo(ProgramInfo programInfo) {
        programInfo.setPartNumber(null);
        programInfo.setTotalParts(null);
        programInfo.setTvSeasonNumber(null);
        programInfo.setTvSeasonEpisodeNumber(null);
    }
}
