package com.theplatform.web.tv.gws.service.common.field.nullification.operations;

import com.theplatform.web.tv.gws.service.common.field.FieldFilteringException;
import com.theplatform.web.tv.gws.service.common.field.descriptor.ApiPropertyDescriptor;
import org.apache.commons.lang3.ArrayUtils;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;

/**
 * Read the value of a property and call another PropertyOperation with the value.  Handles
 * repeatedly invoking another PropertyOperation for each value in an array/Collection.
 */
public class ReadValue implements PropertyOperation {

    protected final ApiPropertyDescriptor descriptor;
    protected final Method readMethod;
    protected final boolean arrayType;
    protected final boolean listType;
    protected final boolean collectionType;
    protected final PropertyOperation next;

    public ReadValue(ApiPropertyDescriptor descriptor, PropertyOperation next) {
        this.descriptor = descriptor;
        this.readMethod = descriptor.getReadMethod();
        this.arrayType = descriptor.isArrayType();
        this.listType = descriptor.isListType();
        this.collectionType = descriptor.isCollectionType();
        this.next = next;
    }

    public void unwrapArray(Object target) {
        int length = Array.getLength(target);
        for (int i = 0; i < length; i++) {
            Object element = Array.get(target, i);
            next.apply(element);
        }
    }

    public void unwrapList(Object target) {
        List<?> list = (List<?>) target;

        // ugly but avoids create an Iterator instance if we know it's a List
        for (int i = 0; i < list.size(); i++) {
            Object current = list.get(i);
            if (current != null) {
                next.apply(current);
            }
        }
    }

    public void unwrapCollection(Object target) {
        Collection<?> collectionValue = (Collection<?>) target;
        for (Object collectionMember : collectionValue) {
            if (collectionMember != null) {
                next.apply(collectionMember);
            }
        }
    }


    @Override
    public void apply(Object target) {

        try {
            // passing ArrayUtils.EMPTY_OBJECT_ARRAY to the invoke method prevents the compiler from implicitly
            // creating a new empty array
            Object value = readMethod.invoke(target, ArrayUtils.EMPTY_OBJECT_ARRAY);

            if (value == null) {
                return;
            }

            if (arrayType) {
                unwrapArray(value);
            }
            else if (listType) {
                unwrapList(value);
            }
            else if (collectionType) {
                unwrapCollection(value);
            }
            else {
                next.apply(value);
            }
        }
        catch (ReflectiveOperationException e) {
            throw new FieldFilteringException("Failed to read property '" + this.descriptor.getPath() + "' for " + target, e);
        }
    }
}
