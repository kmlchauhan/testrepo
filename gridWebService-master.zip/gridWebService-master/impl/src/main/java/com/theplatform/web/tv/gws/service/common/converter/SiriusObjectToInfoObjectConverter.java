package com.theplatform.web.tv.gws.service.common.converter;

import com.theplatform.web.tv.gws.uri.MerlinIdHelper;

import java.util.List;

/**
 * @author jcoelho
 * @since 11/18/14.
 */
public interface SiriusObjectToInfoObjectConverter<S, I> {
    I convert(S productContext);

    List<I> convert(List<S> productContext);

    void setMerlinIdHelper(MerlinIdHelper merlinIdHelper);
}
