package com.theplatform.web.tv.gws.service.common.converter;

import com.theplatform.web.tv.contentresolution.api.objects.ProductContextInfo;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import com.theplatform.web.tv.gws.sirius.model.CRSProductContext;
import com.theplatform.web.tv.gws.sirius.repository.ProductContextRepository;
import org.springframework.beans.factory.annotation.Required;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * @author jcoelho
 * @since 11/14/14.
 */
public class CRSProductContextToProductContextInfoConverter {

    private MerlinIdHelper merlinIdHelper;
    private ProductContextRepository productContextRepository;

    public ProductContextInfo convert(CRSProductContext crsProductContext) {

        return convert(crsProductContext, this.merlinIdHelper);
    }

    public ProductContextInfo convert(CRSProductContext crsProductContext, MerlinIdHelper localMerlinIdHelper) {
        if (crsProductContext == null) return null;
        ProductContextInfo p = new ProductContextInfo();
        p.setId(localMerlinIdHelper.createProductContextId(crsProductContext.getId()));
        p.setTitle(crsProductContext.getTitle());
        p.setType(crsProductContext.getType());
        return p;
    }

    public List<ProductContextInfo> convert(Collection<Long> productContexts) {
        return convert(productContexts, this.merlinIdHelper);
    }

    public List<ProductContextInfo> convert(Collection<Long> productContexts, MerlinIdHelper localMerlinIdHelper) {
        List<Long> productContextsSorted = new ArrayList<>(productContexts);
        Collections.sort(productContextsSorted);
        List<ProductContextInfo> l = new ArrayList<>(productContextsSorted.size());
        for (Long id : productContextsSorted){
            CRSProductContext crsProductContext = productContextRepository.get(id);
            ProductContextInfo productContextInfo = convert(crsProductContext, localMerlinIdHelper);
            if (productContextInfo!=null) l.add(productContextInfo);
        }
        return l;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }

    @Required
    public void setProductContextRepository(ProductContextRepository productContextRepository) {
        this.productContextRepository = productContextRepository;
    }



}
