package com.theplatform.web.tv.gws.sirius.model;


import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.tv.linear.api.data.objects.StreamStatus;

public class CRSStream extends LongDataRepoObject implements Comparable<CRSStream> {

    long stationId;
    private Boolean isDefault;
    private String status;
    private Boolean external;
    private String title;
    private long ownerId;
    private Boolean isDai;
    private String preferredRMType;
    private Boolean travelRights;
    private String serviceZoneType;
    private String type;

    public CRSStream() {
        super( SiriusObjectType.fromFriendlyName("Stream"));
    }

    public CRSStream(long id) {
        super( SiriusObjectType.fromFriendlyName("Stream"), id);
    }

    public String getPreferredRMType() {
        return preferredRMType;
    }

    public void setPreferredRMType(String preferredRMType) {
        this.preferredRMType = preferredRMType;
    }

    public long getStationId() {
        return stationId;
    }

    public void setStationId(long stationId) {
        this.stationId = stationId;
    }

    public Boolean getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Boolean isDefault) {
        this.isDefault = isDefault;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = nullSafeIntern(status);
    }

    public Boolean getExternal() {
        return external;
    }

    public void setExternal(Boolean external) {
        this.external = external;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(long ownerId) {
        this.ownerId = ownerId;
    }

    public Boolean getIsDai() {
        return isDai;
    }

    public void setIsDai(Boolean isDai) {
        this.isDai = isDai;
    }

    public Boolean getTravelRights() {
        return travelRights;
    }

    public void setTravelRights(Boolean travelRights) {
        this.travelRights = travelRights;
    }

    public String getServiceZoneType() {
        return serviceZoneType;
    }

    public void setServiceZoneType(String serviceZoneType) {
        this.serviceZoneType = serviceZoneType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isProduction() {
        return StreamStatus.Production.name().equals(status);
    }

    @Override
    public int compareTo(CRSStream scrStream) {
        if (this.hashCode() > scrStream.hashCode()) {
            return 1;
        }else if (this.hashCode() < scrStream.hashCode()) {
            return -1;
        }
        return 0;
    }

}
