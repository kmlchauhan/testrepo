package com.theplatform.web.tv.gws.ingest.producer.twitter;


import com.theplatform.web.tv.gws.ingest.producer.twitter.json.AlternateIdSource;
import org.apache.commons.collections.buffer.CircularFifoBuffer;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import java.io.Serializable;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

@ManagedResource
public class TwitterMBean {
    // dependencies
    private TwitterSettings settings;
    private TwitterIngestScheduler twitterIngestScheduler;

    // general
    private final AtomicReference<Date> lastExecutionTime = new AtomicReference();
    private final AtomicLong executionCount = new AtomicLong();

    // HTTP
    private final AtomicLong httpOkResponses = new AtomicLong();
    private final AtomicLong httpErrorResponses = new AtomicLong();
    private final AtomicLong rateLimitExceeded = new AtomicLong();

    // mapping related
    private final HashMap<String, Integer> totalFailedIdLookupsByProvider = new HashMap<String, Integer>(2);
    private final CircularFifoBuffer recentFailedLookups = new CircularFifoBuffer(128);


    public synchronized void setLastExecutionTime() {
        this.lastExecutionTime.set(new Date());
    }

    @ManagedAttribute(description="The last time the scheduled job ran on this node.")
    public synchronized Date getLastExecutionTime() {
        return this.lastExecutionTime.get();
    }

    public void incrementExecutionCount() {
        executionCount.getAndIncrement();
    }

    @ManagedAttribute(description="Total number of times the scheduled job has run on this node since the bean was started.")
    public long getExecutionCount() {
        return executionCount.get();
    }

    public void incrementHttpOkResponse() {
        httpOkResponses.getAndIncrement();
    }

    @ManagedAttribute(description="Number of HTTP 200 responses returned by Twitter since the bean was started.")
    public long getHttpOkResponses() {
        return httpOkResponses.get();
    }

    public void incrementHttpErrorResponse() {
         httpErrorResponses.getAndIncrement();
    }

    @ManagedAttribute(description=
        "Number of HTTP error (4xx or 5xx) responses returned by Twitter since the bean was started. " +
        "Note that this number also includes the number of rate limit exceeded responses"
    )
    public long getHttpErrorResponses() {
        return httpErrorResponses.get();
    }

    public void incrementRateLimitExceeded() {
        rateLimitExceeded.getAndIncrement();
    }

    @ManagedAttribute(description="Number of rate limit errors encountered since the bean was started.")
    public long getRateLimitExceeded() {
        return rateLimitExceeded.get();
    }


    public void addFailedIdLookups(AlternateIdSource source, Set<String> failedIds) {
        // running total of failures for the provider
        synchronized (this.totalFailedIdLookupsByProvider) {
            String providerName = source.getMerlinSourceProviderName();
            if (this.totalFailedIdLookupsByProvider.containsKey(providerName)) {
                Integer oldValue = this.totalFailedIdLookupsByProvider.get(providerName);
                Integer newValue = oldValue + failedIds.size();
                this.totalFailedIdLookupsByProvider.put(providerName, newValue);
            } else {
                this.totalFailedIdLookupsByProvider.put(providerName, failedIds.size());
            }
        }

        synchronized (recentFailedLookups) {
            // a circular list of recent failures provides more detailed information than the counts
            Date now = new Date();
            for (String id : failedIds) {
                LoookupFailure failure = new LoookupFailure(now, source.getMerlinSourceProviderName(), id);
                this.recentFailedLookups.add(failure);
            }
        }
    }

    @ManagedAttribute(description="Number of failed ID lookups by Merlin provider name since the bean was started.")
    public Map<String, Integer> getTotalFailedIdLookupsByProvider() {
        synchronized (totalFailedIdLookupsByProvider) {
            return (Map<String, Integer>) this.totalFailedIdLookupsByProvider.clone();
        }
    }

    @ManagedAttribute(description="Recently failed ID lookups.")
    public List<LoookupFailure> getRecentLookupFailures() {
        synchronized (recentFailedLookups) {
            List<LoookupFailure> failuresList = new ArrayList<>(this.recentFailedLookups.size());
            failuresList.addAll(this.recentFailedLookups);
            Collections.sort(failuresList);
            return failuresList;
        }
    }

    @ManagedAttribute(description = "Whether Twitter ingester has been enabled in the main properties file")
    public boolean isEnabled() {
        return settings.isEnabled();
    }

    @ManagedAttribute(description = "Whether the Twitter ingester is running on this node")
    public boolean isRunning() {
        return twitterIngestScheduler.isRunning();
    }

    @ManagedAttribute(description = "Twitter polling frequency, measured from the end of one polling run to the start of the next run")
    public long getRefreshIntervalSeconds() {
        return settings.getRefreshIntervalSeconds();
    }

    @ManagedOperation(description = "Reset all statistics")
    public void clearStats() {
        this.lastExecutionTime.set(null);
        this.executionCount.set(0);
        this.httpOkResponses.set(0);
        this.httpErrorResponses.set(0);
        this.rateLimitExceeded.set(0);

        synchronized (this.totalFailedIdLookupsByProvider) {
            this.totalFailedIdLookupsByProvider.clear();
        }

        synchronized (this.recentFailedLookups) {
            this.recentFailedLookups.clear();
        }
    }

    @Required
    public void setSettings(TwitterSettings settings) {
        this.settings = settings;
    }

    @Required
    public void setTwitterIngestScheduler(TwitterIngestScheduler twitterIngestScheduler) {
        this.twitterIngestScheduler = twitterIngestScheduler;
    }

    public static class LoookupFailure implements Comparable<LoookupFailure>, Serializable {

        private Date date;
        private String providerName;
        private String nativeProviderId;

        public LoookupFailure() {
        }

        public LoookupFailure(Date date, String providerName, String nativeProviderId) {
            this.date = date;
            this.providerName = providerName;
            this.nativeProviderId = nativeProviderId;
        }

        public Date getDate() {
            return date;
        }

        public String getProviderName() {
            return providerName;
        }

        public String getNativeProviderId() {
            return nativeProviderId;
        }

        @Override
        public int compareTo(LoookupFailure other) {
            return other.date.compareTo(this.date);
        }
    }
}
