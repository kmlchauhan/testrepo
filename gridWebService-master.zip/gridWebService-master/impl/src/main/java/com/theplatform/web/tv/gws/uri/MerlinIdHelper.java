package com.theplatform.web.tv.gws.uri;

import com.theplatform.contrib.data.api.objects.UriException;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.web.context.WebServiceContext;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.combine.commons.MerlinService;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;
import java.util.*;

import static com.theplatform.data.tv.ingest.type.MerlinEntityType.*;
import static com.theplatform.web.tv.combine.commons.MerlinService.*;

/**
 * @author jcoelho
 * @since 7/24/14
 */
public class MerlinIdHelper {
    private static Logger log = LoggerFactory.getLogger(MerlinIdHelper.class);

    protected final String[] serviceBaseUrls;

    @Resource
    WebServiceContext webServiceContext;

    @SuppressWarnings("unchecked")
    protected MerlinIdHelper(String[] serviceBaseUrls) {
        this.serviceBaseUrls = serviceBaseUrls;
    }

    public MerlinIdHelper() {
        this(new String[MerlinService.values().length]);
    }

    public MerlinIdHelper(String entityBaseUrl, String linearBaseUrl, String offerBaseUrl, String locationBaseUrl,
                          String sportsBaseUrl) {
        this();
        addServiceBaseUrl(MerlinService.ENTITY, entityBaseUrl);
        addServiceBaseUrl(MerlinService.LINEAR, linearBaseUrl);
        addServiceBaseUrl(MerlinService.LOCATION, locationBaseUrl);
        addServiceBaseUrl(MerlinService.OFFER, offerBaseUrl);
        addServiceBaseUrl(MerlinService.SPORTS, sportsBaseUrl);
    }

    protected final void addServiceBaseUrl(MerlinService type, String url) {
        int index = type.ordinal();
        String actualUrl = StringUtils.removeEnd(url, "/");
        serviceBaseUrls[index] = actualUrl + "/data/";
    }

    protected final String getServiceBaseUrl(MerlinService merlinService) {
        String url = serviceBaseUrls[merlinService.ordinal()];
        if (url == null) {
            throw new UriException("MerlinIdHelper does not support this service: " + merlinService.getServiceName());
        }
        return url;
    }

    /**
     * By default, MerlinIdHelper is thread safe.  This method will always return a new StringBuilder.  See {@link #forSingleThreadedUse()}.
     * @return a new StringBuilder
     */
    protected StringBuilder stringBuilder() {
        return new StringBuilder(120);
    }

    protected Muri createId(long id, MerlinService merlinService, MerlinEntityType entityType, IdForm idForm, StringBuilder builder) {
        if (idForm == IdForm.URN) {
            return UrnUtil.generateUrn(id, merlinService, entityType, builder);
        } else {
            String baseUrl = getServiceBaseUrl(merlinService);
            builder.append(baseUrl).append(entityType.getTypeString()).append("/").append(id);
            return new Muri( builder.toString(), id);
        }
    }

    public Muri createId(long id, MerlinService merlinService, MerlinEntityType entityType, IdForm idForm) {
        return createId(id, merlinService, entityType, idForm, stringBuilder());
    }

    public Muri createId(long id, MerlinService merlinService, MerlinEntityType entityType) {
        return createId(id, merlinService, entityType, getIdForm(), stringBuilder());
    }

    public List<Muri> createIds(Collection<Long> ids, MerlinService merlinService, MerlinEntityType merlinEntityType) {
        if (ids==null) return Collections.emptyList();
        List<Muri> l = new ArrayList<>(ids.size());
        StringBuilder sb = stringBuilder();
        for (long id : ids) {
            l.add(createId(id, merlinService, merlinEntityType, getIdForm(), sb));
            sb.setLength(0);
        }
        return l;
    }

    public List<Muri> createIds(long[] ids, MerlinService merlinService, MerlinEntityType merlinEntityType) {
        List<Muri> l = Collections.emptyList();
        if (ArrayUtils.isNotEmpty(ids)) {
            l = new ArrayList<>(ids.length);
            StringBuilder sb = stringBuilder();
            for (long id : ids) {
                l.add(createId(id, merlinService, merlinEntityType, getIdForm(), sb));
                sb.setLength(0);
            }
        }
        return l;
    }

    public Muri createStreamId(long id) {
        return createId(id, LINEAR, STREAM);
    }

    public Muri createStreamNamespaceId(long id){
        return createId(id, LINEAR, STREAMNAMESPACE);
    }

    public Muri createListingId(long id) {
        return createId(id, LINEAR, LISTING);
    }

    public Muri createStationCompanyId(long id) {
        return createId(id, LINEAR, STATIONCOMPANY);
    }

    public Muri createCompanyId(long id) {
        return createId(id, LINEAR, COMPANY);
    }

    public Muri createChannelId(long id) {
        return createId(id, LINEAR, CHANNEL);
    }

    public Muri createStationId(long id) {
        return createId(id, LINEAR, STATION);
    }

    public Muri createLocationId(long id) {
        return createId(id, LINEAR, MerlinEntityType.LOCATION);
    }

    public Muri createLocatorId(long id) {
        return createId(id, LINEAR, MerlinEntityType.LOCATOR);
    }

    public Muri createProgramId(long id) {
        return createId(id, ENTITY, PROGRAM);
    }

    public Muri createProductContextId(long id) {
        return createId(id, MerlinService.OFFER, PRODUCTCONTEXT);
    }

    public List<Muri> createProductContextIds(long ids[]) {
        return createIds(ids, MerlinService.OFFER, PRODUCTCONTEXT);
    }

    public Muri createGameId(long id) {
        return createId(id, SPORTS, GAME);
    }

    public IdForm getIdForm() {
        try{
            if (webServiceContext != null ){
                String idForm = webServiceContext.getWebServiceRequest().getParameter("idForm");
                if (idForm != null)
                    return IdForm.valueOf(idForm.toUpperCase());
            }
        }
        catch (NullPointerException ignored) {
            // Do nothing.  WebServiceContextImpl always throws a NPE when operating outside of web request
        }
        catch (Exception exc){
            log.info("Problem determining IdForm, using IdForm.URL", exc);
        }
        return IdForm.URL;
    }

    public  void setIdForm(IdForm idForm) {
        if (webServiceContext != null && idForm != null) {
            Map<String, String[]> params = new HashMap<>();
            for (String key : webServiceContext.getWebServiceRequest().getParameters().keySet())
                params.put(key, webServiceContext.getWebServiceRequest().getParameters().get(key));
            params.put("idForm", new String[]{idForm.toString()});
            webServiceContext.getWebServiceRequest().setParameters(params);
        }
    }

    public void setEntityBaseUrl(String entityBaseUrl) {
        addServiceBaseUrl(MerlinService.ENTITY, entityBaseUrl);
    }

    public void setLinearBaseUrl(String linearBaseUrl) {
        addServiceBaseUrl(MerlinService.LINEAR, linearBaseUrl);
    }

    public void setLocationBaseUrl(String locationBaseUrl) {
        addServiceBaseUrl(MerlinService.LOCATION, locationBaseUrl);
    }

    public void setOfferBaseUrl(String offerBaseUrl) {
        addServiceBaseUrl(MerlinService.OFFER, offerBaseUrl);
    }

    public void setSportsBaseUrl(String sportsBaseUrl) {
        addServiceBaseUrl(MerlinService.SPORTS, sportsBaseUrl);
    }

    public void setWebServiceContext(WebServiceContext webServiceContext) {
        this.webServiceContext = webServiceContext;
    }

    /**
     * MerlinIdHelper is thread safe by default.  This method returns a clone of this instance that is NOT thread safe
     * but is significantly more memory efficient.
     * @return a new MerlinIdHelper (not thread safe).
     */
    public MerlinIdHelper forSingleThreadedUse() {
        return new CachingIdHelper(this.serviceBaseUrls, getIdForm());
    }

    public static MerlinIdHelper withDefaultIdForm(MerlinIdHelper other, IdForm idForm) {
        return new FixedFormMerlinIdHelper(other.serviceBaseUrls, idForm, false);
    }

    public static MerlinIdHelper withDefaultIdForm(String entityBaseUrl, String linearBaseUrl, String offerBaseUrl, String locationBaseUrl, String sportsBaseUrl, IdForm idForm) {
        return new FixedFormMerlinIdHelper(entityBaseUrl, linearBaseUrl, offerBaseUrl, locationBaseUrl, sportsBaseUrl, idForm);
    }

    private static class FixedFormMerlinIdHelper extends MerlinIdHelper {

        private final IdForm idForm;
        private final StringBuilder stringBuilder;

        /**
         * @param serviceBaseUrls base service urls
         * @param idForm the IdForm (cannot be changed)
         * @param recycleStringBuilder true if a single StringBuilder should be recycled when creating URLs or
         *                             false if a new StringBuilder should be used each time.
         */
        FixedFormMerlinIdHelper(String[] serviceBaseUrls, IdForm idForm, boolean recycleStringBuilder) {
            super(serviceBaseUrls);
            this.idForm = idForm;
            if (recycleStringBuilder) {
                this.stringBuilder = new StringBuilder(120);
            }
            else {
                this.stringBuilder = null;
            }
        }

        public FixedFormMerlinIdHelper(String entityBaseUrl, String linearBaseUrl, String offerBaseUrl, String locationBaseUrl, String sportsBaseUrl, IdForm idForm) {
            super(entityBaseUrl, linearBaseUrl, offerBaseUrl, locationBaseUrl, sportsBaseUrl);
            this.idForm = idForm;
            this.stringBuilder = null;
        }

        @Override
        protected StringBuilder stringBuilder() {
            if (this.stringBuilder != null) {
                this.stringBuilder.setLength(0);
                return this.stringBuilder;
            }
            else {
                return super.stringBuilder();
            }
        }

        @Override
        public IdForm getIdForm() {
            return idForm;
        }

        @Override
        public void setIdForm(IdForm idForm) {
            throw new IllegalArgumentException("IdForm cannot be changed");
        }
    }

    /**
     * MerlinIdHelper that caches ids that are likely to be created multiple times within a single request.
     * Intended for single threaded use within a single request.
     */
    private static class CachingIdHelper extends FixedFormMerlinIdHelper {
        protected static final boolean[] cacheable;

        static {
            cacheable = new boolean[MerlinEntityType.values().length];
            cacheable[MerlinEntityType.PRODUCTCONTEXT.ordinal()] = true;
        }

        /**
         * Map of long id to previously created CRSUri instances.  A few notes:
         * <ul>
         *     <li>Since each Merlin object type has a unique id suffix there won't be any collisions between
         *         objects of different types.
         *     </li>
         *     <li>
         *         Since this MerlinIdHelper only builds a single type of id (URL, URN, etc) we don't need to
         *         segment the cache by IdForm.
         *     </li>
         *     <li>
         *         We're using fastutil's Long2ObjectMap which provides {@link Long2ObjectMap#get(long) a get method}
         *         that accepts a primitive long rather than a java.lang.Long.  This avoids boxing and helps to boost
         *         performance.
         *     </li>
         * </ul>
         */
        protected final Long2ObjectMap<Muri> uriCache;

        @SuppressWarnings("unchecked")
        public CachingIdHelper(String[] serviceBaseUrls, IdForm idForm) {
            super(serviceBaseUrls, idForm, true);

            this.uriCache = new Long2ObjectOpenHashMap<>();
        }

        @Override
        protected Muri createId(long id, MerlinService merlinService, MerlinEntityType entityType, IdForm idForm, StringBuilder builder) {
            Muri uri;
            if (cacheable[entityType.ordinal()]) {
                uri = uriCache.get(id);
                if (uri == null) {
                    uri = super.createId(id, merlinService, entityType, idForm, builder);
                    uriCache.put(id, uri);
                }
            }
            else {
                uri = super.createId(id, merlinService, entityType, idForm, builder);
            }

            return uri;
        }
    }
}
