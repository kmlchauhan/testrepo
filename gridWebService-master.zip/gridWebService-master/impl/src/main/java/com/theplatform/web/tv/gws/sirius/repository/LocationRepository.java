package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSLocation;

import java.util.HashSet;
import java.util.Set;

public class LocationRepository extends LongObjectRepository<CRSLocation> {
    private ChannelRepository channelRepository;

    // Rex only wants Location with a source of Gracenote.
    private final Set<Long> gracenoteLocation;
    private final String gracenoteSource;

    public LocationRepository(SiriusObjectType siriusObjectType, ChannelRepository channelRepository, String gracenoteSource) {
        super(siriusObjectType);
        this.channelRepository=channelRepository;
        gracenoteLocation = new HashSet<>(20_000);
        this.gracenoteSource = gracenoteSource;
    }

    @Override
    public void addToIndexes(CRSLocation location) {
        channelRepository.addLocation(location);
        if (location.getSource() != null && location.getSource().equalsIgnoreCase(gracenoteSource)){
            gracenoteLocation.add(location.getId());
        }
    }

    @Override
    public void removeFromIndexes(CRSLocation location) {
        channelRepository.removeLocation(location.getId());
        gracenoteLocation.remove(location.getId());
    }

    public boolean isGracenoteLocation(Long locationId){
        return gracenoteLocation.contains(locationId);
    }

}
