package com.theplatform.web.tv.gws.service.common.logic;

import com.comcast.compass.availability.common.domain.Availabilities;
import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import java.net.URI;
import java.util.*;

public class ScopedAvailabilities {

    private static final ScopedAvailabilities NULL_SCOPED_AVAILABILITY = new ScopedAvailabilities();
    
    private Map<Scope, List<Availabilities>> availabilitiesByScope;
    private AvailabilityResolution availabilityResolution;
    
    private ScopedAvailabilities() {
        availabilitiesByScope = Collections.emptyMap();
    }
    
    public static ScopedAvailabilities create(AvailabilityResolution availabilityResolution) {
        if(availabilityResolution == null)
            return NULL_SCOPED_AVAILABILITY;
        ScopedAvailabilities scopedAvailabilities = new ScopedAvailabilities();
        scopedAvailabilities.availabilityResolution = availabilityResolution;

        List<Availabilities> availabilityGroups = availabilityResolution.getAvailabilityGroups();
        if(availabilityGroups != null) {
            Map<Scope, List<Availabilities>> map = new HashMap<Scope, List<Availabilities>>();
            for (Availabilities availabilities : availabilityResolution.getAvailabilityGroups()) {
                Scope scope = Scope.valueOfIgnoreCase(availabilities.getScope());
                List<Availabilities> list = map.get(scope);
                if (list == null) {
                    list = new ArrayList<Availabilities>();
                    map.put(scope, list);
                }
                list.add(availabilities);
            }
            scopedAvailabilities.availabilitiesByScope = map;
        }
        return scopedAvailabilities;
    }
    
    public boolean hasScope(Scope scope) {
        List<Availabilities> list = availabilitiesByScope.get(scope);
        return list != null && !list.isEmpty();
    }
    
    public List<Availabilities> getByScope(Scope scope) {
        List<Availabilities> list = availabilitiesByScope.get(scope);
        if(list != null) 
            return new ArrayList<>(list);
        return Collections.emptyList();
    }

    public List<Availabilities> getStreamAvailabilities() {
        return this.getByScope(Scope.STREAM);
    }
    
    public List<Availabilities> getStationAvailabilities() {
        return this.getByScope(Scope.STATION);
    }

    public Set<URI> getAvailabilityIds(Scope scope) {
        Set<URI> availabilityids = new HashSet<>();

        for (Availabilities availability : getByScope(scope)) {
            List<URI> ids = availability.getAvailabilityIds();

            availabilityids.addAll(ids);
        }

        return availabilityids;
    }
    
    public AvailabilityResolution getAvailabilityResolution() {
        return availabilityResolution;
    }

    public List<Availabilities> getAllAvailabilityGroups() {
        if(availabilityResolution != null)
            return availabilityResolution.getAvailabilityGroups();
        return Collections.emptyList();
    }

    public String getVersion() {
        return this.availabilityResolution.getVersion();
    }
    
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
