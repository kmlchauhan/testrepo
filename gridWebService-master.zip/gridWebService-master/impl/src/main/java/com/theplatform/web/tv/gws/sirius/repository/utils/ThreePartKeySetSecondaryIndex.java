package com.theplatform.web.tv.gws.sirius.repository.utils;

import java.util.Set;

/**
 * A basic index for maintaining values based on a composite key.  This
 * implementation has three parts to the key and the value is a set.
 *
 * @param <K1> First part of the Composite key
 * @param <K2> Second part of the Composite key
 * @param <K3> Third part of the Composite key
 * @param <V>  The value stored in the Set
 */
public class ThreePartKeySetSecondaryIndex<K1, K2, K3, V  extends Comparable<V>>{

    private SortedSetSecondaryIndex<CompositeKey< K1, K2, K3>, V> index;

    public ThreePartKeySetSecondaryIndex() {
        index = new SortedSetSecondaryIndex<>();
    }


    public void put(K1 indexValue1, K2 indexValue2, K3 indexValue3, V object) {
        CompositeKey compositeKey = new CompositeKey( indexValue1, indexValue2, indexValue3);
        index.put( compositeKey, object);
    }

    /**
     * Remove an object from the index
     */
    public void remove(K1 indexValue1, K2 indexValue2, K3 indexValue3, V object) {
        CompositeKey compositeKey = new CompositeKey( indexValue1, indexValue2, indexValue3);
        index.remove(compositeKey, object);
    }

    /**
     * Remove all
     */
    public void removeAll(K1 indexValue1, K2 indexValue2, K3 indexValue3) {
        CompositeKey compositeKey = new CompositeKey( indexValue1, indexValue2, indexValue3);
        if (SiriusDataUtils.hasValue(compositeKey)) {
            index.removeAll(compositeKey);
        }
    }

    /**
     * Returns all the objects associated with a key,
     * or empty set if nothing is associated.
     */
    public Set<V> getByIndexKey(K1 indexValue1, K2 indexValue2, K3 indexValue3) {
        CompositeKey compositeKey = new CompositeKey( indexValue1, indexValue2, indexValue3);
        return index.getByIndexKey(compositeKey);
    }


    public static final class CompositeKey<K1, K2, K3>{
        private K1 value1;
        private K2 value2;
        private K3 value3;
        public CompositeKey(K1 value1, K2 value2, K3 value3){
            this.value1 = value1;
            this.value2 = value2;
            this.value3 = value3;
        }

        @Override
        public boolean equals(Object other){
            if (!(other instanceof CompositeKey)) return false;
            CompositeKey otherCK = (CompositeKey) other;
            if (!otherCK.value1.equals(value1)) return false;
            if (!otherCK.value2.equals(value2)) return false;
            if (!otherCK.value3.equals(value3)) return false;
            return true;
        }

        @Override
        public int hashCode(){
            return value1.hashCode() + 13 * value2.hashCode()  + 31 * value3.hashCode();

        }
    }




}



