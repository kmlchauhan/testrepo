package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.*;
import com.comcast.merlin.sirius.repository.*;
import com.google.common.collect.*;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.sirius.repository.utils.*;
import org.springframework.beans.factory.annotation.*;

import java.util.*;

public class ChannelRepository extends LongObjectRepository<CRSChannel> {

    private OpenSetSecondaryIndex<CRSChannel> locationIndex;
    private SecondaryIndex<Long, CRSChannel> stationIndex;

    private List<String> taggingProductContextTitles;

    private Set<String> taggingProductContextTitlesLookup;
    private Set<Long> taggingProductContexts;
    private Map< Long, Set<Long>> mapTaggingProductContextToLocations;

    // This is a little weird but have a (Location/Station)-> Channels would would require a wrapper key object which
    // would be wasteful because you would need to create a wrapper key for every channel you're checking.
    // Location -> (Station -> Channels[])
    Map<Long, SecondaryIndex<Long, Long>> taggingStationsIndex;

    private JdkCollectionsCompositeKeySecondaryIndex<Long,Long,CRSChannel> stationToContentAvailabilityIndex;       // stationId, ownerId  - (1-n) -> CRSChannel

    private OpenSetSecondaryIndex<CRSChannel> syntheticWhitelistChannelLookup;         //  Whitelist Station Id -> 1 Channel Id

    private Long syntheticChannelWhitelistLocationId;

    private String displayPropertiesHiddenChannel;

    public ChannelRepository(SiriusObjectType siriusObjectType) {
        this(siriusObjectType, 16);
    }

    public ChannelRepository( SiriusObjectType siriusObjectType, int expectedSize) {
        super(siriusObjectType, expectedSize);
        locationIndex = new OpenSetSecondaryIndex<>();
        stationIndex = new OpenSetSecondaryIndex<>();
        taggingProductContexts = new HashSet<>();
        mapTaggingProductContextToLocations = new HashMap<>();
        taggingStationsIndex = new HashMap<>();
        stationToContentAvailabilityIndex = new JdkCollectionsCompositeKeySecondaryIndex<Long,Long,CRSChannel>();

        syntheticWhitelistChannelLookup = new OpenSetSecondaryIndex<>();
    }

    @Override
    public void addToIndexes(CRSChannel channel) {
        locationIndex.put(channel.getLocationId(), channel);
        stationIndex.put(channel.getStationId(), channel);
        addTaggingStation(channel);
        stationToContentAvailabilityIndex.put(channel.getStationId(), channel.getOwnerId(), channel);

        if (syntheticChannelWhitelistLocationId.equals(channel.getLocationId())) {
            syntheticWhitelistChannelLookup.put(channel.getStationId(), channel);
        }
    }

    @Override
    public void removeFromIndexes(CRSChannel channel) {
        locationIndex.remove(channel.getLocationId(), channel);
        stationIndex.remove(channel.getStationId(), channel);
        removeTaggingStation(channel);
        stationToContentAvailabilityIndex.remove(channel.getStationId(), channel.getOwnerId(), channel);

        if (syntheticChannelWhitelistLocationId.equals(channel.getLocationId())) {
            syntheticWhitelistChannelLookup.remove(channel.getStationId(), channel);
        }
    }

    public Collection<CRSChannel> getByLocationId(Long locationId) {
        return locationIndex.getByIndexKey(locationId);
    }

    public Collection<CRSChannel> getByLocationIds(Collection<Long> locationIds) {
        Collection<CRSChannel> resultSet = new HashSet<CRSChannel>();
        for (Long locationId : locationIds) {
            resultSet.addAll(this.getByLocationId(locationId));
        }
        return resultSet;
    }

    // **************************************************************
    // *** Code for tracking tagging stationIds


    public void addProductContext(CRSProductContext crsProductContext){
        if(taggingProductContextTitlesLookup.contains(crsProductContext.getTitle().toUpperCase())){
            taggingProductContexts.add(crsProductContext.getId());
        }
    }

    public void addLocation(CRSLocation crsLocation){
        if (isTaggingProductContext(crsLocation.getProductContextId())){
            if (!mapTaggingProductContextToLocations.containsKey(crsLocation.getProductContextId())){
                mapTaggingProductContextToLocations.put( crsLocation.getProductContextId(), new HashSet());
            }
            mapTaggingProductContextToLocations.get( crsLocation.getProductContextId()).add(crsLocation.getId());
        }
    }

    public void removeLocation(Long id){
        for (long productContext : mapTaggingProductContextToLocations.keySet()){
            mapTaggingProductContextToLocations.get(productContext).remove(id);
        }
    }

    private void addTaggingStation(CRSChannel crsChannel){
        if (! isTaggingLocation(crsChannel.getLocationId())) return;
        if (taggingStationsIndex.get(crsChannel.getLocationId())==null){
            taggingStationsIndex.put(crsChannel.getLocationId(), new OpenSetSecondaryIndex<Long>());
        }
        taggingStationsIndex.get(crsChannel.getLocationId()).put(crsChannel.getStationId(),crsChannel.getId());
    }

    private void removeTaggingStation(CRSChannel crsChannel){
        if (! isTaggingLocation(crsChannel.getLocationId())) return;
        if (taggingStationsIndex.get(crsChannel.getLocationId())!=null){
            taggingStationsIndex.get(crsChannel.getLocationId()).remove(crsChannel.getStationId(),crsChannel.getId());
        }
    }

    public boolean isTaggingStationId( Long location, Long stationId) {
        if(taggingStationsIndex.get(location)==null){
            return false;
        }
        return taggingStationsIndex.get(location).getByIndexKey(stationId).size()>0;
    }


    public boolean isTaggingStationId( List<Long> locationIds, Long stationId) {
        for (Long locationId : locationIds) {
            if (isTaggingStationId( locationId, stationId)) return true;
        }
        return false;
    }

    public boolean isTaggingLocation(Long locationId){
        for ( Set<Long> locations : mapTaggingProductContextToLocations.values()){
            if (locations.contains(locationId)) return true;
        }
        return false;
    }

    public boolean isTaggingProductContext(Long productContextId){
        return taggingProductContexts.contains(productContextId);
    }

    public Set<Long> getTaggingProductContextIds(){
        return taggingProductContexts;
    }


    public Map< Long, Set<Long>> getMapTaggingProductContextToLocations(){
        return mapTaggingProductContextToLocations;
    }

    public long[]  getChannelLocations(){
        return locationIndex.getKeysAsArray();
    }

    public boolean isHiddenChannel(CRSChannel crsChannel){
        if (crsChannel.getDisplayPolicies()==null) return false;
        for (String displayPolicy : crsChannel.getDisplayPolicies()){
            if (displayPolicy.equals(displayPropertiesHiddenChannel)){
                return true;
            }
        }
        return false;
    }

    public Set<CRSChannel> getChannelsByStationId(Long stationId, Long ownerId){
        return stationToContentAvailabilityIndex.getByIndexKey( stationId, ownerId);
    }

    // Used for bulking
    public Set<Long> getStationIds() {
        return stationIndex.getKeys();
    }

    public boolean syntheticChannelStationWhitelistContains(long stationId) {
        return syntheticWhitelistChannelLookup.getByIndexKey(stationId).size()>0;
    }

    public CRSChannel getSyntheticWhitelistChannel(long stationId) {
        Collection<CRSChannel> channels = syntheticWhitelistChannelLookup.getByIndexKey(stationId);
        if (channels.size()==1){
            return Iterables.get(channels, 0);
        } else if (channels.size()==0){
            return null;
        } else {
            // Multiple :(
            List<CRSChannel> listChannels = new ArrayList(channels);
            Collections.sort(listChannels);
            return listChannels.get(0);
        }
    }

    @Required
    public void setTaggingProductContextTitles(String taggingProductContextTitles){
        this.taggingProductContextTitles = Arrays.asList(taggingProductContextTitles.split(","));
        taggingProductContextTitlesLookup = new HashSet<>( );
        for (String title : this.taggingProductContextTitles){
            taggingProductContextTitlesLookup.add(title.toUpperCase());
        }
    }

    @Required
    public void setDisplayPropertiesHiddenChannel(String displayPropertiesHiddenChannel) {
        this.displayPropertiesHiddenChannel = displayPropertiesHiddenChannel;
    }

    @Required
    public void setSyntheticChannelWhitelistLocationId(long locationId) {
        this.syntheticChannelWhitelistLocationId = locationId;
    }

    private static final class TwoPartKey<J,K>{
        private J firstValue;
        private K secondValue;

        public TwoPartKey(J firstValue, K secondValue){
            this.firstValue  = firstValue;
            this.secondValue = secondValue;
        }


        public J getFirstValue() {
            return firstValue;
        }

        public K getSecondValue() {
            return secondValue;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            TwoPartKey<?, ?> that = (TwoPartKey<?, ?>) o;

            if (firstValue != null ? !firstValue.equals(that.firstValue) : that.firstValue != null) return false;
            return !(secondValue != null ? !secondValue.equals(that.secondValue) : that.secondValue != null);

        }

        @Override
        public int hashCode() {
            int result = firstValue != null ? firstValue.hashCode() : 0;
            result = 31 * result + (secondValue != null ? secondValue.hashCode() : 0);
            return result;
        }
    }



}