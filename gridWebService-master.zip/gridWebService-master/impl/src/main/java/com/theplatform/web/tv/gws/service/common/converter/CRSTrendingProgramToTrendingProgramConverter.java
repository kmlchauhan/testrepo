package com.theplatform.web.tv.gws.service.common.converter;

import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import com.theplatform.web.tv.contentresolution.api.objects.TrendingProgram;
import com.theplatform.web.tv.contentresolution.api.objects.TrendingPrograms;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms;
import com.theplatform.web.tv.gws.sirius.repository.ProgramRepository;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CRSTrendingProgramToTrendingProgramConverter {
    private static Logger log = LoggerFactory.getLogger(CRSTrendingProgramToTrendingProgramConverter.class);

    private ProgramRepository crsProgramRepository;
    private CRSProgramToProgramInfoConverter programToProgramInfoConverter;

    public TrendingPrograms convert(CRSTrendingPrograms crsTrendingPrograms, MerlinIdHelper merlinIdHelper, Integer minRankingGroup, Integer maxRankingGroup) {
        TrendingPrograms trendingPrograms = new TrendingPrograms();

        if (crsTrendingPrograms == null) {
            if (log.isDebugEnabled()) {
                log.debug("No CRSTrendingPrograms, returning empty");
            }
            return trendingPrograms;
        }

        List<TrendingProgram> programList = new ArrayList<>(crsTrendingPrograms.getPrograms().size());
        trendingPrograms.setTrendingPrograms(programList);
        trendingPrograms.setRetrievedTime(new Date(crsTrendingPrograms.getRetrievedTime()));
        trendingPrograms.setTimeToLive(crsTrendingPrograms.getTimeToLive());

        for (CRSTrendingProgram crsTrendingProgram : crsTrendingPrograms) {
            TrendingProgram trendingProgram = new TrendingProgram();

            // basic fields
            trendingProgram.setRankingGroup(crsTrendingProgram.getRankingGroup());
            trendingProgram.setTopTrending(crsTrendingProgram.isTopTrending());
            trendingProgram.setScore(crsTrendingProgram.getScore());

            // program info
            Long programId = crsTrendingProgram.getProgramId();
            CRSProgram crsProgram = crsProgramRepository.get(programId);

            if (crsProgram != null) {
                trendingProgram.setProgramId(merlinIdHelper.createProgramId(programId));
                ProgramInfo programInfo = programToProgramInfoConverter.convertCRSProgramToProgramInfo(crsProgram);
                trendingProgram.setTransientProgramInfo(programInfo);
                programList.add(trendingProgram);
            }
            else {
                log.warn("Could not find CRSProgram {}", programId);
            }
        }

        boolean shouldFilterByRankingGroup = (minRankingGroup != null || maxRankingGroup != null) && !programList.isEmpty();
        if (shouldFilterByRankingGroup) {
            filterByRankingGroup(trendingPrograms, minRankingGroup, maxRankingGroup);
        }

        return trendingPrograms;
    }

    private static void filterByRankingGroup(TrendingPrograms trendingPrograms, Integer minRankingGroup, Integer maxRankingGroup){
        List<TrendingProgram> filtered = new ArrayList<>();
        int min = minRankingGroup == null ? 0 : minRankingGroup;
        int max = maxRankingGroup == null ? Integer.MAX_VALUE : maxRankingGroup;
        int rankingGroup;

        for (TrendingProgram tp : trendingPrograms.getTrendingPrograms()){
            rankingGroup = tp.getRankingGroup();
            if (rankingGroup >= min && rankingGroup <= max){
                filtered.add(tp);
            }
        }
        trendingPrograms.setTrendingPrograms(filtered);
    }

    @Required
    public void setCrsProgramRepository(ProgramRepository crsProgramRepository) {
        this.crsProgramRepository = crsProgramRepository;
    }

    @Required
    public void setProgramToProgramInfoConverter(CRSProgramToProgramInfoConverter programToProgramInfoConverter) {
        this.programToProgramInfoConverter = programToProgramInfoConverter;
    }
}
