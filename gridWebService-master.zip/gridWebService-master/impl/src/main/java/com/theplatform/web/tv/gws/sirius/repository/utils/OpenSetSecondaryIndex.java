package com.theplatform.web.tv.gws.sirius.repository.utils;


import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMaps;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;

public class OpenSetSecondaryIndex<V> implements SecondaryIndex<Long, V> {

    protected final Long2ObjectMap<Set<V>> map;

    public OpenSetSecondaryIndex() {
        this(16);
    }

    public OpenSetSecondaryIndex(int expected) {
        this.map = Long2ObjectMaps.synchronize(new Long2ObjectOpenHashMap<Set<V>>());
    }

    protected void createSetIfMissing(Long key) {
        if (map.get(key.longValue()) == null) {
            map.put(key.longValue(), new ObjectOpenHashSet<V>(4));
        }
    }

    @Override
    public void put(Long indexKey, V value) {
        if (indexKey == null) {
            return;
        }

        createSetIfMissing(indexKey);
        map.get(indexKey.longValue()).add(value);
    }

    @Override
    public void remove(Long indexKey, V value) {
        if (indexKey == null) {
            return;
        }

        Set<V> set = map.get(indexKey.longValue());
        if (set!=null && set.contains(value)) {
            set.remove(value);
            if (set.size() == 0) {
                map.remove(indexKey);
            }
        }
    }

    @Override
    public void removeAll(Long indexValue) {
        if (indexValue != null && map.containsKey(indexValue.longValue())) {
            map.put(indexValue.longValue(), null);
        }
    }

    @Override
    public Collection<V> getByIndexKey(Long key) {
        if (key != null && map.containsKey(key.longValue())) {
            Set<V> set = map.get(key.longValue());
            if (set != null && !set.isEmpty()) {
                return set;
            }
        }
        return Collections.emptySet();
    }

    @Override
    public Set<Long> getKeys() {
        return map.keySet();
    }

    public long[] getKeysAsArray() {
        return map.keySet().toLongArray();
    }
}
