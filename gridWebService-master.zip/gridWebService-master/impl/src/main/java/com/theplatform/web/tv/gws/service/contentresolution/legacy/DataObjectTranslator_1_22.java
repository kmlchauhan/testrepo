package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.theplatform.web.tv.contentresolution.api.objects.ApiObjectVisitor;
import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;

public class DataObjectTranslator_1_22 extends ApiObjectVisitor {
    public final static DataObjectTranslator_1_22 INSTANCE = new DataObjectTranslator_1_22();

    @Override
    public void visitProgramInfo(ProgramInfo programInfo) {
        programInfo.setLanguage(null);
    }

}
