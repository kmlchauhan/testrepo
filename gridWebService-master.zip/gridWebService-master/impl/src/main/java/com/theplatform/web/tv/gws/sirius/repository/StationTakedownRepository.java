package com.theplatform.web.tv.gws.sirius.repository;


import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSStationTakedown;
import com.theplatform.web.tv.gws.sirius.repository.utils.JdkCollectionsCompositeKeySecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.OpenSetSecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.SecondaryIndex;

import java.util.Collection;

public class StationTakedownRepository extends LongObjectRepository<CRSStationTakedown> {

    // OwnerId, StationId -> (1-n) CRSStationTakedown
    private final JdkCollectionsCompositeKeySecondaryIndex<Long, Long, CRSStationTakedown> ownerStationIdLookup;


    private final SecondaryIndex<Long, CRSStationTakedown> ownerIdLookup;

    public StationTakedownRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
        ownerStationIdLookup = new JdkCollectionsCompositeKeySecondaryIndex<>();
        ownerIdLookup = new OpenSetSecondaryIndex<>();
    }

    @Override
    public void addToIndexes(CRSStationTakedown stationTakedown) {
        ownerStationIdLookup.put( stationTakedown.getOwnerId(), stationTakedown.getStationId(), stationTakedown);
        ownerIdLookup.put( stationTakedown.getOwnerId(), stationTakedown);
    }

    @Override
    public void removeFromIndexes(CRSStationTakedown stationTakedown) {
        ownerStationIdLookup.remove(stationTakedown.getOwnerId(), stationTakedown.getStationId(), stationTakedown);
        ownerIdLookup.remove( stationTakedown.getOwnerId(), stationTakedown);
    }

    public Collection<CRSStationTakedown> getStationTakedown(Long ownerId, Long stationId){
        return ownerStationIdLookup.getByIndexKey(ownerId, stationId);
    }

    public Collection<CRSStationTakedown> getOwnersStationTakedown(Long ownerId){
        return ownerIdLookup.getByIndexKey( ownerId);
    }


}
