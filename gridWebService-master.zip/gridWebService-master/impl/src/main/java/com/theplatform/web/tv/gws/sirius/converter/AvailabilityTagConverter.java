package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.offer.api.data.objects.AvailabilityTag;
import com.theplatform.web.tv.gws.sirius.model.CRSAvailabilityTag;

public class AvailabilityTagConverter extends AbstractDataObjectConverter<AvailabilityTag, CRSAvailabilityTag> {

    @Override
    public CRSAvailabilityTag convert(AvailabilityTag availabilityTag) {
        CRSAvailabilityTag crsAvailabilityTag = new CRSAvailabilityTag();
        crsAvailabilityTag.setId(LocalUriConverter.convertUriToID(availabilityTag.getId()));
        if (availabilityTag.getNational()!=null){
            crsAvailabilityTag.setNational(availabilityTag.getNational());
        }else{
            crsAvailabilityTag.setNational(false);
        }
        crsAvailabilityTag.setOwnerId(LocalUriConverter.convertUriToID(availabilityTag.getOwnerId()));
        return crsAvailabilityTag;
    }

}
