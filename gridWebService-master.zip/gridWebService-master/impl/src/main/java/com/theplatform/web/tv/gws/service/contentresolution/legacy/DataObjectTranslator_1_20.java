package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.theplatform.web.tv.contentresolution.api.objects.ApiObjectVisitor;

public class DataObjectTranslator_1_20 extends ApiObjectVisitor {
    public final static DataObjectTranslator_1_20 INSTANCE = new DataObjectTranslator_1_20();


}