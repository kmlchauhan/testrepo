package com.theplatform.web.tv.gws.service.contentresolution.episodes;

import com.theplatform.web.tv.gws.sirius.model.CRSProgram;

import java.util.Comparator;

/**
 * This was optimized for readability. There probably is a more efficient way to do this.
 */
public class LegacyEpisodeComparator implements Comparator<CRSProgram> {

    private static final int BEFORE = -1;
    private static final int AFTER = 1;

    @Override
    public int compare(CRSProgram e1, CRSProgram e2) {

        if (!e1.isEpisode() || !e2.isEpisode()) {
            throw new IllegalArgumentException("This comparator should only be used to sort episodes");
        }

        if (!e1.getSeriesId().equals(e2.getSeriesId())) {
            throw new IllegalArgumentException("This comparator should only be used to sort episodes of the same series");
        }

        // episodes with season numbers come before episodes without
        if (e1.hasTvSeasonNumber() && !e2.hasTvSeasonNumber()) {
            return BEFORE;  // (e1 BEFORE e2)
        } else if (!e1.hasTvSeasonNumber() && e2.hasTvSeasonNumber()) {
            return AFTER;
        }

        if (e1.hasTvSeasonNumber() && e2.hasTvSeasonNumber()) {
            if (e1.getTvSeasonNumber() < e2.getTvSeasonNumber()) {
                return BEFORE;
            } else if (e1.getTvSeasonNumber() > e2.getTvSeasonNumber()) {
                return AFTER;
            }
        }

        // at this point, both e1 and e2 have the same or null season number

        // episodes with episode numbers come before episodes without
        if (e1.hasTvSeasonEpisodeNumber() && !e2.hasTvSeasonEpisodeNumber()) {
            return BEFORE;
        } else if (e1.getTvSeasonEpisodeNumber() == null && e2.hasTvSeasonEpisodeNumber()) {
            return AFTER;
        }

        if (e1.hasTvSeasonEpisodeNumber() && e2.hasTvSeasonEpisodeNumber()) {
            if (e1.getTvSeasonEpisodeNumber() < e2.getTvSeasonEpisodeNumber()) {
                return BEFORE;
            } else if (e1.getTvSeasonEpisodeNumber() > e2.getTvSeasonEpisodeNumber()) {
                return AFTER;
            }
        }

        // at this point, both e1 and e2 have the same or null season and episode numbers

        // episodes with part numbers come before episodes without
        if (e1.hasPartNumber() && !e2.hasPartNumber()) {
            return BEFORE;
        } else if (!e1.hasPartNumber() && e2.hasPartNumber()) {
            return AFTER;
        } else if (e1.hasPartNumber() && e2.hasPartNumber() && !e1.getPartNumber().equals(e2.getPartNumber())) {
            return e1.getPartNumber().compareTo(e2.getPartNumber());
        }

        // episodes with episode titles come before episodes without
        if (e1.hasEpisodeTitle() && !e2.hasEpisodeTitle()) {
            return BEFORE;
        } else if (!e1.hasEpisodeTitle() && e2.hasEpisodeTitle()) {
            return AFTER;
        }

        if (e1.hasEpisodeTitle() && e2.hasEpisodeTitle() && !e1.getEpisodeTitle().equals(e2.getEpisodeTitle())) {
            return e1.getEpisodeTitle().compareTo(e2.getEpisodeTitle());
        }

        return Long.valueOf(e1.getId()).compareTo(e2.getId());
    }
}
