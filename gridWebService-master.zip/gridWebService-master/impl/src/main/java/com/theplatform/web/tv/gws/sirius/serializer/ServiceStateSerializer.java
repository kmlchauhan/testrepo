package com.theplatform.web.tv.gws.sirius.serializer;


import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.ServiceStateProto;
import com.theplatform.web.tv.gws.sirius.model.CRSServiceState;

public class ServiceStateSerializer extends AbstractSiriusObjectSerializer<CRSServiceState> {

    public ServiceStateSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSServiceState unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        ServiceStateProto.ServiceStateMessage.Builder message =
                ServiceStateProto.ServiceStateMessage.newBuilder().mergeFrom(bytes);

        CRSServiceState crsServiceState = new CRSServiceState();
        if (message.hasId()){
            crsServiceState.setId(message.getId());
        }
        if (message.hasService()){
            crsServiceState.setService(message.getService());
        }
        if (message.hasContext()){
            crsServiceState.setContext(message.getContext());
        }
        if (message.hasState()){
            crsServiceState.setState(message.getState());
        }
        return crsServiceState;
    }

    @Override
    public ByteString marshallPayload(CRSServiceState crsServiceState) {
        ServiceStateProto.ServiceStateMessage.Builder builder =
                ServiceStateProto.ServiceStateMessage.newBuilder();
        builder.setId(crsServiceState.getId());
        builder.setService(crsServiceState.getService());
        builder.setContext(crsServiceState.getContext());
        builder.setState(crsServiceState.getState());
        return builder.build().toByteString();
    }


}
