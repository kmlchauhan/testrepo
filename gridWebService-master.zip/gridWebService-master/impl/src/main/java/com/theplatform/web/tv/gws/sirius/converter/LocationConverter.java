package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.linear.api.data.objects.Location;
import com.theplatform.data.tv.linear.api.data.objects.LocationType;
import com.theplatform.web.tv.gws.sirius.model.CRSLocation;

public class LocationConverter extends AbstractDataObjectConverter<Location, CRSLocation> {

    @Override
    public CRSLocation convert(Location location) {

        if (!LocationType.ControllerLocation.getFriendlyName().equals(location.getLocationType()))
            return null;

        CRSLocation crsLocation = new CRSLocation();
        crsLocation.setId(LocalUriConverter.convertUriToID(location.getId()));
        if (location.getProductContextId() != null){
            crsLocation.setProductContextId(LocalUriConverter.convertUriToID(location.getProductContextId()));
        }
        if (location.getOwnerId() != null){
            crsLocation.setOwnerId(LocalUriConverter.convertUriToID(location.getOwnerId()));
        }
        if (location.getSource() != null){
            crsLocation.setSource( location.getSource());
        }

        return crsLocation;
    }

}
