package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSStationTakedown extends LongDataRepoObject implements Comparable<CRSStationTakedown>{

    private long ownerId;
    private long expirationDate;
    private long stationId;
    private long placeholderStationId;
    private long locationId;

    public CRSStationTakedown() {
        super( SiriusObjectType.fromFriendlyName("StationTakedown"));
    }

    public CRSStationTakedown(long id) {
        super( SiriusObjectType.fromFriendlyName("StationTakedown"), id);
    }

    public long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(long ownerId) {
        this.ownerId = ownerId;
    }

    public long getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(long expirationDate) {
        this.expirationDate = expirationDate;
    }

    public long getStationId() {
        return stationId;
    }

    public void setStationId(long stationId) {
        this.stationId = stationId;
    }

    public long getPlaceholderStationId() {
        return placeholderStationId;
    }

    public void setPlaceholderStationId(long placeholderStationId) {
        this.placeholderStationId = placeholderStationId;
    }

    public long getLocationId() {
        return locationId;
    }

    public void setLocationId(long locationId) {
        this.locationId = locationId;
    }

    @Override
    public int compareTo(CRSStationTakedown crsStationTakedown) {
        if (this.hashCode() > crsStationTakedown.hashCode()) {
            return 1;
        }
        if (this.hashCode() < crsStationTakedown.hashCode()) {
            return -1;
        }
        return 0;
    }


}

