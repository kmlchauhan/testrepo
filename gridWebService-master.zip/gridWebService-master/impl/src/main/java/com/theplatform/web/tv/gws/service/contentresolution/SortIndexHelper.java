package com.theplatform.web.tv.gws.service.contentresolution;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.TreeMultimap;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.gws.sirius.model.CRSChannel;
import com.theplatform.web.tv.gws.sirius.repository.ChannelRepository;
import com.theplatform.web.tv.gws.sirius.repository.StationCompanyRepository;
import com.theplatform.web.tv.gws.service.common.debug.DebugHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 * Identify any channels with a sortIndexPolicy of ComesBefore:Company:[CompanyID]. Then, identify channels associated
 * to that companyId. If there are multiple channels with the specified Company Id then take the one with the lowest
 * channel number (number not id).  This channel is the target. The 'comes before' channels will have a sort index
 * of one less than the target.  If there are multiple 'comes before' channels for the same target channel then they
 * will each have a unique sort index less than the target and in the order of their channelIds to be deterministic.
 *
 * US31237
 * CMPWM-1271
 */
public class SortIndexHelper {
    private static Logger logger = LoggerFactory.getLogger(SortIndexHelper.class);

    public static final String COMESBEFORE_PREFIX = "ComesBefore:Company:";

    private StationCompanyRepository stationCompanyRepository;
    private ChannelRepository channelRepository;

    /**
     * The sortIndexPolicy we're interested in will be in the following format ComesBefore:Company:<id>
     * This method will parse out the Comapany Id.  If not found then it will return null.
     *
     * @param sortIndexPolicy
     * @return
     */
    protected Long parseCompanyIdFromSortIndexPolicy(String sortIndexPolicy){
        if (sortIndexPolicy==null) return null;
        String suffix = sortIndexPolicy.replace(COMESBEFORE_PREFIX, "");
        try{
            return new Long(suffix);
        }catch (Exception exc){
            logger.error("Unable to extract id from channel with 'comes before' sortIndexPolicy. SortIndexPolicy: " + sortIndexPolicy, exc);
            return null;
        }
    }

    public Long getComesBeforeCompanyId(ChannelInfo channelInfo) {
        CRSChannel crsChannel = channelRepository.get(channelInfo.getChannelId().getId());
        if (crsChannel==null) {
            return null;
        }else{
            String sortIndexPolicy = crsChannel.getSortIndexPolicy();
            if (sortIndexPolicy==null){
                return null;
            } else if (sortIndexPolicy.startsWith(COMESBEFORE_PREFIX)){
                return parseCompanyIdFromSortIndexPolicy(sortIndexPolicy);
            }else {
                return null;
            }
        }

    }

    /**
     *
     *
     */
    public void modifyNhlVirtualChannels( HashMultimap<Long, ChannelInfo> companyToChannelInfos, List<ChannelInfo> allChannelInfos, DebugHelper debugHelper){
        // This will hold the SD Channels mapped to a set of channels that need to come before it.
        // Using a sorted set for the values to keep a deterministic response.
        TreeMultimap<ChannelInfo, ChannelInfo>  targetToComesBeforeChannels = TreeMultimap.create(new ChannelIdComparator(), new ChannelIdComparator(false));

        for (Long companyId : companyToChannelInfos.keySet()){
            ChannelInfo matchedChannelInfo = null;
            Iterator<ChannelInfo> allChannelInfosIter = allChannelInfos.iterator();
            // Check all channels for the company id
            while (allChannelInfosIter.hasNext()){
                ChannelInfo channelInfo = allChannelInfosIter.next();
                boolean channelMatched = stationCompanyRepository.relationShipExists(channelInfo.getStationInfo().getStationId().getId(), companyId);
                if (channelMatched){
                    if (matchedChannelInfo==null){
                        matchedChannelInfo = channelInfo;
                    }else{
                        // We want to place before the lowest channel number
                        if (channelInfo.getNumber() < matchedChannelInfo.getNumber()){
                            matchedChannelInfo = channelInfo;
                        }
                    }

                }
            }
            if (matchedChannelInfo!=null) {
                targetToComesBeforeChannels.putAll( matchedChannelInfo, companyToChannelInfos.get(companyId));
            }
        }

        // Now update the sort index.
        for (ChannelInfo targetChannelInfo : targetToComesBeforeChannels.keySet()){
            int sortIndex = targetChannelInfo.getSortIndex();
            // The ComesBefore Channels are already ordered at this point.
            for (ChannelInfo comesBeforeChannel : targetToComesBeforeChannels.get(targetChannelInfo)){
                sortIndex--;
                comesBeforeChannel.setSortIndex(sortIndex);
            }
        }
   }
    @Required
    public void setStationCompanyRepository(StationCompanyRepository stationCompanyRepository) {
        this.stationCompanyRepository = stationCompanyRepository;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    private static final class ChannelIdComparator implements Comparator<ChannelInfo>{
        final int lessThan;
        final int greaterThan;

        public ChannelIdComparator(){
            this(true);
        }
        public ChannelIdComparator(boolean ascending){
            if (ascending){
                lessThan=-1;
                greaterThan=1;
            }else {
                lessThan=1;
                greaterThan=-1;
            }
        }

        @Override
        public int compare(ChannelInfo o1, ChannelInfo o2) {
            if (o1.getChannelId().getId() < o2.getChannelId().getId()) {
                return lessThan;
            } else if (o1.getChannelId().getId() > o2.getChannelId().getId()) {
                return greaterThan;
            } else {
                return 0;
            }
        }

    }

}
