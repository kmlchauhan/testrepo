/**
 * Classes that produce Events.  The classes in this package should only run on the master r/w node or when
 * bulking.
 */
package com.theplatform.web.tv.gws.ingest.producer;