package com.theplatform.web.tv.gws.ingest.consumer.notifier.check;


import com.comcast.merlin.sirius.ingest.Event;
import com.comcast.merlin.sirius.ingest.Action;
import com.theplatform.web.tv.gws.sirius.model.CRSListing;
import com.theplatform.web.tv.gws.sirius.repository.ListingRepository;
import org.springframework.beans.factory.annotation.Required;

public class ListingCheck implements Check<CRSListing>{

    private ListingRepository listingRepository;

    public boolean shouldPublish(Event<CRSListing> event){
        CRSListing crsListing = null;
        CRSListing oldCrsListing = null;
        if (event.getAction().equals(Action.PUT)){
            crsListing = event.getCrsDataObject();
            oldCrsListing = listingRepository.get(crsListing.getId());
        } else {
            Long id = new Long (event.getKey().getId() );
            oldCrsListing = listingRepository.get(id);

        }
        return ( (crsListing!=null && crsListing.getEndTime()>System.currentTimeMillis())
                ||  (oldCrsListing!=null && oldCrsListing.getEndTime()>System.currentTimeMillis())
                || (crsListing==null &&  oldCrsListing==null) );


    }
    @Required
    public void setListingRepository(ListingRepository listingRepository) {
        this.listingRepository = listingRepository;
    }

}
