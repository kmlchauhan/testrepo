/**
 * Common classes used by both services.
 */
package com.theplatform.web.tv.gws.service.common;