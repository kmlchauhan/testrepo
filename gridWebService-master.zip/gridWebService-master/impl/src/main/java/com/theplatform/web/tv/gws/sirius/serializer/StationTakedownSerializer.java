package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.StationTakedownProto;
import com.theplatform.web.tv.gws.sirius.model.CRSStationTakedown;

public class StationTakedownSerializer extends AbstractSiriusObjectSerializer<CRSStationTakedown> {

    public StationTakedownSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSStationTakedown unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        StationTakedownProto.StationTakedownMessage.Builder message
                = StationTakedownProto.StationTakedownMessage.newBuilder().mergeFrom(bytes);

        CRSStationTakedown stationTakedown = new CRSStationTakedown();

        if (message.hasId()) {
            stationTakedown.setId(message.getId());
        }
        if (message.hasOwnerId()) {
            stationTakedown.setOwnerId(message.getOwnerId());
        }
        if (message.hasExpirationDate()) {
            stationTakedown.setExpirationDate(message.getExpirationDate());
        }
        if (message.hasStationId()) {
            stationTakedown.setStationId(message.getStationId());
        }
        if (message.hasPlaceholderStationId()) {
            stationTakedown.setPlaceholderStationId(message.getPlaceholderStationId());
        }
        if (message.hasLocationId()) {
            stationTakedown.setLocationId(message.getLocationId());
        }
        return stationTakedown;
    }

    @Override
    public ByteString marshallPayload(CRSStationTakedown stationTakedown) {
        StationTakedownProto.StationTakedownMessage.Builder builder
                = StationTakedownProto.StationTakedownMessage.newBuilder();

        builder.setId(stationTakedown.getId());
        builder.setOwnerId(stationTakedown.getOwnerId());
        builder.setExpirationDate(stationTakedown.getExpirationDate());
        builder.setStationId(stationTakedown.getStationId());
        builder.setPlaceholderStationId(stationTakedown.getPlaceholderStationId());
        if (stationTakedown.getLocationId()!=0){
            builder.setLocationId(stationTakedown.getLocationId());
        }

        return builder.build().toByteString();
    }


}
