package com.theplatform.web.tv.gws.service.common.field.descriptor;

import com.theplatform.web.tv.gws.service.common.field.FieldFilteringException;
import io.github.lukehutch.fastclasspathscanner.FastClasspathScanner;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.util.*;

/**
 * Builds an ApiClassDescriptor by recursively reflecting over a Class and all of its properties.
 */
class ApiClassDescriptorBuilder {
    private final static Logger log = LoggerFactory.getLogger(ApiClassDescriptorBuilder.class);
    private final static String GWS_PACKAGE = "com.theplatform.web.tv";
    private final FastClasspathScanner scanner;

    /**
     * Top level API class.  This should be a class returned by {@link com.theplatform.web.tv.contentresolution.api.ContentResolutionService}
     * or {@link com.theplatform.web.tv.backend.api.BackendService}.
     */
    private final Class<?> rootClass;

    /**
     * The classes that have already been visited.  Used to prevent infinite recursion while traversing links between classes.
     */
    private final Set<Class<?>> visited;

    /**
     * Create an ApiClassDescriptorBuilder that inspects the specified Class
     * @param rootClass the Class to inspect
     */
    public ApiClassDescriptorBuilder(Class<?> rootClass) {
        this.rootClass = rootClass;
        this.visited = new HashSet<>();
        this.scanner = new FastClasspathScanner(GWS_PACKAGE).scan();
    }

    /**
     * Inspect the Class and create an ApiClassDescriptor
     * @return a new ApiClassDescriptor instance
     */
    public ApiClassDescriptor build() {
        List<ApiPropertyDescriptor> list = readPropertyDescriptors(StringUtils.EMPTY, rootClass);
        ApiClassDescriptor root = new ApiClassDescriptor(rootClass, list);

        if (log.isTraceEnabled()) {
            log.trace("Built property tree for {}: {}", rootClass.getSimpleName(), root);
        }

        return root;
    }

    /**
     * Create an ApiPropertyDescriptor for each {@link PropertyDescriptor JavaBean property} of
     * the specified Class.
     * @param path the full path (OGNL style) relative to the root object
     * @param clazz the Class to inspect
     * @return a List of ApiPropertyDescriptor (never null)
     */
    private List<ApiPropertyDescriptor> readPropertyDescriptors(String path, Class<?> clazz) {

        // make sure we aren't going in circles.  for example, two classes refer to each other.  note that this
        // would cause a problem for Jackson as well (StackOverflowError).  the solution is to add an @JsonIgnore
        // to prevent loops in the object graph.
        if (this.visited.contains(clazz)) {
            throw new FieldFilteringException("Cycle in the object graph in " + clazz + ": " + path);
        }
        this.visited.add(clazz);

        // using the PropertyDescriptor API rather than reflecting over the Methods of each class ourselves
        // improves the performance of the classes that use ApiPropertyDescriptors for nullification:
        //  * A PropertyDescriptor provides instances of java.lang.Method to read/write a property.
        //  * PropertyUtils caches the PropertyDescriptors for the requested class.
        //  * As a result we end up using the same read/write method for each property.
        //  * The JVM optimizes repeated calls to the same java.lang.Method instance (sun.reflect.inflationThreshold).
        PropertyDescriptor[] descriptors = PropertyUtils.getPropertyDescriptors(clazz);
        List<ApiPropertyDescriptor> properties = new ArrayList<>(descriptors.length);

        // depth first recursion... create children first
        for (PropertyDescriptor current : descriptors) {

            // skip stuff that isn't serializable or nullable.  for example, @JsonIgnore or primitive types.
            if (!isSerializedProperty(current) || current.getReadMethod().getReturnType().isPrimitive()) {
                continue;
            }

            ApiPropertyDescriptor property = readPropertyDescriptor(path, current);
            if (property != null) {
                properties.add(property);
            }
        }

        this.visited.remove(clazz);

        return properties;
    }

    /**
     * Convert a Java PropertyDescriptor to an ApiPropertyDescriptor.  Invokes {@link #readPropertyDescriptors(String, Class)}
     * to create children first.
     * @param parentPath the full path (OGNL style) relative to the root object
     * @param descriptor the descriptor to process
     * @return an ApiPropertyDescriptor created from the Java property descriptor
     */
    private ApiPropertyDescriptor readPropertyDescriptor(String parentPath, PropertyDescriptor descriptor) {

        // if this property is a List<Foo> we want Foo.class, not List.class
        Class<?> propertyType = unwrapCollectionType(descriptor);

        // check if the class associated with this property is subclassed.  for example, if the property is for
        // the type BaseFoo and Foo1 + Foo2 are subclasses of BaseFoo.
        Set<Class<?>> subTypes = subTypesOf(propertyType);
        Map<Class<?>, ApiPropertyDescriptor> subTypeDescriptors = null;
        if (!subTypes.isEmpty()) {
            if (log.isTraceEnabled()) {
                log.trace("Found sub types of {}: {}", propertyType, subTypes);
            }

            subTypeDescriptors = new HashMap<>(subTypes.size());
            for (Class<?> current : subTypes) {
                ApiPropertyDescriptor subDescriptor = createDescriptor(parentPath, current, descriptor, null);
                subTypeDescriptors.put(current, subDescriptor);
            }
        }

        return createDescriptor(parentPath, propertyType, descriptor, subTypeDescriptors);
    }

    /**
     * Find subtypes of the given class or implementations of a given interface
     * @param clazz Class representing a class or interface
     * @return a Set (never null)
     */
    private Set<Class<?>> subTypesOf(Class<?> clazz) {
        List<String> classNames;

        // if the class instance represents an interface, find all implementations of the interface
        if (clazz.isInterface()) {
            classNames = scanner.getNamesOfClassesImplementing(clazz);
        }
        // if the class instance represents a class, find all subclasses
        else {
            classNames = scanner.getNamesOfSubclassesOf(clazz);
        }

        // turn the names returned by the scanner into Class<?> instances
        Set<Class<?>> subTypes = new HashSet<>();
        for (String current : classNames) {
            try {
                Class<?> subType = Class.forName(current);
                subTypes.add(subType);
            }
            catch (ReflectiveOperationException e) {
                throw new FieldFilteringException(e);
            }
        }
        return subTypes;
    }

    /**
     * Create a property descriptor. recursively creating child descriptors first
     * @param parentPath path to the descriptor's parent (relative to the root)
     * @param propertyType unwrapped property type
     * @param descriptor JavaBean property descriptor
     * @param subTypes any subtypes or null if there are no subtypes
     * @return a new ApiPropertyDescriptor
     */
    private ApiPropertyDescriptor createDescriptor(String parentPath, Class<?> propertyType, PropertyDescriptor descriptor, Map<Class<?>, ApiPropertyDescriptor> subTypes) {
        // we're now one level deeper than we were before
        String path = parentPath + descriptor.getName();

        // if this property has child properties descend into the children first
        ApiPropertyDescriptor apiPropertyDescriptor;
        if (hasNestedProperties(propertyType)) {
            List<ApiPropertyDescriptor> children = readPropertyDescriptors(path + ".", propertyType);
            apiPropertyDescriptor = new ApiPropertyDescriptor(propertyType, path, subTypes, children, descriptor);
        }
        // it's a simple/terminal property.  for example, something like String, Integer, or CRSUri
        else {
            apiPropertyDescriptor = new ApiPropertyDescriptor(propertyType, path, subTypes, null, descriptor);
        }

        return apiPropertyDescriptor;
    }

    /**
     * If the PropertyDescriptor is for a Collection extract the generic type.  If it's for an array, extract
     * the element type.  Otherwise,return the actual type associated with the descriptor.  For example, if
     * the PropertyDescriptor represents <code>List&lt;Foo&gt;</code> this method returns <code>Foo.class</code>.
     * @param current JavaBean PropertyDescriptor
     * @return the generic or array component type associated with the PropertyDescriptor or the actual type of the descriptor if
     *         no generics or arrays are involved.
     */
    private Class<?> unwrapCollectionType(PropertyDescriptor current) {

        // for List<Foo> the PropertyDescriptor would show List.class as the type
        Class<?> beanPropertyType = current.getPropertyType();

        // assume for now that the type is what the PropertyDescriptor says and we don't need to unwrap anything
        Class<?> unwrappedType = beanPropertyType;

        // if it's a Collection figure out the object type contained in the Collection
        if (Collection.class.isAssignableFrom(beanPropertyType)) {
            Method readMethod = current.getReadMethod();
            ParameterizedType genericReturnType = (ParameterizedType) readMethod.getGenericReturnType();

            if (genericReturnType != null && ArrayUtils.isNotEmpty(genericReturnType.getActualTypeArguments())) {
                unwrappedType = (Class<?>) genericReturnType.getActualTypeArguments()[0];

                if (log.isTraceEnabled()) {
                    log.trace("Unwrapped {}<{}> to {} for {}", beanPropertyType.getSimpleName(), unwrappedType.getSimpleName(), unwrappedType.getSimpleName(), current.getName());
                }
            }
            else {
                log.warn("Failed to determine generic type for {}", readMethod);
            }
        }
        // if it's an array, get the component type
        else if (beanPropertyType.isArray()) {
            unwrappedType = beanPropertyType.getComponentType();

            if (log.isTraceEnabled()) {
                log.trace("Unwrapped {} to {} for {}", beanPropertyType.getSimpleName(), unwrappedType.getSimpleName(), current.getName());
            }
        }

        return unwrappedType;
    }

    /**
     * Check if a PropertyDescriptor represents a property that will be serialized.
     * @param descriptor a PropertyDescriptor
     * @return true if the Class is serializable
     */
    private boolean isSerializedProperty(PropertyDescriptor descriptor) {
        boolean serializable = true;

        // filter out properties with mismatched getters/setters
        if (descriptor.getReadMethod() == null || descriptor.getWriteMethod() == null || descriptor.getPropertyType() == null) {
            serializable = false;
        }
        // filter out stuff like Object.getClass()
        else if (!descriptor.getReadMethod().getDeclaringClass().getName().startsWith(GWS_PACKAGE)) {
            serializable = false;
        }
        // if it's annotated with @JsonIgnore it won't be serialized.  check for either the Jackson 1 or Jackson 2 version of the annotation
        else if (descriptor.getReadMethod().isAnnotationPresent(com.fasterxml.jackson.annotation.JsonIgnore.class) ||
            descriptor.getReadMethod().isAnnotationPresent(org.codehaus.jackson.annotate.JsonIgnore.class)) {

            if (log.isTraceEnabled()) {
                log.trace("Skipping property '{}' because of @JsonIgnore", descriptor.getName());
            }

            serializable = false;
        }

        return serializable;
    }

    /**
     * Check if a PropertyDescriptor of the specified type has child properties.
     * @param propertyType unwrapped property type
     * @return true if a PropertyDescriptor of the specified type has child properties
     */
    private boolean hasNestedProperties(Class<?> propertyType) {
        // don't descend into nested properties of built in types.  if the propertyType is something like FooBarInfo.class
        // we want to include its child properties but if something like String.class we don't want to scan it for getters/setters
        if (!propertyType.getName().startsWith(GWS_PACKAGE)) {
            return false;
        }

        PropertyDescriptor[] descriptors = PropertyUtils.getPropertyDescriptors(propertyType);

        // no properties
        if (ArrayUtils.isEmpty(descriptors)) {
            return false;
        }

        // if any methods are annotated with @JsonValue it doesn't have nested properties.  this annotation indicates
        // that a single method on the Class is designated as the value that will appear in the JSON.  for example, CRSUri
        for (PropertyDescriptor current : descriptors) {
            Method readMethod = current.getReadMethod();
            if (readMethod != null) {
                if (readMethod.getAnnotation(com.fasterxml.jackson.annotation.JsonValue.class) != null ||
                    readMethod.getAnnotation(org.codehaus.jackson.annotate.JsonValue.class) != null) {
                    return false;
                }
            }
        }

        return true;
    }
}
