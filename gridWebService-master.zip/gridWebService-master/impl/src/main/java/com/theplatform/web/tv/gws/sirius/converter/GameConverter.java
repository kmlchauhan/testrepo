package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.sports.api.data.objects.Game;
import com.theplatform.web.tv.gws.sirius.model.CRSGame;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

public class GameConverter extends AbstractDataObjectConverter<Game, CRSGame> {

    @Override
    public CRSGame convert(Game game) {
        Long id = LocalUriConverter.convertUriToID(game.getId());
        List<Long> listingIds = new ArrayList<>(game.getListingIds().size());

        for (URI listingId : game.getListingIds()) {
            listingIds.add(LocalUriConverter.convertUriToID(listingId));
        }

        boolean liveCoverageAvailable = false;
        if (game.getLiveCoverageAvailable()!=null && game.getLiveCoverageAvailable()){
            liveCoverageAvailable = true;
        }

        return new CRSGame(id, listingIds, liveCoverageAvailable);
    }


}
