/**
 * Classes to create {@link com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms CRSTrendingPrograms} Events
 * at a regular and configurable interval.
 */
package com.theplatform.web.tv.gws.ingest.producer.twitter;