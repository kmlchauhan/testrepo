package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CRSStationModifier extends LongDataRepoObject {
    private long stationId;
    private long ownerId;

    // For easier lookup we will map Type (Yes, String not Enum)   -l
    private Map<String,Set<Long>> relatedStations;

    public CRSStationModifier(long id){
        super( SiriusObjectType.fromFriendlyName("StationModifier"), id);
        relatedStations = new HashMap<>();
    }

    public void setStationId(long stationId) {
        this.stationId = stationId;
    }

    public long getStationId() {
        return stationId;
    }

    public long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(long ownerId) {
        this.ownerId = ownerId;
    }

    public void setRelatedStations(Map<String,Set<Long>> relatedStations){
        this.relatedStations =relatedStations;
    }

    /**
     * This will return a set of relatedStations for a given type
     * It WILL return null if none exist.
     *
     * @param type String representing RelatedStationType (enum not used on purpose)
     */
    public Set<Long> getRelatedStations(String type){
        return relatedStations.get(type);
    }

    public Map<String,Set<Long>> getRelatedStations(){
        return relatedStations;
    }

    @JsonIgnore
    public Set<String> getRelatedStationsTypes(){
        return relatedStations.keySet();
    }


}
