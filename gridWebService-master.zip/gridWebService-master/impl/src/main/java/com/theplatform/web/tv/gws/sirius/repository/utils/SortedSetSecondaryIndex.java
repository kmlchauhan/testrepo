package com.theplatform.web.tv.gws.sirius.repository.utils;

import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import com.google.common.base.Supplier;
import com.google.common.collect.Multimaps;

/**
 * Secondary index based on SetMultimap. Uses a ConcurrentHashMap for the map part,
 * and a TreeSet for the set part.
 *
 * Per how Multimaps work, this guy isn't thread safe. We haven't seen troubles
 * yet... As we don't do concurrent writes, I think reads should be safe enough,
 * maybe inconsistent on occasion.  Making this object properly thread safe
 * would require synchronizing all of AbstractSetSecondaryIndex's methods.
 *
 * To extend on above, and why don't we just make the Multimap a "synchronizedMultimap",
 * it appears that the "sychronizedMultimap" globally locks the collection when
 * performing any operations, which for a globally shared data structure which will
 * likely see a lot of traffic, is probably undesirable.
 *
 * @param <K>
 *            value of the field being indexed
 * @param <V>
 *            object to index
 */
public class SortedSetSecondaryIndex<K, V extends Comparable<V>> extends
        AbstractSetSecondaryIndex<K, V> {

    // I was at this ETE talk about how this pattern is replaced by another language,
    //  I forget which one
    private final Supplier<TreeSet<V>> setSupplier;

    public SortedSetSecondaryIndex(final Comparator<V> comparator) {
        this.setSupplier = new Supplier<TreeSet<V>>() {
            public TreeSet<V> get() {
                return new TreeSet<V>(comparator);
            }
        };
        indexMap = Multimaps.newSetMultimap(new ConcurrentHashMap<K, Collection<V>>(), setSupplier);
    }
    
    public SortedSetSecondaryIndex() {
        this.setSupplier = new Supplier<TreeSet<V>>() {
            public TreeSet<V> get() {
                return new TreeSet<V>();
            }
        };
        indexMap = Multimaps.newSetMultimap(new ConcurrentHashMap<K, Collection<V>>(), setSupplier);
    }

    public static final class CompositeKey<K1, K2>{
        private K1 value1;
        private K2 value2;
        public CompositeKey(K1 value1, K2 value2){
            this.value1 = value1;
            this.value2 = value2;
        }

        @Override
        public boolean equals(Object other){
            if (!(other instanceof CompositeKey)) return false;
            CompositeKey otherCK = (CompositeKey) other;
            if (!otherCK.value1.equals(value1)) return false;
            if (!otherCK.value2.equals(value2)) return false;
            return true;
        }

        @Override
        public int hashCode(){
            return value1.hashCode() + 31 * value2.hashCode();
        }
    }


}
