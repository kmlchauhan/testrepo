package com.theplatform.web.tv.gws.service.common.field;

import com.theplatform.web.tv.gws.service.common.field.nullification.NullificationMode;

public class PlanCacheKey {
    private final Class<?> clazz;
    private final NullificationMode mode;
    private final String props1;
    private final String props2;

    public PlanCacheKey(Class<?> clazz, NullificationMode mode, String props1) {
        this(clazz, mode, props1, null);
    }

    public PlanCacheKey(Class<?> clazz, NullificationMode mode, String props1, String props2) {
        this.clazz = clazz;
        this.mode = mode;
        this.props1 = props1;
        this.props2 = props2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PlanCacheKey that = (PlanCacheKey) o;

        if (!clazz.equals(that.clazz)) return false;
        if (mode != that.mode) return false;
        if (props1 != null ? !props1.equals(that.props1) : that.props1 != null)
            return false;
        return props2 != null ? props2.equals(that.props2) : that.props2 == null;

    }

    @Override
    public int hashCode() {
        int result = clazz.hashCode();
        result = 31 * result + mode.hashCode();
        result = 31 * result + (props1 != null ? props1.hashCode() : 0);
        result = 31 * result + (props2 != null ? props2.hashCode() : 0);
        return result;
    }
}
