package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.linear.api.data.objects.StationCompany;
import com.theplatform.web.tv.gws.sirius.model.CRSStationCompany;

public class StationCompanyConverter extends AbstractDataObjectConverter<StationCompany, CRSStationCompany> {
    @Override
    public CRSStationCompany convert(StationCompany stationCompany) {
        CRSStationCompany crsStationCompany = new CRSStationCompany(LocalUriConverter.convertUriToID(stationCompany.getId()));
        crsStationCompany.setStationId( LocalUriConverter.convertUriToID(stationCompany.getStationId()) );
        crsStationCompany.setCompanyId( LocalUriConverter.convertUriToID(stationCompany.getCompanyId()) );
        if (stationCompany.getAssociationType()!=null && stationCompany.getAssociationType().length()>0) {
            crsStationCompany.setAssociationType(stationCompany.getAssociationType());
        }
        return crsStationCompany;
    }


}
