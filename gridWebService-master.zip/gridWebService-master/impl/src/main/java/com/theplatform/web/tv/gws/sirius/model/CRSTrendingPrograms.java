package com.theplatform.web.tv.gws.sirius.model;


import com.comcast.merlin.sirius.model.RepositoryObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import org.apache.commons.collections.IteratorUtils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CRSTrendingPrograms extends RepositoryObject implements Iterable<CRSTrendingProgram> {
    protected long retrievedTime;
    protected long timeToLive;
    protected List<CRSTrendingProgram> programs = new ArrayList<>();

    public CRSTrendingPrograms() {
        super(SiriusObjectType.fromFriendlyName("TrendingPrograms"));
    }

    public long getRetrievedTime() {
        return retrievedTime;
    }

    public void setRetrievedTime(long retrievedTime) {
        this.retrievedTime = retrievedTime;
    }

    public long getTimeToLive() {
        return timeToLive;
    }

    public void setTimeToLive(long timeToLive) {
        this.timeToLive = timeToLive;
    }

    public List<CRSTrendingProgram> getPrograms() {
        return programs;
    }

    public void setPrograms(List<CRSTrendingProgram> programs) {
        this.programs = programs;
    }

    @Override
    public Iterator<CRSTrendingProgram> iterator() {
        if (programs != null) {
            return programs.iterator();
        }
        else {
            return IteratorUtils.emptyIterator();
        }
    }
}
