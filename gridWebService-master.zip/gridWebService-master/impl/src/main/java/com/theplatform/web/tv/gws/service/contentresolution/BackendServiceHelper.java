package com.theplatform.web.tv.gws.service.contentresolution;

import com.theplatform.contrib.data.api.objects.*;
import com.theplatform.module.exception.*;
import com.theplatform.web.tv.*;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import com.theplatform.web.tv.gws.service.common.converter.*;
import com.theplatform.web.tv.gws.service.common.debug.*;
import com.theplatform.web.tv.gws.service.common.logic.productcontext.*;
import com.theplatform.web.tv.gws.service.common.util.*;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.sirius.repository.*;
import com.theplatform.web.tv.gws.uri.*;
import org.apache.commons.collections.*;
import org.springframework.beans.factory.annotation.*;

import java.util.*;

public class BackendServiceHelper {

    ProductContextLogic productContextLogic;

    private ChannelRepository channelRepository;
    private StreamRepository streamRepository;
    private LocationRepository locationRepository;

    private CRSChannelToChannelInfoConverter crsChannelToChannelInfoConverter;
    private CRSProductContextToProductContextInfoConverter crsProductContextToProductContextInfoConverter;
    private CRSLocatorToLocatorInfoConverter crsLocatorToLocatorInfoConverter;

    private DynamicProperties dynamicProperties;

    private MerlinIdHelper merlinIdHelper;
    private OwnerUtil ownerUtil;

    private TakedownHelper takedownHelper;

    private DebugHelper debugHelper;


    public ChannelInfoCollection getChannelsByAvailabilityId(Muri channelsAvailabilityId) throws GridException {
        long locationId = channelsAvailabilityId.getId();
        long ownerId = ownerUtil.getOwnerIdFromLocation(locationId);

        Collection<CRSChannel> crsChannelsCollection = channelRepository.getByLocationId(locationId);

        List<ChannelInfo> channelInfos = new ArrayList<>();
        for(CRSChannel channel : crsChannelsCollection){
            // Strip out any hidden channels
            if (channelRepository.isHiddenChannel(channel)) continue;

            Set<Long> productContexts = productContextLogic.getProductContextMapping(channel,ownerId);
            if ( !CollectionUtils.isEmpty(productContexts)){
                ChannelInfo channelInfo =
                        crsChannelToChannelInfoConverter.convert( channel,
                                merlinIdHelper,
                                null);
                List<ProductContextInfo> productContextInfos =
                        crsProductContextToProductContextInfoConverter.convert(productContexts);
                channelInfo.getStationInfo().setProductContextList(productContextInfos);
                channelInfos.add(channelInfo);
            }
        }

        Collections.sort(channelInfos, CRSChannelToChannelInfoConverter.CHANNEL_ORDER);

        channelInfos = takedownHelper.takedownBlacklistedStations(ownerId,channelInfos);

        ChannelInfoCollection channelInfoCollection = new ChannelInfoCollection();
        channelInfoCollection.setChannels(channelInfos);

        return debugHelper.applyWarnings(channelInfoCollection);
    }

    public LocatorInfoCollection getLocatorsByRegion(String region) throws GridException {
        if (region == null)
            throw new BadParameterException("region is required");
        Collection<CRSStream> crsStreams = streamRepository.getByTitlePrefix(region);
        Set<LocatorInfo> uniqueLocatorInfos = new HashSet<>();
        for (CRSStream crsStream : crsStreams){
            uniqueLocatorInfos.addAll(crsLocatorToLocatorInfoConverter.getIpLocators(crsStream));
        }
        ArrayList<LocatorInfo> locatorInfos = new ArrayList<>(uniqueLocatorInfos);
        Collections.sort(locatorInfos);

        LocatorInfoCollection locatorInfoCollection = new LocatorInfoCollection();
        locatorInfoCollection.setLocatorInfos(locatorInfos);

        return locatorInfoCollection;
    }

    public IdCollection getChannelAvailabilityIds() throws GridException {
        IdCollection idCollection = new IdCollection();

        long[] locationIds = channelRepository.getChannelLocations();
        Arrays.sort(locationIds);

        Collection<Set<Long>> taggingLocations = channelRepository.getMapTaggingProductContextToLocations().values();
        Set<Long> locationsLookup = new HashSet <>();
        for (Set<Long> values : taggingLocations){
            locationsLookup.addAll(values);
        }

        boolean filterGracenoteLocation = dynamicProperties.get(DynamicProperties.DynamicPropertiesEnum.GRACENOTE_LOCATION_FILTER).equals("true");

        for (Long locationId : locationIds){
            // Filter out Tagging Locations AND Gracenote Locations.
            if (! locationsLookup.contains(locationId) ){
                if ( !filterGracenoteLocation || !locationRepository.isGracenoteLocation(locationId) ) {
                    idCollection.getIds().add(merlinIdHelper.createLocationId(locationId));
                }
            }
        }
        return idCollection;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }

    @Required
    public void setStreamRepository(StreamRepository streamRepository) {
        this.streamRepository = streamRepository;
    }

    @Required
    public void setCrsChannelToChannelInfoConverter(CRSChannelToChannelInfoConverter crsChannelToChannelInfoConverter) {
        this.crsChannelToChannelInfoConverter = crsChannelToChannelInfoConverter;
    }

    @Required
    public void setCrsProductContextToProductContextInfoConverter(CRSProductContextToProductContextInfoConverter crsProductContextToProductContextInfoConverter) {
        this.crsProductContextToProductContextInfoConverter = crsProductContextToProductContextInfoConverter;
    }

    @Required
    public void setProductContextLogic(ProductContextLogic productContextLogic) {
        this.productContextLogic = productContextLogic;
    }

    @Required
    public void setOwnerUtil(OwnerUtil ownerUtil) {
        this.ownerUtil = ownerUtil;
    }

    @Required
    public void setDebugHelper(DebugHelper debugHelper) {
        this.debugHelper = debugHelper;
    }

    @Required
    public void setTakedownHelper(TakedownHelper takedownHelper) {
        this.takedownHelper = takedownHelper;
    }

    @Required
    public void setCrsLocatorToLocatorInfoConverter(CRSLocatorToLocatorInfoConverter crsLocatorToLocatorInfoConverter) {
        this.crsLocatorToLocatorInfoConverter = crsLocatorToLocatorInfoConverter;
    }

    @Required
    public void setLocationRepository(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }

    @Required
    public void setDynamicProperties(DynamicProperties dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }
}
