package com.theplatform.web.tv.gws.service.common.util;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MiscUtil {
    public static Set parseCsvLongs(String csv){
        Set<Long> set = new HashSet<>();
        if (csv==null) return set;
        if (csv!=null && csv.length()>0){
            String ids[] = csv.split(",");
            for (String id : ids){
                set.add(Long.parseLong(id));
            }
        }
        return set;
    }

    /**
     *   Union of Sets
     */
    public static Set<Long> union(Collection<Set<Long>> collectionOfSet){
        Set<Long> union = new TreeSet<>();
        for (Set<Long> set : collectionOfSet){
            union.addAll(set);
        }
        return union;
    }

    public static Long longFromCombineOwnerId(String combineOwnerId){
        Long comcastId = null;
        String regex = ".*/([0-9]+)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(combineOwnerId);
        if (matcher.find()){
            String id = matcher.group(1);
            comcastId = Long.valueOf(id);
        }
        return comcastId;
    }


}
