package com.theplatform.web.tv.gws.sirius.repository.utils;

import com.google.common.collect.SetMultimap;

import java.util.Collections;
import java.util.Set;

/**
 * Secondary index based on SetMultimap.
 *
 * @param <K> value of the field being indexed
 * @param <V> object to index
 */
abstract public class AbstractSetSecondaryIndex<K,V> implements SecondaryIndex<K, V> {

    protected SetMultimap<K, V> indexMap;


    /**
     * Adds or replaces an object in the index.
     */
    @Override
    public void put(K indexValue, V object) {

        if (SiriusDataUtils.hasValue(indexValue)) {
            SiriusDataUtils.addOrReplace(indexValue, object, indexMap);
        }
    }

    /**
     * Remove an object from the index
     */
    @Override
    public void remove(K indexValue, V object) {

        if (SiriusDataUtils.hasValue(indexValue)) {
            indexMap.remove(indexValue, object);
        }
    }

    /**
     * Remove all
     */
    @Override
    public void removeAll(K indexValue) {
        if (SiriusDataUtils.hasValue(indexValue)) {
            indexMap.removeAll(indexValue);
        }
    }

    /**
     * Returns all the objects associated with a key,
     * or empty set if nothing is associated.
     */
    @Override
    public Set<V> getByIndexKey(K key) {
        // XXX: this SiriusDataUtils seems a bit strange...
        return (SiriusDataUtils.hasValue(key)) ? indexMap.get(key) : Collections.<V>emptySet();
    }

    @Override
    public Set<K> getKeys() {
       return indexMap.keySet();
    }
}
