package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSProgramTeamAssociation extends LongDataRepoObject {
    private final long programId;
    private final long sportsTeamId;

    public CRSProgramTeamAssociation(long id, long programId, long sportsTeamId) {
        super( SiriusObjectType.fromFriendlyName("ProgramTeamAssociation") , id);

        this.programId = programId;
        this.sportsTeamId = sportsTeamId;
    }

    public long getProgramId() {
        return programId;
    }

    public long getSportsTeamId() {
        return sportsTeamId;
    }
}
