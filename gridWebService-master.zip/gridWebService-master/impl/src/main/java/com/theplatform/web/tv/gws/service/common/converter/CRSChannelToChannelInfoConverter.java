package com.theplatform.web.tv.gws.service.common.converter;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.contrib.stats.StatsCollector;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;
import com.theplatform.web.tv.gws.sirius.model.CRSChannel;
import com.theplatform.web.tv.gws.sirius.model.CRSStation;
import com.theplatform.web.tv.gws.uri.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static java.lang.System.currentTimeMillis;

public class CRSChannelToChannelInfoConverter {
    private static Logger logger = LoggerFactory.getLogger(CRSChannelToChannelInfoConverter.class);

    // Default multiplier used to calculate the SortIndex from the Channel Number
    public static final int SORT_INDEX_MULTIPLIER = 10;

    private CRSStationToStationInfoConverter crsStationToStationInfoConverter;
    private LongObjectRepository<CRSStation> stationRepository;

    private AccountIdHelper accountIdHelper;

    /**
     * Order
     *  Ascending SortIndex; Ascending ChannelId
     */
    public static final Comparator<ChannelInfo> CHANNEL_ORDER = new Comparator<ChannelInfo>() {
        public int compare(ChannelInfo a, ChannelInfo b) {
            int result = a.getSortIndex() - b.getSortIndex();
            if (result == 0) {
                if (a.getChannelId().getId()<b.getChannelId().getId()){
                    return -1;
                } else if (a.getChannelId().getId()>b.getChannelId().getId()){
                    return 1;
                }
                else {
                    return 0;
                }
            }
            return result;
        }
    };

    /**
     * Convert a CRSChannel to a ChannelInfo Object
     *
     * @param crsChannel                Source CRSChannel
     * @param merlinIdHelper            For converting to requested ID Forms (e.g. CURN, URL)
     * @param recorderManagerUri        Can be null
     * @return
     */
    public ChannelInfo convert( CRSChannel crsChannel
                              , MerlinIdHelper merlinIdHelper
                              , URI recorderManagerUri){
        ChannelInfo channelInfo = new ChannelInfo();

        long convertStationInfoStartTime = currentTimeMillis();
        CRSStation crsStation = stationRepository.get(crsChannel.getStationId());
        String recorderManager = (recorderManagerUri==null) ? null : recorderManagerUri.toString();
        StationInfo stationInfo = crsStationToStationInfoConverter.convert(crsStation, merlinIdHelper, recorderManager);

        channelInfo.setChannelId(merlinIdHelper.createChannelId(crsChannel.getId()));

        // Channel's OCS if it exists, otherwise Station's
        if (crsChannel.getOnScreenCallsign() != null) {
            channelInfo.setOnScreenCallsign(crsChannel.getOnScreenCallsign());
        }else if (crsStation !=null ){
            channelInfo.setOnScreenCallsign(crsStation.getOnScreenCallSign());
        }

        channelInfo.setStationInfo(stationInfo);
        if (crsChannel.getEmergencyAlertSystemType() != null) {
            channelInfo.setEmergencyAlertSystemType(crsChannel.getEmergencyAlertSystemType());
        }
        else if (crsStation != null) {
            channelInfo.setEmergencyAlertSystemType(crsStation.getEmergencyAlertSystemType());
        }

        if (!crsChannel.isIpDeliveryOnly()) {
            // Channel's Digicable ID  if it exists, otherwise Station's
            if (crsChannel.getDigicableId() != 0) {
                channelInfo.setDigicableId(crsChannel.getDigicableId());
            } else if (crsStation != null && crsStation.getDigicableId() != 0) {
                channelInfo.setDigicableId(crsStation.getDigicableId());
            }
        }

        channelInfo.setSdv( crsChannel.getSdv());
        channelInfo.setSdvTimeout( crsChannel.getSdvTimeout());

        channelInfo.setNumber(crsChannel.getChannelNumber());
        channelInfo.setDisplayPolicies(crsChannel.getDisplayPolicies());
        // This is the default and can be overridden elsewhere
        channelInfo.setSortIndex(calculateSortIndex(channelInfo));
        channelInfo.setOwnerId( accountIdHelper.createId(crsChannel.getOwnerId()));
        channelInfo.setIpDeliveryOnly(crsChannel.isIpDeliveryOnly());

        return channelInfo;
    }

    public static int calculateSortIndex(ChannelInfo channelInfo) {
        return SORT_INDEX_MULTIPLIER * channelInfo.getNumber();
    }

    @Required
    public void setCrsStationToStationInfoConverter(CRSStationToStationInfoConverter crsStationToStationInfoConverter) {
        this.crsStationToStationInfoConverter = crsStationToStationInfoConverter;
    }

    @Required
    public void setStationRepository(LongObjectRepository<CRSStation> stationRepository) {
        this.stationRepository = stationRepository;
    }

    @Required
    public void setAccountIdHelper(AccountIdHelper accountIdHelper) {
        this.accountIdHelper = accountIdHelper;
    }
}