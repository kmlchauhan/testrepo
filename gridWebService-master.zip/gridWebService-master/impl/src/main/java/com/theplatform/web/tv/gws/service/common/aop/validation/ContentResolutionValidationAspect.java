package com.theplatform.web.tv.gws.service.common.aop.validation;

import com.comcast.compass.availability.common.domain.Availabilities;
import com.theplatform.module.exception.BadParameterException;
import com.theplatform.web.tv.gws.service.common.logic.ScopedAvailabilities;
import com.theplatform.web.tv.gws.service.common.logic.Scope;

import java.util.Arrays;
import java.util.List;

/**
 * Created by jcoelho on 5/22/13.
 */
public abstract class ContentResolutionValidationAspect {

    private static final List<String> SUPPORTED_SCOPES = Arrays.asList("station", "channel", "stream", "vod");

    public void validateRequest(ScopedAvailabilities scopedAvailabilities) throws Throwable {

        if (scopedAvailabilities.getAvailabilityResolution() == null)
            throw new BadParameterException("Missing Availaibilty Resolution");

        validateRequestParams(scopedAvailabilities);
    }

    private static void validateRequestParams(ScopedAvailabilities scopedAvailabilities) {
        validateAvailabilitiesHavingStationScopeHasProductContext(scopedAvailabilities);
        validateAllAvailabilitiesHaveContentAndSupportedScope(scopedAvailabilities);
    }

    private static void validateAllAvailabilitiesHaveContentAndSupportedScope(ScopedAvailabilities scopedAvailabilities) {
        for (Availabilities availabilities : scopedAvailabilities.getAllAvailabilityGroups()) {
            if (isSupportedScope(availabilities.getScope())) {
                if (availabilities.getAvailabilityIds().size() == 0)
                    throw new BadParameterException("All availabilities elements must have content.");
            }
        }
    }

    private static void validateAvailabilitiesHavingStationScopeHasProductContext(ScopedAvailabilities scopedAvailabilities) {
        for (Availabilities availabilities : scopedAvailabilities.getStationAvailabilities())
            if (availabilities.getProductContext() == null)
                throw new BadParameterException("An availabilities tag of scope STATION does not have a product context.  A product context is required.");
    }

    protected static void validateAvailabilitiesGroupHasScopes(ScopedAvailabilities scopedAvailabilities, Scope... scopes) {
        for (Scope scope : scopes) {
            if (!scopedAvailabilities.hasScope(scope))
                throw new BadParameterException("An availabilities tag of scope " + scope + " is required.");
        }
    }

    static private boolean isSupportedScope(String scope) {
        return SUPPORTED_SCOPES.contains(scope.toLowerCase());
    }
}
