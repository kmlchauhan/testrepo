package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.web.tv.gws.sirius.repository.utils.*;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CRSContentAvailability extends LongDataRepoObject implements Comparable<CRSContentAvailability> {

    public static final int CONTENT_TYPE_STREAM = 0;
    public static final int CONTENT_TYPE_STATION = 1;
    public static final int CONTENT_TYPE_LOCATOR = 2;

    private long contentId;
    private long availabilityId;
    private CanonicalIds productContexts;

    private long ownerId;
    private int contentType;

    public CRSContentAvailability() {
        super( SiriusObjectType.fromFriendlyName("ContentAvailability") );
    }

    public CRSContentAvailability(long id) {
        super( SiriusObjectType.fromFriendlyName("ContentAvailability") , id);
    }

    public long getContentId() {
        return contentId;
    }

    public void setContentId(long contentId) {
        this.contentId = contentId;
    }

    public long getAvailabilityId() {
        return availabilityId;
    }

    public void setAvailabilityId(long availabilityId) {
        this.availabilityId = availabilityId;
    }

    public Set<Long> getProductContextIds() {
        return productContexts.getLongIds();
    }

    public void setProductContextIds(CanonicalIds productContexts) {
        this.productContexts = productContexts;
    }

    public long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(long ownerId) {
        this.ownerId = ownerId;
    }

    public int getContentType() {
        return contentType;
    }

    public void setContentType(int contentType) {
        this.contentType = contentType;
    }

    @Override
    public int compareTo(CRSContentAvailability contentAvailability) {
        if (this.hashCode() > contentAvailability.hashCode()) {
            return 1;
        }
        if (this.hashCode() < contentAvailability.hashCode()) {
            return -1;
        }
        return 0;
    }

}
