package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSCompany extends LongDataRepoObject implements Comparable<CRSCompany> {
    private String displayName;
    private String title;

    public CRSCompany() {
        super( SiriusObjectType.fromFriendlyName("Company") );
    }

    public CRSCompany(long id) {
        super( SiriusObjectType.fromFriendlyName("Company"), id);
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public int compareTo(CRSCompany that) {
        if (this.hashCode() > that.hashCode()) {
            return 1;
        }
        if (this.hashCode() < that.hashCode()) {
            return -1;
        }
        return 0;
    }

}
