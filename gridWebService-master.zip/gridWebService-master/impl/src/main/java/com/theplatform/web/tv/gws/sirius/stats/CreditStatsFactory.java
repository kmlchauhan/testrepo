package com.theplatform.web.tv.gws.sirius.stats;

import com.comcast.merlin.data.notification.count.NotificationCountClient;
import com.comcast.merlin.sirius.ingest.IngestMode;
import com.comcast.merlin.sirius.ingest.consumer.replay.NotificationRepositoryWriter;
import com.comcast.merlin.sirius.ingest.dispatcher.SiriusEventDispatcher;
import com.comcast.merlin.sirius.ingest.producer.dataservice.DataObjectReceiverImpl;
import com.comcast.merlin.sirius.ingest.producer.dataservice.notification.DataServiceNotificationListener;
import com.comcast.merlin.sirius.ingest.stats.DataServiceCountProvider;
import com.comcast.merlin.sirius.ingest.stats.DataServiceStatsFactory;
import com.comcast.merlin.sirius.ingest.stats.IngestStat;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.NotificationSequenceRepository;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.web.tv.gws.ingest.maintainer.CreditRepositoryMaintainer;

import java.net.URISyntaxException;

public class CreditStatsFactory extends DataServiceStatsFactory {

    private final CreditRepositoryMaintainer maintainer;

    public CreditStatsFactory(SiriusObjectType siriusObjectType, DataServiceCountProvider dataServiceCountProvider,
                NotificationSequenceRepository notificationRepository, DataServiceNotificationListener dataServiceNotificationListener,
                DataObjectReceiverImpl dataObjectReceiver, SiriusEventDispatcher siriusEventDispatcher,
                NotificationRepositoryWriter notificationRepositoryWriter, CreditRepositoryMaintainer maintainer) {
        super(siriusObjectType, dataServiceCountProvider, notificationRepository,
              createNotificationCountClient(dataServiceNotificationListener), dataServiceNotificationListener,
              dataObjectReceiver, siriusEventDispatcher, notificationRepositoryWriter);
        this.maintainer = maintainer;
    }

    @Override
    public IngestStat getIngestStats(boolean includeDataService, IngestMode ingestMode) {
        IngestStat ingestStat = super.getIngestStats(includeDataService, ingestMode);

        ingestStat.setMaintainer(maintainer.getStats());
        return ingestStat;
    }

    private static NotificationCountClient createNotificationCountClient(DataServiceNotificationListener listener) {
        String baseUrl = listener.getNotificationClient().getBaseUrl();
        MerlinEntityType merlinEntityType = listener.getCrsObjectType().getMerlinEntityType();

        try {
            return new NotificationCountClient(baseUrl, merlinEntityType);
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException(merlinEntityType + " NotificationClient has invalid baseUrl");
        }
    }
}
