package com.theplatform.web.tv.gws.ingest.consumer.notifier;

import com.comcast.merlin.sirius.ingest.Event;
import com.comcast.merlin.sirius.ingest.dispatcher.Stop;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.commons.job.api.client.ServiceStateClient;
import com.theplatform.data.commons.job.api.client.query.servicestate.ByContext;
import com.theplatform.data.commons.job.api.client.query.servicestate.ByService;
import com.theplatform.data.commons.job.api.data.objects.ServiceState;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * This class is used to track the last sequence CRS pushed out a notification for a given endpoint.  This class
 * must be initialized prior to playing back the sirius log.  This class should only be used by the Notifier Node.
 * If it cannot reach the jobDataService after retries then the entire service should shut down.
 *
 * Startup: We need the last notification sequence per endpoint prior to playing back the sirius log.  So we cannot
 * rely on the value in the repo, we need to first make a call to the JobDS to get the required value.
 *
 */
public class SequenceTracker {
    protected final Logger logger = LoggerFactory.getLogger(getClass());

    public static final String SEQUENCE_PROPERTY_PREFIX = "lastSequence.";
    private static final int MAX_ATTEMPTS = 5;          // Max attempts when initialing the sequence numbers

    private static boolean initialized=false;

    private ScheduledExecutorService executor;
    private Map<SiriusObjectType,TrackedSequence> trackedSequences;

    private ServiceStateClient serviceStateClient;
    private Set<SiriusObjectType> typeBeingTracked;
    private boolean isNotificationNode = false;
    private URI ownerId;
    private long persisterHeartbeat;

    /**
     * Get the last sequence we published a notification for.
     *
     * This should only be called once by the Notifier Node at Startup before the sirius log playback.
     */
    @PostConstruct
    public void initializeNotifier(){
        if (!isNotificationNode ){
            return;
        }

        if (initialized){
            logger.error("Multiple attempts to initialize the SequenceTracker is not allowed.");
            return;
        }

        // Load up the current sequence we're on
        trackedSequences = new HashMap<>();
        for (SiriusObjectType siriusObjectType : typeBeingTracked){
            trackedSequences.put(siriusObjectType, getTrackedSequence(siriusObjectType));
        }

        if (logger.isInfoEnabled()){
            StringBuffer buff = new StringBuffer("Task=SequenceTracker SubTask=Initialization Event=Complete");
            for (SiriusObjectType siriusObjectType : trackedSequences.keySet()){
                buff.append("\n\t").append(getSequencePropertyName(siriusObjectType)).append("=").append(trackedSequences.get(siriusObjectType).getInMemorySequence());
            }
            logger.info(buff.toString());
        }

        // Background thread for persisting the latest sequences
        executor = Executors.newScheduledThreadPool(1);
        ScheduledFuture<?> result = executor.scheduleWithFixedDelay(
                new Runnable() {
                    @Override
                    public void run(){
                        try {
                            persist();
                        }catch (Throwable throwable){
                            logger.error("Failed to update sequence in JobDS.", throwable);
                        }
                    }
                }
                , persisterHeartbeat, persisterHeartbeat, TimeUnit.SECONDS);
        logger.info("Task=SequenceTracker Subtask=BackgroundThread Event=Started");

        initialized = true;
    }


    /**
     * Null if it doesn't exist
     *
     * @param siriusObjectType
     * @return
     */
    private TrackedSequence getTrackedSequence( SiriusObjectType siriusObjectType){
        TrackedSequence trackedSequence = null;
        Query[] queries = { new ByService("gridWebService")
                , new ByContext(getSequencePropertyName(siriusObjectType))};
        Feed<ServiceState> feed = null;
        List<ServiceState> serviceStateList = null;
        int attempts = 0;

        while (feed == null && attempts< MAX_ATTEMPTS) {
            attempts++;
            try {
                feed = serviceStateClient.getAll(null, queries, null, null, Boolean.FALSE);
                serviceStateList = feed.getEntries();
            } catch (Exception exc) {
                logger.error("Failed request to JobDS to retriece last sequence.  ObjectType={} Attempt={} ", siriusObjectType.getFriendlyName(), MAX_ATTEMPTS, exc);
                long delay = ((long) Math.pow(2, attempts+1) * 1000L);
                try {
                    Thread.sleep(delay);
                }catch (Exception e){};
            }
        }
        if (feed == null){
            Stop.instance().stop("SequenceTracker unable to connect to jobDS after {} tries." );
        }

        if (serviceStateList!=null && serviceStateList.size()>0){
            ServiceState serviceState = serviceStateList.get(0);
            if (NumberUtils.isNumber(serviceState.getState())){
                trackedSequence = new TrackedSequence(siriusObjectType, serviceState.getId(), new Long(serviceState.getState()));
                logger.error("Task=SequenceTracker SubTask=Initialization Type={} Value={}", siriusObjectType.getFriendlyName(), serviceState.getState());
            } else {
                logger.error("Task=SequenceTracker SubTask=Initialization Error=NonNumericState Type={} Value={}", siriusObjectType.getFriendlyName(), serviceState.getState());
                // Something is messed up with the entry.  Overwrite the value.
                trackedSequence = new TrackedSequence(siriusObjectType, serviceState.getId(), null);
            }
        }else{
            logger.error("Task=SequenceTracker SubTask=Initialization Error=StateNotFound Type={} Value={}", siriusObjectType.getFriendlyName());
            trackedSequence = new TrackedSequence(siriusObjectType);
        }
        return trackedSequence;
    }


    @PreDestroy
    public void shutdown(){
        executor.shutdown();
        // persist any outstanding sequence numbers
        persist();
        logger.info("Task=SequenceTracker Event=Shutdown Sequences Persisted");
    }


    private void persist(){
        TrackedSequence trackedSequence = null;
        for (SiriusObjectType siriusObjectType : trackedSequences.keySet()){
            trackedSequence = trackedSequences.get(siriusObjectType);
            if (!trackedSequence.parity()){
                writeServiceState(trackedSequence);
            }
        }
    }

    private void writeServiceState(TrackedSequence trackedSequence){
        if (trackedSequence.getServiceStateId()!=null){
            try {
                // Update
                ServiceState serviceState = new ServiceState();
                Long sequence = trackedSequence.getInMemorySequence();
                serviceState.setId(trackedSequence.serviceStateId);
                serviceState.setState(sequence.toString());
                serviceStateClient.update(serviceState);
                trackedSequence.setPersistedSequence(sequence);
            }catch ( Throwable throwable){
                logger.error("Task=SequenceTracker Event=FailedUpdateSequence Sequence={} Context={} Failed to update sequence", trackedSequence.getInMemorySequence(), getSequencePropertyName(trackedSequence.getSiriusObjectType()), throwable);
                throw new RuntimeException("Failed to update sequence", throwable);
            }
        } else {
            try {
                // new Entry
                ServiceState serviceState = new ServiceState();
                Long sequence = trackedSequence.getInMemorySequence();
                serviceState.setId(trackedSequence.serviceStateId);
                serviceState.setTitle("gridWebService");
                serviceState.setService(URI.create("gridWebService"));
                serviceState.setContext( URI.create(getSequencePropertyName(trackedSequence.getSiriusObjectType())) );
                serviceState.setState(sequence.toString());
                serviceState.setOwnerId(ownerId);

                serviceState = serviceStateClient.create(serviceState);
                trackedSequence.setServiceStateId(serviceState.getId());
                trackedSequence.setPersistedSequence(sequence);
            }catch ( Throwable throwable){
                logger.error("Task=SequenceTracker Event=FailedNewSequence Sequence={} Context={} Failed to write new sequence Message:\n{}", trackedSequence.getInMemorySequence(), getSequencePropertyName(trackedSequence.getSiriusObjectType()), throwable.getMessage(), throwable);
                throw new RuntimeException("Failed to write new sequence", throwable);
           }
        }


    }


    /**
     * Track the last sequence that was notified on.
     */
    public void updateSequence(SiriusObjectType type, Long sequence){
        if (sequence==null) return;      // If we tickled, we won't have a sequence and there is nothing to track
        trackedSequences.get(type).setInMemorySequence(sequence);
    }

    /**
     *
     */
    public boolean isNotifiableEvent(Event event){
        Long inMemorySequence = trackedSequences.get(event.getCrsObjectType()).getInMemorySequence();
        return  (inMemorySequence==null ||
            inMemorySequence < event.getSequence());
    }

    /**
     * Get the property name used in ServiceState to store the SiriusObjectType 's last sequence it notified on.
     *
     * @param siriusObjectType
     * @return
     */
    public static final String getSequencePropertyName(SiriusObjectType siriusObjectType){
        return SEQUENCE_PROPERTY_PREFIX  + siriusObjectType.getFriendlyName();
    }

    @Required
    public void setTypeBeingTracked(Map<SiriusObjectType,Object> typeBeingTracked) {
        this.typeBeingTracked = typeBeingTracked.keySet();
    }

    @Required
    public void setServiceStateClient(ServiceStateClient serviceStateClient) {
        this.serviceStateClient = serviceStateClient;
    }

    @Required
    public void setNotificationNode(boolean notificationNode) {
        isNotificationNode = notificationNode;
    }

    @Required
    public void setOwnerId(URI ownerId) {
        this.ownerId = ownerId;
    }

    @Required
    public void setPersisterHeartbeat(long persisterHeartbeatSec) {
        this.persisterHeartbeat = persisterHeartbeatSec;
    }

    private class TrackedSequence{
        private URI serviceStateId;
        private final SiriusObjectType siriusObjectType;
        private final AtomicLong inMemorySequence;
        private long persistedSequence;


        /**
         * Currently no entry in the JobDS
         */
        public TrackedSequence( SiriusObjectType siriusObjectType){
            this (siriusObjectType, null, null);
        }

        /**
         * If there is an entry in the JobDS
         */
        public TrackedSequence(SiriusObjectType siriusObjectType, URI serviceStateId, Long sequence){
            this.serviceStateId=serviceStateId;
            this.siriusObjectType = siriusObjectType;

            // At startup these will be in parity; Leave as zero if a null sequence is passed in.
            if (sequence!=null) {
                inMemorySequence = new AtomicLong(sequence);
                this.persistedSequence = sequence;
            }else{
                // No existing data use the first sequence encountered.
                inMemorySequence = new AtomicLong(0l);
                persistedSequence = 0L;
            }
        }

        // False indicates that we are ready to persist the inMemorySequence
        public boolean parity(){
            return inMemorySequence.get()==persistedSequence || inMemorySequence.get()<persistedSequence;
        }

        public URI getServiceStateId() {
            return serviceStateId;
        }

        public void setServiceStateId(URI serviceStateId) {
            this.serviceStateId = serviceStateId;
        }

        public SiriusObjectType getSiriusObjectType() {
            return siriusObjectType;
        }

        public Long getInMemorySequence() {
            return inMemorySequence.get();
        }

        /**
         * Update the inMemorySequence.  Update will only set the inMemorySequence to a greater value.  If less, the
         * request will be dropped.  This is threadsafe.
         *
         * @param inMemorySequence
         */
        public void setInMemorySequence(Long inMemorySequence) {
            boolean updated = false;
            while (!updated) {
                long oldValue = this.inMemorySequence.get();
                if (inMemorySequence < oldValue) {
                    logger.info("Task=SequenceTracker Event=SequenceRollback OldSequence={} NewSequence={} New sequence is less than the old sequence.", this.inMemorySequence, inMemorySequence);
                    break;
                }
                // Make sure another thread didn't change the value while we were trying to update
                updated = this.inMemorySequence.compareAndSet( oldValue, inMemorySequence);
            }
        }

        public Long getPersistedSequence() {
            return persistedSequence;
        }

        /**
         * This is not threadsafe but should only be acted on by a single thread.
         * @param persistedSequence
         */
        public void setPersistedSequence(long persistedSequence) {
            this.persistedSequence = persistedSequence;
        }
    }

}
