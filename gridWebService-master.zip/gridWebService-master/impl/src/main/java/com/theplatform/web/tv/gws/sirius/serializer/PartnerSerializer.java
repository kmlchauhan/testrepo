package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.PartnerProto;
import com.theplatform.web.tv.gws.sirius.model.CRSPartner;

public class PartnerSerializer extends AbstractSiriusObjectSerializer<CRSPartner> {

    public PartnerSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSPartner unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        PartnerProto.PartnerMessage.Builder message
                = PartnerProto.PartnerMessage.newBuilder().mergeFrom(bytes);

        CRSPartner crsPartner = new CRSPartner();
        crsPartner.setId(message.getId());
        crsPartner.setTitle(message.getTitle());
        if (message.hasInternalAccountId()) crsPartner.setInternalAccountId(message.getInternalAccountId());
        if (message.hasParentPartnerId()) crsPartner.setParentPartnerId(message.getParentPartnerId());
        if (message.hasPartnerType()) crsPartner.setPartnerType(message.getPartnerType());
        if (message.hasNationalAvailabilityTag()) crsPartner.setNationalAvailabilityTag(message.getNationalAvailabilityTag());

        return crsPartner;
    }

    @Override
    public ByteString marshallPayload(CRSPartner partner) {
        PartnerProto.PartnerMessage.Builder builder
                = PartnerProto.PartnerMessage.newBuilder();

        builder.setId(partner.getId());
        builder.setTitle(partner.getTitle());
        if (partner.getInternalAccountId() != null){
            builder.setInternalAccountId(partner.getInternalAccountId());
        }
        if (partner.getParentPartnerId() != null){
            builder.setParentPartnerId(partner.getParentPartnerId());
        }
        if (partner.getPartnerType() != null){
            builder.setPartnerType(partner.getPartnerType());
        }
        if (partner.getNationalAvailabilityTag() != null){
            builder.setNationalAvailabilityTag(partner.getNationalAvailabilityTag());
        }

        return builder.build().toByteString();
    }



}
