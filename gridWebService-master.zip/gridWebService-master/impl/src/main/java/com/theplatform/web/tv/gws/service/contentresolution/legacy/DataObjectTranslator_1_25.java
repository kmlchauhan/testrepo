package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.theplatform.web.tv.contentresolution.api.objects.ApiObjectVisitor;
import com.theplatform.web.tv.contentresolution.api.objects.LocatorInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;

public class DataObjectTranslator_1_25 extends ApiObjectVisitor {
    public final static DataObjectTranslator_1_25 INSTANCE = new DataObjectTranslator_1_25();

    @Override
    public void visitStationInfo(StationInfo stationInfo){
        stationInfo.setUhd(null);
        stationInfo.setHdLevel(null);
        stationInfo.setColorDepth(null);
    }

    public void visitLocatorInfo(LocatorInfo locatorInfo) {
        locatorInfo.setQuality(null);
        locatorInfo.setType(null);
        locatorInfo.setTravelRights(null);
        locatorInfo.setServiceZoneType(null);
    }

}
