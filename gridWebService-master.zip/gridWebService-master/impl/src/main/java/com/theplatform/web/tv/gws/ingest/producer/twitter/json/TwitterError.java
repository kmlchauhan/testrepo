package com.theplatform.web.tv.gws.ingest.producer.twitter.json;


import org.apache.commons.lang3.StringUtils;

/**
 * Object representation of a Twitter JSON error.  See <a href="https://dev.twitter.com/overview/api/response-codes"></a>.
 */
public class TwitterError {
    private Integer code;
    private String label;
    private String message;

    /**
     * Twitter specific error code extracted from the JSON payload.  For example, 99.
     * @return the code or null if no code was included in the JSON
     */
    public Integer getCode() {
        return code;
    }

    void setCode(Integer code) {
        this.code = code;
    }

    /**
     * Machine readable error description.  For example, "authenticity_token_error".
     * @return the label or null if no label was included in the JSON
     */
    public String getLabel() {
        return label;
    }

    void setLabel(String label) {
        this.label = label;
    }

    /**
     * Human readable error message.  For example, ""Unable to verify your credentials".
     * @return human readable message or null if no message was included in the JSON
     */
    public String getMessage() {
        return message;
    }

    void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder(128);

        if (StringUtils.isNotBlank(message)) {
            sb.append(message);
        }

        if (StringUtils.isNotBlank(label) || code != null) {
            sb.append(" (");

            if (code != null) {
                sb.append("code ").append(code);

                if (StringUtils.isNotBlank(label)) {
                    sb.append(", ");
                }
            }

            if (StringUtils.isNotBlank(label)) {
                sb.append(label);
            }

            sb.append(")");
        }

        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TwitterError)) return false;

        TwitterError that = (TwitterError) o;

        if (code != null ? !code.equals(that.code) : that.code != null) return false;
        if (label != null ? !label.equals(that.label) : that.label != null) return false;
        return !(message != null ? !message.equals(that.message) : that.message != null);

    }

    @Override
    public int hashCode() {
        int result = code != null ? code.hashCode() : 0;
        result = 31 * result + (label != null ? label.hashCode() : 0);
        result = 31 * result + (message != null ? message.hashCode() : 0);
        return result;
    }
}
