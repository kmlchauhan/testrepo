package com.theplatform.web.tv.gws.service.common.field;


import com.google.common.base.Preconditions;
import jersey.repackaged.jsr166e.StampedLock;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Thread safe and non blocking fixed sized cache.
 * @param <K> key type
 * @param <V> value type
 */
public class FieldFilterCache<K, V> {
    public static final int DEFAULT_SIZE = 25;

    /**
     * Fixed size FIFO Map.  Since this class is designed for high performance we're using a simple FIFO
     * caching expiration rather than something more complicated like LRU or LFU.
     */
    private final Map<K, V> map;

    /**
     * This lock is highly efficient when there are multiple concurrent readers and few concurrent writers.
     */
    private final StampedLock lock;

    /**
     * Create a new instance with the {@link #DEFAULT_SIZE default maximum capacity}.
     */
    public FieldFilterCache() {
        this(DEFAULT_SIZE);
    }

    /**
     * Create a new instance of with the specified maximum capacity.
     * @param maxSize maximum capacity
     */
    public FieldFilterCache(final int maxSize) {
        Preconditions.checkArgument(maxSize > 0, "maxSize must be > 0");

        // create a new Map that removes the oldest element after the maximum size is exceeded
        this.map = new LinkedHashMap<K, V>(maxSize) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
                return super.size() > maxSize;
            }
        };
        this.lock = new StampedLock();
    }

    /**
     * Retrieve the item with the specified key without blocking.  Returns null if the lock protecting the cache
     * could not be acquired.
     * @param key the key
     * @return the value for the specified key or null if no value exists or the lock could not be acquired.
     */
    public V get(K key) {

        V value = null;

        // try to acquire the lock if it's available
        long stamp = lock.tryReadLock();

        // if we acquired the lock check the map
        if (stamp != 0) {
            try {
                value = map.get(key);
            }
            finally {
                lock.unlockRead(stamp);
            }
        }
        return value;
    }

    /**
     * Add an item to the cache.  Note that unlike {@link #get(Object)} this method will block until the lock
     * protecting the cache can be acquired.
     * @param key the key
     * @param value the value to cache
     */
    public void put(K key, V value) {
        long stamp = lock.writeLock();
        try {
            map.put(key, value);
        }
        finally {
            lock.unlockWrite(stamp);
        }
    }
}
