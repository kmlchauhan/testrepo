package com.theplatform.web.tv.gws.service.contentresolution.ono;

import com.rits.cloning.Cloner;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.ProductContextInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;
import com.theplatform.web.tv.gws.sirius.model.CRSChannel;
import com.theplatform.web.tv.gws.sirius.repository.ChannelRepository;
import com.theplatform.web.tv.gws.service.common.converter.CRSChannelToChannelInfoConverter;
import com.theplatform.web.tv.gws.service.common.converter.CRSProductContextToProductContextInfoConverter;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.springframework.beans.factory.annotation.Required;

import java.util.Collection;
import java.util.List;

public class ChannelCloner {
    private CRSProductContextToProductContextInfoConverter productContextConverter;
    private ChannelRepository channelRepository;

    public ChannelInfo clone(ChannelInfo original, Collection<Long> tveProductContexts, MerlinIdHelper merlinIdHelper) {
        // 1- Clone Channel
        Cloner cloner = new Cloner();
        ChannelInfo synthChannel = cloner.deepClone(original);

        // 2 - Mod Channel - Channe Id, Channel Number
        synthChannel.setChannelId(generateSyntheticChannelId( original, merlinIdHelper));
        synthChannel.setNumber( synthChannel.getNumber() + TveSyntheticChannelHelper.SYNTH_CHANNEL_NUMBER_OFFSET );

        // 3 - Mod Product Context
        StationInfo stationInfo = synthChannel.getStationInfo();
        List<ProductContextInfo> productContextInfos = productContextConverter.convert(tveProductContexts);
        stationInfo.setProductContextList(productContextInfos);

        // 4 - Mod sortIndex
        int sortIndex = CRSChannelToChannelInfoConverter.calculateSortIndex(synthChannel);
        synthChannel.setSortIndex(sortIndex);

        return synthChannel;
    }


    protected Muri generateSyntheticChannelId(ChannelInfo original, MerlinIdHelper merlinIdHelper){
        CRSChannel crsChannel = channelRepository.getSyntheticWhitelistChannel(original.getStationInfo().getStationId().getId());
        return merlinIdHelper.createChannelId(crsChannel.getId());
    }

    @Required
    public void setProductContextConverter(CRSProductContextToProductContextInfoConverter productContextConverter) {
        this.productContextConverter = productContextConverter;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }
}
