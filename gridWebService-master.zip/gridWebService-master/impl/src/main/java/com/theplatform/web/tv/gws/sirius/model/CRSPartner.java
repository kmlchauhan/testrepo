package com.theplatform.web.tv.gws.sirius.model;


import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSPartner extends LongDataRepoObject implements Comparable<CRSPartner> {

    private String title;
    private Long internalAccountId;
    private Long parentPartnerId;
    private String partnerType;
    private Long nationalAvailabilityTag;

    public CRSPartner () {
        super( SiriusObjectType.fromFriendlyName("Partner"));
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getInternalAccountId() {
        return internalAccountId;
    }

    public void setInternalAccountId(Long internalAccountId) {
        this.internalAccountId = internalAccountId;
    }

    public Long getParentPartnerId() {
        return parentPartnerId;
    }

    public void setParentPartnerId(Long parentPartnerId) {
        this.parentPartnerId = parentPartnerId;
    }

    public String getPartnerType() {
        return partnerType;
    }

    public void setPartnerType(String partnerType) {
        this.partnerType = partnerType;
    }

    public Long getNationalAvailabilityTag() {
        return nationalAvailabilityTag;
    }

    public void setNationalAvailabilityTag(Long nationalAvailabilityTag) {
        this.nationalAvailabilityTag = nationalAvailabilityTag;
    }

    @Override
    public int compareTo(CRSPartner partner) {
        if (this.hashCode() > partner.hashCode()) {
            return 1;
        }
        if (this.hashCode() < partner.hashCode()) {
            return -1;
        }
        return 0;
    }
}
