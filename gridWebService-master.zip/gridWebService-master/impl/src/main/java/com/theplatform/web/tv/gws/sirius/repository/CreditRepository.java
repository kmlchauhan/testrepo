package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSCredit;
import com.theplatform.web.tv.gws.sirius.repository.utils.OpenSetSecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.SecondaryIndex;

import java.util.ArrayList;
import java.util.Collection;

public class CreditRepository extends LongObjectRepository<CRSCredit> {

    private final SecondaryIndex<Long, CRSCredit> personToCreditIndex;
    private final SecondaryIndex<Long, CRSCredit> programToCreditIndex;

    public CreditRepository( SiriusObjectType siriusObjectType, int expectedCredits, int expectedPersons, int expectedPrograms) {
        super(siriusObjectType, expectedCredits);
        personToCreditIndex = new OpenSetSecondaryIndex<>(expectedPersons);
        programToCreditIndex = new OpenSetSecondaryIndex<>(expectedPrograms);
    }

    @Override
    protected void addToIndexes(CRSCredit crsCredit) {
        personToCreditIndex.put(crsCredit.getPersonId(), crsCredit);
        programToCreditIndex.put(crsCredit.getProgramId(), crsCredit);
    }

    @Override
    protected void removeFromIndexes(CRSCredit crsCredit) {
        personToCreditIndex.remove(crsCredit.getPersonId(), crsCredit);
        programToCreditIndex.remove(crsCredit.getProgramId(), crsCredit);
    }

    public Collection<Long> getProgramIds(long personId) {
        ArrayList<Long> programIds = new ArrayList<>();
        for (CRSCredit credit : personToCreditIndex.getByIndexKey(personId)) {
            programIds.add(credit.getProgramId());
        }

        return programIds;
    }

    public Collection<CRSCredit> getCredits(long programId) {
        return programToCreditIndex.getByIndexKey(programId);
    }
}
