package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.contentresolution.api.objects.IdCollection;
import com.theplatform.web.tv.contentresolution.api.annotation.ResolveChannelsValidation;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import com.theplatform.web.tv.gws.service.common.aop.stats.CollectStats;
import com.theplatform.web.tv.gws.service.common.field.FieldFilterUtil;

import javax.jws.WebParam;
import java.util.Date;
import java.util.List;

public class ContentResolutionServiceImpl_1_22 extends LegacyContentResolutionServiceImpl<ContentResolutionService_1_23> implements ContentResolutionService_1_22 {
    private static final String INCLUDE_ALWAYS = "verboseInfo";

    protected final ApiObjectVisitor visitor;

    public ContentResolutionServiceImpl_1_22() {
        visitor = DataObjectTranslator_1_22.INSTANCE;
    }

    @CollectStats
    @ResolveChannelsValidation
    @Override
    public ChannelInfoCollection resolveChannels(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                                                 @WebParam(name = "fields") String fields,
                                                 @WebParam(name = "byStreamStatus") String byStreamStatus,
                                                 @WebParam(name = "filterAdult") Boolean filterAdult) throws GridException {
        ChannelInfoCollection collection = contentResolutionService.resolveChannels(availabilityResolution, null, byStreamStatus, filterAdult);
        collection.accept(visitor);
        FieldFilterUtil.filterFields(collection, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return collection;
    }

    @Override
    public ChannelInfoCollection resolveChannelsByStreamId(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                                                           @WebParam(name = "streamId") Long streamId,
                                                           @WebParam(name = "fields") String fields,
                                                           @WebParam(name = "filterAdult") Boolean filterAdult) throws GridException {
        ChannelInfoCollection collection = contentResolutionService.resolveChannelsByStreamId(availabilityResolution, streamId, null, filterAdult);
        collection.accept(visitor);
        FieldFilterUtil.filterFields(collection, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return collection;
    }

    @Override
    public Grid getGrid(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                        @WebParam(name = "numGridUnits") Integer numGridUnits,
                        @WebParam(name = "gridUnitWidth") Integer gridUnitWidth,
                        @WebParam(name = "offset") Integer offset,
                        @WebParam(name = "timeZone") String timeZone,
                        @WebParam(name = "categories") String[] categories,
                        @WebParam(name = "companyIds") Long[] companyIds,
                        @WebParam(name = "stationTagIds") Long[] stationTagIds,
                        @WebParam(name = "locatorFormats") String[] locatorFormats,
                        @WebParam(name = "hd") Boolean hd,
                        @WebParam(name = "rowStart") Integer rowStart,
                        @WebParam(name = "rowEnd") Integer rowEnd,
                        @WebParam(name = "programTagIds") Long[] programTagIds,
                        @WebParam(name = "fields") String fields) throws GridException {
        Grid grid = contentResolutionService.getGrid(availabilityResolution, numGridUnits, gridUnitWidth, offset, timeZone, categories, companyIds, stationTagIds, locatorFormats, hd, rowStart, rowEnd, programTagIds, null);
        grid.accept(visitor);
        FieldFilterUtil.filterFields(grid, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return grid;
    }

    @Override
    public Grid getGridByDate(@WebParam(name = "resolveAvailabilityResponse") AvailabilityResolution availabilityResolution,
                              @WebParam(name = "startTime") Date startTime,
                              @WebParam(name = "numGridUnits") Integer numGridUnits,
                              @WebParam(name = "gridUnitWidth") Integer gridUnitWidth,
                              @WebParam(name = "timeZone") String timeZone,
                              @WebParam(name = "categories") String[] categories,
                              @WebParam(name = "companyIds") Long[] companyIds,
                              @WebParam(name = "stationTagIds") Long[] stationTagIds,
                              @WebParam(name = "locatorFormats") String[] locatorFormats,
                              @WebParam(name = "hd") Boolean hd,
                              @WebParam(name = "rowStart") Integer rowStart,
                              @WebParam(name = "rowEnd") Integer rowEnd,
                              @WebParam(name = "programTagIds") Long[] programTagIds,
                              @WebParam(name = "fields") String fields) throws GridException {
        Grid grid = contentResolutionService.getGridByDate(availabilityResolution, startTime, numGridUnits, gridUnitWidth, timeZone, categories, companyIds, stationTagIds, locatorFormats, hd, rowStart, rowEnd, programTagIds, null);
        grid.accept(visitor);
        FieldFilterUtil.filterFields(grid, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return grid;
    }

    @Override
    public List<ListingInfo> getListings(@WebParam(name = "stationId") Long stationId,
                                         @WebParam(name = "numGridUnits") Integer numGridUnits,
                                         @WebParam(name = "gridUnitWidth") Integer gridUnitWidth,
                                         @WebParam(name = "offset") Integer offset,
                                         @WebParam(name = "programTagIds") Long[] programTagIds,
                                         @WebParam(name = "fields") String fields) throws GridException {
        List<ListingInfo> listingInfos = contentResolutionService.getListings(stationId, numGridUnits, gridUnitWidth, offset, programTagIds, null);
        visitor.visitEach(listingInfos);
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);
        return listingInfos;
    }

    @Override
    public List<ListingInfo> getListingsByDate(@WebParam(name = "stationId") Long stationId,
                                               @WebParam(name = "startTime") Date startTime,
                                               @WebParam(name = "endTime") Date endTime,
                                               @WebParam(name = "gridUnitWidth") Integer gridUnitWidth,
                                               @WebParam(name = "programTagIds") Long[] programTagIds,
                                               @WebParam(name = "fields") String fields) throws GridException {
        List<ListingInfo> listingInfos = contentResolutionService.getListingsByDate(stationId, startTime, endTime, gridUnitWidth, programTagIds, null);
        visitor.visitEach(listingInfos);
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);
        return listingInfos;
    }

    @Override
    public List<ListingInfo> getListingsById(@WebParam(name = "listingIds") List<Muri> listingIds,
                                             @WebParam(name = "programTagIds") Long[] programTagIds,
                                             @WebParam(name = "fields") String fields) throws GridException {
        List<ListingInfo> listingInfos = contentResolutionService.getListingsById(listingIds, programTagIds, null);
        visitor.visitEach(listingInfos);
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);
        return listingInfos;
    }

    public List<ListingInfo> getListingsBySeriesId(@WebParam(name = "seriesIds") Muri[] seriesIds,
                                                   @WebParam(name = "startTime") Date startTime,
                                                   @WebParam(name = "endTime") Date endTime,
                                                   @WebParam(name = "stationIds") Muri[] stationIds,
                                                   @WebParam(name = "programTagIds") Long[] programTagIds,
                                                   @WebParam(name = "fields") String fields) {

        List<ListingInfo> listingInfos =
                contentResolutionService.getListingsBySeriesId( seriesIds
                                                              , startTime
                                                              , endTime
                                                              , stationIds
                                                              , programTagIds, null );
        visitor.visitEach(listingInfos);
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);
        return listingInfos;
    }

    @Override
    public List<ListingInfo> getListingsBySportsTeamId(@WebParam(name = "sportsTeamIds") Muri[] sportsTeamIds,
                                                       @WebParam(name = "startTime") Date startTime,
                                                       @WebParam(name = "endTime") Date endTime,
                                                       @WebParam(name = "stationIds") Muri[] stationIds,
                                                       @WebParam(name = "programTagIds") Long[] programTagIds,
                                                       @WebParam(name = "fields") String fields) {
        List<ListingInfo> listingInfos =
                contentResolutionService.getListingsBySportsTeamId( sportsTeamIds
                                                                  , startTime
                                                                  , endTime
                                                                  , stationIds
                                                                  , programTagIds, null );
        visitor.visitEach(listingInfos);
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);
        return listingInfos;
    }

    @Override
    public List<ListingInfo> getListingsByPersonId(@WebParam(name = "personIds") Muri[] personIds,
                                                   @WebParam(name = "startTime") Date startTime,
                                                   @WebParam(name = "endTime") Date endTime,
                                                   @WebParam(name = "stationIds") Muri[] stationIds,
                                                   @WebParam(name = "programTagIds") Long[] programTagIds,
                                                   @WebParam(name = "fields") String fields) {
        List<ListingInfo> listingInfos =
                contentResolutionService.getListingsByPersonId( personIds
                                                              , startTime
                                                              , endTime
                                                              , stationIds
                                                              , programTagIds, null );
        visitor.visitEach(listingInfos);
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);
        return listingInfos;
    }

    @Override
    public IdCollection getStationsBySeriesId(@WebParam(name = "seriesIds") Muri[] seriesIds,
                                              @WebParam(name = "startTime") Date startTime,
                                              @WebParam(name = "endTime") Date endTime) {

        return  contentResolutionService.getStationsBySeriesId( seriesIds
                                                              , startTime
                                                              , endTime);
    }

    @Override
    public IdCollection getStationsBySportsTeamId(@WebParam(name = "sportsTeamIds") Muri[] sportsTeamIds,
                                                  @WebParam(name = "startTime") Date startTime,
                                                  @WebParam(name = "endTime") Date endTime) {
        return  contentResolutionService.getStationsBySportsTeamId( sportsTeamIds
                                                              , startTime
                                                              , endTime);
    }

    @Override
    public IdCollection getStationsByPersonId(@WebParam(name = "personIds") Muri[] personIds,
                                              @WebParam(name = "startTime") Date startTime,
                                              @WebParam(name = "endTime") Date endTime) {
        return  contentResolutionService.getStationsByPersonId( personIds
                                                              , startTime
                                                              , endTime);
    }

    @Override
    public EpisodesMap getEpisodes(@WebParam(name = "episodeIds") Muri[] episodeIds,
                                   @WebParam(name = "previousEpisodeCount") Integer previousEpisodeCount,
                                   @WebParam(name = "nextEpisodeCount") Integer nextEpisodeCount,
                                   @WebParam(name = "excludeProvidedEpisodes") Boolean excludeProvidedEpisodes,
                                   @WebParam(name = "fields") String fields) throws GridException {
        EpisodesMap episodesMap =
                contentResolutionService.getEpisodes( episodeIds
                                                    , previousEpisodeCount
                                                    , nextEpisodeCount
                                                    , excludeProvidedEpisodes
                                                    , null);
        visitor.visitEpisodeMap(episodesMap);
        FieldFilterUtil.filterFields( episodesMap, fields);
        return episodesMap;

    }

    @Override
    public List<ProgramInfo> getProgramsById( @WebParam(name = "programIds") Muri[] programIds
                                            , @WebParam(name = "fields") String fields) throws GridException{
        List<ProgramInfo> programInfos =
                contentResolutionService.getProgramsById( programIds, null);
        visitor.visitEach(programInfos);
        FieldFilterUtil.filterFieldsForEach(programInfos, fields);
        return programInfos;
    }

    @Override
    public TrendingPrograms getTrendingPrograms(@WebParam(name = "fields") String fields) throws GridException {
        TrendingPrograms programs = contentResolutionService.getTrendingPrograms(null);
        programs.accept(visitor);
        FieldFilterUtil.filterFields(programs, fields, Boolean.FALSE, INCLUDE_ALWAYS);
        return programs;
    }

}