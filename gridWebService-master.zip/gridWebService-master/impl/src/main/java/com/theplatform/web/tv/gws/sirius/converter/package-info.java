/**
 * Classes that convert the DataObjects used by data services to in-memory CRS objects.  See {@link com.theplatform.web.tv.gws.sirius.converter.ConverterFacade}
 * to avoid working with each of these classes individually.
 */
package com.theplatform.web.tv.gws.sirius.converter;