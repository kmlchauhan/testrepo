package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.TagAssociationProto.TagAssociationMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSTagAssociation;

/**
 * @author jcoelho
 * @since 6/9/15.
 */
public class TagAssociationSerializer extends AbstractSiriusObjectSerializer<CRSTagAssociation> {

    public TagAssociationSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSTagAssociation unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        TagAssociationMessage.Builder message = TagAssociationMessage.newBuilder().mergeFrom(bytes);
        return new CRSTagAssociation(message.getId(), message.getTagId(), message.getEntityId());
    }

    @Override
    public ByteString marshallPayload( CRSTagAssociation object) {
        TagAssociationMessage.Builder builder = TagAssociationMessage.newBuilder();

        builder.setId(object.getId());
        builder.setTagId(object.getTagId());
        builder.setEntityId(object.getObjectId());

        return builder.build().toByteString();
    }

}
