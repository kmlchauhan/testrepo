package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.web.tv.gws.sirius.model.CRSProgramTeamAssociation;

public class ProgramTeamAssociationConverter extends AbstractDataObjectConverter<ProgramTeamAssociation, CRSProgramTeamAssociation> {

    @Override
    public CRSProgramTeamAssociation convert(ProgramTeamAssociation pta) {
        long id = LocalUriConverter.convertUriToID(pta.getId());
        long programId = LocalUriConverter.convertUriToID(pta.getProgramId());
        long sportsTeamId = LocalUriConverter.convertUriToID(pta.getSportsTeamId());

        return new CRSProgramTeamAssociation(id, programId, sportsTeamId);
    }


}
