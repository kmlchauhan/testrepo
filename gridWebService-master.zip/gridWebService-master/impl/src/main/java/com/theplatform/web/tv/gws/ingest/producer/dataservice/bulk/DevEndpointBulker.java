package com.theplatform.web.tv.gws.ingest.producer.dataservice.bulk;


import com.comcast.merlin.sirius.ingest.EventOrigin;
import com.comcast.merlin.sirius.ingest.IngestException;
import com.comcast.merlin.sirius.ingest.producer.dataservice.DataObjectReceiver;
import com.comcast.merlin.sirius.ingest.producer.dataservice.bulk.EndpointBulker;
import com.comcast.merlin.sirius.ingest.producer.dataservice.client.ClientFacade;
import com.comcast.merlin.sirius.ingest.producer.dataservice.client.IdResponse;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.google.common.collect.Lists;
import com.theplatform.contrib.data.api.objects.MerlinDataObject;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.CloseableIterator;
import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.credit.ByProgramId;
import com.theplatform.data.tv.linear.api.client.query.channel.ByLocationId;
import com.theplatform.data.tv.linear.api.client.query.listing.ByStationId;
import com.theplatform.data.tv.offer.api.client.query.contentavailability.ByContentId;
import com.theplatform.web.tv.gws.sirius.model.CRSLocation;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSStation;
import com.theplatform.web.tv.gws.sirius.repository.ChannelRepository;
import com.theplatform.web.tv.gws.sirius.repository.ListingRepository;
import com.theplatform.web.tv.gws.sirius.repository.StreamRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.RetryOperations;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

import static org.apache.commons.lang.StringUtils.isEmpty;

public class DevEndpointBulker implements EndpointBulker {
    private static Logger logger = LoggerFactory.getLogger(DevEndpointBulker.class);

    private static final int MAX_CLIENT_RETRIES = 6;

    private int bulkBatchSize = 100;

    private Integer bulkLoadPoolSize;

    private DataObjectReceiver dataObjectReceiver;

    private LongObjectRepository<CRSLocation> locationRepository;
    private LongObjectRepository<CRSStation> stationRepository;
    private LongObjectRepository<CRSProgram> programRepository;
    private ListingRepository listingRepository;
    private ChannelRepository channelRepository;
    private StreamRepository streamRepository;

    private String locationIds;

    private RetryOperations retryPolicy;
    private int count = 0;
    private ClientFacade clientFacade;

    // NOT Thread-safe - see count
    @Override
    public void bulk() throws Exception{
        final String endpoint = clientFacade.getObjectType().getDataServiceObjectClass().getSimpleName();
        retryPolicy.execute(new RetryCallback<RuntimeException, Exception>() {
            @Override
            public RuntimeException doWithRetry(RetryContext context) {
                count = 0;
                if (clientFacade.getObjectType().getFriendlyName().equalsIgnoreCase("Listing")) {
                    count = handleWithMultipleThreadsUsingQueryAndIds(clientFacade, dataObjectReceiver, ByStationId.class, getStationIds());
                } else if (clientFacade.getObjectType().getFriendlyName().equalsIgnoreCase("Channel")) {
                    count = handleWithMultipleThreadsUsingQueryAndIds(clientFacade, dataObjectReceiver, ByLocationId.class, getLocationIds());
                } else if (clientFacade.getObjectType().getFriendlyName().equalsIgnoreCase("Program") && !isEmpty(locationIds)) {
                    count = handleWithMultipleThreadsUsingQueryAndIds( clientFacade, dataObjectReceiver, null, new ArrayList(listingRepository.getAllProgramIds()));
                } else if ( clientFacade.getObjectType().getFriendlyName().equalsIgnoreCase("Credit") ) {
                    count = handleWithMultipleThreadsUsingQueryAndIds( clientFacade, dataObjectReceiver, ByProgramId.class, programRepository.keys());
                } else if ( clientFacade.getObjectType().getFriendlyName().equalsIgnoreCase("ProgramTeamAssociation") ) {
                    count = handleWithMultipleThreadsUsingQueryAndIds( clientFacade, dataObjectReceiver, com.theplatform.data.tv.entity.api.client.query.programteamassociation.ByProgramId.class, programRepository.keys());
                } else if ( clientFacade.getObjectType().getFriendlyName().equalsIgnoreCase("ContentAvailability") ) {
                    // We need Stream and Station CAs
                    count = handleWithMultipleThreadsUsingQueryAndIds( clientFacade, dataObjectReceiver, ByContentId.class, streamRepository.keys());
                    count += handleWithMultipleThreadsUsingQueryAndIds( clientFacade, dataObjectReceiver, ByContentId.class, stationRepository.keys());
                } else {
                    Feed all = clientFacade.getAll();
                    CloseableIterator<? extends DataObject> streamingIterator = all.getStreamingIterator();
                    logger.info("DS count for {} was {}", endpoint, all.getEntryCount());
                    while (streamingIterator.hasNext()) {
                        loadObjectIntoSirius( clientFacade.getObjectType(), streamingIterator.next(), dataObjectReceiver);
                        count++;
                    }
                }
                logger.info("{}s loaded: {}", endpoint, count);
                return null;
            }
        });
    }

    @Override
    public void initializeEventQueue() {
        clientFacade.getNotificationClient().beginQueuing();
    }

    @Override
    public String getEndpointName() {
        return clientFacade.getObjectType().toString();
    }

    private List<Long> getLocationIds() {
        List<Long> locationIdsArr = new ArrayList<>();
        if (isEmpty(locationIds))
            locationIdsArr =  locationRepository.keys();
        else {
            String[] split = locationIds.split(",");
            for (String s : split)
                locationIdsArr.add(Long.parseLong(s));
        }
        return locationIdsArr;
    }


    private List<Long> getStationIds() {
        if (isEmpty(locationIds))
            return stationRepository.keys();
        return new ArrayList<>(channelRepository.getStationIds());
    }

    private int handleWithMultipleThreadsUsingQueryAndIds(final ClientFacade client,
                                                          final DataObjectReceiver dataObjectReceiver,
                                                          Class<? extends Query> queryClass,
                                                          List<Long> ids) {

        logger.info("Size of Ids to query: " + ids.size());

        ExecutorService executor = Executors.newFixedThreadPool(bulkLoadPoolSize);

        Integer count = 0;
        for (FutureTask<Integer> task : getFutureTasks(client, dataObjectReceiver, executor, queryClass, ids)) {
            try {
                count += task.get();
            } catch (Exception e) {
                logger.info("Exception while dividing and conquering {}s. Shutting down task executor...",
                        client.getObjectType(), e);
                executor.shutdownNow();
                try {
                    executor.awaitTermination(30, TimeUnit.SECONDS);
                    logger.info("Backing off.  Waiting 10 seconds");
                    Thread.sleep(10000);
                } catch (InterruptedException ie) {
                    // if we're interrupted while waiting, that's okay
                }
                logger.info("Executor terminated prior to timeout: {}", executor.isTerminated());
                throw new RuntimeException(e);
            }
        }

        executor.shutdown();
        return count;
    }

    private <T extends MerlinDataObject> List<FutureTask<Integer>> getFutureTasks(final ClientFacade dataServiceClient,
                                                                                  final DataObjectReceiver dataObjectReceiver,
                                                                                  ExecutorService executor,
                                                                                  final Class<? extends Query> queryClass,
                                                                                  List<Long> ids) {

        List<FutureTask<Integer>> taskList = new ArrayList<>();

        List<List<Long>> idsPerQuery = Lists.partition( ids, bulkBatchSize);
        final SiriusObjectType type = dataServiceClient.getObjectType();
        for (final List<Long> idsInQuery : idsPerQuery) {
            FutureTask<Integer> futureTask = new FutureTask<>(
                    new Callable<Integer>() {
                        @Override
                        public Integer call() {
                            int attempts = 0;
                            try{
                                if(queryClass == null) {
                                    IdResponse idResponse = dataServiceClient.getByLongIds( idsInQuery );
                                    int count = 0;
                                    for (DataObject dataObject : idResponse.getDataObjects()) {
                                        loadObjectIntoSirius( type, dataObject, dataObjectReceiver);
                                        count++;
                                    }
                                    return count;
                                }else {
                                    Feed all = dataServiceClient.getAll(createQuery(queryClass, idsInQuery), null);
                                    CloseableIterator<? extends DataObject> streamingIterator = all.getStreamingIterator();
                                    int count = 0;
                                    while (streamingIterator.hasNext()) {
                                        loadObjectIntoSirius( type, streamingIterator.next(), dataObjectReceiver);
                                        count++;
                                    }
                                    return count;
                                }
                            }catch (Exception exc){
                                attempts++;
                                if(attempts>= MAX_CLIENT_RETRIES){
                                    logger.error( "Request Failed. Attempt: " + attempts + " - LAST ATTEMPT", exc );
                                    throw exc;
                                }else{
                                    logger.error( "Request Failed. Attempt: " + attempts + ".  Trying again.", exc );
                                    // convertIpLocator this to ClientFacade which internally manages retries
                                    try{
                                        Thread.sleep(1000 * ( (int)Math.pow(attempts,2) ));
                                    }catch (InterruptedException e){}      // Back off
                                }
                            }
                            return 0;
                        }
                    }
            );
            taskList.add(futureTask);
            executor.execute(futureTask);
        }
        return taskList;
    }

    private <T extends DataObject> void loadObjectIntoSirius(SiriusObjectType type, T dataObject, DataObjectReceiver dataObjectReceiver) {
        long id = Muri.getObjectId(dataObject);
        logger.info("Bulk Loading {} {} ", type, id);
        try {
            dataObjectReceiver.add(type, EventOrigin.BULK, dataObject);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
            throw new IngestException(e);
        }
    }

    private Query createQuery(Class<? extends Query> queryClass, List<Long> idsInQuery) {
        try {
            return queryClass.getConstructor(List.class)
                    .newInstance(idsInQuery);
        } catch (Exception e) {
            throw new IngestException(e);
        }
    }

    @Required
    public void setBulkLoadPoolSize(Integer bulkLoadPoolSize) {
        this.bulkLoadPoolSize = bulkLoadPoolSize;
    }

    @Required
    public void setBulkBatchSize(int bulkBatchSize) {
        this.bulkBatchSize = bulkBatchSize;
    }

    @Required
    public void setLocationRepository(LongObjectRepository<CRSLocation> locationRepository) {
        this.locationRepository = locationRepository;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    @Required
    public void setStationRepository(LongObjectRepository<CRSStation> stationRepository) {
        this.stationRepository = stationRepository;
    }

    @Required
    public void setListingRepository(ListingRepository listingRepository) {
        this.listingRepository = listingRepository;
    }

    @Required
    public void setProgramRepository(LongObjectRepository<CRSProgram> programRepository) {
        this.programRepository = programRepository;
    }

    @Required
    public void setLocationIds(String locationIds) {
        this.locationIds = locationIds;
    }

    @Required
    public void setRetryPolicy(RetryOperations retryPolicy) {
        this.retryPolicy = retryPolicy;
    }

    @Required
    public void setDataObjectReceiver(DataObjectReceiver dataObjectReceiver) {
        this.dataObjectReceiver = dataObjectReceiver;
    }

    @Required
    public void setClientFacade(ClientFacade clientFacade) {
        this.clientFacade = clientFacade;
    }

    @Required
    public void setStreamRepository(StreamRepository streamRepository) {
        this.streamRepository = streamRepository;
    }
}
