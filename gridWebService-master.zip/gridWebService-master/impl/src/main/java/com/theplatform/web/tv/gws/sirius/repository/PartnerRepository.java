package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSPartner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PartnerRepository extends LongObjectRepository<CRSPartner> {

    private IsMyChild comcastParent;

    private Map<Long, Long> ownerIdToParentPartnerIdIndex;

    public PartnerRepository( SiriusObjectType siriusObjectType, long comcastOwnerId) {
        super(siriusObjectType);
        comcastParent = new IsMyChild(comcastOwnerId);
        ownerIdToParentPartnerIdIndex = new HashMap<>();
    }

    @Override
    protected void addToIndexes(CRSPartner crsPartner) {
        if (crsPartner.getInternalAccountId() != null)
            ownerIdToParentPartnerIdIndex.put(crsPartner.getInternalAccountId(), crsPartner.getParentPartnerId());

        comcastParent.changeOccurred();
    }

    @Override
    protected void removeFromIndexes(CRSPartner crsPartner) {
        if (crsPartner.getInternalAccountId() != null)
            ownerIdToParentPartnerIdIndex.remove(crsPartner.getInternalAccountId());

        comcastParent.changeOccurred();

    }

    public Long getParentOwnerId(long ownerId){

        Long parentPartnerId = ownerIdToParentPartnerIdIndex.get(ownerId);

        if (parentPartnerId != null){

            CRSPartner parent = get(parentPartnerId);

            if (parent != null){
                return parent.getInternalAccountId();
            }
        }
        return null;
    }
    // We need an unsynchronized call because we will be calling from a synchronized addToIndexes/removeFromIndexes
    // which will deadlock.
    private List<Long> unsynchronizedKeys(){
        return new ArrayList(this.map.keySet());
    }
    private CRSPartner unsynchronizedGet(long id) {
        return this.map.get(id);
    }


    /**
     *  Since the state of the Partner data may not be complete, we will have Partners referencing other Partners
     *  that do not exist in the repository yet.  Therefore there isn't an easy/efficient way to update the tree
     *  durring a change.  On writes, this will iterate over all Partners and check the state of the tree.  This will
     *  be slow but should not be a problem because we have so few partners and very few changes other than at
     *  startup time.  The reads will be fast because it's a Set lookup.
     *
     */
    protected class IsMyChild{
        private Long parentInternalAccountId;
        private final int MAX_DEPTH = 10;
        public Set<Long> isChild = new HashSet<>(300);


        public IsMyChild(Long parentInternalAccountId){
            this.parentInternalAccountId = parentInternalAccountId;
        }

        public void changeOccurred(){
            Set<Long> tempIsChild = new HashSet<>(300);
            List<Long> allIds = unsynchronizedKeys();
            for (Long partnerId : allIds){
                CRSPartner crsPartner = unsynchronizedGet(partnerId);
                if ( crsPartner.getInternalAccountId()!=null && isParent( partnerId, MAX_DEPTH)){
                    tempIsChild.add(crsPartner.getInternalAccountId());
                }
            }
            // Swap in the new settings
            isChild=tempIsChild;
        }

        private boolean isParent( Long partnerId, int depth){
            CRSPartner crsPartner = unsynchronizedGet(partnerId);
            if (crsPartner == null){
                return false;       // Not in the repo [yet]
            } else if ( crsPartner.getInternalAccountId()!=null && crsPartner.getInternalAccountId().equals(parentInternalAccountId)){
                return true;
            } else if ( crsPartner.getParentPartnerId() == null){
                return false;       // At root
            } else if (depth--==0){
                return false;
            }
            return isParent(crsPartner.getParentPartnerId(), depth);
        }

        public boolean isChild(long ownerId){
            return isChild.contains(ownerId);
        }

    }

    /**
     * Check to see if the OwnerId (NOT Partner.id) is Comcast or a child of Comcast based on the Partner Tree.
     *
     * @param ownerId
     * @return
     */
    public boolean isComcastOwnerId(long ownerId){
        return comcastParent.isChild(ownerId);
    }

}
