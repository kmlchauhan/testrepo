package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.tv.entity.api.data.objects.TagType;

/**
 * @author Segun Abimbola (oabimb200)
 * 2/05/18
 */
public class CRSStreamNamespace extends LongDataRepoObject {

    private String title;

    public CRSStreamNamespace() {
        super( SiriusObjectType.fromFriendlyName("StreamNamespace"));
    }

    public CRSStreamNamespace(long id) {
        super( SiriusObjectType.fromFriendlyName("StreamNamespace"), id);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
