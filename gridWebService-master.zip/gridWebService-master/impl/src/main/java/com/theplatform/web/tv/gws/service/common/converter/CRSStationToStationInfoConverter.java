package com.theplatform.web.tv.gws.service.common.converter;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.web.tv.combine.commons.MerlinService;
import com.theplatform.web.tv.contentresolution.api.objects.CompanyAssociationInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;
import com.theplatform.web.tv.gws.sirius.model.CRSStation;
import com.theplatform.web.tv.gws.sirius.model.CRSStationCompany;
import com.theplatform.web.tv.gws.sirius.repository.LinearTagAssociationRepository;
import com.theplatform.web.tv.gws.sirius.repository.StationCompanyRepository;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Required;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.lang.System.currentTimeMillis;

public class CRSStationToStationInfoConverter {

    private CRSStationCompanyToCompanyAssociationConverter crsStationCompanyToCompanyAssociationConverter;
    private StationCompanyRepository stationCompanyRepository;
    private LinearTagAssociationRepository linearTagAssociationRepository;

    public StationInfo convert( CRSStation crsStation, MerlinIdHelper merlinIdHelper, String recorderManager){
        StationInfo stationInfo = new StationInfo();
        if (crsStation != null) {
            long convertStationStartTime = currentTimeMillis();
            stationInfo.setStationId(merlinIdHelper.createStationId( crsStation.getId()) );
            stationInfo.setTitle(crsStation.getTitle());
            stationInfo.setCallsign(crsStation.getCallSign());
            stationInfo.setTimeZone(crsStation.getTimeZone());
            if (crsStation.getExpirationDate() != 0) {
                Date date = new DateTime(crsStation.getExpirationDate(), DateTimeZone.UTC).toDate();
                stationInfo.setExpirationDate(date);
            }
            if (crsStation.getAssociatedStationId() != 0)
                stationInfo.setTransientAssociatedStationId(merlinIdHelper.createStationId(crsStation.getAssociatedStationId()));
            stationInfo.setLanguage(crsStation.getLanguage());
            if (crsStation.getOtaChannelNumber() != 0)
                stationInfo.setOtaChannelNumber(crsStation.getOtaChannelNumber());
            stationInfo.setPayPerView(crsStation.getPayPerView());
            stationInfo.setShortName(crsStation.getShortName());
            stationInfo.setVod(crsStation.getVod());
            stationInfo.setCompanyAssociations(getCompanyAssociationInfo( crsStation.getId(), merlinIdHelper));
            stationInfo.setColorDepth(crsStation.getColorDepth());
            stationInfo.setHdLevel(crsStation.getHdLevel());
            stationInfo.setQuality(crsStation.getQuality());
            stationInfo.setQualityVariants(getQualityVariants(crsStation.getQualityVariants(), merlinIdHelper));

            if (CollectionUtils.isNotEmpty(linearTagAssociationRepository.getTagIds(crsStation.getId()))){
                List<Muri> tagIds = merlinIdHelper.createIds( linearTagAssociationRepository.getTagIds(crsStation.getId()), MerlinService.ENTITY, MerlinEntityType.TAG);
                stationInfo.setTagIds(tagIds);
            }

            if (recorderManager != null) {
                stationInfo.setRecorderManager( recorderManager);
            }
        }

        return stationInfo;
    }

    public List<CompanyAssociationInfo> getCompanyAssociationInfo( long stationId, MerlinIdHelper merlinIdHelper) {
        Collection<CRSStationCompany> crsStationCompanys= stationCompanyRepository.getStationCompanyByStationId(stationId);

        return crsStationCompanyToCompanyAssociationConverter.convert( crsStationCompanys, merlinIdHelper);
    }

    private Map<String, Muri> getQualityVariants(Map<String, Long> qualityVariants, MerlinIdHelper merlinIdHelper){
        Map<String, Muri> result = new HashMap<>();

        if (qualityVariants == null || qualityVariants.size() == 0)
            return result;

        for (Map.Entry<String, Long> entry: qualityVariants.entrySet()){
            result.put(entry.getKey(), merlinIdHelper.createStationId(entry.getValue()));
        }
        return result;
    }

    @Required
    public void setCrsStationCompanyToCompanyAssociationConverter(CRSStationCompanyToCompanyAssociationConverter crsStationCompanyToCompanyAssociationConverter) {
        this.crsStationCompanyToCompanyAssociationConverter = crsStationCompanyToCompanyAssociationConverter;
    }

    @Required
    public void setStationCompanyRepository(StationCompanyRepository stationCompanyRepository) {
        this.stationCompanyRepository = stationCompanyRepository;
    }

    @Required
    public void setLinearTagAssociationRepository(LinearTagAssociationRepository linearTagAssociationRepository) {
        this.linearTagAssociationRepository = linearTagAssociationRepository;
    }
}
