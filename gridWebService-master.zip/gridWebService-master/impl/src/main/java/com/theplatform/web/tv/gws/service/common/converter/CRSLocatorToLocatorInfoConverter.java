package com.theplatform.web.tv.gws.service.common.converter;

import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.LocatorInfo;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.sirius.repository.ChannelRepository;
import com.theplatform.web.tv.gws.sirius.repository.CompanyRepository;
import com.theplatform.web.tv.gws.sirius.repository.LocatorRepository;
import com.theplatform.web.tv.gws.sirius.repository.StationCompanyRepository;
import com.theplatform.web.tv.gws.sirius.repository.StreamNamespaceRepository;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import java.util.stream.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.*;

public class CRSLocatorToLocatorInfoConverter {
    private static Logger logger = LoggerFactory.getLogger(CRSLocatorToLocatorInfoConverter.class);

    private ChannelRepository channelRepository;
    private LongObjectRepository<CRSStation> stationRepository;
    private LocatorRepository locatorRepository;
    private CompanyRepository companyRepository;
    private StationCompanyRepository stationCompanyRepository;
    private StreamNamespaceRepository streamNamespaceRepository;

    private String defaultVodLocatorUrl;
    private String vodLocatorUrl;

    private MerlinIdHelper merlinIdHelper;

    /**
     *  Return an ordered list of LocatorInfo for a given CRSStream
     *
     *  Note: We use the Stream Owner Id when looking up IP Locators unlike OnDemand Locators
     */
    @Deprecated
    public List<LocatorInfo> getIpLocators( CRSStream crsStream){
        List<LocatorInfo> locatorInfos = new ArrayList<>();
        Set<CRSLocator> crsLocators = locatorRepository.getIPLocators( crsStream.getOwnerId(), crsStream.getId());
        if (crsLocators==null) return locatorInfos;
        for ( CRSLocator crsLocator : crsLocators){
            locatorInfos.add( convertIpLocator(crsLocator, crsStream));
        }
        if (locatorInfos.size()>1){
            Collections.sort(locatorInfos);
        }
        return locatorInfos;
    }

    public LocatorInfo getQAMLocator(Long channelId, long stationId){
        CRSChannel crsChannel = channelRepository.get(channelId);

        // IpDeliveryOnly Won't have a QAM Locator
        if (crsChannel==null || crsChannel.isIpDeliveryOnly()){
            return null;
        }

        LocatorInfo qamLocator = null;
        if (channelId != null){
            qamLocator = getChannelQAMLocator(channelId);
        }
        if (qamLocator == null){
            qamLocator = getStationQAMLocator(stationId);
        }
        return qamLocator;
    }

    /**
     *  Note: We use the caller's Owner Id when looking up OnDemand Locators unlike IP Locators which uses the
     *  Stream's Owner Id.
     */
    public LocatorInfo getOnDemandLocator(long stationId, Long ownerId){
        CRSStation crsStation = stationRepository.get(stationId);

        // Check VOD - if VOD is false then then return null.
        if (crsStation==null || crsStation.getVod()==null || !crsStation.getVod().booleanValue()){
            return null;
        }
        LocatorInfo locatorInfo = null;

        // Try Linear Locator with StationId OwnerId
        Set<CRSLocator> locatorInfos = locatorRepository.getOnDemandLocators( ownerId, stationId);
        if (locatorInfos!=null && locatorInfos.size()>0){
            if (locatorInfos.size()>1){
                logger.warn("Multiple onDemand locators were found for stationId: " + stationId + "; ownerId: " + ownerId);
            }
            CRSLocator crsLocator = getOneLocator(locatorInfos);
            locatorInfo = convertLocator(crsLocator);
        }

        // Get the Station Locator of default station locator
        if (locatorInfo == null){
            locatorInfo = getDefaultOnDemandLocator(crsStation.getId());
        }

        return locatorInfo;
    }

    public Collection<LocatorInfo> convertIpLocators( Collection<CRSLocator> crsLocators, CRSStream crsStream) {
        return crsLocators.stream()
                .map(crsLocator -> convertIpLocator(crsLocator, crsStream))
                .sorted()
                .collect(Collectors.toList());
    }

    public LocatorInfo convertIpLocator( CRSLocator crsLocator, CRSStream crsStream) {
        LocatorInfo locatorInfo = convertLocator(crsLocator);

        // Add the Stream Info to the ip locator
        locatorInfo.setStreamId(merlinIdHelper.createStreamId(crsStream.getId()));
        locatorInfo.setStatus(crsStream.getStatus());
        locatorInfo.setExternal(crsStream.getExternal());
        locatorInfo.setIsDai(crsStream.getIsDai());
        locatorInfo.setServiceZoneType(crsStream.getServiceZoneType());
        locatorInfo.setType(crsStream.getType());
        locatorInfo.setTravelRights(crsStream.getTravelRights());
        if (crsLocator.getPlayerConfig() != null && !crsLocator.getPlayerConfig().isEmpty()){
            locatorInfo.setPlayerConfig(crsLocator.getPlayerConfig());
        }
        return locatorInfo;
    }


    protected LocatorInfo getChannelQAMLocator(Long channelId){
        LocatorInfo locator = null;
        CRSChannel crsChannel = channelRepository.get(channelId);
        if (crsChannel!=null && crsChannel.getDigicableId()!=0){
            locator = new LocatorInfo();
            locator.setFormat("QAM");
            locator.setLocatorUri( new Muri("ocap://0x" + Long.toHexString(crsChannel.getDigicableId())));
        }
        return locator;
    }

    protected LocatorInfo getStationQAMLocator(Long stationId){
        LocatorInfo locator = null;
        CRSStation crsStation = stationRepository.get(stationId);
        if (crsStation!=null && crsStation.getDigicableId()!=0){
            locator = new LocatorInfo();
            locator.setFormat("QAM");
            locator.setLocatorUri( new Muri("ocap://0x" + Long.toHexString(crsStation.getDigicableId())));
        }
        return locator;
    }

    private LocatorInfo convertLocator( CRSLocator crsLocator){
        LocatorInfo locatorInfo = new LocatorInfo();
        if (crsLocator.getId() != 0){
            locatorInfo.setLocatorId( merlinIdHelper.createLocatorId(crsLocator.getId()));
        }
        if (crsLocator.getBitrate()!=null && crsLocator.getBitrate() != 0)
            locatorInfo.setBitrate(crsLocator.getBitrate());
        locatorInfo.setCodec(crsLocator.getCodec());
        locatorInfo.setFormat(crsLocator.getFormat());
        if (crsLocator.getHeight() != null && crsLocator.getHeight() != 0)
            locatorInfo.setHeight(crsLocator.getHeight());
        if (crsLocator.getLocatorURI()!=null){
            locatorInfo.setLocatorUri(new Muri(crsLocator.getLocatorURI()));
        }
        locatorInfo.setProtectionScheme(crsLocator.getProtectionScheme());
        if (crsLocator.getWidth()!=null && crsLocator.getWidth() != 0)
            locatorInfo.setWidth(crsLocator.getWidth());
        locatorInfo.setProvider(crsLocator.getProvider());
        locatorInfo.setExternalStreamId(crsLocator.getExternalStreamId());
        locatorInfo.setQuality(crsLocator.getQuality());

        if (crsLocator.getNamespaceId() != null){
            CRSStreamNamespace streamNamespace = streamNamespaceRepository.get(crsLocator.getNamespaceId());
            if (streamNamespace != null){
                locatorInfo.setNamespaceId(merlinIdHelper.createStreamNamespaceId(crsLocator.getNamespaceId()));
                locatorInfo.setNamespaceTitle(streamNamespace.getTitle());
            }
        }
        return locatorInfo;
    }

    // Deterministically get one Locator
    private CRSLocator getOneLocator(Set<CRSLocator> crsLocators){
        CRSLocator crsLocator = null;
        for (CRSLocator l : crsLocators){
            if (crsLocator == null){
                crsLocator = l;
            }else if (crsLocator.getId() < l.getId()){
                crsLocator = l;
            }
        }
        return crsLocator;
    }

    private LocatorInfo getDefaultOnDemandLocator(long StationId){
        String url = defaultVodLocatorUrl;
        Collection<CRSStationCompany> crsStationCompanies = stationCompanyRepository.getStationCompanyByStationId(StationId);
        if (crsStationCompanies.size()>0){
            long companyId = getStationCompanyWithMinCompanyId(crsStationCompanies);
            CRSCompany crsCompany = companyRepository.get(companyId);
            if (crsCompany!=null){
                url = determineOnDemandVodLocatorBasedOnCompanies(crsCompany);
            }
        }

        LocatorInfo onDemandLocator = new LocatorInfo();
        onDemandLocator.setFormat("OnDemand");
        onDemandLocator.setLocatorUri( new Muri(url));
        return onDemandLocator;
    }

    /**
     * Create a url from the given stationCompany instance
     */
    private String determineOnDemandVodLocatorBasedOnCompanies(CRSCompany crsCompany) {
        String url = null;
        try {
            String companyUrl = URLEncoder.encode(crsCompany.getDisplayName(), "UTF-8");
            String companyId = Long.toString(crsCompany.getId());
            url = String.format("%scompanyName=%s&companyId=%s", vodLocatorUrl, companyUrl, companyId);
        } catch (UnsupportedEncodingException e) {
            logger.error("UnsupportedEncodingException when creating OnDemand Locator.locatorURI for companyName="
                    + crsCompany.getDisplayName() + "; companyId=" + crsCompany.getId());
        }
        return url;
    }

    private long getStationCompanyWithMinCompanyId(Collection<CRSStationCompany> stationCompanys) {
        long minimumCompanyId = Long.MAX_VALUE;
        for (CRSStationCompany stationCompany : stationCompanys) {
            if (stationCompany.getCompanyId() <= minimumCompanyId) {
                minimumCompanyId = stationCompany.getCompanyId();
            }
        }
        return minimumCompanyId;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    @Required
    public void setStationRepository(LongObjectRepository<CRSStation> stationRepository) {
        this.stationRepository = stationRepository;
    }

    @Required
    public void setLocatorRepository(LocatorRepository locatorRepository) {
        this.locatorRepository = locatorRepository;
    }

    @Required
    public void setDefaultVodLocatorUrl(String defaultVodLocatorUrl) {
        this.defaultVodLocatorUrl = defaultVodLocatorUrl;
    }

    @Required
    public void setVodLocatorUrl(String vodLocatorUrl) {
        this.vodLocatorUrl = vodLocatorUrl;
    }

    @Required
    public void setCompanyRepository(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }

    @Required
    public void setStationCompanyRepository(StationCompanyRepository stationCompanyRepository) {
        this.stationCompanyRepository = stationCompanyRepository;
    }

    @Required
    public void setStreamNamespaceRepository(StreamNamespaceRepository streamNamespaceRepository){
        this.streamNamespaceRepository = streamNamespaceRepository;
    }
}
