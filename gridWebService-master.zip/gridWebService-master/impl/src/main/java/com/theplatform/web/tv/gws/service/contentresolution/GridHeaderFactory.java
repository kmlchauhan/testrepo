package com.theplatform.web.tv.gws.service.contentresolution;

import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.contentresolution.api.objects.Grid;
import com.theplatform.web.tv.contentresolution.api.objects.Header;
import com.theplatform.web.tv.gws.service.common.util.GridUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class GridHeaderFactory {

    // Not exposed externally
    public static Grid createGridHeader(Integer numGridUnits, Integer gridUnitWidth, Integer offset, String timeZone) throws GridException {

        // default the number of grid units if they are not supplied
        if (null == numGridUnits)
            numGridUnits = ContentResolutionDefaults.DEFAULT_NUM_GRID_UNITS;

        // default the grid unit length if it is not supplied
        if (null == gridUnitWidth)
            gridUnitWidth = ContentResolutionDefaults.DEFAULT_GRID_UNIT_WIDTH;

        // default offset if it is not supplied
        if (null == offset)
            offset = ContentResolutionDefaults.DEFAULT_GRID_OFFSET;

        // get the timezone based on user input or default timezone
        TimeZone tz = GridUtils.getTimeZone(timeZone, ContentResolutionDefaults.DEFAULT_TIME_ZONE);

        // determine start time and end times based on grid units, unit widths, offset, and current time
        Date now = new Date();
        Date offsetTime = new Date(now.getTime() + TimeUnit.MINUTES.toMillis(gridUnitWidth * offset));
        Date currentTime = GridUtils.rollBackToStartOfGridUnit(offsetTime, gridUnitWidth);
        Date endTime = new Date(currentTime.getTime() + TimeUnit.MINUTES.toMillis(numGridUnits * gridUnitWidth));

        List<Header> headers = new ArrayList<Header>();
        long gridUnitWidthInMillis = TimeUnit.MINUTES.toMillis(gridUnitWidth);

        // while there are still grid units in the grid range, add their headers to the list
        while (currentTime.getTime() != endTime.getTime()) {
            long endTimeMillis = currentTime.getTime() + gridUnitWidthInMillis;

            // create header and add it to the list
            Header header = new Header();
            header.setStartTime(new Date(currentTime.getTime()));
            header.setEndTime(new Date(endTimeMillis));
            header.setTitle(GridUtils.getTime(currentTime, tz));
            headers.add(header);

            // increment to the next grid unit
            currentTime.setTime(currentTime.getTime() + gridUnitWidthInMillis);
        }
        Grid grid = new Grid();
        grid.setHeader(headers);
        return grid;
    }
}
