package com.theplatform.web.tv.gws.sirius.converter;


import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.location.api.data.objects.RecorderManager;
import com.theplatform.web.tv.gws.sirius.model.CRSRecorderManager;

public class RecorderManagerConverter extends AbstractDataObjectConverter<RecorderManager, CRSRecorderManager> {

    @Override
    public CRSRecorderManager convert(RecorderManager recorderManager) {
        CRSRecorderManager crsRecorderManager = new CRSRecorderManager();

        crsRecorderManager.setId(LocalUriConverter.convertUriToID(recorderManager.getId()));
        crsRecorderManager.setType(recorderManager.getType());
        crsRecorderManager.setNativeId(recorderManager.getNativeId());
        if (recorderManager.getRegionId()!=null) {
            crsRecorderManager.setRegionId(Muri.getObjectId(recorderManager.getRegionId()));
        }

        return crsRecorderManager;
    }

}
