package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.StationCompanyProto.StationCompanyMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSStationCompany;

public class StationCompanySerializer extends AbstractSiriusObjectSerializer<CRSStationCompany> {

    public StationCompanySerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    protected CRSStationCompany unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        StationCompanyMessage.Builder message = StationCompanyMessage.newBuilder().mergeFrom(bytes);

        CRSStationCompany crsStationCompany = new CRSStationCompany(message.getId());
        crsStationCompany.setStationId(message.getStationId());
        crsStationCompany.setCompanyId(message.getCompanyId());
        if (message.hasAssociationType()){
            crsStationCompany.setAssociationType(message.getAssociationType());
        }
        return crsStationCompany;
    }

    @Override
    protected ByteString marshallPayload(CRSStationCompany payload) {
        StationCompanyMessage.Builder builder = StationCompanyMessage.newBuilder();
        builder.setId(payload.getId());
        builder.setStationId(payload.getStationId());
        builder.setCompanyId(payload.getCompanyId());
        if (payload.getAssociationType() != null ){
            builder.setAssociationType(payload.getAssociationType());
        }
        return builder.build().toByteString();
    }
}
