package com.theplatform.web.tv.gws.service.contentresolution;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.comcast.merlin.sirius.repository.SingletonRepository;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.contrib.stats.StatsCollector;
import com.theplatform.contrib.web.service.BaseWebServiceImpl;
import com.theplatform.module.exception.BadParameterException;
import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.contentresolution.api.ContentResolutionService;
import com.theplatform.web.tv.contentresolution.api.annotation.ResolveChannelsValidation;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import com.theplatform.web.tv.contentresolution.api.objects.episodes.EpisodeMap;
import com.theplatform.web.tv.gws.service.common.aop.stats.CollectStats;
import com.theplatform.web.tv.gws.service.common.converter.CRSChannelToChannelInfoConverter;
import com.theplatform.web.tv.gws.service.common.converter.CRSListingToListingInfoConverter;
import com.theplatform.web.tv.gws.service.common.converter.CRSProgramToProgramInfoConverter;
import com.theplatform.web.tv.gws.service.common.converter.CRSTrendingProgramToTrendingProgramConverter;
import com.theplatform.web.tv.gws.service.common.debug.DebugHelper;
import com.theplatform.web.tv.gws.service.common.field.FieldFilterUtil;
import com.theplatform.web.tv.gws.service.common.logic.Scope;
import com.theplatform.web.tv.gws.service.common.logic.ScopedAvailabilities;
import com.theplatform.web.tv.gws.service.common.util.*;
import com.theplatform.web.tv.gws.service.contentresolution.episodes.EpisodesHelper;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.sirius.repository.*;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import javax.jws.WebParam;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static java.lang.System.currentTimeMillis;

/**
 * @author pdwinnell
 */
public class ContentResolutionServiceImpl extends BaseWebServiceImpl implements ContentResolutionService {

    private static final String INCLUDE_ALWAYS = "verboseInfo";
    public static final String ADULT = "Adult";

    protected StatsCollector statsCollector = StatsCollector.getInstance();
    private DynamicProperties dynamicProperties;
    private MerlinDAO merlinDAO;
    private GridMapper gridMapper;
    private ContentResolutionHelper contentResolutionHelper;
    private BackendServiceHelper backendServiceHelper;

    private CRSListingToListingInfoConverter CRSListingToListingInfoConverter;
    private CRSTrendingProgramToTrendingProgramConverter crsTrendingProgramConverter;
    private CRSProgramToProgramInfoConverter crsProgramToProgramInfoConverter;
    private CRSChannelToChannelInfoConverter crsChannelToChannelInfoConverter;
    private SingletonRepository<CRSTrendingPrograms> trendingProgramsRepository;
    private ProgramRepository programRepository;
    private ChannelRepository channelRepository;
    private StreamRepository streamRepository;
    private LocatorRepository locatorRepository;
    private ContentAvailabilityRepository contentAvailabilityRepository;
    private AvailabilitiesResolutionModifier availabilitiesResolutionModifier;
    private Boolean validateFieldFilterNames = Boolean.FALSE;

    private TagRepository tagRepository;

    private TakedownHelper takedownHelper;
    private OwnerUtil ownerUtil;

    private DebugHelper debugHelper;
    private EpisodesHelper episodesHelper;
    private MerlinIdHelper merlinIdHelper;

    private Set<String> createAllowedStreamStatusSet(String byStreamStatus) {
        if (StringUtils.isEmpty(byStreamStatus))
            return ContentResolutionDefaults.DEFAULT_STREAM_STATUS_SET;
        String[] split = byStreamStatus.split("\\|");
        for (int i = 0; i < split.length; i++) {
            split[i] = split[i].trim();
        }
        HashSet<String> allowedStreamStatus = new HashSet<>(Arrays.asList(split));
        return allowedStreamStatus;
    }

    @ResolveChannelsValidation
    @Override
    public ChannelInfoCollection resolveChannels(AvailabilityResolution availabilityResolution,
                                                 String fields,
                                                 String byStreamStatus,
                                                 Boolean filterAdult) throws GridException {
        long resolveChannelsStartTime = currentTimeMillis();

        availabilitiesResolutionModifier.modify(availabilityResolution);

        Set<String> allowedStreamStatus = createAllowedStreamStatusSet(byStreamStatus);

        ScopedAvailabilities scopedAvailabilities = ScopedAvailabilities.create(availabilityResolution);

        // If there are no Station Scopes, do not proceed. We cannot continue because we glean the OwnerId from the
        // first station's Location.  Also, DO NOT REPLACE THIS WITH ASPECTS!
        if (scopedAvailabilities.getByScope(Scope.STATION).size()==0){
            return new ChannelInfoCollection();
        }

        List<ChannelInfo> channelInfosList = contentResolutionHelper.getChannelMap(scopedAvailabilities, allowedStreamStatus);

        if (filterAdult != null && filterAdult == true)
            channelInfosList = contentResolutionHelper.filterOutChannelInfosByTags(channelInfosList, getAdultTagFromRepo());

        // Take down any blacklisted channel/stations
        long ownerId = ownerUtil.getOwnerId(scopedAvailabilities);
        channelInfosList = takedownHelper.takedownBlacklistedStations(ownerId,channelInfosList);

        ChannelInfoCollection channelInfoCollection = new ChannelInfoCollection();
        channelInfoCollection.setChannels(channelInfosList);
        channelInfoCollection.setVersion(availabilityResolution.getVersion());

        FieldFilterUtil.filterFields(channelInfoCollection, fields, this.validateFieldFilterNames, INCLUDE_ALWAYS);


        return debugHelper.applyWarnings(channelInfoCollection);
    }

    private CRSTag[] getAdultTagFromRepo() {
        return tagRepository.getCRSTTagsByTitle(ADULT);
    }

    /**
     * Remove any Channel's where stationInfo.stream.streamId is not equal to the provided streamId
     * @param channelInfos not null
     * @param streamId not null
     */
    private void filterByStreamId(ChannelInfoCollection channelInfos, Long streamId) {
        List<ChannelInfo> channelInfoList = new ArrayList<>();
        for (ChannelInfo current : channelInfos.getChannels()) {
            // Find the Channels StreamId if it exists
            Long currentStreamId = null;
            if ( current.getLocators()!=null ){
                for(LocatorInfo locatorInfo : current.getLocators()){
                    if (locatorInfo.getStreamId()!=null){
                        currentStreamId = locatorInfo.getStreamId().getId();
                        break;
                    }
                }
            }

            // Channels without a streamId are always filtered
            if ( currentStreamId == null){
                continue;
            }

            // if the streamId equals the streamId that we're searching for, keep it
            if (streamId.equals(currentStreamId)) {
                channelInfoList.add(current);
            }
        }
        channelInfos.setChannels(channelInfoList);
    }

    @ResolveChannelsValidation
    @Override
    public ChannelInfoCollection resolveChannelsByStreamId(AvailabilityResolution availabilityResolution, Long streamId, String fields,
                                                           Boolean filterAdult) throws GridException {
        String streamStatus;

        if (streamId == null) {
            throw new BadParameterException("streamId is required");
        }

        if (streamRepository.containsKey(streamId)) {
            streamStatus = streamRepository.get(streamId).getStatus();
        } else {
            // resort to old behavior when stream is not found
            streamStatus = "Staging|Production";
        }

        ChannelInfoCollection channelInfos = resolveChannels(availabilityResolution, null, streamStatus, filterAdult);
        filterByStreamId(channelInfos, streamId);

        // filter the fields after we've filtered by stream id
        if (StringUtils.isNotBlank(fields)) {
            FieldFilterUtil.filterFields(channelInfos, fields, this.validateFieldFilterNames, INCLUDE_ALWAYS);
        }

        return channelInfos;
    }

    @CollectStats
    @ResolveChannelsValidation
    @Override
    public Grid getGrid(AvailabilityResolution availabilityResolution, Integer numGridUnits,
                        Integer gridUnitWidth, Integer offset, String timeZone, String[] categories, Long[] companyIds, Long[] stationTagIds,
                        String[] locatorFormats, Boolean hd, Integer rowStart, Integer rowEnd, Long[] programTagIds, String fields) throws GridException {

        availabilitiesResolutionModifier.modify(availabilityResolution);

        Grid grid;
        List<Header> header = GridHeaderFactory.createGridHeader(numGridUnits, gridUnitWidth, offset, timeZone).getHeader();
        ScopedAvailabilities scopedAvailabilities = ScopedAvailabilities.create(availabilityResolution);

        if (categories == null) {
            ChannelInfoCollection channels = getChannelsForGrid(availabilityResolution, null, null, null, categories,
                    companyIds, stationTagIds, locatorFormats, hd, rowStart, rowEnd);
            grid = gridMapper.createGrid(channels.getChannels(), header, this, numGridUnits, gridUnitWidth, offset, programTagIds);
        } else {
            // If we are filtering channels by the categories of the programs on the channel, we don't
            // necessarily know all the channels we will or wont return, so get back the entire list of channels
            // for the location (ignore any rowStart or rowEnd parameters).
            ChannelInfoCollection unfilteredChannels = getChannelsForGrid(availabilityResolution, numGridUnits,
                    gridUnitWidth, offset, null, companyIds, stationTagIds, locatorFormats, hd, 1, null);
            grid = gridMapper.createFilteredGrid(unfilteredChannels.getChannels(), header, this, numGridUnits, gridUnitWidth, offset, categories, programTagIds);

            List<ChannelInfo> channelsFilteredByCategory = grid.getChannels();
            List<ChannelInfo> channels = filterByRows(channelsFilteredByCategory, rowStart, rowEnd);
            grid.setChannels(channels);
        }
        FieldFilterUtil.filterFields(grid, fields, this.validateFieldFilterNames, INCLUDE_ALWAYS);

        return debugHelper.applyWarnings(grid);
    }

    static private List<ChannelInfo> filterOutNonHd(List<ChannelInfo> channels) {
        List<ChannelInfo> filteredChannels = new ArrayList<ChannelInfo>();
        for (ChannelInfo channelInfo : channels) {
            if (channelInfo.getStationInfo().getQuality().equals("HD")) {
                filteredChannels.add(channelInfo);
            }
        }
        return filteredChannels;
    }

    @CollectStats
    @ResolveChannelsValidation
    @Override
    public Grid getGridByDate(AvailabilityResolution availabilityResolution, Date startTime,
                              Integer numGridUnits, Integer gridUnitWidth, String timeZone, String[] categories, Long[] companyIds, Long[] stationTagIds,
                              String[] locatorFormats, Boolean hd, Integer rowStart, Integer rowEnd, Long[] programTagIds, String fields) throws GridException {
        // default the grid unit length if it is not supplied
        if (null == gridUnitWidth)
            gridUnitWidth = ContentResolutionDefaults.DEFAULT_GRID_UNIT_WIDTH;

        // Default to 0
        Integer offsetMinutes = 0;
        if (startTime != null) {
            offsetMinutes = (int) ((GridUtils.rollBackToStartOfGridUnit(startTime, gridUnitWidth).getTime()
                    - GridUtils.rollBackToStartOfGridUnit(new Date(), gridUnitWidth).getTime()
            )
                    / 60000);
        }

        int offset = (offsetMinutes / gridUnitWidth);

        return getGrid(availabilityResolution, numGridUnits, gridUnitWidth, offset, timeZone, categories,
                companyIds, stationTagIds, locatorFormats, hd, rowStart, rowEnd, programTagIds, fields);

    }

    private ChannelInfoCollection getChannelsForGrid(AvailabilityResolution availabilityResolution,
                                                     Integer numGridUnits, Integer gridUnitWidth, Integer offset, String[] categories, Long[] companyIds, Long[] stationTagIds,
                                                     String[] locatorFormats, Boolean hd, Integer rowStart, Integer rowEnd) throws GridException {
        // check for illegal or missing arguments on the api call
        for (Object requiredParam : new Object[]{availabilityResolution}) {
            if (requiredParam == null) {
                throw new BadParameterException("availabilityResolution params must be provided");
            }
        }
        ChannelInfoCollection collection = new ChannelInfoCollection();

        List<ChannelInfo> channels;
        if (categories != null) {
            // categories filtering happens in getGrid
            Grid grid = getGrid(availabilityResolution, numGridUnits, gridUnitWidth, offset, null, categories,
                    companyIds, stationTagIds, locatorFormats, hd, null, null, null, null);

            // this method isn't supposed to return Listings, but we just called getGrid (which does)
            for (ChannelInfo channelInfo : grid.getChannels()) {
                StationInfo stationInfo = channelInfo.getStationInfo();
                stationInfo.setListings(null);
            }

            channels = grid.getChannels();
        } else {
            ChannelInfoCollection channelInfoCollection = this.resolveChannels(availabilityResolution, null, null,false);
            List<ChannelInfo> channelInfos = channelInfoCollection.getChannels();
            channels = channelInfos;
        }
        if (hd != null && hd) {
            channels = filterOutNonHd(channels);
        }
        if (stationTagIds != null && stationTagIds.length > 0) {
            channels = filterByStationTagIds(channels, Arrays.asList(stationTagIds));
        }
        if (companyIds != null && companyIds.length > 0) {
            channels = filterByCompanyIds(channels, Arrays.asList(companyIds));
        }

        channels = filterByRows(channels, rowStart, rowEnd);

        collection.setVersion(availabilityResolution.getVersion());
        collection.setChannels(channels);

        return debugHelper.applyWarnings(collection);
    }

    @CollectStats
    @Override
    public List<ListingInfo> getListings(Long stationId, Integer numGridUnits, Integer gridUnitWidth, Integer offset, Long[] programTagIds, String fields) {

        // check for illegal or missing arguments on the api call
        if (null == stationId)
            throw new BadParameterException("stationId param cannot be null on getChannels call");

        // default the number of grid units if they are not supplied
        if (null == numGridUnits)
            numGridUnits = ContentResolutionDefaults.DEFAULT_NUM_GRID_UNITS;

        // default the grid unit length if it is not supplied
        if (null == gridUnitWidth)
            gridUnitWidth = ContentResolutionDefaults.DEFAULT_GRID_UNIT_WIDTH;

        // default offset if it is not supplied
        if (null == offset)
            offset = ContentResolutionDefaults.DEFAULT_GRID_OFFSET;

        // determine start time and end times based on grid units, unit widths, offset, and current time
        Date now = new Date();
        Date offsetTime = new Date(now.getTime() + TimeUnit.MINUTES.toMillis(gridUnitWidth * offset));
        Date startTime = GridUtils.rollBackToStartOfGridUnit(offsetTime, gridUnitWidth);
        Date endTime = new Date(startTime.getTime() + TimeUnit.MINUTES.toMillis(numGridUnits * gridUnitWidth));

        // Remove the one second off the end of the endTime
        endTime = GridUtils.roundDateDownToMinute(endTime);

        return getListings(stationId, startTime, endTime, programTagIds, fields);
    }

    private List<ListingInfo> getListings(Long stationId, Date startTime, Date endTime, Long[] programTagIds, String fields) {
        // retrieve listings for specified time interval on specified station id
        long getListingsFromRepoStartTime = currentTimeMillis();
        List<CRSListing> listings = merlinDAO.retrieveListings(stationId, startTime, endTime);

        // map listings to listing info objects
        long convertListingsStartTime = currentTimeMillis();
        List<ListingInfo> listingInfos = CRSListingToListingInfoConverter.convert(listings, startTime, endTime, programTagIds);

        // filter fields if applicable
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);

        return listingInfos;
    }

    @CollectStats
    @Override
    public List<ListingInfo> getListingsByDate(Long stationId, Date startTime, Date endTime, Integer gridUnitWidth, Long[] programTagIds, String fields) {
        ValidateUtil.validateDates(startTime, endTime);

        // check for illegal or missing arguments on the api call
        if (null == stationId)
            throw new BadParameterException("stationId param cannot be null on getChannels call");

        // set defaults for start time if necessary
        if (null == startTime)
            startTime = new Date();

        // set default for end time if necessary
        if (null == endTime)
            endTime = new Date(startTime.getTime() + TimeUnit.HOURS.toMillis(ContentResolutionDefaults.DEFAULT_GRID_TIME_RANGE));

        // default the grid unit length if it is not supplied:
        if (null == gridUnitWidth)
            gridUnitWidth = ContentResolutionDefaults.DEFAULT_GRID_UNIT_WIDTH;

        startTime = GridUtils.rollBackToStartOfGridUnit(startTime, gridUnitWidth);
        endTime = GridUtils.rollForwardToNextGridUnit(endTime, gridUnitWidth);

        // check for a start time that is later than the end time
        if (startTime.after(endTime))
            throw new BadParameterException("startTime param cannot correspond to a time later than the endTime param");

        return getListings(stationId, startTime, endTime, programTagIds, fields);
    }

    @CollectStats
    @Override
    public List<ListingInfo> getListingsById(@WebParam(name = "listingIds") List<Muri> listingIds,
                                             @WebParam(name = "programTagIds") Long[] programTagIds,
                                             @WebParam(name = "fields") String fields) throws GridException {
        if (listingIds == null) {
            throw new BadParameterException("listingIds param cannot be null on getListingsById call");
        }
        List<CRSListing> listings = merlinDAO.retrieveListings( Muri.getIds(listingIds));

        List<ListingInfo> listingInfos = CRSListingToListingInfoConverter.convert(listings, null, null, programTagIds);

        // filter fields if applicable
        FieldFilterUtil.filterFieldsForEach(listingInfos, fields);

        return listingInfos;
    }

    @Override
    public IdCollection getStationsBySeriesId(@WebParam(name = "seriesIds") Muri[] seriesIds,
                                              @WebParam(name = "startTime") Date startTime,
                                              @WebParam(name = "endTime") Date endTime) {
        if (seriesIds == null || seriesIds.length == 0) {
            throw new BadParameterException("The seriesIds parameter is required and was not populated.");
        }

        return contentResolutionHelper.getStationIdsByIds("series", seriesIds, startTime, endTime);
    }

    @Override
    public IdCollection getStationsBySportsTeamId(@WebParam(name = "sportsTeamIds") Muri[] sportsTeamIds,
                                                  @WebParam(name = "startTime") Date startTime,
                                                  @WebParam(name = "endTime") Date endTime) {
        if (sportsTeamIds == null || sportsTeamIds.length == 0) {
            throw new BadParameterException("The sportsTeamIds parameter is required and was not populated.");
        }

        return contentResolutionHelper.getStationIdsByIds("sportsteam", sportsTeamIds, startTime, endTime);
    }

    @Override
    public IdCollection getStationsByPersonId(@WebParam(name = "personIds") Muri[] personIds,
                                              @WebParam(name = "startTime") Date startTime,
                                              @WebParam(name = "endTime") Date endTime) {
        if (personIds == null || personIds.length == 0) {
            throw new BadParameterException("The personIds parameter is required and was not populated.");
        }

        return contentResolutionHelper.getStationIdsByIds("person", personIds, startTime, endTime);
    }

    @Override
    public List<StationInfo> getStationsById(@WebParam(name = "stationIds") Muri[] stationIds,
                                             @WebParam(name = "fields") String fields) throws GridException {
        if (stationIds == null || stationIds.length == 0) {
            throw new BadParameterException("The stationIds parameter is required and was not populated.");
        }
        List<StationInfo> stationInfos = contentResolutionHelper.getStationsByIds(stationIds);
        // filter fields if applicable
        FieldFilterUtil.filterFieldsForEach(stationInfos, fields);
        return stationInfos;
    }



    public List<ListingInfo> getListingsBySeriesId(@WebParam(name = "seriesIds") Muri[] seriesIds,
                                                   @WebParam(name = "startTime") Date startTime,
                                                   @WebParam(name = "endTime") Date endTime,
                                                   @WebParam(name = "stationIds") Muri[] stationIds,
                                                   @WebParam(name = "programTagIds") Long[] programTagIds,
                                                   @WebParam(name = "fields") String fields) {
        if (seriesIds == null || seriesIds.length == 0) {
            throw new BadParameterException("The seriesIds parameter is required and was not populated.");
        }

        List<CRSListing> crsListings = contentResolutionHelper.getListingsByIds("series", seriesIds, startTime,
                                                                                endTime, stationIds);
        List<ListingInfo> listingInfos = CRSListingToListingInfoConverter.convert(crsListings, null, null, programTagIds);

        for (ListingInfo listingInfo : listingInfos) {
            FieldFilterUtil.preserveFields(listingInfo, null, fields);
        }

        return listingInfos;
    }

    @Override
    public List<ListingInfo> getListingsBySportsTeamId(@WebParam(name = "sportsTeamIds") Muri[] sportsTeamIds,
                                                       @WebParam(name = "startTime") Date startTime,
                                                       @WebParam(name = "endTime") Date endTime,
                                                       @WebParam(name = "stationIds") Muri[] stationIds,
                                                       @WebParam(name = "programTagIds") Long[] programTagIds,
                                                       @WebParam(name = "fields") String fields) {
        if (sportsTeamIds == null || sportsTeamIds.length == 0) {
            throw new BadParameterException("The sportsTeamIds parameter is required and was not populated.");
        }

        List<CRSListing> crsListings = contentResolutionHelper.getListingsByIds("sportsteam", sportsTeamIds, startTime,
                                                                                endTime, stationIds);
        List<ListingInfo> listingInfos = CRSListingToListingInfoConverter.convert(crsListings, null, null, programTagIds);

        for (ListingInfo listingInfo : listingInfos) {
            FieldFilterUtil.preserveFields(listingInfo, null, fields);
        }

        return listingInfos;
    }

    @Override
    public List<ListingInfo> getListingsByPersonId(@WebParam(name = "personIds") Muri[] personIds,
                                                   @WebParam(name = "startTime") Date startTime,
                                                   @WebParam(name = "endTime") Date endTime,
                                                   @WebParam(name = "stationIds") Muri[] stationIds,
                                                   @WebParam(name = "programTagIds") Long[] programTagIds,
                                                   @WebParam(name = "fields") String fields) {
        if (personIds == null || personIds.length == 0) {
            throw new BadParameterException("The personIds parameter is required and was not populated.");
        }

        List<CRSListing> crsListings = contentResolutionHelper.getListingsByIds("person", personIds, startTime, endTime, stationIds);
        List<ListingInfo> listingInfos = CRSListingToListingInfoConverter.convert(crsListings, null, null, programTagIds);

        for (ListingInfo listingInfo : listingInfos) {
            FieldFilterUtil.preserveFields(listingInfo, null, fields);
        }

        return listingInfos;
    }

    @Override
    public TrendingPrograms getTrendingPrograms(@WebParam(name = "fields") String fields,
                                                @WebParam(name = "minRankingGroup") Integer minRankingGroup,
                                                @WebParam(name = "maxRankingGroup") Integer maxRankingGroup) throws GridException {
        if (dynamicProperties.get(DynamicProperties.DynamicPropertiesEnum.TWITTER_TRENDING_API_ENABLED).equals("false")) {
            return new TrendingPrograms();
        }

        CRSTrendingPrograms crsTrendingPrograms = trendingProgramsRepository.get(null);
        TrendingPrograms trendingPrograms = crsTrendingProgramConverter.convert(crsTrendingPrograms, merlinIdHelper, minRankingGroup, maxRankingGroup);

        initHeaders();
        if (trendingPrograms.getMaxAge() != null) {
            webServiceContext.getWebServiceResponse().setCacheControlHeader("max-age=" + trendingPrograms.getMaxAge());
        }
        FieldFilterUtil.filterFields(trendingPrograms, fields, this.validateFieldFilterNames, INCLUDE_ALWAYS);
        return trendingPrograms;
    }

    @Override
    public EpisodeMap getEpisodes(@WebParam(name = "episodeIds") Muri[] episodeIds,
                                  @WebParam(name = "previousEpisodeCount") Integer previousEpisodeCount,
                                  @WebParam(name = "nextEpisodeCount") Integer nextEpisodeCount,
                                  @WebParam(name = "excludeProvidedEpisodes") Boolean excludeProvidedEpisodes,
                                  @WebParam(name = "fields") String fields) throws GridException {
        if (episodeIds == null || episodeIds.length == 0) {
            throw new BadParameterException("The episodeIds parameter is required and was not populated.");
        }

        if (previousEpisodeCount != null && previousEpisodeCount < 0) {
            throw new BadParameterException("previousEpisodeCount cannot be negative.");
        }

        if (nextEpisodeCount != null && nextEpisodeCount < 0) {
            throw new BadParameterException("nextEpisodeCount cannot be negative");
        }

        // set defaults
        if (previousEpisodeCount == null) previousEpisodeCount = Integer.MAX_VALUE;
        if (nextEpisodeCount == null) nextEpisodeCount = Integer.MAX_VALUE;
        if (excludeProvidedEpisodes == null) excludeProvidedEpisodes = false;

        Map<Muri, List<Set<ProgramInfo>>> episodeLists = new HashMap<>(episodeIds.length);

        for (Muri episodeId : episodeIds) {
            List<Set<ProgramInfo>> episodes = episodesHelper.getEpisodes(episodeId, previousEpisodeCount,
                                                                         nextEpisodeCount, excludeProvidedEpisodes);
            episodeLists.put(episodeId, episodes);
        }

        EpisodeMap episodeMap = new EpisodeMap(episodeLists);
        FieldFilterUtil.filterFields(episodeMap, fields);

        return episodeMap;
    }

    @CollectStats
    @Override
    public List<ProgramInfo> getProgramsById( @WebParam(name = "programIds") Muri[] programIds
                                            , @WebParam(name = "fields") String fields){
        if (programIds == null) {
            throw new BadParameterException("programIds param cannot be null on getProgramsByProgramId call");
        }
        List<ProgramInfo> programInfos = new ArrayList<>();

        for (Muri programId : programIds){
            CRSProgram crsProgram = programRepository.get(programId.getId());
            if (crsProgram!=null){
                ProgramInfo programInfo = crsProgramToProgramInfoConverter.convertCRSProgramToProgramInfo(crsProgram);
                programInfos.add(programInfo);
            }
        }

        // filter fields if applicable
        FieldFilterUtil.filterFieldsForEach( programInfos, fields);

        return programInfos;
    }

    @CollectStats
    @Override
    public List<ChannelInfo> getChannelsById(Muri[] channelIds, String fields) throws GridException {
        if (channelIds == null) {
            throw new BadParameterException("channelIds param cannot be null");
        }

        List<ChannelInfo> channelInfos = new ArrayList<>();
        for (Muri channelId : channelIds) {
            CRSChannel crsChannel = channelRepository.get(channelId.getId());
            if (crsChannel != null) {
                ChannelInfo channelInfo = crsChannelToChannelInfoConverter.convert(crsChannel, merlinIdHelper, null);
                channelInfos.add(channelInfo);
            }
        }

        FieldFilterUtil.filterFieldsForEach(channelInfos, fields);

        return channelInfos;
    }


    private List<ChannelInfo> filterByCompanyIds(List<ChannelInfo> channels, List<Long> companyIds) {
        List<ChannelInfo> filteredChannels = new ArrayList<>();
        for (ChannelInfo channel : channels) {
            List<CompanyAssociationInfo> companies = channel.getStationInfo().getCompanyAssociations();
            List<Long> channelCompanyIds = Lists.transform(companies, new Function<CompanyAssociationInfo, Long>() {
                public Long apply(CompanyAssociationInfo company) {
                    return company.getCompanyId().getId();
                }
            });
            if (CollectionUtils.containsAny(channelCompanyIds, companyIds))
                filteredChannels.add(channel);
        }
        return filteredChannels;
    }

    private List<ChannelInfo> filterByStationTagIds(List<ChannelInfo> channels, List<Long> stationTagIds) {
        List<ChannelInfo> filteredChannels = new ArrayList<ChannelInfo>();
        for (ChannelInfo channel : channels) {
            List<Muri> tagUrns = channel.getStationInfo().getTagIds();
            List<Long> tagIds = Lists.transform(tagUrns, new Function<Muri, Long>() {
                public Long apply(Muri urn) {
                    return urn.getId();
                }
            });
            if (CollectionUtils.containsAny(tagIds, stationTagIds))
                filteredChannels.add(channel);
        }
        return filteredChannels;
    }


    static <T> List<T> filterByRows(List<T> channels, Integer rowStart, Integer rowEnd) {
        int channelCount = channels.size();
        int fromIndex;
        int toIndex;

        if (rowStart == null) {
            fromIndex = 0;
        } else if (rowStart < 1) {
            throw new IllegalArgumentException("rowStart must be >= 1");
        } else if (rowStart > channelCount) {
            return Collections.emptyList();
        } else {
            fromIndex = rowStart - 1;
        }

        if (rowEnd == null) {
            toIndex = channelCount;
        } else if (rowStart != null && rowEnd < rowStart) {
            throw new IllegalArgumentException("rowEnd must be > rowStart");
        } else if ((rowEnd - 1) > channelCount) {
            toIndex = channelCount;
        } else {
            toIndex = rowEnd - 1;
        }

        return channels.subList(fromIndex, toIndex);
    }

    /**
     * Originally a Backend Service
     */
    @CollectStats
    @Override
    public IdCollection getChannelAvailabilityIds() throws GridException {
        return backendServiceHelper.getChannelAvailabilityIds();
    }


    @CollectStats
    @Override
    public ChannelInfoCollection getChannelsByAvailabilityId(Muri channelsAvailabilityId) throws GridException {
        return backendServiceHelper.getChannelsByAvailabilityId(channelsAvailabilityId);
    }

    @Override
    public LocatorInfoCollection getLocatorsByRegion(String region) throws GridException {
        return backendServiceHelper.getLocatorsByRegion(region);
    }


    @CollectStats
    @Override
    public IdCollection getStreamsByStationIdAndAvailabilityId(Muri stationId, Muri availabilityId){
        if (stationId == null) {
            throw new BadParameterException("The stationId parameter is required but was not populated.");
        }

        if (availabilityId == null) {
            throw new BadParameterException("The availabilityId parameter is required but was not populated.");
        }
        IdCollection idCollection = new IdCollection();

        Collection<CRSContentAvailability> locatorCACollection = contentAvailabilityRepository.getLocatorsByAvailabilityId(availabilityId.getId());
        for (CRSContentAvailability lca : locatorCACollection){
            CRSLocator locator = locatorRepository.get(lca.getContentId());
            if (locator != null){
                CRSStream stream = streamRepository.get(locator.getStreamId());
                if (stream != null){
                    if (stationId.getId() == stream.getStationId()){
                        idCollection.getIds().add(merlinIdHelper.createStreamId(stream.getId()));
                    }
                }
            }
        }

        return idCollection;
    }

    @Override
    public List<ListingInfo> getListingsByProgramId(Muri[] programIds, Date startTime, Date endTime, Muri[] stationIds, String fields) throws GridException {

        if (programIds == null || programIds.length == 0) {
            throw new BadParameterException("The programIds parameter is required but was not populated.");
        }

        List<CRSListing> crsListings = contentResolutionHelper.getListingsByIds("program", programIds, startTime, endTime, stationIds);
        List<ListingInfo> listingInfos = CRSListingToListingInfoConverter.convert(crsListings, null, null);

        for (ListingInfo listingInfo : listingInfos) {
            FieldFilterUtil.preserveFields(listingInfo, null, fields);
        }

        return listingInfos;
    }


    @Required
    public void setCRSListingToListingInfoConverter(CRSListingToListingInfoConverter CRSListingToListingInfoConverter) {
        this.CRSListingToListingInfoConverter = CRSListingToListingInfoConverter;
    }

    @Required
    public void setCrsTrendingProgramConverter(CRSTrendingProgramToTrendingProgramConverter crsTrendingProgramConverter) {
        this.crsTrendingProgramConverter = crsTrendingProgramConverter;
    }

    @Required
    public void setTrendingProgramsRepository(SingletonRepository<CRSTrendingPrograms> trendingProgramsRepository) {
        this.trendingProgramsRepository = trendingProgramsRepository;
    }

    @Required
    public void setProgramRepository(ProgramRepository programRepository) {
        this.programRepository = programRepository;
    }

    @Required
    public void setGridMapper(GridMapper gridMapper) {
        this.gridMapper = gridMapper;
    }

    @Required
    public void setMerlinDAO(MerlinDAO merlinDAO) {
        this.merlinDAO = merlinDAO;
    }

    @Required
    public void setContentResolutionHelper(ContentResolutionHelper contentResolutionHelper) {
        this.contentResolutionHelper = contentResolutionHelper;
    }

    @Required
    public void setAvailabilitiesResolutionModifier(AvailabilitiesResolutionModifier availabilitiesResolutionModifier) {
        this.availabilitiesResolutionModifier = availabilitiesResolutionModifier;
    }

    @Required
    public void setTagRepository(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }

    @Required
    public void setDebugHelper(DebugHelper debugHelper) {
        this.debugHelper = debugHelper;
    }

    @Required
    public void setTakedownHelper(TakedownHelper takedownHelper) {
        this.takedownHelper = takedownHelper;
    }

    @Required
    public void setOwnerUtil(OwnerUtil ownerUtil) {
        this.ownerUtil = ownerUtil;
    }

    @Required
    public void setEpisodesHelper(EpisodesHelper episodesHelper) {
        this.episodesHelper = episodesHelper;
    }

    @Required
    public void setCrsProgramToProgramInfoConverter(CRSProgramToProgramInfoConverter crsProgramToProgramInfoConverter) {
        this.crsProgramToProgramInfoConverter = crsProgramToProgramInfoConverter;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    @Required
    public void setCrsChannelToChannelInfoConverter(CRSChannelToChannelInfoConverter crsChannelToChannelInfoConverter) {
        this.crsChannelToChannelInfoConverter = crsChannelToChannelInfoConverter;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }

    @Required
    public void setBackendServiceHelper(BackendServiceHelper backendServiceHelper) {
        this.backendServiceHelper = backendServiceHelper;
    }

    @Required
    public void setStreamRepository(StreamRepository streamRepository) {
        this.streamRepository = streamRepository;
    }

    @Required
    public void setContentAvailabilityRepository(ContentAvailabilityRepository contentAvailabilityRepository) {
        this.contentAvailabilityRepository = contentAvailabilityRepository;
    }

    @Required
    public void setLocatorRepository(LocatorRepository locatorRepository) {
        this.locatorRepository = locatorRepository;
    }

    @Required
    public void setDynamicProperties(DynamicProperties dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }
}
