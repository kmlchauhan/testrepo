package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.LocatorProto.LocatorMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSLocator;

import java.util.HashMap;
import java.util.Map;

public class LocatorSerializer extends AbstractSiriusObjectSerializer<CRSLocator> {

    public LocatorSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSLocator unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        LocatorMessage.Builder message = LocatorMessage.newBuilder().mergeFrom(bytes);

        CRSLocator locator = new CRSLocator(message.getId());
        if (message.hasBitrate()) locator.setBitrate(message.getBitrate());
        if (message.hasCodec()) locator.setCodec(message.getCodec());
        if (message.hasDigicableId()) locator.setDigicableId(message.getDigicableId());
        if (message.hasFormat()) locator.setFormat(message.getFormat().intern());
        if (message.hasHeight()) locator.setHeight(message.getHeight());
        if (message.hasLocatorUri()) locator.setLocatorURI(message.getLocatorUri());
        if (message.hasOwnerId()) locator.setOwnerId(message.getOwnerId());
        if (message.hasProtectionScheme()) locator.setProtectionScheme(message.getProtectionScheme());
        if (message.hasStationId()) locator.setStationId(message.getStationId());
        if (message.hasWidth()) locator.setWidth(message.getWidth());
        if (message.hasQuality()) locator.setQuality(message.getQuality());
        if (message.hasStreamId()) locator.setStreamId(message.getStreamId());
        if (message.hasType()) locator.setType(message.getType().intern());
        if (message.hasProvider()) locator.setProvider(message.getProvider());
        if (message.hasExternalStreamId()) locator.setExternalStreamId(message.getExternalStreamId());
        if (message.getPlayerConfigCount() > 0){
            Map<String, String> playerConfig = new HashMap<>();
            for (int i = 0; i < message.getPlayerConfigCount(); i++){
                LocatorMessage.PlayerConfigMessage playerConfigMessage = message.getPlayerConfig(i);
                playerConfig.put(playerConfigMessage.getKey(), playerConfigMessage.getValue());
            }
            locator.setPlayerConfig(playerConfig);
        }
        if (message.hasNamespaceId()) locator.setNamespaceId(message.getNamespaceId());
        return locator;
    }

    @Override
    public ByteString marshallPayload( CRSLocator locator) {
        LocatorMessage.Builder builder = LocatorMessage.newBuilder();

        builder.setId(locator.getId());
        if (locator.getBitrate() != null) builder.setBitrate(locator.getBitrate());
        if (locator.getCodec() != null) builder.setCodec(locator.getCodec());
        if (locator.getDigicableId() != null) builder.setDigicableId(locator.getDigicableId());
        if (locator.getFormat() != null) builder.setFormat(locator.getFormat());
        if (locator.getHeight() != null) builder.setHeight(locator.getHeight());
        if (locator.getLocatorURI() != null) builder.setLocatorUri(locator.getLocatorURI());
        if (locator.getOwnerId() != null) builder.setOwnerId(locator.getOwnerId());
        if (locator.getProtectionScheme() != null) builder.setProtectionScheme(locator.getProtectionScheme());
        if (locator.getStationId() != null) builder.setStationId(locator.getStationId());
        if (locator.getWidth() != null) builder.setWidth(locator.getWidth());
        if (locator.getQuality() != null) builder.setQuality(locator.getQuality());
        if (locator.getStreamId() != null) builder.setStreamId(locator.getStreamId());
        if (locator.getType() != null) builder.setType(locator.getType());
        if (locator.getProvider() != null) builder.setProvider(locator.getProvider());
        if (locator.getExternalStreamId() != null) builder.setExternalStreamId(locator.getExternalStreamId());
        if (locator.getPlayerConfig() != null && !locator.getPlayerConfig().isEmpty()){
            for (Map.Entry<String,String> entry : locator.getPlayerConfig().entrySet()){
                LocatorMessage.PlayerConfigMessage playerConfig = LocatorMessage.PlayerConfigMessage.newBuilder()
                        .setKey(entry.getKey())
                        .setValue(entry.getValue())
                        .build();
                builder.addPlayerConfig(playerConfig);
            }
        }
        if (locator.getNamespaceId() != null) builder.setNamespaceId(locator.getNamespaceId());
        return builder.build().toByteString();
    }

}
