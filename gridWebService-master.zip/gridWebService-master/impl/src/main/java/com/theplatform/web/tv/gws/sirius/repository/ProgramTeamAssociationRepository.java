package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSProgramTeamAssociation;
import com.theplatform.web.tv.gws.sirius.repository.utils.OpenSetSecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.SecondaryIndex;

import java.util.Collection;

public class ProgramTeamAssociationRepository extends LongObjectRepository<CRSProgramTeamAssociation> {

    private final SecondaryIndex<Long, Long> sportsTeamIdToProgramIds = new OpenSetSecondaryIndex<>();

    public ProgramTeamAssociationRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    protected void addToIndexes(CRSProgramTeamAssociation pta) {
        sportsTeamIdToProgramIds.put(pta.getSportsTeamId(), pta.getProgramId());
    }

    @Override
    protected void removeFromIndexes(CRSProgramTeamAssociation pta) {
        sportsTeamIdToProgramIds.remove(pta.getSportsTeamId(), pta.getProgramId());
    }

    public Collection<Long> getProgramIds(Long sportsTeamId) {
        return sportsTeamIdToProgramIds.getByIndexKey(sportsTeamId);
    }
}
