package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSLocation extends LongDataRepoObject {

    private Long productContextId;
    private long ownerId;
    private String source;

    public CRSLocation() {
        super( SiriusObjectType.fromFriendlyName("Location") );
    }

    public CRSLocation(long id) {
        super( SiriusObjectType.fromFriendlyName("Location"), id);
    }

    public Long getProductContextId() {
        return productContextId;
    }

    public void setProductContextId(Long productContextId) {
        this.productContextId = productContextId;
    }

    public long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(long ownerId) {
        this.ownerId = ownerId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}
