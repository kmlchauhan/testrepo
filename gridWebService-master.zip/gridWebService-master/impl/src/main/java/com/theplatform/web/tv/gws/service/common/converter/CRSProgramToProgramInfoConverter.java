package com.theplatform.web.tv.gws.service.common.converter;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Required;

import java.util.*;

import static com.theplatform.data.tv.ingest.type.MerlinEntityType.TAG;
import static com.theplatform.web.tv.combine.commons.MerlinService.ENTITY;

public class CRSProgramToProgramInfoConverter {
    private MerlinIdHelper merlinIdHelper;

    public ProgramInfo[] convert(Collection<CRSProgram> crsPrograms) {
        ProgramInfo[] programInfos = new ProgramInfo[crsPrograms.size()];
        int i = 0;
        for (CRSProgram crsProgram : crsPrograms) {
            programInfos[i] = convertCRSProgramToProgramInfo(crsProgram);
            i++;
        }
        return programInfos;
    }

    public ProgramInfo convertCRSProgramToProgramInfo(CRSProgram crsProgram) {
        return convertCRSProgramToProgramInfo(crsProgram, null);
    }

    public ProgramInfo convertCRSProgramToProgramInfo(CRSProgram crsProgram, Long[] requestedProgramTagIds) {
        if (crsProgram == null)
            return null;
        ProgramInfo programInfo = new ProgramInfo();
        programInfo.setProgramId(merlinIdHelper.createProgramId(crsProgram.getId()));
        if (crsProgram.getType()!=null) programInfo.setType(crsProgram.getType().getFriendlyName());
        if (crsProgram.getCategory()!=null) programInfo.setCategory(crsProgram.getCategory().getFriendlyName());
        programInfo.setTitle(crsProgram.getTitle());
        programInfo.setGridTitle(crsProgram.getGridTitle());
        if (crsProgram.getSeriesId() != null)
            programInfo.setSeriesId(merlinIdHelper.createProgramId(crsProgram.getSeriesId()));
        programInfo.setEpisodeTitle(crsProgram.getEpisodeTitle());
        programInfo.setSportsSubtitle(crsProgram.getSportsSubtitle());
        programInfo.setAdult(crsProgram.getAdult());
        programInfo.setPartNumber(crsProgram.getPartNumber());
        programInfo.setTotalParts(crsProgram.getTotalParts());
        programInfo.setTvSeasonEpisodeNumber(crsProgram.getTvSeasonEpisodeNumber());
        programInfo.setTvSeasonNumber(crsProgram.getTvSeasonNumber());
        programInfo.setSeriesEpisodeNumber(crsProgram.getSeriesEpisodeNumber());
        programInfo.setLanguage(crsProgram.getLanguage());

        List<Muri> matchedTagIds;

        // only include the tagIds that were requested
        if (ArrayUtils.isNotEmpty(crsProgram.getTagIds()) && ArrayUtils.isNotEmpty(requestedProgramTagIds)) {

            // the list of tagids that are present on the CRSProgram and were requested by the caller
            matchedTagIds = new ArrayList<>(requestedProgramTagIds.length);

            for (long currentTagId : crsProgram.getTagIds()) {

                if (ArrayUtils.contains(requestedProgramTagIds, currentTagId)) {
                    Muri muri = merlinIdHelper.createId(currentTagId, ENTITY, TAG);
                    matchedTagIds.add(muri);
                }
            }

            programInfo.setTagIds(matchedTagIds);
        }
        // if we have any tagIds, include them all
        else if (ArrayUtils.isNotEmpty(crsProgram.getTagIds())) {
            programInfo.setTagIds(merlinIdHelper.createIds(crsProgram.getTagIds(), ENTITY, TAG));
        }

        programInfo.setContentRatings(CRSRatingToRatingInfoConverter.convert(crsProgram.getContentRatings()));

        return programInfo;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }
}
