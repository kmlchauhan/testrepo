package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.theplatform.web.tv.contentresolution.api.objects.ApiObjectVisitor;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.LocatorInfo;
import com.theplatform.web.tv.contentresolution.api.objects.TrendingProgram;
import com.theplatform.web.tv.contentresolution.api.objects.TrendingPrograms;

public class DataObjectTranslator_1_29 extends ApiObjectVisitor {
    public final static DataObjectTranslator_1_29 INSTANCE = new DataObjectTranslator_1_29();

    @Override
    public void visitTrendingProgram(TrendingProgram trendingProgram) {
        trendingProgram.setProgramId(null);
        trendingProgram.setProgramInfo(trendingProgram.getTransientProgramInfo());
    }

    @Override
    public void visitChannelInfo(ChannelInfo channelInfo) {
        channelInfo.setIpDeliveryOnly(null);
    }
}
