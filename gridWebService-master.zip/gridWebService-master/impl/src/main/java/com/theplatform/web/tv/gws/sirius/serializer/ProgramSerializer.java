package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.common.primitives.Longs;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.ProgramProto.ProgramMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSRating;
import org.apache.commons.lang.ArrayUtils;

import java.util.List;

public class ProgramSerializer extends AbstractSiriusObjectSerializer<CRSProgram> {

    public ProgramSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSProgram unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        ProgramMessage.Builder message = ProgramMessage.newBuilder().mergeFrom(bytes);

        CRSProgram program = new CRSProgram(message.getId());

        if (message.hasType()) {
            program.setType(ProgramType.getByFriendlyName(message.getType()));
        }
        if (message.hasTitle()) {
            program.setTitle(message.getTitle());
        }
        if (message.hasGridTitle()) {
            program.setGridTitle(message.getGridTitle());
        }
        if (message.hasCategory()) {
            program.setCategory(ProgramCategory.getByFriendlyName(message.getCategory()));
        }
        if (message.hasSeriesId()) {
            program.setSeriesId(message.getSeriesId());
        }
        if (message.hasEpisodeTitle()) {
            program.setEpisodeTitle(message.getEpisodeTitle());
        }
        if (message.hasSportsSubtitle()){
            program.setSportsSubtitle(message.getSportsSubtitle());
        }
        if (message.hasAdult()){
            program.setAdult(message.getAdult());
        }
        if (message.getTagIdsCount() > 0) {
            long[] tagIds = Longs.toArray(message.getTagIdsList());
            program.setTagIds(tagIds);
        }
        if (message.hasTvSeasonEpisodeNumber()) {
            program.setTvSeasonEpisodeNumber(message.getTvSeasonEpisodeNumber());
        }
        if (message.hasTvSeasonNumber()) {
            program.setTvSeasonNumber(message.getTvSeasonNumber());
        }
        if (message.hasSeriesEpisodeNumber()) {
            program.setSeriesEpisodeNumber(message.getSeriesEpisodeNumber());
        }
        if (message.hasPartNumber()) {
            program.setPartNumber(message.getPartNumber());
        }
        if (message.hasTotalParts()) {
            program.setTotalParts(message.getTotalParts());
        }
        if (message.hasLanguage()){
            program.setLanguage(message.getLanguage().intern());
        }

        // Content Rating
        List<ProgramMessage.ContentRatingMessage> messageContentRatings = message.getContentRatingsList();
        if (!messageContentRatings.isEmpty()){
            CRSRating[] contentRatings = new CRSRating[messageContentRatings.size()];
            for(int i=0; i<messageContentRatings.size(); i++){
                ProgramMessage.ContentRatingMessage contentRating = messageContentRatings.get(i);
                String scheme = null;
                if (contentRating.hasScheme()) {
                    scheme = contentRating.getScheme();
                }

                String ratingString = null;
                if (contentRating.hasRating()) {
                    ratingString = contentRating.getRating();
                }

                String[] subratings = null;
                if (contentRating.getSubRatingsList() != null && contentRating.getSubRatingsCount() > 0) {

                    subratings = new String[contentRating.getSubRatingsCount()];
                    contentRating.getSubRatingsList().toArray(subratings);
                }
                CRSRating rating = CRSRating.getInstance(scheme, ratingString, subratings);
                contentRatings[i] = rating;
            }
            program.setContentRatings(contentRatings);
        }

        return program;
    }

    @Override
    public ByteString marshallPayload( CRSProgram program) {
        ProgramMessage.Builder builder = ProgramMessage.newBuilder();

        builder.setId(program.getId());
        builder.setType(program.getType().getFriendlyName());
        if (program.getTitle() != null)
            builder.setTitle(program.getTitle());
        if (program.getGridTitle() != null)
            builder.setGridTitle(program.getGridTitle());
        if (program.getCategory() != null)
            builder.setCategory(program.getCategory().getFriendlyName());
        if(program.getSeriesId() != null) {
            builder.setSeriesId(program.getSeriesId());
        }
        if(program.getEpisodeTitle() != null) {
            builder.setEpisodeTitle(program.getEpisodeTitle());
        }
        if(program.getSportsSubtitle() != null){
            builder.setSportsSubtitle(program.getSportsSubtitle());
        }
        if (program.getAdult() != null){
            builder.setAdult(program.getAdult());
        }
        if (ArrayUtils.isNotEmpty(program.getTagIds())) {
            builder.addAllTagIds(Longs.asList(program.getTagIds()));
        }
        if (program.getTvSeasonNumber() != null) {
            builder.setTvSeasonNumber(program.getTvSeasonNumber());
        }
        if (program.getTvSeasonEpisodeNumber() != null) {
            builder.setTvSeasonEpisodeNumber(program.getTvSeasonEpisodeNumber());
        }
        if (program.getSeriesEpisodeNumber() != null) {
            builder.setSeriesEpisodeNumber(program.getSeriesEpisodeNumber());
        }
        if (program.getPartNumber() != null) {
            builder.setPartNumber(program.getPartNumber());
        }
        if (program.getTotalParts() != null) {
            builder.setTotalParts(program.getTotalParts());
        }
        if (program.getLanguage() != null){
            builder.setLanguage(program.getLanguage());
        }

        // Content Rating
        if (program.getContentRatings()!=null && program.getContentRatings().length>0){
            for (CRSRating crsRating : program.getContentRatings()){
                ProgramMessage.ContentRatingMessage.Builder contentRatingBuilder = ProgramMessage.ContentRatingMessage.newBuilder();
                if (crsRating.getScheme() != null)
                    contentRatingBuilder.setScheme(crsRating.getScheme().intern());
                if (crsRating.getRating() != null)
                    contentRatingBuilder.setRating(crsRating.getRating().intern());
                if (crsRating.getSubRatings() != null) {
                    for (String subRating : crsRating.getSubRatings()) {
                        contentRatingBuilder.addSubRatings(subRating);
                    }
                }
                builder.addContentRatings(contentRatingBuilder.build());
            }
        }

        return builder.build().toByteString();
    }



}
