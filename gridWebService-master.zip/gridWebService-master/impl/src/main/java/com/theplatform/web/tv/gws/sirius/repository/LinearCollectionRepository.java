package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.data.tv.linear.api.data.objects.LinearCollection;
import com.theplatform.web.tv.gws.sirius.model.CRSLinearCollection;
import com.theplatform.web.tv.gws.sirius.repository.utils.OpenSetSecondaryIndex;

import java.util.Collection;

public class LinearCollectionRepository extends LongObjectRepository<CRSLinearCollection> {
    private OpenSetSecondaryIndex<CRSLinearCollection> stationIndex = new OpenSetSecondaryIndex<>();

    public LinearCollectionRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    protected void addToIndexes(CRSLinearCollection object) {
        for (long stationId : object.getStationIds()) {
            stationIndex.put(stationId, object);
        }
    }

    @Override
    protected void removeFromIndexes(CRSLinearCollection object) {
        for (long stationId : object.getStationIds()) {
            stationIndex.remove(stationId, object);
        }
    }

    public Collection<CRSLinearCollection> getByStationId(long stationId) {
        return stationIndex.getByIndexKey(stationId);
    }
}
