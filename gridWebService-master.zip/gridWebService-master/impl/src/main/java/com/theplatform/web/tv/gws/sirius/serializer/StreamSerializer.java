package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.StreamProto.StreamMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSStream;

/**
 * Factory that converts Stream protobufs to CRSStreams and visa-versa.
 * 
 */
public class StreamSerializer extends AbstractSiriusObjectSerializer<CRSStream> {

    public StreamSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSStream unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        StreamMessage.Builder message = StreamMessage.newBuilder().mergeFrom(bytes);

        CRSStream stream = new CRSStream();

        if (message.hasId())
            stream.setId(message.getId());
        if (message.hasStationId())
            stream.setStationId(message.getStationId());
        if (message.hasOwnerId())
            stream.setOwnerId(message.getOwnerId());
        if (message.hasIsDefault())
            stream.setIsDefault(message.getIsDefault());
        if (message.hasStatus())
            stream.setStatus(message.getStatus().intern());
        if (message.hasExternal())
            stream.setExternal(message.getExternal());
        if (message.hasTitle())
            stream.setTitle(message.getTitle());
        if (message.hasIsDai())
            stream.setIsDai(message.getIsDai());
        if (message.hasServiceZoneType())
            stream.setServiceZoneType(message.getServiceZoneType());
        if (message.hasTravelRights())
            stream.setTravelRights(message.getTravelRights());
        if (message.hasType())
            stream.setType(message.getType());
        stream.setPreferredRMType(message.getPreferredRmType());

        return stream;
    }

    @Override
    public ByteString marshallPayload(  CRSStream stream) {
        StreamMessage.Builder builder = StreamMessage.newBuilder();

        builder.setId(stream.getId());
        builder.setStationId(stream.getStationId());
        builder.setOwnerId(stream.getOwnerId());
        if (stream.getIsDefault()!=null)
            builder.setIsDefault(stream.getIsDefault());
        if(stream.getStatus() != null)
            builder.setStatus(stream.getStatus());
        if (stream.getExternal() != null)
            builder.setExternal(stream.getExternal());
        if (stream.getTitle() != null)
            builder.setTitle(stream.getTitle());
        if (stream.getIsDai() != null)
            builder.setIsDai(stream.getIsDai());
        if (stream.getTravelRights() != null)
            builder.setTravelRights(stream.getTravelRights());
        if (stream.getType() != null)
            builder.setType(stream.getType());
        if (stream.getServiceZoneType() != null)
            builder.setServiceZoneType(stream.getServiceZoneType());
        builder.setPreferredRmType(stream.getPreferredRMType());

        return builder.build().toByteString();
    }

}
