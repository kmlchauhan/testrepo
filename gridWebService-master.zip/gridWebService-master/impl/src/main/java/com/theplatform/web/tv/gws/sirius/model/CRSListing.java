package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSListing extends LongDataRepoObject implements Comparable<CRSListing> {

    // previously each of these booleans was stored in a separate java.lang.Boolean instance (using a total
    // of 144 bytes per CRSListing).  Stuffing all of the booleans into a single int reduces the storage to 4 bytes.
    // two bits are used for each boolean value.  one bit records null/not-null and the other bit records the actual value
    private final static int payPerViewBit = 1;
    private final static int descriptiveVideoServiceBit = 4;
    private final static int sapBit = 16;
    private final static int subjectToBlackoutBit = 64;
    private final static int subtitledBit = 256;
    private final static int threeDBit = 1024;
    private int values;

    private long stationId;
    private long startTime;
    private long endTime;
    private String crsAiringType;
    private String captionType;
    private String hdLevel;
    private String quality;
    private String colorDepth;
    private long programId = Long.MIN_VALUE;
    private long seriesId = Long.MIN_VALUE;
    private String audioType;
    private String showingType;
    private CRSRating[] contentRatings;
    private String cci;
    private int dvrProgramId = Integer.MIN_VALUE;
    private int dvrSeriesId = Integer.MIN_VALUE;

    public CRSListing() {
        super( SiriusObjectType.fromFriendlyName("Listing") );
    }

    public CRSListing(long id) {
        super( SiriusObjectType.fromFriendlyName("Listing"), id);
    }

    /**
     * Extract a Boolean from #values.
     * @param indicatorBit
     * @return a Boolean or null if no value was set
     */
    private Boolean extractBooleanValue(int indicatorBit) {
        Boolean extracted = null;

        // the constant defines whether a value is set
        if ((values & indicatorBit) != 0) {
            // if a value was set, one bit to the left of the constant defines the value of the Boolean
            int valueBit = indicatorBit << 1;
            if ((values & valueBit) != 0) {
                extracted = Boolean.TRUE;
            }
            else {
                extracted = Boolean.FALSE;
            }
        }
        return extracted;
    }

    /**
     * Store a Boolean in #values.
     * @param indicatorBit
     * @param boolValue
     */
    private void setBooleanValue(int indicatorBit, Boolean boolValue) {
        int valueBit = indicatorBit << 1;

        if (boolValue != null) {
            this.values = this.values | indicatorBit;

            if (Boolean.TRUE.equals(boolValue)) {
                this.values = this.values | valueBit;
            }
            else {
                this.values = this.values & ~valueBit;
            }
        }
        else {
            this.values = this.values & ~indicatorBit;
        }
    }

    public String getAudioType() {
        return audioType;
    }

    public void setAudioType(String audioType) {
        this.audioType = nullSafeIntern(audioType);
    }

    public String getShowingType() {
        return showingType;
    }

    public void setShowingType(String showingType) {
        this.showingType = nullSafeIntern(showingType);
    }

    public Boolean getSap() {
        return extractBooleanValue(sapBit);
    }

    public void setSap(Boolean sap) {
        setBooleanValue(sapBit, sap);
    }

    public Boolean getSubjectToBlackout() {
        return extractBooleanValue(subjectToBlackoutBit);
    }

    public void setSubjectToBlackout(Boolean subjectToBlackout) {
        setBooleanValue(subjectToBlackoutBit, subjectToBlackout);
    }

    public Boolean getSubtitled() {
        return extractBooleanValue(subtitledBit);
    }

    public void setSubtitled(Boolean subtitled) {
        setBooleanValue(subtitledBit, subtitled);
    }

    public CRSRating[] getContentRatings() {
        return contentRatings;
    }

    public void setContentRatings(CRSRating[] contentRatings) {
        this.contentRatings = contentRatings;
    }

    public Boolean getThreeD() {
        return extractBooleanValue(threeDBit);
    }

    public void setThreeD(Boolean threeD) {
        setBooleanValue(threeDBit, threeD);
    }

    public String getCci() {
        return cci;
    }

    public void setCci(String cci) {
        this.cci = nullSafeIntern(cci);
    }

    public Integer getDvrProgramId() {
        if (dvrProgramId != Integer.MIN_VALUE) {
            return dvrProgramId;
        }
        else {
            return null;
        }
    }

    public void setDvrProgramId(Integer dvrProgramId) {
        if (dvrProgramId != null) {
            this.dvrProgramId = dvrProgramId;
        }
        else {
            this.dvrProgramId = Integer.MIN_VALUE;
        }
    }

    public Integer getDvrSeriesId() {
        if (dvrSeriesId != Integer.MIN_VALUE) {
            return dvrSeriesId;
        }
        else {
            return null;
        }

    }

    public void setDvrSeriesId(Integer dvrSeriesId) {
        if (dvrSeriesId != null) {
            this.dvrSeriesId = dvrSeriesId;
        }
        else {
            this.dvrSeriesId = Integer.MIN_VALUE;
        }
    }

    public long getStationId() {
        return stationId;
    }

    public void setStationId(long stationId) {
        this.stationId = stationId;
    }

    public Long getProgramId() {
        if (programId != Long.MIN_VALUE) {
            return programId;
        }
        else {
            return null;
        }
    }

    public void setProgramId(Long programId) {
        if (programId != null) {
            this.programId = programId;
        }
        else {
            this.programId = Long.MIN_VALUE;
        }
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public String getCrsAiringType() {
        return crsAiringType;
    }

    public void setCrsAiringType(String crsAiringType) {
        this.crsAiringType = nullSafeIntern(crsAiringType);
    }

    public String getCaptionType() {
        return captionType;
    }

    public void setCaptionType(String captionType) {
        this.captionType = nullSafeIntern(captionType);
    }

    public String getHdLevel() {
        return hdLevel;
    }

    public void setHdLevel(String hdLevel) {
        this.hdLevel = nullSafeIntern(hdLevel);
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public String getColorDepth() {
        return colorDepth;
    }

    public void setColorDepth(String colorDepth) {
        this.colorDepth = colorDepth;
    }

    public Boolean getPayPerView() {
        return extractBooleanValue(payPerViewBit);
    }

    public void setPayPerView(Boolean payPerView) {
        setBooleanValue(payPerViewBit, payPerView);
    }

    public Boolean getDescriptiveVideoService() {
        return extractBooleanValue(descriptiveVideoServiceBit);
    }

    public void setDescriptiveVideoService(Boolean descriptiveVideoService) {
        setBooleanValue(descriptiveVideoServiceBit, descriptiveVideoService);
    }

    public Long getSeriesId() {
        if (seriesId != Long.MIN_VALUE) {
            return seriesId;
        }
        else {
            return null;
        }
    }

    public void setSeriesId(Long seriesId) {
        if (seriesId != null) {
            this.seriesId = seriesId;
        }
        else {
            this.seriesId = Long.MIN_VALUE;
        }
    }

    @Override
    public int compareTo(CRSListing listing) {
        if (this.hashCode() > listing.hashCode()) {
            return 1;
        }
        if (this.hashCode() < listing.hashCode()) {
            return -1;
        }
        return 0;
    }
}
