package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.AvailabilityTagProto.AvailabilityTagMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSAvailabilityTag;

/**
 * Factory that converts AvailabilityTag protobufs to CRSAvailabilityTags and visa-versa.
 * 
 */
public class AvailabilityTagSerializer extends AbstractSiriusObjectSerializer<CRSAvailabilityTag> {

    public AvailabilityTagSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSAvailabilityTag unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException{
        AvailabilityTagMessage.Builder message = AvailabilityTagMessage.newBuilder().mergeFrom(bytes);

        CRSAvailabilityTag crsAvailabilityTag = new CRSAvailabilityTag(message.getId());
        crsAvailabilityTag.setNational(message.getNational());
        crsAvailabilityTag.setOwnerId(message.getOwnerId());
        return crsAvailabilityTag;
    }

    @Override
    public ByteString marshallPayload( CRSAvailabilityTag availabilityTag) {
        AvailabilityTagMessage.Builder builder = AvailabilityTagMessage.newBuilder();

        builder.setId(availabilityTag.getId());
        builder.setNational(availabilityTag.getNational());
        builder.setOwnerId(availabilityTag.getOwnerId());

        return builder.build().toByteString();
    }

}
