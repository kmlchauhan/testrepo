package com.theplatform.web.tv.gws.service.common.field.nullification.operations;


public interface PropertyOperation {
    void apply(Object target);
}
