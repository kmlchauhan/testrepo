package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSListing;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.repository.utils.OpenSetSecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.SecondaryIndex;
import org.apache.commons.collections.CollectionUtils;

import java.util.*;

public class ListingRepository extends LongObjectRepository<CRSListing> {
    protected final SecondaryIndex<Long, CRSListing> stationIndex;
    protected final SecondaryIndex<Long, CRSListing> programIndex;
    protected final SecondaryIndex<Long, CRSListing> seriesIndex;

    public ListingRepository(SiriusObjectType siriusObjectType) {
        this(siriusObjectType, 1024, 1024);
    }

    public ListingRepository(SiriusObjectType siriusObjectType, int expectedListings, int expectedStations) {
        super(siriusObjectType, expectedListings);
        stationIndex = new OpenSetSecondaryIndex<>(expectedStations);
        programIndex = new OpenSetSecondaryIndex<>();
        seriesIndex = new OpenSetSecondaryIndex<>();
    }

    @Override
    public void addToIndexes(CRSListing listing) {
        stationIndex.put(listing.getStationId(), listing);
        programIndex.put(listing.getProgramId(), listing);
        if (listing.getSeriesId()!=null) seriesIndex.put(listing.getSeriesId(), listing);
    }

    @Override
    public void removeFromIndexes(CRSListing listing) {
        stationIndex.remove(listing.getStationId(), listing);
        programIndex.remove(listing.getProgramId(), listing);
        seriesIndex.remove(listing.getSeriesId(), listing);
    }

    public List<CRSListing> getListings(long stationId, Date beginRange, Date endRange) {
        long begin = beginRange.getTime();
        long end = endRange.getTime();

        List<CRSListing> result = new ArrayList<CRSListing>();
        Collection<CRSListing> listings = stationIndex.getByIndexKey(stationId);
        for (CRSListing listing : listings) {
            if (listing.getEndTime() > begin && listing.getStartTime() < end)
                result.add(listing);
        }
        Collections.sort(result, new StartTimeListingComparator());
        return result;
    }

    public Collection<CRSListing> getByStationId(Long stationId) {
        return stationIndex.getByIndexKey(stationId);
    }

    public Collection<CRSListing> getByProgramId(long programId) {
        return programIndex.getByIndexKey(programId);
    }

    public Collection<CRSListing> getBySeriesId(long seriesId) {
        return seriesIndex.getByIndexKey(seriesId);
    }

    public boolean hasListingReferencing(CRSProgram program) {
        long programId = program.getId();

        return CollectionUtils.isNotEmpty(getByProgramId(programId))
                || CollectionUtils.isNotEmpty(getBySeriesId(programId));
    }

    public Set<Long> getAllProgramIds() {
        Set<Long> programIdSet = new HashSet<>(map.size());

        long stamp = super.lock.readLock();
        try {
            for (CRSListing listing : map.values()) {
                for (Long id : Arrays.asList(listing.getProgramId(), listing.getSeriesId())) {
                    if (id != null) {
                        programIdSet.add(id);
                    }
                }
            }
            return programIdSet;
        }
        finally {
            super.lock.unlockRead(stamp);
        }
    }

    public boolean isOnlyListingReferencing(CRSListing listing, Long programId) {
        long stamp = super.lock.readLock();

        try {
            Collection<CRSListing> listingsByProgramId = getByProgramId(programId);
            Collection<CRSListing> listingsBySeriesId = getBySeriesId(programId);

            if (listingsByProgramId.size() > 1 || listingsBySeriesId.size() > 1) {
                return false;
            } else {
                Set<CRSListing> listingReferences = new HashSet<>(listingsByProgramId);
                listingReferences.addAll(listingsBySeriesId);

                return listingReferences.size() == 1 && listingReferences.iterator().next().equals(listing);
            }
        } finally {
            super.lock.unlockRead(stamp);
        }
    }
}
