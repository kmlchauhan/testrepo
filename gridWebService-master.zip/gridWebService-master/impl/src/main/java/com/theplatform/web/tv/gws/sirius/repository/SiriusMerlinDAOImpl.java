package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.contrib.stats.StatsCollector;
import com.theplatform.web.tv.gws.sirius.model.*;
import org.springframework.beans.factory.annotation.Required;

import java.util.*;

import static org.apache.commons.collections.CollectionUtils.isEmpty;

public class SiriusMerlinDAOImpl implements MerlinDAO {

    static protected StatsCollector statsCollector = StatsCollector.getInstance();
    LongObjectRepository<CRSLocation> locationRepository;
    ChannelRepository channelRepository;
    LongObjectRepository<CRSStation> stationRepository;
    LongObjectRepository<CRSStream> streamRepository;
    LongObjectRepository<CRSAvailabilityTag> availabilityTagRepository;
    LongObjectRepository<CRSProductContext> productContextRepository;
    ListingRepository listingRepository;

    @Override
    public List<CRSStation> retrieveStations(List<Long> stationIds) {
        return new ArrayList<CRSStation>(stationRepository.getByIds(stationIds));
    }


    @Override
    public List<CRSLocation> retrieveLocations(List<Long> locationIds) {
        return new ArrayList<>(this.locationRepository.getByIds(locationIds));
    }

    @Override
    public List<CRSStream> retrieveStreams(List<Long> streamIds, Set<String> allowedStreamStatus) {
        Collection<CRSStream> byIds = streamRepository.getByIds(streamIds);
        ArrayList<CRSStream> arrayList;
        if(!isEmpty(allowedStreamStatus)) {
            arrayList = new ArrayList<>();
            for (CRSStream crsStream : byIds) {
                if(allowedStreamStatus.contains(crsStream.getStatus())) {
                    arrayList.add(crsStream);
                }
            }
        } else {
            arrayList = new ArrayList<>(byIds);
        }
        
        return arrayList;
    }

    @Override
    public List<CRSAvailabilityTag> retrieveAvailabilityTag(List<Long> availabilityTagIds) {
        return new ArrayList<CRSAvailabilityTag>(this.availabilityTagRepository.getByIds(availabilityTagIds));
    }

    @Override
    public List<CRSListing> retrieveListings(List<Long> listingIds) {
        long statsStartTime = System.currentTimeMillis();
        List<CRSListing> listings = new ArrayList<>(listingRepository.getByIds(listingIds));
        return listings;
    }

    @Override
    public List<CRSListing> retrieveListings(Long stationId, Date startTime, Date endTime) {
        long statsStartTime = System.currentTimeMillis();
        List<CRSListing> listings = new ArrayList<CRSListing>(listingRepository.getListings(stationId, startTime, endTime));
        return listings;
    }

    @Override
    public List<CRSProductContext> retrieveProductContext(List<Long> productContextIds) {
        return new ArrayList<CRSProductContext>(this.productContextRepository.getByIds(productContextIds));
    }

    @Required
    public void setLocationRepository(LongObjectRepository<CRSLocation> locationRepository) {
        this.locationRepository = locationRepository;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    @Required
    public void setStationRepository(LongObjectRepository<CRSStation> stationRepository) {
        this.stationRepository = stationRepository;
    }

    @Required
    public void setStreamRepository(LongObjectRepository<CRSStream> streamRepository) {
        this.streamRepository = streamRepository;
    }

    @Required
    public void setAvailabilityTagRepository(LongObjectRepository<CRSAvailabilityTag> availabilityTagRepository) {
        this.availabilityTagRepository = availabilityTagRepository;
    }

    @Required
    public void setProductContextRepository(LongObjectRepository<CRSProductContext> productContextRepository) {
        this.productContextRepository = productContextRepository;
    }

    @Required
    public void setListingRepository(ListingRepository listingRepository) {
        this.listingRepository = listingRepository;
    }

}
