package com.theplatform.web.tv.gws.service.common.util;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author jcoelho
 */
public class DedupeUtil {
    private static Logger logger = LoggerFactory.getLogger(DedupeUtil.class);

    /**
     * When two DataObjectInfo's are being collapsed, determine if the first one takes precedence.
     */
    public static boolean firstTakesPrecedence(ChannelInfo firstChannelInfo, ChannelInfo secondChannelInfo, MerlinIdHelper merlinIdHelper) {
        return firstTakesPrecedence(firstChannelInfo.getChannelId(), secondChannelInfo.getChannelId(), merlinIdHelper);
    }

    /**
     * Determine which URL Takes precedence.
     */
    public static boolean firstTakesPrecedence(Muri firstId, Muri secondId, MerlinIdHelper merlinIdHelper) {
        return firstTakesPrecedence(firstId.getId(), secondId.getId());
    }

    public static boolean firstTakesPrecedence(long firstId, long secondId) {
        return firstId <= secondId;
    }


}
