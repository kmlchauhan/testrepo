/**
 * Internal representation of objects received from external systems.
 *
 * With the exception of {@link com.theplatform.web.tv.gws.sirius.model.CRSTrendingProgram CRSTrendingProgram} which is sourced
 * from Twitter and {@link com.theplatform.web.tv.gws.sirius.model.CRSBulkInfo CRSBulkInfo} which is generated
 * internally, all of these objects come from data services.
 * <br><br>
 * This package and the {@link com.theplatform.web.tv.gws.sirius.repository repository package} are the bridge between the
 * {@link com.theplatform.web.tv.gws.ingest ingest package} (which processes data from external systems) and
 * the {@link com.theplatform.web.tv.gws.service service package} (which uses data received from external systems
 * to service HTTP requests).
 */
package com.theplatform.web.tv.gws.sirius.model;