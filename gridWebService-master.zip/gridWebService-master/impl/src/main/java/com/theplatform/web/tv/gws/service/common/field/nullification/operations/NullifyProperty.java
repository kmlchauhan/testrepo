package com.theplatform.web.tv.gws.service.common.field.nullification.operations;

import com.theplatform.web.tv.gws.service.common.field.FieldFilteringException;
import com.theplatform.web.tv.gws.service.common.field.descriptor.ApiPropertyDescriptor;

import java.lang.reflect.Method;

/**
 * Nullify a property of the target object.
 */
public class NullifyProperty implements PropertyOperation {
    protected final ApiPropertyDescriptor descriptor;
    protected final static Object[] EMPTY_ARGS = new Object[]{null};

    protected final Method writeMethod;

    public NullifyProperty(ApiPropertyDescriptor descriptor) {
        this.descriptor = descriptor;
        this.writeMethod = descriptor.getWriteMethod();
    }

    @Override
    public void apply(Object target) {
        if (target == null) {
            return;
        }

        try {
            // passing EMPTY_ARGS rather than "(Object) null" to the invoke method avoids implicitly creating a new array each time.
            this.writeMethod.invoke(target, EMPTY_ARGS);
        }
        catch (ReflectiveOperationException e) {
            throw new FieldFilteringException("Failed to nullify property '" + descriptor.getPath() + "' for " + target, e);
        }
    }
}
