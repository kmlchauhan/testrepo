package com.theplatform.web.tv.gws.ingest.producer.twitter.json;


import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Maps JSON responses from Twitter to {@link TwitterTrendingResponse} and {@link TwitterError}.  See the test
 * resources for an example of the JSON format.
 */
public class TwitterJsonParser {

    // the main node for trending responses
    private static final String ITEMS = "items";

    // nested as "_embedded.metrics.tweets.ALL" where the value of "ALL" contains a tweet count integer.
    private static final String EMBEDDED = "_embedded";
    private static final String METRICS = "metrics";
    private static final String TWEETS = "tweets";
    private static final String ALL = "ALL";

    // other children of "items"
    private static final String ALTERNATE_IDS = "alternate_ids";
    private static final String TITLE = "title";
    private static final String SHOW_TITLE = "show_title";

    // auth responses
    private static final String TOKEN_TYPE = "token_type";
    private static final String ACCESS_TOKEN = "access_token";
    private static final String BEARER = "bearer";

    // error response
    public static final String ERRORS = "errors";
    
    private final Logger log = LoggerFactory.getLogger(getClass());


    /**
     * Set the tweetCount using the value of "_embedded.metrics.tweets.ALL".  Expects JSON containing
     * a child "_embedded" node:
     * <br>
     * <pre>
     *  {
     *      "_embedded": {
     *          "metrics": {
     *                "tweets": {
     *                    "ALL": 162566
     *                 }
     *           }
     *       }
     *  }
     * </pre>
     *
     * @param item a TwitterItem
     * @param itemNode a JsonNode representing an item
     * @return true if the tweet count was set, false if the structure of the JSON is incorrect or the node was not found.
     */
    private boolean setTweetCount(TwitterItem item, JsonNode itemNode) {

        JsonNode embeddedNode = itemNode.get(EMBEDDED);
        if (embeddedNode == null) {
            return false;
        }

        JsonNode metricsNode = embeddedNode.get(METRICS);
        if (metricsNode == null) {
            return false;
        }

        JsonNode tweets = metricsNode.get(TWEETS);
        if (tweets == null) {
            return false;
        }

        JsonNode allNode = tweets.get(ALL);
        if (allNode == null || !allNode.isInt()) {
            return false;
        }

        int tweetCount = allNode.getIntValue();
        item.setTweetCount(tweetCount);
        return true;
    }

    /**
     * Convert an array JsonNode to a List of String.  Expects JSON like:
     * <br>
     * <pre>
     *     "inputNode" : ["foo", "bar"]
     * </pre>
     * @param arrayNode a possibly null JsonNode
     * @return a List of Strings or null if the arrayNode is null, is not an array node, or has no values.
     */
    private List<String> valuesAsStrings(JsonNode arrayNode) {

        List<String> values = null;

        // check that the input node is a non-empty array
        if (arrayNode != null && arrayNode.isArray() && arrayNode.size() > 0) {
            values = new ArrayList<>(arrayNode.size());

            // each element of the array is separate JsonNode.  from the example above,
            // we're looping over nodes representing ["foo", "bar"]
            for (JsonNode elementNode : arrayNode) {
                String value = elementNode.getValueAsText();
                values.add(value);
            }
        }

        return values;
    }

    /**
     * Populate the {@link TwitterItem#getAlternateIds() alternateIds} of the item
     * from the "alternate_ids" child JSON node.  Expects JSON like this.  Note that
     * it's possible that multiple ids from a single provider are returned:
     *
     * <pre>
     *    "alternate_ids": {
     *       "Rovi1.1": [
     *           "26248194"
     *        ],
     *        "Tms": [
     *           "EP008965610547"
     *        ]
     *    }
     * </pre>
     *
     * @param item item to which the alternate ids should be added
     * @param itemNode JsonNode node representing an item (should have an "alternate_ids" child)
     * @return false if the structure of the JSON is incorrect or no alternate ids are present,
     *          true if one or more alternate ids were found and added to the item.
     */
    private boolean setAlternateIds(TwitterItem item, JsonNode itemNode) {
        JsonNode alternateIdNode = itemNode.get(ALTERNATE_IDS);
        if (alternateIdNode == null || !alternateIdNode.isObject() || alternateIdNode.size() == 0) {
            return false;
        }

        // loop over each possible AlternateIdSource and see if the "alternate_ids" contains a child that matches
        for (AlternateIdSource source : AlternateIdSource.values()) {

            // find a node like "Rovi1.1" or "Tms"
            String nodeName = source.getJsonName();
            JsonNode idArray = alternateIdNode.get(nodeName);

            List<String> values = valuesAsStrings(idArray);
            if (values != null) {
                item.getAlternateIds().get(source).addAll(values);
            }
        }
        
        return !item.getAlternateIds().isEmpty();
    }

    private void setTitles(TwitterItem item, JsonNode itemNode) {
        String title = itemNode.findPath(TITLE).getValueAsText();
        item.setTitle(title);

        String showTitle = itemNode.findPath(SHOW_TITLE).getValueAsText();
        item.setShowTitle(showTitle);
    }

    /**
     * Parse the String as JSON and return the root JsonNode
     * @param json a non-null JSON string
     * @return the root JSON node
     * @throws TwitterJsonException on null input or when the JSON could not be parsed
     */
    private JsonNode readJson(String json) throws TwitterJsonException {
        try {
            if (StringUtils.isBlank(json)) {
                throw new TwitterJsonException("Cannot parse null Twitter JSON");
            }

            ObjectMapper mapper = new ObjectMapper();
            return mapper.readTree(json);
        }
        catch (IOException e) {
            throw new TwitterJsonException("Failed to read Twitter JSON", e);
        }
    }

    /**
     * Parse Twitter JSON responses for trending items.  Documents are expected to have the following structure:
     * <br>
     * <pre>
     *  {
     *      "items": [
     *           {
     *               "_embedded": {
     *                   "metrics": {
     *                       "tweets": {
     *                           "ALL": 162566
     *                        }
     *                   }
     *               },
     *               "alternate_ids": {
     *                   "Rovi1.1": [
     *                       "26248194"
     *                    ],
     *                    "Tms": [
     *                       "EP008965610547"
     *                    ]
     *               },
     *               "show_title": "FA Cup Soccer",
     *               "title": "Bolton vs. Liverpool FC"
     *           },
     *           {
     *                 ... more items ...
     *           }
     *      ]
     *  }
     * </pre>
     *
     * Note that there are a lot of additional attributes at each level of the document
     * that are ignored by this simple parser.
     *
     * @param json Twitter JSON for trending items
     * @return a TwitterTrendingResponse containing the items parsed from the JSON
     * @throws TwitterJsonException when the format of the JSON document is incorrect or no items are
     *      contained in the JSON.
     */
    public TwitterTrendingResponse parseTrendingResponse(String json) throws TwitterJsonException {
        if (log.isTraceEnabled()) {
            log.trace("Parsing trending JSON: {}", json);
        }

        // find the "items" array
        JsonNode rootNode = readJson(json);
        JsonNode itemsArrayNode = rootNode.get(ITEMS);

        // check that items node was found, is an array, and is not empty
        if (itemsArrayNode == null) {
            throw new TwitterJsonException("JSON node 'items' is missing");
        }
        else if (!itemsArrayNode.isArray()) {
            throw new TwitterJsonException("Expected 'items' JSON node to be an array");
        }
        else if (itemsArrayNode.size() == 0) {
            throw new TwitterJsonException("'items' JSON node is empty");
        }

        // map each item to a TwitterItem instance and add it to our response
        TwitterTrendingResponse response = new TwitterTrendingResponse(itemsArrayNode.size());

        for(JsonNode currentNode : itemsArrayNode) {
            TwitterItem item = new TwitterItem();

            // if we were able to find the basic minimum requiremens (some ids + tweet count)
            if (setAlternateIds(item, currentNode) && setTweetCount(item, currentNode)) {

                // check for titles and then add it to the response
                setTitles(item, currentNode);
                response.addItem(item);
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("Parsed {} trending items", response.size());
        }

        return response;
    }

    /**
     * Parse a Twitter OAuth2 authentication response.  Documents are expected to have the following structure:
     *
     * <pre>
     *     {
     *          "token_type": "bearer",
     *          "access_token": "foo"
     *     }
     * </pre>
     *
     * @param authResponse Twitter JSON auth response
     * @return the bearer token extracted from the response (never null)
     * @throws TwitterJsonException if the bearer token could not be extracted
     */
    public String parseAuthResponse(String authResponse) throws TwitterJsonException {
        if (log.isTraceEnabled()) {
            log.trace("Parsing auth response JSON: {}", authResponse);
        }

        JsonNode rootNode = readJson(authResponse);
        JsonNode tokenTypeNode = rootNode.get(TOKEN_TYPE);
        JsonNode accessTokenNode = rootNode.get(ACCESS_TOKEN);

        // check that we the nodes are there and that "token_type" == "bearer"
        if (tokenTypeNode == null || accessTokenNode == null) {
            throw new TwitterJsonException("Expected 'token_type' or 'access_type' nodes in auth response");
        }

        String tokenType = tokenTypeNode.getValueAsText();
        if (!BEARER.equals(tokenType)) {
            throw new TwitterJsonException("Expected 'token_type' with type 'bearer' but got type '" + tokenType + "'");
        }

        // get the value of the "access_token" node and check that it's not null or blank
        String bearerToken = accessTokenNode.getValueAsText();
        if (StringUtils.isBlank(bearerToken)) {
            throw new TwitterJsonException("'access_token' is null or blank");
        }

        if (log.isDebugEnabled()) {
            log.debug("Parsed bearer token {}", bearerToken);
        }

        return bearerToken;
    }

    /**
     * Try to parse a Twitter error response.  Unlike other methods in this class, this method does not throw exceptions.
     * If the document is null, invalid, or does not contain an error, an empty List is returned.  Expects JSON like this:
     * <pre>
     *     {
     *        "errors":[
     *           {
     *              "code":99,
     *              "label": "authenticity_token_error",
     *              "message": "Unable to verify your credentials"
     *           }
     *        ]
     *     }
     * </pre>
     * @param errorResponse JSON representing errors
     * @return a List of TwitterError or an empty List if the input could not be parsed or was not an error document,
     */
    public List<TwitterError> parseErrorsResponse(String errorResponse) {
        List<TwitterError> errors = new ArrayList<>(4);
        try {
            JsonNode rootNode = readJson(errorResponse);
            JsonNode errorNode = rootNode.get(ERRORS);
            ObjectMapper mapper = new ObjectMapper();

            for (JsonNode currentError : errorNode) {
                TwitterError error = mapper.readValue(currentError, TwitterError.class);
                errors.add(error);
            }

        }
        catch (Exception ignored) {
            // do nothing
        }

        return errors;
    }
}
