package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import java.util.HashMap;
import java.util.Map;


public class CRSLocator extends LongDataRepoObject implements Comparable<CRSLocator> {
    private String format;
    private String locatorURI;
    private int digicableId = Integer.MIN_VALUE;
    private int width = Integer.MIN_VALUE;
    private int height = Integer.MIN_VALUE;
    private long bitrate = Long.MIN_VALUE;
    private String protectionScheme;
    private String codec;
    private long ownerId = Long.MIN_VALUE;
    private long stationId = Long.MIN_VALUE;
    private String quality;
    private long streamId = Long.MIN_VALUE;
    private String type;
    private String provider;
    private String externalStreamId;
    private long namespaceId = Long.MIN_VALUE;
    private Map<String, String> playerConfig;

    public CRSLocator() {
        super( SiriusObjectType.fromFriendlyName("Locator"));
    }

    public CRSLocator(long id) {
        super( SiriusObjectType.fromFriendlyName("Locator"), id);
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = nullSafeIntern(format);
    }

    public String getLocatorURI() {
        return locatorURI;
    }

    public void setLocatorURI(String locatorURI) {
        this.locatorURI = locatorURI;
    }

    public Integer getDigicableId() {
        if (digicableId == Integer.MIN_VALUE) {
            return null;
        }
        else {
            return digicableId;
        }
    }

    public void setDigicableId(Integer digicableId) {
        if (digicableId == null) {
            this.digicableId = Integer.MIN_VALUE;
        }
        else {
            this.digicableId = digicableId;
        }
    }

    public Integer getWidth() {
        if (width == Integer.MIN_VALUE) {
            return null;
        }
        else {
            return width;
        }
    }

    public void setWidth(Integer width) {
        if (width == null) {
            this.width = Integer.MIN_VALUE;
        }
        else {
            this.width = width;
        }
    }

    public Integer getHeight() {
        if (height == Integer.MIN_VALUE) {
            return null;
        }
        else {
            return height;
        }
    }

    public void setHeight(Integer height) {
        if (height == null) {
            this.height = Integer.MIN_VALUE;
        }
        else {
            this.height = height;
        }
    }

    public Long getBitrate() {
        if (bitrate == Long.MIN_VALUE) {
            return null;
        }
        else {
            return bitrate;
        }
    }

    public void setBitrate(Long bitrate) {
        if (bitrate == null) {
            this.bitrate = Long.MIN_VALUE;
        }
        else {
            this.bitrate = bitrate;
        }
    }

    public String getProtectionScheme() {
        return protectionScheme;
    }

    public void setProtectionScheme(String protectionScheme) {
        this.protectionScheme = nullSafeIntern(protectionScheme);
    }

    public String getCodec() {
        return codec;
    }

    public void setCodec(String codec) {
        this.codec = nullSafeIntern(codec);
    }

    public Long getOwnerId() {
        if (ownerId == Long.MIN_VALUE) {
            return null;
        }
        else {
            return ownerId;
        }
    }

    public void setOwnerId(Long ownerId) {
        if (ownerId == null) {
            this.ownerId = Long.MIN_VALUE;
        }
        else {
            this.ownerId = ownerId;
        }
    }

    public Long getStationId() {
        if (stationId == Long.MIN_VALUE) {
            return null;
        }
        else {
            return stationId;
        }
    }

    public void setStationId(Long stationId) {
        if (stationId == null) {
            this.stationId = Long.MIN_VALUE;
        }
        else {
            this.stationId = stationId;
        }
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public Long getStreamId() {
        if (streamId == Long.MIN_VALUE) {
            return null;
        }
        else {
            return streamId;
        }
    }

    public void setStreamId(Long streamId) {
        if (streamId == null) {
            this.streamId = Long.MIN_VALUE;
        }
        else {
            this.streamId = streamId;
        }
    }

    public Long getNamespaceId() {
        if (this.namespaceId == Long.MIN_VALUE){
            return null;
        }else {
            return namespaceId;
        }
    }

    public void setNamespaceId(Long namespaceId) {
        if (namespaceId == null) {
            this.namespaceId = Long.MIN_VALUE;
        } else {
            this.namespaceId = namespaceId;
        }
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = nullSafeIntern(type);
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getExternalStreamId() {
        return externalStreamId;
    }

    public void setExternalStreamId(String externalStreamId) {
        this.externalStreamId = externalStreamId;
    }

    public Map<String, String> getPlayerConfig() {
        return playerConfig;
    }

    public void setPlayerConfig(Map<String, String> playerConfig) {
        this.playerConfig = playerConfig;
    }

    @Override
    public int compareTo(CRSLocator crsLocator) {
        if (this.hashCode() > crsLocator.hashCode()) {
            return 1;
        }
        if (this.hashCode() < crsLocator.hashCode()) {
            return -1;
        }
        return 0;
    }

    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
