package com.theplatform.web.tv.gws.service.common.debug;

import com.theplatform.web.context.WebServiceContext;
import com.theplatform.web.tv.contentresolution.api.debug.CauseType;
import com.theplatform.web.tv.contentresolution.api.debug.VerboseInfo;
import com.theplatform.web.tv.contentresolution.api.debug.WarningItem;
import com.theplatform.web.tv.contentresolution.api.debug.WarningType;
import com.theplatform.web.tv.contentresolution.api.objects.ContentResolutionResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import javax.annotation.Resource;

/**
 *   The DebugHelper will write out debug information if verboseMode is set to true.  This class should be used
 *   to write out debugging information to help understand the CRS response.  For example, why a channel was dropped,
 *   why a productConext was dropped or other date related issues such as mutiple streams.
 */
public class DebugHelper {
    private static Logger logger = LoggerFactory.getLogger(DebugHelper.class);

    private static final String DEBUG_WARNING = "DEBUG_WARNING";

    @Resource
    private WebServiceContext webServiceContext;

    public boolean isVerboseMode(){
        try{
            if (webServiceContext != null ){
                String idForm = webServiceContext.getWebServiceRequest().getParameter("verboseMode");
                if (idForm==null || !idForm.equals("true")){
                    return false;
                } else {
                    return true;
                }
            }
        }catch (NullPointerException ignored) {
            // Do nothing.  WebServiceContextImpl always throws a NPE when operating outside of web request
            return false;
        }
        return false;
    }

    public void logResponseWarning( WarningType warningType, CauseType causeType, WarningItem item){
        logWarning( false, warningType, causeType, item);
    }

    public void logRequestWarning( WarningType warningType, CauseType causeType, WarningItem item){
        logWarning( true, warningType, causeType, item);
    }


    /**
     * If the verboseMode flag is true this will add the VerboseInfo to the ContentResolutionResponse.
     *
     * @param contentResolutionResponse
     */
    public <T extends ContentResolutionResponse> T applyWarnings(T contentResolutionResponse){
        if (contentResolutionResponse==null) return null;
        contentResolutionResponse.setVerboseInfo(getDebugWarnings());
        return contentResolutionResponse;
    }

    private void logWarning( boolean request, WarningType warningType, CauseType causeType, WarningItem item){
        if (isVerboseMode()){
            // Add to context so that we can write it out to response when it is complete
            try{
                VerboseInfo verboseInfo = (VerboseInfo)webServiceContext.getWebServiceRequest().getHttpServletRequest().getAttribute( DEBUG_WARNING);
                if ( verboseInfo ==null){
                    verboseInfo = new VerboseInfo();
                    webServiceContext.getWebServiceRequest().getHttpServletRequest().setAttribute( DEBUG_WARNING, verboseInfo);
                }
                if (request){
                    verboseInfo.addRequestWarning(warningType, causeType, item);
                } else {
                    verboseInfo.addResponseWarning(warningType, causeType, item);
                }
            }catch (Exception exc){
                logger.error( "Failed to write warning", exc);
            }
        }
        splunkWarning(request, warningType, causeType, item);
    }

    /**
     *  Write warning out to Splunk
     */
    private void splunkWarning( boolean request, WarningType warningType, CauseType causeType, WarningItem item){
        StringBuilder builder = new StringBuilder(64);
        builder.append("CRSDebugInfo");
        builder.append(" exchange=").append( (request) ? "request" : "response");   // Which part of the exchange request or response
        builder.append(" warningType=").append(warningType);
        builder.append(" causeType=").append(causeType);
        builder.append(item);
        logger.debug( builder.toString());
    }

    private VerboseInfo getDebugWarnings(){
        if (!isVerboseMode()) return null;
        VerboseInfo verboseInfo = null;
        try{
            verboseInfo = (VerboseInfo)webServiceContext.getWebServiceRequest().getHttpServletRequest().getAttribute( DEBUG_WARNING);
        }catch (Exception exc){
            logger.error( "Failed to look up warning", exc);
        }
        return verboseInfo;
    }

    /**
     * Hook if needed for testing
     * @param webServiceContext
     */
    public void setWebServiceContext(WebServiceContext webServiceContext) {
        this.webServiceContext = webServiceContext;
    }

}
