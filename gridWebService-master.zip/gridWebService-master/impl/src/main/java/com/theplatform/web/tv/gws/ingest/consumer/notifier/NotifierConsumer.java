package com.theplatform.web.tv.gws.ingest.consumer.notifier;

import com.comcast.merlin.sirius.ingest.Event;
import com.comcast.merlin.sirius.ingest.EventConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

public class NotifierConsumer implements EventConsumer{
    protected final Logger logger = LoggerFactory.getLogger(getClass());

    private boolean notificationEnabled;

    private Notifier notifier;


    @Override
    public boolean consumePut(Event event) {
        return consume(event);
    }

    @Override
    public boolean consumeDelete(Event event) {
        return consume(event);
    }

    private boolean consume(Event event) {
        if (!notificationEnabled) return true;
        if (event.getSequence() != null && event.getSequence() > 0) {
            notifier.publish(event);
        }
        return true;
    }

    @Required
    public void setNotifier(Notifier notifier) {
        this.notifier = notifier;
    }

    @Required
    public void setNotificationEnabled(boolean notificationEnabled) {
        this.notificationEnabled = notificationEnabled;
    }


}
