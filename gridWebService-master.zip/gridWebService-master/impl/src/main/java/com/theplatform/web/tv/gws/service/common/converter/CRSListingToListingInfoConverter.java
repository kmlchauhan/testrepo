package com.theplatform.web.tv.gws.service.common.converter;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.data.tv.linear.api.data.objects.AiringType;
import com.theplatform.data.tv.linear.api.data.objects.ColorDepthType;
import com.theplatform.web.tv.combine.commons.MerlinService;
import com.theplatform.web.tv.contentresolution.api.debug.CauseType;
import com.theplatform.web.tv.contentresolution.api.debug.WarningItem;
import com.theplatform.web.tv.contentresolution.api.debug.WarningType;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import com.theplatform.web.tv.gws.sirius.model.CRSGame;
import com.theplatform.web.tv.gws.sirius.model.CRSListing;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.repository.GameRepository;
import com.theplatform.web.tv.gws.sirius.repository.LinearTagAssociationRepository;
import com.theplatform.web.tv.gws.sirius.repository.ProgramRepository;
import com.theplatform.web.tv.gws.service.common.debug.DebugHelper;
import com.theplatform.web.tv.gws.service.common.util.GridUtils;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;

import java.util.*;
import java.util.concurrent.TimeUnit;

public class CRSListingToListingInfoConverter {

    private LinearTagAssociationRepository linearTagAssociationRepository;
    private ProgramRepository programRepository;
    private GameRepository gameRepository;
    private CRSProgramToProgramInfoConverter crsProgramToProgramInfoConverter;
    private long sportingEventTagId;

    private DebugHelper debugHelper;

    @Autowired
    private MerlinIdHelper merlinIdHelper;

    public CRSListingToListingInfoConverter() {

    }

    /**
     * Maps the provided Listings into ListingInfo objects.  All ProgramInfo.tagIds are included.
     *
     * @param crsListings      to map to ListingInfo objects
     * @param gridStartTime time to set on the ListingInfo object for crsListings that start before the gridStartTime.
     * @param gridEndTime   time to set on the ListingInfo object for crsListings that end after the gridEndTime.
     * @return the ListingInfo objects
     */
    public List<ListingInfo> convert(Collection<CRSListing> crsListings, Date gridStartTime, Date gridEndTime) {
        return convert(crsListings, gridStartTime, gridEndTime, null);
    }

    /**
     * Maps the provided Listings into ListingInfo objects.
     *
     * @param crsListings      to map to ListingInfo objects
     * @param gridStartTime time to set on the ListingInfo object for crsListings that start before the gridStartTime.
     * @param gridEndTime   time to set on the ListingInfo object for crsListings that end after the gridEndTime.
     * @param programTagIds the tagIds that should be included in each ProgramInfo or null if all tags should be included.
     * @return the ListingInfo objects
     */
    public List<ListingInfo> convert(Collection<CRSListing> crsListings, Date gridStartTime, Date gridEndTime, Long[] programTagIds) {
        List<ListingInfo> listingInfos = new ArrayList<>(crsListings.size());
        Map<Long, ProgramInfo> programMap = new TreeMap<>();       // For performance

        MerlinIdHelper requestScopedIdHelper = merlinIdHelper.forSingleThreadedUse();

        for (CRSListing crsListing : crsListings) {
            ListingInfo listingInfo = new ListingInfo();
            listingInfo.setProgramInfo( getProgramInfo( crsListing.getId(), crsListing.getProgramId(), programMap, programTagIds) );
            listingInfo.setSeriesInfo(  getProgramInfo( crsListing.getId(), crsListing.getSeriesId(),  programMap, programTagIds) );

            setListingInfoTitle(listingInfo, programRepository.get(crsListing.getProgramId()));

            Date startTime = new Date(crsListing.getStartTime());
            Date endTime = new Date(crsListing.getEndTime());
            CRSGame crsGame = gameRepository.getByListingId(crsListing.getId());

            if (crsGame != null) {
                Muri gameId = requestScopedIdHelper.createGameId(crsGame.getId());
                listingInfo.setAutoextendable(true);
                listingInfo.setExtendableEntityId(gameId);
            } else {
                listingInfo.setAutoextendable(false);
            }

            if (gridStartTime != null && startTime.before(gridStartTime)) {
                startTime = GridUtils.roundDateDownToMinute(gridStartTime);
            }
            if (gridEndTime != null && endTime.after(gridEndTime)) {
                endTime = gridEndTime;
            }
            Integer inWindowMinutes = (int) TimeUnit.MILLISECONDS.toMinutes(endTime.getTime() - startTime.getTime());

            if (crsListing.getCrsAiringType() != null) {
                listingInfo.setAiringType(AiringType.valueOf(crsListing.getCrsAiringType()));
            }
            listingInfo.setCaptionType(crsListing.getCaptionType());

            listingInfo.setStartTime(new Date(crsListing.getStartTime()));
            listingInfo.setEndTime(new Date(crsListing.getEndTime()));
            listingInfo.setHdLevel(crsListing.getHdLevel());
            listingInfo.setQuality(crsListing.getQuality());

            /**
             * TODO: This is temporary. We should REMOVE the defaulting of null values to 'SDR', as soon as
             * all Listing.colorDepth values are non-null and constraints have been implemented.
             */
            if (crsListing.getColorDepth() != null)
                listingInfo.setColorDepth(crsListing.getColorDepth());
            else
                listingInfo.setColorDepth(ColorDepthType.SDR.getFriendlyName());

            listingInfo.setListingId(requestScopedIdHelper.createListingId(crsListing.getId()));
            listingInfo.setStationId(requestScopedIdHelper.createStationId(crsListing.getStationId()));
            listingInfo.setInWindowMinutes(inWindowMinutes);
            listingInfo.setPrice(0); // TODO: figure out where price comes from

            listingInfo.setAudioType(crsListing.getAudioType());
            listingInfo.setShowingType(crsListing.getShowingType());
            listingInfo.setSap(crsListing.getSap());
            listingInfo.setSubjectToBlackout(crsListing.getSubjectToBlackout());
            listingInfo.setSubtitled(crsListing.getSubtitled());
            listingInfo.setThreeD(crsListing.getThreeD());
            listingInfo.setCci(crsListing.getCci());
            listingInfo.setDvrProgramId(crsListing.getDvrProgramId());
            listingInfo.setDvrSeriesId(crsListing.getDvrSeriesId());

            if ( CollectionUtils.isNotEmpty(linearTagAssociationRepository.getTagIds(crsListing.getId())) ){
                List<Muri> tagIds = requestScopedIdHelper.createIds( linearTagAssociationRepository.getTagIds(crsListing.getId()), MerlinService.ENTITY, MerlinEntityType.TAG);
                listingInfo.setTagIds(tagIds);
            }

            if (crsListing.getPayPerView() != null) {
                listingInfo.setPayPerView(crsListing.getPayPerView());
            } else {
                listingInfo.setPayPerView(Boolean.FALSE);
            }
            if (crsListing.getDescriptiveVideoService() != null) {
                listingInfo.setDescriptiveVideoService(crsListing.getDescriptiveVideoService());
            } else {
                listingInfo.setDescriptiveVideoService(Boolean.FALSE);
            }

            listingInfo.setContentRatings(CRSRatingToRatingInfoConverter.convert(crsListing.getContentRatings()));
            listingInfos.add(listingInfo);
        }

        return listingInfos;
    }



    private ProgramInfo getProgramInfo(long listingId, Long programId, Map<Long, ProgramInfo> programIdMap, Long[] programTagids) {
        ProgramInfo programInfo = null;
        if (programId == null)
            return null;
        if (programIdMap.containsKey(programId)) {
            programInfo = programIdMap.get(programId);
        } else {
            CRSProgram program = programRepository.get(programId);
            if (program != null) {
                programInfo = crsProgramToProgramInfoConverter.convertCRSProgramToProgramInfo(program, programTagids);
                if (programInfo == null){
                    debugHelper.logResponseWarning(WarningType.InvalidObject, CauseType.ProgramNotFound,
                            WarningItem.instance()
                                            .setProgramId(merlinIdHelper.createProgramId(programId))
                                            .setListingId(merlinIdHelper.createListingId(listingId)));
                }
                programIdMap.put(programId,programInfo);
                programIdMap.put(programId, programInfo);
            }
        }

        return programInfo;
    }

    /**
     * Sets the ListingInfo title if ProgramInfo is available. If the Program has sportsSubitle and has either a type
     * of SportingEvent or it has a tag with the genre of SportingEvent then
     * it will set the listingInfo title to: programInfo.title - programInfo.sportsSubtitle
     * Otherwise it will set the title to just programInfo.title
     * @param listingInfo the listing info whose title will be updated
     * @param program the program is used to check to see if it contains the sporting event genre tag
     */
    private void setListingInfoTitle( ListingInfo listingInfo, CRSProgram program ) {
        //Check to see if the program has a special sporting event genre tag
        boolean hasSportingEventTagAndIsAnEpisode = false;
        if (program != null && program.getTagIds() != null && ProgramType.Episode.equals(program.getType())) {
            for (long tagId : program.getTagIds()) {
                if (sportingEventTagId == tagId) {
                    hasSportingEventTagAndIsAnEpisode = true;
                    break;
                }
            }
        }

        //Set the listing title. If the program is of type sporting event or has the sporting event genre tag then
        //combine the program title with a '-' and the sportsSubtitle (if available)
        if (listingInfo.getProgramInfo() != null) {
            if ((ProgramType.SportingEvent.getFriendlyName().equals(listingInfo.getProgramInfo().getType()) || hasSportingEventTagAndIsAnEpisode)
                    && listingInfo.getProgramInfo().getSportsSubtitle() != null
                    && !listingInfo.getProgramInfo().getSportsSubtitle().trim().isEmpty()) {
                String combinedTitle = listingInfo.getProgramInfo().getTitle() + ": " + listingInfo.getProgramInfo().getSportsSubtitle();
                listingInfo.setTitle(combinedTitle);
            }
            else {
                listingInfo.setTitle(listingInfo.getProgramInfo().getTitle());
            }
        }
    }

    @Required
    public void setLinearTagAssociationRepository(LinearTagAssociationRepository linearTagAssociationRepository) {
        this.linearTagAssociationRepository = linearTagAssociationRepository;
    }

    @Required
    public void setProgramRepository(ProgramRepository programRepository) {
        this.programRepository = programRepository;
    }

    @Required
    public void setGameRepository(GameRepository gameRepository) {
        this.gameRepository = gameRepository;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }

    @Required
    public void setCrsProgramToProgramInfoConverter(CRSProgramToProgramInfoConverter crsProgramToProgramInfoConverter) {
        this.crsProgramToProgramInfoConverter = crsProgramToProgramInfoConverter;
    }

    @Required
    public void setSportingEventTagId(long sportingEventTagId) {
        this.sportingEventTagId = sportingEventTagId;
    }

    @Required
    public void setDebugHelper(DebugHelper debugHelper) {
        this.debugHelper = debugHelper;
    }
}
