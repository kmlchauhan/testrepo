package com.theplatform.web.tv.gws.sirius.repository;


import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSStream;
import com.theplatform.web.tv.gws.sirius.repository.utils.SecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.SortedSetSecondaryIndex;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class StreamRepository extends LongObjectRepository<CRSStream> {

    private SecondaryIndex<Long, CRSStream> stationIndex;
    private SecondaryIndex<Long, CRSStream> defaultStationIndex;
    private SecondaryIndex<String, CRSStream> titleIndex;

    public StreamRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
        stationIndex = new SortedSetSecondaryIndex<>();
        defaultStationIndex = new SortedSetSecondaryIndex<>();
        titleIndex = new SortedSetSecondaryIndex<>();
    }

    @Override
    protected void addToIndexes(CRSStream crsStream) {
        stationIndex.put(crsStream.getStationId(), crsStream);
        titleIndex.put(crsStream.getTitle(), crsStream);
        if (crsStream.getIsDefault()!=null && crsStream.getIsDefault().booleanValue()){
            defaultStationIndex.put(crsStream.getStationId(), crsStream);
        }
    }

    @Override
    protected void removeFromIndexes(CRSStream crsStream) {
        stationIndex.remove(crsStream.getStationId(), crsStream);
        defaultStationIndex.remove(crsStream.getStationId(), crsStream);
        titleIndex.remove(crsStream.getTitle(),crsStream);
    }

    public Collection<CRSStream> getByStationId(Long stationId) {
        return stationIndex.getByIndexKey(stationId);
    }

    public Collection<CRSStream> getDefaultStreamByStationId(Long stationId) {
        return defaultStationIndex.getByIndexKey(stationId);
    }

    public Collection<CRSStream> getByTitlePrefix(String titlePrefix) {
        List<CRSStream> crsStreamList = new ArrayList<>();
        for (String key :  titleIndex.getKeys())
            if (key.startsWith(titlePrefix))
                crsStreamList.addAll(titleIndex.getByIndexKey(key));
        return crsStreamList;
    }

}
