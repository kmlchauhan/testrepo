package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.tv.linear.api.data.objects.Listing;
import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.web.tv.gws.sirius.model.CRSListing;
import com.theplatform.web.tv.gws.sirius.model.CRSRating;

import java.util.Arrays;
import java.util.List;

public class ListingConverter extends AbstractDataObjectConverter<Listing, CRSListing> {

    @Override
    public CRSListing convert(Listing listing) {

        CRSListing crsListing = new CRSListing();
        crsListing.setId(Muri.getObjectId(listing));
        crsListing.setStationId(Muri.getObjectId(listing.getStationId()));

        if (listing.getStartTime() != null)
            crsListing.setStartTime(listing.getStartTime().getTime());
        if (listing.getEndTime() != null)
            crsListing.setEndTime(listing.getEndTime().getTime());
        if (listing.getAiringType() != null)
            crsListing.setCrsAiringType(listing.getAiringType().name());
        if (listing.getCaptionType() != null)
            crsListing.setCaptionType(listing.getCaptionType());
        if (listing.getHdLevel() != null)
            crsListing.setHdLevel(listing.getHdLevel());

        if (listing.getProgramId() != null)
            crsListing.setProgramId(Muri.getObjectId(listing.getProgramId()));

        if (listing.getPayPerView() != null)
            crsListing.setPayPerView(listing.getPayPerView());
        if (listing.getDescriptiveVideoService()  != null)
            crsListing.setDescriptiveVideoService(listing.getDescriptiveVideoService());

        if (listing.getSeriesId() != null){
            crsListing.setSeriesId(Muri.getObjectId(listing.getSeriesId()));
        }
        if (listing.getAudioType() != null){
            crsListing.setAudioType(listing.getAudioType());
        }
        if (listing.getShowingType() != null){
            crsListing.setShowingType(listing.getShowingType());
        }
        if (listing.getSap() != null){
            crsListing.setSap(listing.getSap());
        }
        if (listing.getSubjectToBlackout() != null){
            crsListing.setSubjectToBlackout(listing.getSubjectToBlackout());
        }
        if (listing.getSubtitled() != null){
            crsListing.setSubtitled(listing.getSubtitled());
        }
        if (listing.getThreeD() != null){
            crsListing.setThreeD(listing.getThreeD());
        }
        if (listing.getCci() != null){
            crsListing.setCci(listing.getCci());
        }
        if (listing.getDvrProgramId() != null){
            crsListing.setDvrProgramId(listing.getDvrProgramId());
        }
        if (listing.getDvrSeriesId() != null){
            crsListing.setDvrSeriesId(listing.getDvrSeriesId());
        }
        if (listing.getContentRatings() != null && listing.getContentRatings().size()>0){
            crsListing.setContentRatings( getCRSRatings(listing.getContentRatings()));
        }
        if (listing.getQuality() != null){
            crsListing.setQuality(listing.getQuality());
        }
        if (listing.getColorDepth() != null){
            crsListing.setColorDepth(listing.getColorDepth());
        }

        return crsListing;
    }

    private CRSRating[] getCRSRatings(List<Rating> rating) {
        CRSRating[] crsRatings = new CRSRating[rating.size()];
        for (int i=0; i<rating.size(); i++){
            crsRatings[i] =  getCRSRating(rating.get(i));
        }
        return crsRatings;
    }

    private CRSRating getCRSRating(Rating rating) {
        String scheme = rating.getScheme();
        String ratingString = rating.getRating();
        String[] subratings = null;
        if (rating.getSubRatings()!=null && rating.getSubRatings().length>0){
            subratings = rating.getSubRatings();
            Arrays.sort(subratings);
        }else{
            subratings = null;
        }
        return CRSRating.getInstance(scheme, ratingString, subratings);
    }

}
