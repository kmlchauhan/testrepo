package com.theplatform.web.tv.gws.sirius.repository.utils;

import java.util.Set;

/**
 * A basic index for maintaining values based on a composite key.  This
 * implementation has to parts to the key.
 *
 * @param <K1> First part of the Composite key
 * @param <K2> Second part of the Composite key
 * @param <V>  The value
 */
public class JdkCollectionsCompositeKeySecondaryIndex<K1, K2, V  extends Comparable<V>> implements CompositeKeySecondaryIndex<K1,K2,V> {

    private SortedSetSecondaryIndex<CompositeKey< K1, K2>, V> index;

    public JdkCollectionsCompositeKeySecondaryIndex() {                                 //
        index = new SortedSetSecondaryIndex<>();
    }


    @Override
    public void put(K1 indexValue1, K2 indexValue2, V object) {
        CompositeKey compositeKey = new CompositeKey(indexValue1,indexValue2);
        index.put( compositeKey, object);
    }

    @Override
    public void remove(K1 indexValue1, K2 indexValue2, V object) {
        CompositeKey compositeKey = new CompositeKey(indexValue1,indexValue2);
        index.remove(compositeKey, object);
    }

    @Override
    public void removeAll(K1 indexValue1, K2 indexValue2) {
        CompositeKey compositeKey = new CompositeKey(indexValue1,indexValue2);
        if (SiriusDataUtils.hasValue(compositeKey)) {
            index.removeAll(compositeKey);
        }
    }

    @Override
    public Set<V> getByIndexKey(K1 indexValue1, K2 indexValue2) {
        CompositeKey compositeKey = new CompositeKey(indexValue1,indexValue2);
        return index.getByIndexKey(compositeKey);
    }


    public static final class CompositeKey<K1, K2>{
        private K1 value1;
        private K2 value2;
        public CompositeKey(K1 value1, K2 value2){
            this.value1 = value1;
            this.value2 = value2;
        }

        @Override
        public boolean equals(Object other){
            if (!(other instanceof CompositeKey)) return false;
            CompositeKey otherCK = (CompositeKey) other;
            if (!otherCK.value1.equals(value1)) return false;
            if (!otherCK.value2.equals(value2)) return false;
            return true;
        }

        @Override
        public int hashCode(){
            return value1.hashCode() + 31 * value2.hashCode();
        }
    }




}



