package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.google.common.collect.HashBasedTable;
import com.theplatform.data.tv.linear.api.data.objects.RelatedStationType;
import com.theplatform.web.tv.gws.sirius.model.CRSStationModifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Set;

public class StationModifierRepository extends LongObjectRepository<CRSStationModifier> {
    private static Logger logger = LoggerFactory.getLogger(StationModifierRepository.class);

    // Station Id / Owner Id -> StationModifier
    HashBasedTable<Long, Long, CRSStationModifier> stationModifierIndex;

    // For OutOfHome, Station Id -> Related Station Id
    HashBasedTable<Long, Long, Long> outOfHomeIndex;

    public StationModifierRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
        stationModifierIndex = HashBasedTable.create();
        outOfHomeIndex = HashBasedTable.create();
    }

    @Override
    public void addToIndexes(CRSStationModifier crsStationModifier) {
        stationModifierIndex.put( crsStationModifier.getStationId(), crsStationModifier.getOwnerId(), crsStationModifier);

        // OutOfHome Index
        Set<Long> outOfHomeRelatedStations = crsStationModifier.getRelatedStations(RelatedStationType.OutOfHome.name());
        if (outOfHomeRelatedStations!=null && outOfHomeRelatedStations.size()>0){
            if (outOfHomeRelatedStations.size()>1){
                // There can be only one.
                logger.error("StationModifier {} contains multiple 'OutOfHome' Related Station Ids: {}", crsStationModifier.getId(), Arrays.toString(outOfHomeRelatedStations.toArray()));
            }
            Long relatedStationId = outOfHomeRelatedStations.iterator().next();
            outOfHomeIndex.put( crsStationModifier.getStationId(), crsStationModifier.getOwnerId(), relatedStationId);
        }
    }

    @Override
    protected void removeFromIndexes(CRSStationModifier stationModifier) {
        if (stationModifier!=null){
            stationModifierIndex.remove(stationModifier.getStationId(), stationModifier.getOwnerId());
            outOfHomeIndex.remove(stationModifier.getStationId(), stationModifier.getOwnerId());
        }
    }

    /**
     *  Return the outOfHome related Station Id / Owner Id or null if none exists
     */
    public Long getOutOfHomeStationId(Long stationId, Long ownerId){
        return outOfHomeIndex.get( stationId, ownerId);
    }

    /**
     *  Return the CRSStationModifier from Station Id / Owner Id or null if none exists
     */
    public CRSStationModifier getStationModifier(Long stationId, Long ownerId){
        return stationModifierIndex.get( stationId, ownerId);
    }

}
