package com.theplatform.web.tv.gws.service.common.converter;

import com.theplatform.web.tv.contentresolution.api.objects.CompanyAssociationInfo;
import com.theplatform.web.tv.gws.sirius.model.CRSCompany;
import com.theplatform.web.tv.gws.sirius.model.CRSStationCompany;
import com.theplatform.web.tv.gws.sirius.repository.CompanyRepository;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.springframework.beans.factory.annotation.Required;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class CRSStationCompanyToCompanyAssociationConverter {
    private CompanyRepository companyRepository;

    public List<CompanyAssociationInfo> convert(Collection<CRSStationCompany> crsStationCompanys, MerlinIdHelper merlinIdHelper) {
        List<CompanyAssociationInfo> companyAssociationInfos = new ArrayList<>();
        if (crsStationCompanys == null || crsStationCompanys.size()==0){
            // None
            return companyAssociationInfos;
        }

        List<CRSStationCompany> crsStationCompanysList = new ArrayList<>(crsStationCompanys);
        if (crsStationCompanysList.size()>1){
            Collections.sort(crsStationCompanysList);
        }

        for (CRSStationCompany crsStationCompany : crsStationCompanysList){
            companyAssociationInfos.add(convert(crsStationCompany, merlinIdHelper));
        }
        return companyAssociationInfos;
    }

    private CompanyAssociationInfo convert( CRSStationCompany crsStationCompany, MerlinIdHelper merlinIdHelper){
        CompanyAssociationInfo companyAssociationInfo = new CompanyAssociationInfo();
        companyAssociationInfo.setStationCompanyId(merlinIdHelper.createStationCompanyId(crsStationCompany.getId()));
        companyAssociationInfo.setCompanyId(merlinIdHelper.createCompanyId(crsStationCompany.getCompanyId()));
        companyAssociationInfo.setAssociationType(crsStationCompany.getAssociationType());

        CRSCompany crsCompany = companyRepository.get(crsStationCompany.getCompanyId());
        if (crsCompany != null && crsCompany.getDisplayName()!=null){
            companyAssociationInfo.setCompanyName(crsCompany.getTitle());
        }
        return companyAssociationInfo;
    }

    @Required
    public void setCompanyRepository(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

}