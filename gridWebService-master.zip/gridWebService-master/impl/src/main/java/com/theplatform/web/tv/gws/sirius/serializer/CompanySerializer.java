package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.CompanyProto.CompanyMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSCompany;

public class CompanySerializer extends AbstractSiriusObjectSerializer<CRSCompany> {

    public CompanySerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSCompany unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        CompanyMessage.Builder message = CompanyMessage.newBuilder().mergeFrom(bytes);

        CRSCompany crsCompany = new CRSCompany(message.getId());
        crsCompany.setDisplayName(message.getDisplayName());
        if (message.hasTitle()) {
            crsCompany.setTitle(message.getTitle());
        }
        return crsCompany;
    }


    @Override
    public ByteString marshallPayload( CRSCompany crsCompany) {
        CompanyMessage.Builder builder = CompanyMessage.newBuilder();

        builder.setId(crsCompany.getId());
        builder.setDisplayName(crsCompany.getDisplayName());
        if (crsCompany.getTitle()!=null) {
            builder.setTitle(crsCompany.getTitle());
        }
        return builder.build().toByteString();
    }


}
