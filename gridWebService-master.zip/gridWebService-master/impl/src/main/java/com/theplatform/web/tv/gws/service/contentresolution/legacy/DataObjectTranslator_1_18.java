package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.theplatform.web.tv.contentresolution.api.objects.ApiObjectVisitor;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;

public class DataObjectTranslator_1_18 extends ApiObjectVisitor {
    public final static DataObjectTranslator_1_18 INSTANCE = new DataObjectTranslator_1_18();

    @Override
    public void visitChannelInfo(ChannelInfo channelInfo){
        StationInfo stationInfo = channelInfo.getStationInfo();
        /**
         * OnScreenCallsign and Digicable were moved from StationInfo to ChannelInfo.  Undo this.
         */
        if (stationInfo != null){
            stationInfo.setOnScreenCallsign(channelInfo.getOnScreenCallsign());
            stationInfo.setDigicableId(channelInfo.getDigicableId());
            channelInfo.setOnScreenCallsign(null);
            channelInfo.setDigicableId(null);
        }
    }
}