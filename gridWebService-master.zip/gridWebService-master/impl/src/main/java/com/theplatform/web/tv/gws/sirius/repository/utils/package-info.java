/**
 * Classes used internally by the repositories.  These classes are not intended to be used outside of
 * the repository package.
 */
package com.theplatform.web.tv.gws.sirius.repository.utils;