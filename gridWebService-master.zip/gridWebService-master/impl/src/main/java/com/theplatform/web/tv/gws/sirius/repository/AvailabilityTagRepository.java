package com.theplatform.web.tv.gws.sirius.repository;


import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSAvailabilityTag;

import java.util.HashMap;
import java.util.Map;

public class AvailabilityTagRepository extends LongObjectRepository<CRSAvailabilityTag> {

    private Map<Long, CRSAvailabilityTag> nationalAvailabilityIdIndex;             // OwnerId -> Availability Tag Id

    public AvailabilityTagRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
        nationalAvailabilityIdIndex = new HashMap<>();
    }

    @Override
    public void addToIndexes(CRSAvailabilityTag availabilityTag) {
        if (availabilityTag.getNational()){
            nationalAvailabilityIdIndex.put(availabilityTag.getOwnerId(),availabilityTag);
        }
    }

    @Override
    public void removeFromIndexes(CRSAvailabilityTag availabilityTag) {
        if (availabilityTag.getNational()){
            nationalAvailabilityIdIndex.remove(availabilityTag.getOwnerId());
        }
    }

    public CRSAvailabilityTag getNationalAvailabilityTag(long ownerId){
        return nationalAvailabilityIdIndex.get(ownerId);
    }



}
