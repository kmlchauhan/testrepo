/**
 * Describes the properties of and relationships between API ("info") classes.
 */
package com.theplatform.web.tv.gws.service.common.field.descriptor;