package com.theplatform.web.tv.gws.service.contentresolution;

import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.contentresolution.api.objects.*;

import java.util.*;

/**
 * User: mmattozzi
 * Date: 12/13/11
 * Time: 2:06 PM
 */
public class GridMapper {


    public Grid createGrid(List<ChannelInfo> channels, List<Header> header, ContentResolutionServiceImpl gridService,
            Integer numGridUnits, Integer gridUnitWidth, Integer offset, Long[] programTagIds) throws GridException {
        
        Grid grid = new Grid();
        grid.setHeader(header);
        grid.setChannels(channels);

        for (ChannelInfo channelInfo : channels) {
            StationInfo stationInfo = channelInfo.getStationInfo();
            List<ListingInfo> listings = fetchListings(gridService, numGridUnits, gridUnitWidth, offset, stationInfo, programTagIds);

            stationInfo.setListings(listings);
        }

        return grid;
    }

    public Grid createFilteredGrid(List<ChannelInfo> channels, List<Header> header, ContentResolutionServiceImpl gridService,
            Integer numGridUnits, Integer gridUnitWidth, Integer offset, String[] categories, Long[] programTagIds) throws GridException {

        Grid grid = new Grid();
        grid.setHeader(header);

        Set<String> filterCategories = new HashSet<String>(Arrays.asList(categories));
        List<ChannelInfo> filteredChannelList = new ArrayList<ChannelInfo>();

        for (ChannelInfo channelInfo : channels) {
            StationInfo stationInfo = channelInfo.getStationInfo();
            List<ListingInfo> listings = fetchListings(gridService, numGridUnits, gridUnitWidth, offset, stationInfo, programTagIds);

            if (listingsMatchFilter(listings, filterCategories)) {
                filteredChannelList.add(channelInfo);
                stationInfo.setListings(listings);
            }
        }

        grid.setChannels(filteredChannelList);
        
        return grid;
    }
    
    public boolean listingsMatchFilter(List<ListingInfo> listings, Set<String> categories) {
        for (ListingInfo listingInfo : listings) {
            if (categories.contains(listingInfo.getProgramInfo().getCategory()))
                return true;
        }

        return false;
    }

    private static List<ListingInfo> fetchListings(ContentResolutionServiceImpl gridService, Integer numGridUnits, Integer gridUnitWidth, Integer offset, StationInfo stationInfo, Long[] programTagIds) throws GridException {
        Long numericStationId = stationInfo.getStationId().getId();
        return gridService.getListings(numericStationId, numGridUnits, gridUnitWidth, offset, programTagIds, null);
    }
}
