package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.StationProto.StationMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSStation;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

/**
 * Factory that converts Station protobufs to CRSStations and visa-versa.
 *
 */
public class StationSerializer extends AbstractSiriusObjectSerializer<CRSStation> {

    public StationSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSStation unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        StationMessage.Builder message = StationMessage.newBuilder().mergeFrom(bytes);

        CRSStation station = new CRSStation();

        if (message.hasId()) {
            station.setId(message.getId());
        }
        if (message.hasTitle()) {
            station.setTitle(message.getTitle());
        }
        if (message.hasCallSign()) {
            station.setCallSign(message.getCallSign());
        }
        if (message.hasOnScreenCallSign()) {
            station.setOnScreenCallSign(message.getOnScreenCallSign());
        }
        if (message.hasTimeZone()) {
            station.setTimeZone(message.getTimeZone().intern());
        }
        if (message.hasExpirationDate()) {
            station.setExpirationDate(message.getExpirationDate());
        }
        if (message.hasAssociatedStationId()) {
            station.setAssociatedStationId(message.getAssociatedStationId());
        }
        if (message.hasLanguage()) {
            station.setLanguage(message.getLanguage().intern());
        }
        if (message.hasOtaChannelNumber()) {
            station.setOtaChannelNumber(message.getOtaChannelNumber());
        }
        if (message.hasPayPerView()) {
            station.setPayPerView(message.getPayPerView());
        }
        if (message.hasShortName()) {
            station.setShortName(message.getShortName());
        }
        if (message.hasVod()) {
            station.setVod(message.getVod());
        }
        if (message.hasDigicableId()) {
            station.setDigicableId(message.getDigicableId());
        }
        if (message.hasEmergencyAlertSystemType()) {
            station.setEmergencyAlertSystemType(message.getEmergencyAlertSystemType());
        }
        if (message.hasHdLevel()){
            station.setHdLevel(message.getHdLevel());
        }
        if (message.hasColorDepth()){
            station.setColorDepth(message.getColorDepth());
        }
        if (message.hasQuality()){
            station.setQuality(message.getQuality());
        }
        if (message.hasSdStationId()){
            station.getQualityVariants().put("SD", message.getSdStationId());
        }
        if (message.hasHdStationId()){
            station.getQualityVariants().put("HD", message.getHdStationId());
        }
        if (message.hasUhdStationId()){
            station.getQualityVariants().put("UHD", message.getUhdStationId());
        }

        return station;
    }

    @Override
    public ByteString marshallPayload( CRSStation station) {
        StationMessage.Builder builder = StationMessage.newBuilder();

        builder.setId(station.getId());
        if (station.getTitle() != null)
            builder.setTitle(station.getTitle());
        if (station.getCallSign() != null)
            builder.setCallSign(station.getCallSign());
        builder.setOnScreenCallSign(station.getOnScreenCallSign());
        builder.setTimeZone(station.getTimeZone());
        builder.setExpirationDate(station.getExpirationDate());
        builder.setAssociatedStationId(station.getAssociatedStationId());
        builder.setLanguage(station.getLanguage());
        builder.setOtaChannelNumber(station.getOtaChannelNumber());
        if (station.getPayPerView() != null)
            builder.setPayPerView(station.getPayPerView());
        if (station.getShortName() != null)
            builder.setShortName(station.getShortName());
        if (station.getVod() != null)
            builder.setVod(station.getVod());
        builder.setDigicableId(station.getDigicableId());
        if (station.getEmergencyAlertSystemType() != null) {
            builder.setEmergencyAlertSystemType(station.getEmergencyAlertSystemType());
        }
        if (station.getHdLevel() != null){
            builder.setHdLevel(station.getHdLevel());
        }
        if (station.getColorDepth() != null){
            builder.setColorDepth(station.getColorDepth());
        }
        if (station.getQuality() != null){
            builder.setQuality(station.getQuality());
        }

        if (station.getQualityVariants() != null && Boolean.FALSE.equals(station.getQualityVariants().isEmpty())){
            String key;
            for (Map.Entry<String, Long> entry : station.getQualityVariants().entrySet()) {
                key = entry.getKey();
                if (key.equals("SD")) builder.setSdStationId(entry.getValue());
                else if (key.equals("HD")) builder.setHdStationId(entry.getValue());
                else if (key.equals("UHD")) builder.setUhdStationId(entry.getValue());
            }
        }

        return builder.build().toByteString();
    }


}

