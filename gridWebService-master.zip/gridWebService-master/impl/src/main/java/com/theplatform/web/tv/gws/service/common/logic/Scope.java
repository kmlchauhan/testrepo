package com.theplatform.web.tv.gws.service.common.logic;

public enum Scope {
    STREAM,
    STATION,
    VOD,
    CHANNEL,
    OFFER,
    MENU,
    SHADOW,
    UNKNOWN;

    public static Scope valueOfIgnoreCase(String scope) {
        if (scope == null) {
            return Scope.UNKNOWN;
        } else {
            try {
                return Scope.valueOf(scope.toUpperCase());
            } catch (IllegalArgumentException e) {
                return UNKNOWN;
            }
        }
    }
}
