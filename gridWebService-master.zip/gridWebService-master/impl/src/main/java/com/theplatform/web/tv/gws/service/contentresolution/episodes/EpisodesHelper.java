package com.theplatform.web.tv.gws.service.contentresolution.episodes;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.repository.ProgramRepository;
import com.theplatform.web.tv.gws.service.common.converter.CRSProgramToProgramInfoConverter;
import org.springframework.beans.factory.annotation.Required;

import java.util.*;

public class EpisodesHelper {

    private ProgramRepository programRepository;
    private CRSProgramToProgramInfoConverter crsProgramToProgramInfoConverter;

    public List<Set<ProgramInfo>> getEpisodes(Muri episodeId, long previousEpisodeCount, long nextEpisodeCount,
                                              boolean excludeProvidedEpisode) {
        Long seriesId = programRepository.getSeriesId(episodeId.getId());

        if (seriesId == null) return Collections.emptyList();

        Collection<CRSProgram> allEpisodes = programRepository.getEpisodes(seriesId);

        List<Set<CRSProgram>> episodeSets = constructSets(allEpisodes);

        Integer providedEpisodeIndex = indexOf(episodeId, episodeSets);

        // the provided episode has no seriesEpisodeNumber, so there are no episodes before or after it
        if (providedEpisodeIndex == null) {
            return Collections.emptyList();
        }

        if (excludeProvidedEpisode) {
            episodeSets.remove((int) providedEpisodeIndex);
        }

        int fromIndex = (int) Math.max(0, providedEpisodeIndex - previousEpisodeCount);
        int toIndex = (int) Math.min(episodeSets.size(),
                providedEpisodeIndex + nextEpisodeCount + (excludeProvidedEpisode ? 0 : 1));

        List<Set<CRSProgram>> crsProgramSets = episodeSets.subList(fromIndex, toIndex);

        return convert(crsProgramSets);
    }

    private List<Set<CRSProgram>> constructSets(Collection<CRSProgram> crsPrograms) {
        Map<Integer, Set<CRSProgram>> bySeriesEpisodeNumber = indexBySeriesEpisodeNumber(crsPrograms);

        if (bySeriesEpisodeNumber.isEmpty()) {
            return Collections.emptyList();
        }

        int maxSeriesEpisodeNumber = Collections.max(bySeriesEpisodeNumber.keySet());

        List<Set<CRSProgram>> crsProgramSets = new ArrayList<>(crsPrograms.size());

        for (int i = 1; i <= maxSeriesEpisodeNumber; ++i) {
            Set<CRSProgram> equivalentEpisodes = bySeriesEpisodeNumber.get(i);

            if (equivalentEpisodes == null) {
                crsProgramSets.add(Collections.<CRSProgram>emptySet());
            } else {
                crsProgramSets.add(equivalentEpisodes);
            }
        }

        return crsProgramSets;
    }

    /**
     * CRSPrograms w/out a seriesEpisodeNumber will not be added to the index
     */
    private Map<Integer, Set<CRSProgram>> indexBySeriesEpisodeNumber(Collection<CRSProgram> crsPrograms) {
        Map<Integer, Set<CRSProgram>> index = new HashMap<>(crsPrograms.size());

        for (CRSProgram crsProgram : crsPrograms) {
            Integer seriesEpisodeNumber = crsProgram.getSeriesEpisodeNumber();

            if (seriesEpisodeNumber != null) {
                Set<CRSProgram> equivalentEpisodes = index.get(seriesEpisodeNumber);

                if (equivalentEpisodes == null) {
                    index.put(seriesEpisodeNumber, new HashSet<>(Collections.singletonList(crsProgram)));
                } else {
                    equivalentEpisodes.add(crsProgram);
                }
            }
        }

        return index;
    }

    private List<Set<ProgramInfo>> convert(List<Set<CRSProgram>> crsProgramSets) {
        List<Set<ProgramInfo>> programInfoSets = new ArrayList<>(crsProgramSets.size());

        for (Set<CRSProgram> crsProgramSet : crsProgramSets) {
            Set<ProgramInfo> programInfoSet;

            if (crsProgramSet.isEmpty()) {
                programInfoSet = Collections.emptySet();
            } else {
                programInfoSet = new HashSet<>(crsProgramSet.size());
                for (CRSProgram crsProgram : crsProgramSet) {
                    ProgramInfo programInfo = crsProgramToProgramInfoConverter.convertCRSProgramToProgramInfo(crsProgram);
                    programInfoSet.add(programInfo);
                }
            }

            programInfoSets.add(programInfoSet);
        }

        return programInfoSets;
    }

    private Integer indexOf(Muri episodeId, List<Set<CRSProgram>> crsProgramSets) {
        for (int i = 0; i < crsProgramSets.size(); ++i) {
            Set<CRSProgram> crsProgramSet = crsProgramSets.get(i);

            if (crsProgramSet.contains(new CRSProgram(episodeId.getId()))) {
                return i;
            }
        }

        return null;
    }

    @Required
    public void setProgramRepository(ProgramRepository programRepository) {
        this.programRepository = programRepository;
    }

    @Required
    public void setCrsProgramToProgramInfoConverter(CRSProgramToProgramInfoConverter crsProgramToProgramInfoConverter) {
        this.crsProgramToProgramInfoConverter = crsProgramToProgramInfoConverter;
    }
}
