package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.common.primitives.Longs;
import org.apache.commons.lang.Validate;

import java.util.List;

public class CRSGame extends LongDataRepoObject implements Comparable<CRSGame> {

    private long[] listingIds;
    private boolean liveCoverageAvailable;

    public CRSGame(long id, List<Long> listingIds, boolean liveCoverageAvailable) {
        super( SiriusObjectType.fromFriendlyName("Game") , id);
        Validate.notNull(listingIds);
        this.listingIds = Longs.toArray(listingIds);
        this.liveCoverageAvailable = liveCoverageAvailable;
    }

    public long[] getListingIds() {
        if (listingIds==null){
            return new long[0];
        } else {
            return this.listingIds;
        }
    }

    public boolean isLiveCoverageAvailable() {
        return liveCoverageAvailable;
    }

    @Override
    public int compareTo(CRSGame game) {
        if (this.id > game.id) {
            return 1;
        } else if (this.id < game.id) {
            return -1;
        } else {
            return 0;
        }
    }
}
