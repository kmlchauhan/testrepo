package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.data.tv.offer.api.data.objects.ProductContextType;
import com.theplatform.web.tv.gws.sirius.model.CRSProductContext;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProductContextRepository extends LongObjectRepository<CRSProductContext> {
    private ChannelRepository channelRepository;

    private List<String> tveProductContextTitles;
    private Set<String> tveProductContextTitlesLookup;
    private Set<Long> tveProductContexts;

    public ProductContextRepository( SiriusObjectType siriusObjectType, ChannelRepository channelRepository, String tveProductContextTitles) {
        super(siriusObjectType);
        this.channelRepository = channelRepository;
        tveProductContexts = new HashSet<>();
        setTveProductContextTitles(tveProductContextTitles);
    }

    @Override
    public void addToIndexes(CRSProductContext crsProductContext) {
        channelRepository.addProductContext(crsProductContext);
        if(tveProductContextTitlesLookup.contains(crsProductContext.getTitle().toUpperCase())){
            tveProductContexts.add(crsProductContext.getId());
        }
    }

    @Override
    public void removeFromIndexes(CRSProductContext crsProductContext) {
        tveProductContexts.remove(crsProductContext.getId());
    }

    public boolean isTveProductContext(long id){
        return tveProductContexts.contains(id);
    }

    /**
     *  Is a particular ProductContext of a specific Type.
     */
    public boolean isProductContextOfType(long productContextId, ProductContextType productContextType){
        CRSProductContext crsProductContext = get(productContextId);
        if (crsProductContext==null) return false;
        return crsProductContext.getType().equals(productContextType.name());
    }

    private void setTveProductContextTitles(String tveProductContextTitles){
        this.tveProductContextTitles = Arrays.asList(tveProductContextTitles.split(","));
        tveProductContextTitlesLookup = new HashSet<>( );
        for (String title : this.tveProductContextTitles){
            tveProductContextTitlesLookup.add(title.toUpperCase());
        }
    }

}
