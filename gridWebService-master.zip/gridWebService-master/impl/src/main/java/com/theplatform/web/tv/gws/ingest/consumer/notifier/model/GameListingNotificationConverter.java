package com.theplatform.web.tv.gws.ingest.consumer.notifier.model;

import com.comcast.merlin.sirius.ingest.Action;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.common.collect.Sets;
import com.theplatform.data.tv.sports.api.data.objects.Game;
import com.theplatform.web.tv.gws.sirius.model.CRSGame;
import com.theplatform.web.tv.gws.sirius.model.CRSListing;
import com.theplatform.web.tv.gws.sirius.repository.GameRepository;
import com.theplatform.web.tv.gws.sirius.repository.ListingRepository;
import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class GameListingNotificationConverter implements NotificationConverter<CRSGame, NotificationListing> {
    private static final Logger LOGGER = LoggerFactory.getLogger(GameListingNotificationConverter.class);

    private final GameRepository gameRepository;
    private final ListingRepository listingRepository;

    public GameListingNotificationConverter(GameRepository gameRepository, ListingRepository listingRepository) {
        this.gameRepository = gameRepository;
        this.listingRepository = listingRepository;
    }

    @Override
    public List<NotificationListing> convert(long id, CRSGame currentGame, Action action, Long sequence) {
        CRSGame oldGame = gameRepository.get(id);
        Set<Long> oldListingIds = extractListingIds(oldGame);
        Set<Long> currentListingIds = extractListingIds(currentGame);
        Set<Long> listingIdsToNotify;

        if (Action.DELETE.equals(action)) {
            listingIdsToNotify = oldListingIds;
        } else if (Action.PUT.equals(action)) {
            listingIdsToNotify = Sets.symmetricDifference(oldListingIds, currentListingIds);
        } else {
            throw new IllegalArgumentException("Unexpected Action: " + action);
        }

        List<NotificationListing> notifications = new ArrayList<>(listingIdsToNotify.size());
        for (Long listingId : listingIdsToNotify) {
            CRSListing crsListing = listingRepository.get(listingId);
            if (crsListing != null) {
                NotificationListing notificationListing = new NotificationListing(Action.PUT, listingId);
                notificationListing.setSourceSequence(sequence);
                notificationListing.setSourceSiriusObjectType(SiriusObjectType.fromDataServiceObjectClass(Game.class));
                notificationListing.setStartTime(crsListing.getStartTime());

                notifications.add(notificationListing);
            }
        }

        return notifications;
    }

    private Set<Long> extractListingIds(CRSGame game) {
        if (game == null || game.getListingIds() == null) {
            return Collections.emptySet();
        } else {
            return new HashSet<>(Arrays.asList(ArrayUtils.toObject(game.getListingIds())));
        }
    }
}
