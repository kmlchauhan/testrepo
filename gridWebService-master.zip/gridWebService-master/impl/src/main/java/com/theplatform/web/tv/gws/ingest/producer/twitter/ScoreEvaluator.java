package com.theplatform.web.tv.gws.ingest.producer.twitter;

import com.theplatform.web.tv.gws.sirius.model.CRSTrendingProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.springframework.beans.factory.annotation.Required;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Calculate {@link CRSTrendingProgram#getRankingGroup() rankingGroup} and {@link CRSTrendingProgram#isTopTrending() topTrending}
 * attributes of each CRSTrendingProgram based on the {@link TwitterSettings#getTopTrendThreshold() topTrendingThreshold} and
 * {@link TwitterSettings#getNumberOfRankGroups() numberOfRankGroups} settings.
 * User: mmattozzi
 * Date: 2/13/14
 * Time: 2:51 PM
 */
public class ScoreEvaluator {

    protected int numberOfRankGroups;

    /**
     * Any trending program with a score above this value will be a topTrend.
     */
    protected int topTrendThreshold;

    /**
     * Set the {@link CRSTrendingProgram#getRankingGroup() rankingGroup} and {@link CRSTrendingProgram#isTopTrending() topTrending}
     * properties of each CRSTrendingProgram based on a statistical analysis of the overall {@link CRSTrendingProgram#getScore() score}
     * distribution and the configured threshold and number of rank groups.
     * <br><br>
     * After statistics are calculated, the list of trending programs is sorted in descending order by score.
     * @param trendingPrograms not null, one or more CRSTrendingProgram
     */
    public void updateTrendingPrograms(CRSTrendingPrograms trendingPrograms) {
        calculatePercentiles(trendingPrograms);
        calculateTopTrends(trendingPrograms);
    }

    protected void calculateTopTrends(CRSTrendingPrograms trendingPrograms) {
        for (CRSTrendingProgram trendingProgram : trendingPrograms) {
            if (trendingProgram.getScore() >= topTrendThreshold) {
                trendingProgram.setTopTrending(true);
            }
        }
    }

    protected void calculatePercentiles(CRSTrendingPrograms trendingPrograms) {
        DescriptiveStatistics statistics = new DescriptiveStatistics();


        for (CRSTrendingProgram trendingProgram : trendingPrograms) {
            statistics.addValue(trendingProgram.getScore());
        }

        Map<Integer, Double> rankGroupToPercentile = new HashMap<Integer, Double>();
        for (int i = 1; i <= numberOfRankGroups; i++) {
            double percentileForRankGroup = 100.0 * (((double) numberOfRankGroups - (double) i) / (double) numberOfRankGroups);
            if (percentileForRankGroup > 0) {
                rankGroupToPercentile.put(i, statistics.getPercentile(percentileForRankGroup));
            } else {
                rankGroupToPercentile.put(i, 0.0);
            }
        }

        for (CRSTrendingProgram trendingProgram : trendingPrograms) {
            for (int i = 1; i <= numberOfRankGroups; i++) {
                if (trendingProgram.getScore() >= rankGroupToPercentile.get(i)) {
                    trendingProgram.setRankingGroup(i);
                    break;
                }
            }
        }

        Collections.sort(trendingPrograms.getPrograms());
    }

    @Required
    public void setSettings(TwitterSettings settings) {
        this.numberOfRankGroups = settings.getNumberOfRankGroups();
        this.topTrendThreshold = settings.getTopTrendThreshold();
    }

}
