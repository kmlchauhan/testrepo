package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.ProgramTeamAssociationProto.ProgramTeamAssociationMessage;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.ProgramTeamAssociationProto.ProgramTeamAssociationMessageOrBuilder;
import com.theplatform.web.tv.gws.sirius.model.CRSProgramTeamAssociation;

public class ProgramTeamAssociationSerializer extends AbstractSiriusObjectSerializer<CRSProgramTeamAssociation> {

    public ProgramTeamAssociationSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    protected CRSProgramTeamAssociation unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        ProgramTeamAssociationMessageOrBuilder msg = ProgramTeamAssociationMessage.newBuilder().mergeFrom(bytes);

        return new CRSProgramTeamAssociation(msg.getId(), msg.getProgramId(), msg.getSportsTeamId());
    }

    @Override
    protected ByteString marshallPayload(CRSProgramTeamAssociation payload) {
        return ProgramTeamAssociationMessage.newBuilder()
                .setId(payload.getId())
                .setProgramId(payload.getProgramId())
                .setSportsTeamId(payload.getSportsTeamId())
                .build()
                .toByteString();
    }
}
