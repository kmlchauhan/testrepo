package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.StationModifierProto;
import com.theplatform.web.tv.gws.sirius.model.CRSStationModifier;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class StationModifierFactory extends AbstractSiriusObjectSerializer<CRSStationModifier> {

    public StationModifierFactory(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSStationModifier unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        StationModifierProto.StationModifierMessage.Builder message = StationModifierProto.StationModifierMessage.newBuilder().mergeFrom(bytes);
        CRSStationModifier crsStationModifier = new CRSStationModifier(message.getId());
        crsStationModifier.setStationId(message.getStationId());
        crsStationModifier.setOwnerId(message.getOwnerId());
        Map<String,Set<Long>> relatedStationsLookup = new HashMap<>();
        for (StationModifierProto.StationModifierMessage.RelatedStations relatedStationsMessage : message.getRelatedStationsList()) {
            if (!relatedStationsLookup.containsKey(relatedStationsMessage.getType())){
                relatedStationsLookup.put(relatedStationsMessage.getType(), new HashSet<Long>());
            }
            relatedStationsLookup.get(relatedStationsMessage.getType()).add(relatedStationsMessage.getStationId());
        }
        crsStationModifier.setRelatedStations(relatedStationsLookup);
        return crsStationModifier;
    }

    @Override
    public ByteString marshallPayload(CRSStationModifier crsStationModifier) {
        StationModifierProto.StationModifierMessage.Builder builder = StationModifierProto.StationModifierMessage.newBuilder();
        builder.setId(crsStationModifier.getId());
        builder.setStationId(crsStationModifier.getStationId());
        builder.setOwnerId(crsStationModifier.getOwnerId());
        for (String type : crsStationModifier.getRelatedStationsTypes()){
            Set<Long> relatedStaionIds = crsStationModifier.getRelatedStations(type);

            for (Long relatedStationId : relatedStaionIds){
                StationModifierProto.StationModifierMessage.RelatedStations.Builder relatedStationBuilder = StationModifierProto.StationModifierMessage.RelatedStations.newBuilder();
                relatedStationBuilder.setStationId(relatedStationId);
                relatedStationBuilder.setType(type);
                builder.addRelatedStations(relatedStationBuilder);
            }
        }
        return builder.build().toByteString();
    }

}
