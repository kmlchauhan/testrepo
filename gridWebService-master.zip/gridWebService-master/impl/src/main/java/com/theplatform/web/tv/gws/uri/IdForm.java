package com.theplatform.web.tv.gws.uri;


public enum IdForm {
    URL,
    URN;
}
