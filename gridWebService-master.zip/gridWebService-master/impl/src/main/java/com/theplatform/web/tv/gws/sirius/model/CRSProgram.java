package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CRSProgram extends LongDataRepoObject {
    private final Logger logger = LoggerFactory.getLogger(CRSProgram.class);

    private String title;
    private String gridTitle;
    private ProgramCategory category;
    private ProgramType type;

    // this SeriesMaster might not be in the repository since we're currently ingesting Programs
    // by Listing.seriesId and Listing.programId (but not Program.seriesId)
    private long seriesId = Long.MIN_VALUE;
    private String episodeTitle;
    private String sportsSubtitle;
    private Boolean adult;
    private long[] tagIds;
    private CRSRating[] contentRatings;
    private Integer tvSeasonNumber;
    private Integer tvSeasonEpisodeNumber;
    private Integer seriesEpisodeNumber;
    private Integer partNumber;
    private Integer totalParts;
    private String language;

    public CRSProgram() {
        super( SiriusObjectType.fromFriendlyName("Program"));
    }

    public CRSProgram(long id) {
        super( SiriusObjectType.fromFriendlyName("Program"), id);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        // if the caller is setting title to the same value as gridTitle, update this instance so that
        // title and gridTitle point to the same String instance rather than separate Strings that contain
        // the exact same content.  this allows the other String instance to get garbage collected and reduces
        // our overall memory footprint
        if (this.gridTitle != null && this.gridTitle.equals(title)) {
            this.title = this.gridTitle;
        }
        else {
            this.title = title;
        }
    }

    public String getGridTitle() {
        return gridTitle;
    }

    public void setGridTitle(String gridTitle) {
        if (this.title != null && this.title.equals(gridTitle)) {
            this.gridTitle = this.title;
        }
        else {
            this.gridTitle = gridTitle;
        }
    }

    public ProgramCategory getCategory() {
        return category;
    }

    public void setCategory(ProgramCategory category) {
        this.category = category;
    }

    public ProgramType getType() {
        return type;
    }

    public void setType(ProgramType programType) {
        this.type = programType;
    }

    public Long getSeriesId() {
        if (seriesId != Long.MIN_VALUE) {
            return seriesId;
        }
        else {
            return null;
        }
    }

    public void setSeriesId(Long seriesId) {
        if (seriesId != null) {
            this.seriesId = seriesId;
        }
        else {
            this.seriesId = Long.MIN_VALUE;
        }
    }

    public String getEpisodeTitle() {
        return episodeTitle;
    }

    public void setEpisodeTitle(String episodeTitle) {
        this.episodeTitle = episodeTitle;
    }

    public String getSportsSubtitle() {
        return sportsSubtitle;
    }

    public void setSportsSubtitle(String sportsSubtitle) {
        this.sportsSubtitle = sportsSubtitle;
    }

    public Boolean getAdult() {
        return adult;
    }

    public void setAdult(Boolean adult) {
        this.adult = adult;
    }

    public CRSRating[] getContentRatings() {
        return contentRatings;
    }

    public void setContentRatings(CRSRating[] contentRatings) {
        this.contentRatings = contentRatings;
    }

    public long[] getTagIds() {
        if (tagIds == null){
            return ArrayUtils.EMPTY_LONG_ARRAY;
        } else {
            return tagIds;
        }
    }

    public void setTagIds(long[] tagIds) {
        this.tagIds = tagIds;
    }

    public boolean isEpisode() {
        return type != null && type.equals(ProgramType.Episode);
    }

    public Integer getTvSeasonNumber() {
        return tvSeasonNumber;
    }

    public void setTvSeasonNumber(Integer tvSeasonNumber) {
        this.tvSeasonNumber = tvSeasonNumber;
    }

    public Integer getTvSeasonEpisodeNumber() {
        return tvSeasonEpisodeNumber;
    }

    public void setTvSeasonEpisodeNumber(Integer tvSeasonEpisodeNumber) {
        this.tvSeasonEpisodeNumber = tvSeasonEpisodeNumber;
    }

    public Integer getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(Integer partNumber) {
        this.partNumber = partNumber;
    }

    public Integer getTotalParts() {
        return totalParts;
    }

    public void setTotalParts(Integer totalParts) {
        this.totalParts = totalParts;
    }

    public boolean hasTvSeasonEpisodeNumber() {
        return tvSeasonEpisodeNumber != null;
    }

    public boolean hasTvSeasonNumber() {
        return tvSeasonNumber != null;
    }

    public boolean hasEpisodeTitle() {
        return episodeTitle != null;
    }

    public boolean hasPartNumber() {
        return partNumber != null;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getLanguage() {
        return language;
    }

    public Integer getSeriesEpisodeNumber() {
        return seriesEpisodeNumber;
    }

    public void setSeriesEpisodeNumber(Integer seriesEpisodeNumber) {
        this.seriesEpisodeNumber = seriesEpisodeNumber;
    }
}
