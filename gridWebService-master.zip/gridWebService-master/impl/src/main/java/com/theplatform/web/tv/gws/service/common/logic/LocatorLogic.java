package com.theplatform.web.tv.gws.service.common.logic;

import com.comcast.compass.availability.common.domain.*;
import com.google.common.collect.*;
import com.theplatform.contrib.data.api.objects.*;
import com.theplatform.web.tv.contentresolution.api.debug.*;
import com.theplatform.web.tv.contentresolution.api.objects.*;
import com.theplatform.web.tv.gws.service.common.converter.*;
import com.theplatform.web.tv.gws.service.common.debug.*;
import com.theplatform.web.tv.gws.service.common.util.*;
import com.theplatform.web.tv.gws.sirius.model.*;
import com.theplatform.web.tv.gws.sirius.repository.*;
import com.theplatform.web.tv.gws.uri.*;
import java.net.*;
import java.util.*;
import org.slf4j.*;
import org.springframework.beans.factory.annotation.*;

import static com.theplatform.contrib.data.api.objects.Muri.*;
import static org.apache.commons.collections.CollectionUtils.*;

/**
 *   Locator CA Based Locator/Stream Logic.
 *
 *   1) Find the IP Locators, if Any  See this{@link #applyIpLocators(ChannelInfo, LocatorLookup, Set)} for more detail.
 *   2) Create all IP Locators for the Locator(Again, if any)
 *   3) If QAM PC, create QAM Locator
 *   4) If OnDemand, create OnDemand Locator
 *
 */
public class LocatorLogic {
    private static Logger logger = LoggerFactory.getLogger(LocatorLogic.class);

    private DebugHelper debugHelper;

    private CRSLocatorToLocatorInfoConverter crsLocatorToLocatorInfoConverter;
    private ProductContextRepository productContextRepository;
    private ContentAvailabilityRepository contentAvailabilityRepository;
    private LocatorRepository locatorRepository;
    private StreamRepository streamRepository;

    private MerlinIdHelper merlinIdHelper;

    private static final StreamPrecedenceComparator STREAM_PRECEDENCE_COMPARATOR = new StreamPrecedenceComparator();

    /**
     *
     * @param scopedAvailabilities
     * @param channelInfos
     * @param allowedStreamStatus Required to be one or two.  This will be default by the caller of this method if the client doesn't provide it.
     * @param ownerId
     */
    public void modify( ScopedAvailabilities scopedAvailabilities,
                        List<ChannelInfo> channelInfos,
                        Set<String> allowedStreamStatus,
                        Long ownerId) {
        if (ownerId==null) throw new RuntimeException("OwnerId must be passed in.");
        if (isEmpty(allowedStreamStatus)) throw new RuntimeException("allowedStreamStatus must be provided.");
        LocatorLookup locatorLookup = getLocatorLookupTable( scopedAvailabilities, allowedStreamStatus);
        applyAllLocators(channelInfos, locatorLookup, allowedStreamStatus, ownerId);
    }

    private void applyAllLocators( List<ChannelInfo> channelInfos
                                 , LocatorLookup locatorLookup
                                 , Set<String> allowedStreamStatus
                                 , Long ownerId){

        Iterator<ChannelInfo> channelInfosIterator = channelInfos.iterator();
        // Iterate through the channel map
        while (channelInfosIterator.hasNext()) {
            ChannelInfo channelInfo = channelInfosIterator.next();
            applyIpLocators( channelInfo, locatorLookup, allowedStreamStatus);
            applyOnDemandLocator(channelInfo, ownerId);
            applyQamLocator(channelInfo);
        }

    }

    /**
     * Given a LocatorLookup = (ProductContextType, StationId) -> (Stream->N CRSLocators)
     *
     * 1) Find all Streams for the ChannelInfo where (ProductContextType, StationId) match.
     * 2) Find which of the Streams takes precedence.
     * 3) Find all unique locators that match the ChannelInfo.stationId (1), Channel.pcs (N), StreamId with precedence(1)
     * 4) Convert and add all unique locators to ChannelInfo.
     * 5) If verbose mode, log all Streams->Locators that were dropped.
     *
     * @param channelInfo
     */
    private void applyIpLocators( ChannelInfo channelInfo
                                , LocatorLookup locatorLookup
                                , Set<String> allowedStreamStatus){

        long stationId = channelInfo.getStationInfo().getStationId().getId();

        // 1) Find all Streams for the ChannelInfo where (ProductContextType, StationId)
        //    and Find unique PC Types on the Channel
        Set<String> channelPcTypes = new HashSet<>();
        Set<Long> potentialStreamIds = new HashSet<>();
        for (ProductContextInfo pcInfo : channelInfo.getProductContexts()) {
            String pcInfoType = pcInfo.getType();
            Multimap<Long, CRSLocator> streamIdsToLocators = locatorLookup.getStreamIdsToLocators(pcInfoType, stationId);
            if (!streamIdsToLocators.keySet().isEmpty()) {
                // Find the Stream that takes precedence
                channelPcTypes.add(pcInfo.getType());
                potentialStreamIds.addAll(streamIdsToLocators.keys());
            }
        }

        // 1.5) Short-circuit
        if (potentialStreamIds.size()==0) return;

        // 2) Find the Stream that takes precedence
        Long highestPrecedenceStreamId = streamWithPrecedence( potentialStreamIds, allowedStreamStatus);

        // 3) Find all unique locators that match the ChannelInfo.stationId (1), Channel.pcs (N), StreamId with precedence(1) to ChannelInfo
        //    The Locator could fall under multiple PC Types and therefore we need to dedupe.
        Set<CRSLocator> crsLocators = new HashSet<>();
        for (String pcInfoType : channelPcTypes) {
            Multimap<Long, CRSLocator> streamIdsToLocators = locatorLookup.getStreamIdsToLocators(pcInfoType, stationId);

            if (!streamIdsToLocators.keySet().isEmpty() && streamIdsToLocators.containsKey(highestPrecedenceStreamId)) {
                // Now add all the locators for that streamId
                crsLocators.addAll(streamIdsToLocators.get(highestPrecedenceStreamId));
            }
        }

        // 4) Convert and add all unique locators to ChannelInfo.
        CRSStream crsStream = streamRepository.get(highestPrecedenceStreamId);
        List<LocatorInfo> locatorInfos = new ArrayList<>();
        for (CRSLocator crsLocator : crsLocators) {
                LocatorInfo locatorInfo = crsLocatorToLocatorInfoConverter.convertIpLocator( crsLocator, crsStream);
                locatorInfos.add(locatorInfo);
        }
        Collections.sort(locatorInfos);
        channelInfo.setLocators(locatorInfos);

        // ** ONLY FOR DEBUGGING ** LOG THE STREAMS AND LOCATORS NOT CHOSEN
        // This is only logging Locators that were not included because of the Prcedence Check. It will NOT include
        // Locators not returned because they didn't have the same PC Type as the channel
        if (debugHelper.isVerboseMode()) {
            Muri highestPrecedenceStreamUri = merlinIdHelper.createStreamId(highestPrecedenceStreamId);
            Set<CRSLocator> crsDroppedLocators = new HashSet<>();
            for (Long streamId : potentialStreamIds) {
                if (streamId.equals(highestPrecedenceStreamId)){
                    continue;
                }
                for (String pcInfoType : channelPcTypes) {
                    Multimap<Long, CRSLocator> streamIdsToLocators = locatorLookup.getStreamIdsToLocators(pcInfoType, stationId);
                    if (!streamIdsToLocators.keySet().isEmpty() && streamIdsToLocators.containsKey(streamId)) {
                        // Now add all the locators for that streamId that were not in the response.
                        // We needed to add this to a set in a set because it may have matched multiple PC Types
                        crsDroppedLocators.addAll(streamIdsToLocators.get(streamId));
                    }
                }
            }
            for (CRSLocator crsDroppedLocator : crsDroppedLocators) {
                Muri alternateStreamUri = merlinIdHelper.createStreamId( crsDroppedLocator.getStreamId());
                debugHelper.logResponseWarning(WarningType.StreamWarning, CauseType.MultipleStreams,
                        WarningItem.instance().setStationId(merlinIdHelper.createStationId(stationId))
                                .setStreamId(highestPrecedenceStreamUri)
                                .setAlternateId(alternateStreamUri)
                                .setAlternateLocatorId(merlinIdHelper.createLocatorId(crsDroppedLocator.getId()))
                );
            }
        }

    }

    private void applyQamLocator(ChannelInfo channelInfo){
        channelInfo.addLocator(crsLocatorToLocatorInfoConverter.getQAMLocator(channelInfo.getChannelId().getId(), channelInfo.getStationInfo().getStationId().getId()));
    }

    private void applyOnDemandLocator(ChannelInfo channelInfo, Long ownerId){
        channelInfo.addLocator(crsLocatorToLocatorInfoConverter.getOnDemandLocator(channelInfo.getStationInfo().getStationId().getId(), ownerId));
    }


    /**
     *  Using the availabilities create a CRSLocator lookup based on Locator CAs
     *
     *  This will include all available Streams for the provided Stream Scope
     *
     */
    private LocatorLookup getLocatorLookupTable( ScopedAvailabilities scopedAvailabilities, Set<String> allowedStreamStatus) {
        LocatorLookup locatorLookup = new LocatorLookup();
        List<Availabilities> streamAvailabilities = scopedAvailabilities.getStreamAvailabilities();

        for (Availabilities availabilities : streamAvailabilities) {
            URI productContextUri = availabilities.getProductContext();
            if (productContextUri == null) {
                // PC Required on Stream Scope
                logger.debug("Stream scope requires a productContext.");
                continue;
            }

            Long productContextId = Muri.getObjectId(productContextUri);
            CRSProductContext crsProductContext = productContextRepository.get(productContextId);
            if (crsProductContext==null) {
                logger.warn("Stream scope in ARS blob referenced a ProductContext not in the repo.  ProductContext={}", productContextId);
                continue;
            }
            String productContextType = crsProductContext.getType();

            // Identify Station/Streams
            List<Long> availabilityIds = new ArrayList<>(getObjectIds(availabilities.getAvailabilityIds()));
            Set<Long> locatorIds = retrieveAvailabilityIdToLocators( availabilityIds, productContextId);
            Collection<CRSLocator> locators = locatorRepository.getByIds(locatorIds);

            for (CRSLocator locator : locators) {
                CRSStream crsStream = streamRepository.get(locator.getStreamId());
                if (crsStream == null) {
                    logger.debug("Locator referenced Stream not in repo. LocatorId={} StreamId={}", locator.getId(), locator.getStreamId());
                    continue;
                } else if (!allowedStreamStatus.contains(crsStream.getStatus()) ) {
                    // Filtered by stream status
                    continue;
                }

                locatorLookup.put( productContextType, crsStream.getStationId(), locator);
            }
        }
        return locatorLookup;
    }

    Long streamWithPrecedence( Set<Long> streamIds, Set<String> allowedStreamStatus) {
        if (allowedStreamStatus.size()>1) {
            // Multiple statuses, use the more complicated precedence calculation
            return streamRepository.getByIds(streamIds).stream().min(STREAM_PRECEDENCE_COMPARATOR).get().getId();
        } else {
            // Most of the time we will only have Production OR Staging, Not both. This is faster.
            return streamIds.stream().min(Long::compareTo).get();
        }
    }

    public static final class StreamPrecedenceComparator implements Comparator<CRSStream> {
        @Override
        public int compare(CRSStream stream1, CRSStream stream2) {
            if (stream1.isProduction() && !stream2.isProduction()) {
                return -1;
            } else if (stream2.isProduction() && !stream1.isProduction()) {
                return 1;
            } else if (DedupeUtil.firstTakesPrecedence(stream1.getId(), stream2.getId())) {
                return -1;
            } else {
                return 1;
            }
        }
    }

    /**
     * Used to track:
     *  (ProductContextType, StationId) -> (Stream->N CRSLocators)
     *
     */
    private static class LocatorLookup {
        // (ProductContextType, StationId) -> (Stream->N CRSLocators)
        protected Map<CompositeKey< String, Long>, HashMultimap<Long,CRSLocator>> lookup;
        private static final HashMultimap EMPTY_HASHMULTIMAP = HashMultimap.create() ;

        private LocatorLookup() {
            lookup = new HashMap<>();
        }

        public void put(String productContextType, Long stationId, CRSLocator crsLocator) {
            CompositeKey compositeKey = new CompositeKey(productContextType, stationId);
            if (!lookup.containsKey(compositeKey)) {
                lookup.put(compositeKey, HashMultimap.create());
            }
            lookup.get( compositeKey).put(crsLocator.getStreamId(), crsLocator);
        }

        public Multimap<Long,CRSLocator> getStreamIdsToLocators(String productContextType, Long stationId) {
            if (productContextType==null || stationId == null) return EMPTY_HASHMULTIMAP;
            return lookup.getOrDefault(new CompositeKey(productContextType, stationId), EMPTY_HASHMULTIMAP);
        }

        public boolean contains(String productContextType, Long stationId) {
            if (productContextType==null || stationId == null) return false;
            return lookup.containsKey(new CompositeKey(productContextType, stationId));
        }

        private final class CompositeKey<K1, K2>{
            private K1 value1;
            private K2 value2;
            public CompositeKey(K1 value1, K2 value2){
                this.value1 = value1;
                this.value2 = value2;
            }

            @Override
            public boolean equals(Object other){
                if (!(other instanceof CompositeKey)) return false;
                CompositeKey otherCK = (CompositeKey) other;
                if (!otherCK.value1.equals(value1)) return false;
                if (!otherCK.value2.equals(value2)) return false;
                return true;
            }

            @Override
            public int hashCode(){
                return value1.hashCode() + 31 * value2.hashCode();
            }
        }
    }


    /**
     * Look up locators based on AvailabilityId and PC.
     *
     */
    private Set<Long> retrieveAvailabilityIdToLocators(List<Long> availabilityIds, Long streamScopeProductContextId) {
        Set<Long> locatorIds = new HashSet<>();
        Collection<CRSContentAvailability> contentAvailabilities = this.contentAvailabilityRepository.getLocatorsByAvailabilityIds(availabilityIds);
        for (CRSContentAvailability crsContentAvailability : contentAvailabilities) {
            // Filter by PC
            if (crsContentAvailability.getProductContextIds().contains(streamScopeProductContextId)){
                locatorIds.add(crsContentAvailability.getContentId());
            }
        }
        return locatorIds;
    }

    @Required
    public void setProductContextRepository(ProductContextRepository productContextRepository) {
        this.productContextRepository = productContextRepository;
    }

    @Required
    public void setContentAvailabilityRepository(ContentAvailabilityRepository contentAvailabilityRepository) {
        this.contentAvailabilityRepository = contentAvailabilityRepository;
    }

    @Required
    public void setLocatorRepository(LocatorRepository locatorRepository) {
        this.locatorRepository = locatorRepository;
    }
    @Required
    public void setStreamRepository(StreamRepository streamRepository) {
        this.streamRepository = streamRepository;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }

    @Required
    public void setDebugHelper(DebugHelper debugHelper) {
        this.debugHelper = debugHelper;
    }

    @Required
    public void setCrsLocatorToLocatorInfoConverter(CRSLocatorToLocatorInfoConverter crsLocatorToLocatorInfoConverter) {
        this.crsLocatorToLocatorInfoConverter = crsLocatorToLocatorInfoConverter;
    }

}
