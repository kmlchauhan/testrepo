package com.theplatform.web.tv.gws.service.common.logic.stream;

import com.comcast.compass.availability.common.domain.Availabilities;
import com.google.common.collect.HashBasedTable;
import com.theplatform.data.tv.offer.api.data.objects.ProductContextType;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.debug.CauseType;
import com.theplatform.web.tv.contentresolution.api.debug.WarningItem;
import com.theplatform.web.tv.contentresolution.api.debug.WarningType;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.LocatorInfo;
import com.theplatform.web.tv.contentresolution.api.objects.ProductContextInfo;
import com.theplatform.web.tv.gws.service.common.logic.*;
import com.theplatform.web.tv.gws.sirius.model.CRSContentAvailability;
import com.theplatform.web.tv.gws.sirius.model.CRSProductContext;
import com.theplatform.web.tv.gws.sirius.model.CRSStream;
import com.theplatform.web.tv.gws.sirius.repository.ContentAvailabilityRepository;
import com.theplatform.web.tv.gws.sirius.repository.MerlinDAO;
import com.theplatform.web.tv.gws.sirius.repository.ProductContextRepository;
import com.theplatform.web.tv.gws.sirius.repository.StreamRepository;
import com.theplatform.web.tv.gws.service.common.converter.CRSLocatorToLocatorInfoConverter;
import com.theplatform.web.tv.gws.service.common.debug.DebugHelper;
import com.theplatform.web.tv.gws.service.common.util.DedupeUtil;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.net.URI;
import java.util.*;

import static com.theplatform.contrib.data.api.objects.Muri.getObjectIds;
import static java.lang.System.currentTimeMillis;

/**
 *   Stream CA Based Locator/Stream Logic.
 *   Deprecated CMPWM-2123
 *
 *   1) Find the IP Stream If Any
 *   2) Create all IP Loctors for the Stream (Again, if any)
 *   3) If QAM PC Create QAM
 *
 */
@Deprecated
public class StreamLocatorLogic {
    private static Logger logger = LoggerFactory.getLogger(StreamLocatorLogic.class);

    private DebugHelper debugHelper;

    private CRSLocatorToLocatorInfoConverter crsLocatorToLocatorInfoConverter;
    private ProductContextRepository productContextRepository;
    private ContentAvailabilityRepository contentAvailabilityRepository;
    private StreamRepository streamRepository;
    private MerlinIdHelper merlinIdHelper;
    private MerlinDAO merlinDAO;

    /**
     *
     * @param scopedAvailabilities
     * @param channelInfos
     * @param allowedStreamStatus
     * @param ownerId  Callers ownerId.  This can be null if includeNonIpLocators is false
     * @param includeNonIpLocators Should non-IP Locators (onDemand,QAM) be included on Stream
     */
    public void modify( ScopedAvailabilities scopedAvailabilities,
                        List<ChannelInfo> channelInfos,
                        Set<String> allowedStreamStatus,
                        Long ownerId,
                        boolean includeNonIpLocators) {
        if (ownerId==null && !includeNonIpLocators) throw new RuntimeException("If includeNonIpLocators is true then an the callers ownerId must be passed in.");
        HashBasedTable<String,Long,CRSStream> prodTypeSpecificStreamLookup = HashBasedTable.create();
        Long2ObjectMap<CRSStream> defaultStreamLookup = new Long2ObjectOpenHashMap<>();
        getStreamLookupTable( prodTypeSpecificStreamLookup, defaultStreamLookup, scopedAvailabilities, allowedStreamStatus, ownerId);
        applyAllLocators(channelInfos, prodTypeSpecificStreamLookup, defaultStreamLookup, ownerId, includeNonIpLocators);
    }


    private void applyAllLocators( List<ChannelInfo> channelInfos
                                 , HashBasedTable<String,Long,CRSStream> prodTypeSpecificStreamLookup
                                 , Long2ObjectMap<CRSStream> defaultStreamLookup
                                 , Long ownerId
                                 , boolean includeNonIpLocators){

        Iterator<ChannelInfo> channelInfosIterator = channelInfos.iterator();
        MerlinIdHelper requestIdHelper = merlinIdHelper.forSingleThreadedUse();
        // Iterate through the channel map
        while (channelInfosIterator.hasNext()){
            ChannelInfo channelInfo = channelInfosIterator.next();

            CRSStream crsStream = getStream(channelInfo, prodTypeSpecificStreamLookup, defaultStreamLookup);
            applyIpLocators( channelInfo, crsStream);
            if (includeNonIpLocators){
                applyOnDemandLocator(channelInfo, ownerId);
                applyQamLocator(channelInfo);
            }

            // BACKWARDS COMPATABILITY SUPPORT (pre-1.21)
            // This is a reference to the identiefied Stream for backwards compatability (pre-1.21)
            // This is used NOT used by schema 1.21 or greater but ONLY USED FOR backwards compatability.
            // We need this for channels that do not have IP Locators (i.e. QAM/OnDemand Locators or simply no
            // locators).  In that case, the backwardsCompatibilityStreamId will allow us to create the Stream without
            // having to look it up again,
            if (crsStream!=null){
                channelInfo.setBackwardsCompatibilityStreamId(crsStream.getId());
            }

        }

    }

    private CRSStream getStream(ChannelInfo channelInfo,
                                HashBasedTable<String,Long,CRSStream> prodTypeSpecificStreamLookup,
                                Long2ObjectMap<CRSStream> defaultStreamLookup){
        // 1) The Stream
        long stationId = channelInfo.getStationInfo().getStationId().getId();

        CRSStream crsStream = null;
        for (ProductContextInfo pcInfo : channelInfo.getProductContexts()){
            String pcInfoType = pcInfo.getType();
            if ( pcInfoType!=null && prodTypeSpecificStreamLookup.contains( pcInfoType, stationId)){
                if (crsStream!=null){
                    CRSStream other = prodTypeSpecificStreamLookup.get( pcInfoType, stationId);
                    logger.debug("ChannelMatchedMultipleStreams ChannelId=" + channelInfo.getChannelId() + " ProductContextType=" + pcInfoType + " Stream1=" + crsStream.getId() + " Stream2=" + other.getId());
                    if (DedupeUtil.firstTakesPrecedence(other.getId(), crsStream.getId())){
                        crsStream = other;
                    }
                }else{
                    crsStream = prodTypeSpecificStreamLookup.get( pcInfoType, stationId);
                }
            }
        }

        // If none of the PC.Type/StationId Match then use any Stream Scope without productcontext                                                       :
        if (crsStream == null){
            crsStream = defaultStreamLookup.get(stationId);
        }
        if (crsStream==null) return null;

        return crsStream;
    }

    /**
     * Apply IP Locators Based on Stream
     * 1) Find all CRSLocators for the CRSStream
     * 2) Generate LocatorInfos based on the CRSLocators and Single CRSStream
     * 3) Add to ChannelInfo
     *
     * @param channelInfo
     * @param crsStream
     */
    private void applyIpLocators( ChannelInfo channelInfo,
                                  CRSStream crsStream){
        if (crsStream==null) return;
        // 1) Find the Locator
        // 2) Create LocatorInfos
        List<LocatorInfo> locatorInfos = crsLocatorToLocatorInfoConverter.getIpLocators( crsStream);

        // 3) Add to Channel
        channelInfo.addLocators(locatorInfos);
    }

    private void applyQamLocator(ChannelInfo channelInfo){
        channelInfo.addLocator(crsLocatorToLocatorInfoConverter.getQAMLocator(channelInfo.getChannelId().getId(), channelInfo.getStationInfo().getStationId().getId()));
    }

    private void applyOnDemandLocator(ChannelInfo channelInfo, Long ownerId){
        channelInfo.addLocator(crsLocatorToLocatorInfoConverter.getOnDemandLocator(channelInfo.getStationInfo().getStationId().getId(), ownerId));
    }


    /**
     *  Using the availabilities create a CRSStreams lookup
     *
     *  This method populates
     *  1) Table( (PC.Type & Station.id) -> CRSStream )
     *  2) Map( Station.id -> CRSStream )
     *  When looking up a station's stream the first takes precedence and the second is only used if
     *  there is no match.
     */
    private void getStreamLookupTable( HashBasedTable<String,Long,CRSStream> prodTypeSpecificStreamLookup
                                     , Long2ObjectMap<CRSStream> defaultStreamLookup
                                     , ScopedAvailabilities scopedAvailabilities
                                     , Set<String> streamStatus
                                     , Long ownerId) {
        List<Availabilities> streamAvailabilities = scopedAvailabilities.getStreamAvailabilities();

        long streamLookupStartTime = currentTimeMillis();
        for (Availabilities availabilities : streamAvailabilities) {
            // Identify PC.Type
            URI productContextUri = availabilities.getProductContext();
            String productContextType = null;
            Long productContectId = null;
            if (productContextUri!=null) {
                productContectId = Muri.getObjectId(productContextUri);
                CRSProductContext crsProductContext = productContextRepository.get(productContectId);
                if (crsProductContext!=null) productContextType = crsProductContext.getType();
            }

            // Identify Station/Streams
            List<Long> availabilityIds = new ArrayList<>(getObjectIds(availabilities.getAvailabilityIds()));
            Set<Long> streamIds = retrieveAvailabilityIdToStream( availabilityIds, productContectId, productContextType, ownerId);


            List<CRSStream> streams = merlinDAO.retrieveStreams(new ArrayList<>(streamIds), streamStatus);

            for (CRSStream stream : streams) {
                long stationId = stream.getStationId();
                if (productContextType==null){
                    // Default No ProductContext or ProductContext.Type
                    if (defaultStreamLookup.containsKey(stationId)) {
                        // Multiple matching Streams
                        CRSStream other = defaultStreamLookup.get(stationId);
                        StreamResolution streamResolution = new StreamResolution(stream, other);
                        defaultStreamLookup.put(stationId, streamResolution.getPrecedentStream());

                        debugHelper.logResponseWarning(WarningType.StreamWarning, CauseType.MultipleStreams,
                                WarningItem.instance().setStationId(merlinIdHelper.createStationId(stationId))
                                                                                  .setStreamId(streamResolution.getPrecedentStreamId())
                                                                                  .setAlternateId(streamResolution.getDroppedStreamId())
                        );
                    } else {
                        defaultStreamLookup.put(stationId, stream);
                    }
                } else {
                    if (prodTypeSpecificStreamLookup.contains(productContextType, stationId)) {
                        // Multiple matching Streams
                        CRSStream other = prodTypeSpecificStreamLookup.get(productContextType, stationId);
                        StreamResolution streamResolution = new StreamResolution(stream, other);
                        prodTypeSpecificStreamLookup.put(productContextType, stationId, streamResolution.getPrecedentStream());

                        debugHelper.logResponseWarning(WarningType.StreamWarning, CauseType.MultipleStreams,
                                WarningItem.instance().setStationId(merlinIdHelper.createStationId(stationId))
                                        .setStreamId(streamResolution.getPrecedentStreamId())
                                        .setAlternateId(streamResolution.getDroppedStreamId())
                        );
                    } else {
                        prodTypeSpecificStreamLookup.put(productContextType, stationId, stream);
                    }
                }
            }
        }
    }

    class StreamResolution {
        private CRSStream precedentStream;
        private CRSStream droppedStream;

        StreamResolution(CRSStream stream1, CRSStream stream2) {
            if (stream1.isProduction() && !stream2.isProduction()) {
                precedentStream = stream1;
                droppedStream = stream2;
            } else if (stream2.isProduction() && !stream1.isProduction()) {
                precedentStream = stream2;
                droppedStream = stream1;
            } else if (DedupeUtil.firstTakesPrecedence(stream1.getId(), stream2.getId())) {
                precedentStream = stream1;
                droppedStream = stream2;
            } else {
                precedentStream = stream2;
                droppedStream = stream1;
            }
        }

        CRSStream getPrecedentStream() {
            return precedentStream;
        }

        Muri getPrecedentStreamId() {
            return merlinIdHelper.createStreamId(precedentStream.getId());
        }

        Muri getDroppedStreamId() {
            return merlinIdHelper.createStreamId(droppedStream.getId());
        }
    }

    /**
     * Look up streams.
     *
     * For non-partners(i,e. Comcast) if productContextId is not null AND productContextType is not Type (TitleVI, CTV, CDVR) then filter
     * out any CA that do not have the provided productContextId (The ID NOT the Type).
     *
     */
    private Set<Long> retrieveAvailabilityIdToStream(List<Long> availabilityIds, Long streamScopeProductContextId, String productContextType, Long ownerId) {
        Set<Long> streamIds = new HashSet<Long>();
        Collection<CRSContentAvailability> contentAvailabilities = this.contentAvailabilityRepository.getStreamsByAvailabilityIds(availabilityIds);
        for (CRSContentAvailability crsContentAvailability : contentAvailabilities) {
            if (filterByPc(crsContentAvailability, streamScopeProductContextId)){
                // Filter by PC
                if (crsContentAvailability.getProductContextIds().contains(streamScopeProductContextId)){
                    streamIds.add(crsContentAvailability.getContentId());
                }
            }else{
                // DO not filter
                streamIds.add(crsContentAvailability.getContentId());
            }

        }
        return streamIds;
    }

    /**
     * If the Stream Scope request does not contain a PC then do not filter.
     * Purpose: Backwards compatibility
     *
     * If the Stream Scope request contains any PC of type that are (TitleVI, CDVR, CTV)
     * AND the CA PC is empty then no filter.
     * Purpose: To give us time to populate the Stream CAs with PCs
     *
     * @param crsContentAvailability
     * @return
     */
    private boolean filterByPc(CRSContentAvailability crsContentAvailability, Long streamScopeProductContextId){
        if (streamScopeProductContextId ==null) return false;
        if (crsContentAvailability.getProductContextIds().size()>0) return true;

        // CA has no PCs.  Check the Stream Scope's PC
        CRSProductContext crsProductContext = productContextRepository.get(streamScopeProductContextId);
        if (crsProductContext==null) return true;
        if (crsProductContext.getType().equals(ProductContextType.CDVR.name())
            || crsProductContext.getType().equals(ProductContextType.CTV.name())
            || crsProductContext.getType().equals(ProductContextType.TitleVI.name())){
            return false;
        }else{
            return true;
        }
    }

    @Required
    public void setProductContextRepository(ProductContextRepository productContextRepository) {
        this.productContextRepository = productContextRepository;
    }

    @Required
    public void setContentAvailabilityRepository(ContentAvailabilityRepository contentAvailabilityRepository) {
        this.contentAvailabilityRepository = contentAvailabilityRepository;
    }

    @Required
    public void setMerlinIdHelper(MerlinIdHelper merlinIdHelper) {
        this.merlinIdHelper = merlinIdHelper;
    }

    @Required
    public void setMerlinDAO(MerlinDAO merlinDAO) {
        this.merlinDAO = merlinDAO;
    }

    @Required
    public void setDebugHelper(DebugHelper debugHelper) {
        this.debugHelper = debugHelper;
    }

    @Required
    public void setCrsLocatorToLocatorInfoConverter(CRSLocatorToLocatorInfoConverter crsLocatorToLocatorInfoConverter) {
        this.crsLocatorToLocatorInfoConverter = crsLocatorToLocatorInfoConverter;
    }

    @Required
    public void setStreamRepository(StreamRepository streamRepository) {
        this.streamRepository = streamRepository;
    }
}
