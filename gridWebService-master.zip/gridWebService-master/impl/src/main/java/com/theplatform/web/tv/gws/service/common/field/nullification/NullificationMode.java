package com.theplatform.web.tv.gws.service.common.field.nullification;

/**
 * Inclusive/exclusive property selection mode.
 */
public enum NullificationMode {
    /**
     * Nullify the selected properties.  Other properties will not be modified.
     */
    NULLIFY_SELECTED_PROPERTIES,

    /**
     * Nullify all of the properties that are NOT selected.  In other words, only the properties specified (and
     * their parent properties) will be non-null.
     */
    PRESERVE_SELECTED_PROPERTIES;
}
