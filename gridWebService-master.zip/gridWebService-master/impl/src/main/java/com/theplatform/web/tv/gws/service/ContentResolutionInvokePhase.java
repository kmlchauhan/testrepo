package com.theplatform.web.tv.gws.service;

import com.github.zafarkhaja.semver.Version;
import com.google.common.collect.ImmutableMap;
import com.theplatform.module.exception.BadParameterException;
import com.theplatform.module.pipeline.NextPhaseTrigger;
import com.theplatform.web.pipeline.phase.InvokePhase;
import com.theplatform.web.pipeline.phase.WebServicePhaseContext;
import com.theplatform.web.tv.gws.service.common.util.DynamicProperties;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import javax.servlet.http.HttpServletResponse;
import java.util.Collection;
import java.util.Map;

import static java.lang.Integer.parseInt;

/**
 * @author jcoelho
 */
public class ContentResolutionInvokePhase extends InvokePhase {
    private static Logger logger = LoggerFactory.getLogger(ContentResolutionInvokePhase.class);

    public static final String CACHE_CONTROL_HEADER = "Cache-Control";
    public static final String CACHE_CONTROL_VALUE_PREFIX = "max-age=";
    public static final long CACHE_CONTROL_MIN_VALUE = 300;
    public static final String VARY_HEADER_KEY = "Vary";
    public static final String VARY_VALUE = "Accept-Encoding";
    
    public static final String DATE = "Date";
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormat.forPattern("E, dd MMM yyyy HH:mm:ss 'GMT'");

    private DynamicProperties dynamicProperties;

    private Map<String,  String> requiredClientIdVersion;   // What version is a client Id required
    // Mapping to look up the minimum schema version for each service
    private static final Map<String, String> SERVICE_NAME_TO_CONFIG_NAME = ImmutableMap.of(
            "contentResolution", "gridWebService.frontend.schema.minimum"
    );

    @Override
    public void doExecute(WebServicePhaseContext<?> context, NextPhaseTrigger<WebServicePhaseContext<?>> nextPhaseTrigger)
            throws Exception {

        HttpServletResponse httpResponse = context.getWebServiceResponse().getHttpResponse();

        DateTime now = new DateTime(DateTimeZone.UTC);

        httpResponse.setHeader(DATE,now.toString(DATE_TIME_FORMATTER));
        httpResponse.setHeader(VARY_HEADER_KEY, VARY_VALUE);

        // Cache-Control
        String operation = context.getOperation();
        if (operation!=null){
            String cacheSetting = getCacheControlHeader( operation);
            if (cacheSetting!=null){    // Some may be null if handled as special cases (e.g. trending)
                httpResponse.setHeader(CACHE_CONTROL_HEADER, cacheSetting);
            }
        }

        validateMinimumSchemaVersion(context);
        validateRequestContainsClientId(context);
        super.doExecute(context, nextPhaseTrigger);
    }

    // Unsupport versions under a certain schema
    public void validateMinimumSchemaVersion(WebServicePhaseContext<?> webServiceContext) {
        String requestedSchema = webServiceContext.getWebServiceRequest().getParameter("schema");
        if (requestedSchema == null){
            throw new BadParameterException("schema parameter is missing");
        }

        String configName = SERVICE_NAME_TO_CONFIG_NAME.get(webServiceContext.getWebServiceRequest().getServiceName());
        if (configName!=null){
            String minimumSchema = dynamicProperties.get(configName);
            boolean success = true;
            try {
                success = isVersionGreaterThanOrEqualRequiredSchema( requestedSchema, minimumSchema);
            }catch (Exception exc){
                logger.info( "Problem checking version number. requestedSchema: {}; minimumSchema: {}", requestedSchema, minimumSchema, exc);
            }
           if (!success) {
                throw new BadParameterException("Requested Schema is no longer supported");
           }
        } else {
            logger.info( "Could not find version configuration for " + webServiceContext.getWebServiceRequest().getServiceName());
        }


    }

    // Versions >= than some point must have a clientId
    public void validateRequestContainsClientId(WebServicePhaseContext<?> webServiceContext) {
        String clientId = webServiceContext.getWebServiceRequest().getParameter("clientId");
        if (isVersionGreaterThanOrEqual1dot10( webServiceContext, requiredClientIdVersion))
            if (StringUtils.isEmpty(clientId))
                throw new BadParameterException("The request is missing a client id");
    }

    /**
     *
     * @param requiredVersionMap Service->Required Schema Version.
     * @return
     */
    private boolean isVersionGreaterThanOrEqual1dot10(WebServicePhaseContext<?> webServiceContext, Map<String,String> requiredVersionMap) {
        String reqSchema = webServiceContext.getWebServiceRequest().getParameter("schema");
        if (reqSchema == null)
            throw new BadParameterException("schema parameter is missing");

        return isVersionGreaterThanOrEqualRequiredSchema(reqSchema, webServiceContext.getWebServiceRequest().getServiceName(), requiredVersionMap);
    }

    /**
     *
     * @param requestedSchema    Requested Schema.
     * @param serviceName        Service request is originating from.
     * @param requiredVersionMap Service->Required Schema Version.
     * @return
     */
    public static boolean isVersionGreaterThanOrEqualRequiredSchema(String requestedSchema, String serviceName, Map<String,String> requiredVersionMap) {
        return isVersionGreaterThanOrEqualRequiredSchema( requestedSchema, requiredVersionMap.get(serviceName));
    }
    public static boolean isVersionGreaterThanOrEqualRequiredSchema(String requestedSchema, String minimumSchema) {
        String[] schema = requestedSchema.split("\\.");
        if(schema.length != 2)
            throw new RuntimeException("Invalid schema version");
        Version requestedVersion = Version.forIntegers(parseInt(schema[0]), parseInt(schema[1]));

        String[] requiredSchema = minimumSchema.split("\\.");
        Version requiredVersion = Version.forIntegers(parseInt(requiredSchema[0]), parseInt(requiredSchema[1]));

        if (requestedVersion.greaterThan(requiredVersion) || requestedVersion.equals(requiredVersion))
            return true;

        return false;
    }

    private String getCacheControlHeader( String operation){
        String cacheSetting = dynamicProperties.get("cacheControl." + operation);
        if (cacheSetting !=null && StringUtils.isNumeric(cacheSetting)){
            if ( Long.parseLong(cacheSetting) < CACHE_CONTROL_MIN_VALUE ){
                cacheSetting = CACHE_CONTROL_VALUE_PREFIX + CACHE_CONTROL_MIN_VALUE;
            } else {
                cacheSetting = CACHE_CONTROL_VALUE_PREFIX + cacheSetting;
            }
            return cacheSetting;
        } else {
            return null;
        }
    }

    @Required
    public void setDynamicProperties(DynamicProperties dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }

    @Required
    public void setRequiredClientIdVersion(Map<String, String> requiredClientIdVersion) {
        validateSchemaVersions( requiredClientIdVersion.values(), "requiredClientIdVersion version is not valid:");
        this.requiredClientIdVersion = requiredClientIdVersion;
    }

    private boolean validateSchemaVersions(Collection<String> schemaVersion, String errorMessage){
        for (String version : schemaVersion){
            String tokens[] = version.split("\\.");
            if (tokens.length!=2) throw new RuntimeException(errorMessage + " " + version);
            try{
                Integer.parseInt(tokens[0]);
                Integer.parseInt(tokens[1]);
            }catch (NumberFormatException exc){
                throw new RuntimeException(errorMessage + " " + version);
            }
        }
        return true;
    }



}
