package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.RecorderManagerProto;
import com.theplatform.web.tv.gws.sirius.model.CRSRecorderManager;

/**
 * Created by pdwinnell on 5/3/17.
 */
public class RecorderManagerSerializer extends AbstractSiriusObjectSerializer<CRSRecorderManager> {

    public RecorderManagerSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }


    @Override
    public CRSRecorderManager unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        RecorderManagerProto.RecorderManagerMessage.Builder message =
                RecorderManagerProto.RecorderManagerMessage.newBuilder().mergeFrom(bytes);
        CRSRecorderManager recorderManager = new CRSRecorderManager(message.getId());
        if (message.hasNativeId()){
            recorderManager.setNativeId(message.getNativeId());
        }
        if (message.hasRegionId()){
            recorderManager.setRegionId(message.getRegionId());
        }
        if (message.hasType()){
            recorderManager.setType(message.getType());
        }

        return recorderManager;
    }

    @Override
    public ByteString marshallPayload(CRSRecorderManager crsRecorderManager) {

        RecorderManagerProto.RecorderManagerMessage.Builder builder =
                RecorderManagerProto.RecorderManagerMessage.newBuilder();
        builder.setId( crsRecorderManager.getId());
        builder.setType( crsRecorderManager.getType());
        if (crsRecorderManager.getNativeId() != null){
            builder.setNativeId(crsRecorderManager.getNativeId());
        }
        if (crsRecorderManager.getRegionId() != null){
            builder.setRegionId(crsRecorderManager.getRegionId());
        }

        return builder.build().toByteString();
    }


}
