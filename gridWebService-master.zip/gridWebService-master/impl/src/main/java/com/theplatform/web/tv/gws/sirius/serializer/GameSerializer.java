package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.common.primitives.Longs;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.GameProto.GameMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSGame;

public class GameSerializer extends AbstractSiriusObjectSerializer<CRSGame> {

    public GameSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSGame unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        GameMessage.Builder message = GameMessage.newBuilder().mergeFrom(bytes);
        return new CRSGame(message.getId(), message.getListingIdsList(), message.getLiveCoverageAvailable() );
    }

    @Override
    public ByteString marshallPayload( CRSGame game) {
        GameMessage.Builder payload = GameMessage.newBuilder();

        payload.setId(game.getId());
        payload.addAllListingIds(Longs.asList(game.getListingIds()));
        payload.setLiveCoverageAvailable(game.isLiveCoverageAvailable());
        return payload.build().toByteString();
    }
}
