/**
 * Implementation project for Grid Web Service.
 * <br></br>
 * There are three primary components of Grid Web Service:
 * <ol>
 *     <li>The ingest components that receives data from external sources (data service notifications, polling external service providers) and
 *         communicate the data between Grid Web Service nodes.</li>
 *     <li>{@link com.theplatform.web.tv.gws.sirius.repository.Repository Repositories} which store the objects received from the ingest components.</li>
 *     <li>Externally exposed services that apply {@link com.theplatform.web.tv.gws.service.common.logic business logic} to the objects stored in the repositories.</li>
 * </ol>
 * <pre>
 *                                                                                                                     
 *                +-------------------------------------------------------+                                            
 *                |                     Data Services                     |                                            
 *                +-------------------------------------------------------+                                            
 *                                          |                                                                          
 *                                          |                                                                          
 *                                          |                                                                          
 *           +--Grid Web Service------------+--------------------------------+                                         
 *           |                              v                                |                                         
 *           |    +-------------------------------------------------------+  |                                         
 *           |    |                   EventProducers                      |  |                                         
 *           |    +-------------------------------------------------------+  |                                         
 *           |                               |                               |                                         
 *           |                               |                               |                                         
 *           |                               v                               |                                         
 *           |    +-------------------------------------------------------+  |                                         
 *           |    |                   EventDispatcher                     |  |                                         
 *           |    +-------------------------------------------------------+  |                                         
 *           |           |         ^                 |          ^            |                                         
 *           |           |         |                 |          |            |                                         
 *           |           |         |                 |          |            |                                         
 *           |           |         |                 v          |            |                                         
 *           |    +------------------------+   +--------------------------+  |             +-------------+             
 *           |    |     EventConsumers     |   |          Sirius          |--------------->|   Network   |             
 *           |    +------------------------+   +--------------------------+  |             +-------------+             
 *           |                |                                              |                                         
 *           |                |                                              |                                         
 *           |                v                                              |                                         
 *           |    +------------------------------------------------------+   |                                         
 *           |    |                    Repositories                      |   |                                         
 *           |    +------------------------------------------------------+   |                                         
 *           |                |                             |                |                                         
 *           |                |                             |                |                                         
 *           |                v                             v                |                                         
 *           |    +------------------------------------------------------+   |                                         
 *           |    |               ContentResolutionService               |   |                                      
 *           |    +------------------------------------------------------+   |                                         
 *           |                ^                             ^                |                                         
 *           +----------------+-----------------------------+----------------+                                         
 *                            |                             |                                                          
 *                            |                             |                                                          
 *                            |                             |                                                          
 *                +------------------------------------------------------+                                             
 *                |                      Clients                         |                                             
 *                +------------------------------------------------------+                                             
 *                              
 * </pre>
 */
package com.theplatform.web.tv.gws;