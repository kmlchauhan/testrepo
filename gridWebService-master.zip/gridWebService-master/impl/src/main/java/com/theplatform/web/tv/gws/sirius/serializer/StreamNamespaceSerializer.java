package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.StreamNamespaceProto.StreamNamespaceMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSStreamNamespace;

/**
 * @author Segun Abimbola (oabimb200)
 * 2/05/18
 */
public class StreamNamespaceSerializer extends AbstractSiriusObjectSerializer<CRSStreamNamespace> {

    public StreamNamespaceSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSStreamNamespace unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        StreamNamespaceMessage.Builder message = StreamNamespaceMessage.newBuilder().mergeFrom(bytes);
        CRSStreamNamespace crsObject = new CRSStreamNamespace(message.getId());

        if (message.hasTitle()){
            crsObject.setTitle(message.getTitle());
        }
        return crsObject;
    }

    @Override
    public ByteString marshallPayload( CRSStreamNamespace object) {
        StreamNamespaceMessage.Builder builder = StreamNamespaceMessage.newBuilder();
        builder.setId(object.getId());

        if (object.getTitle() != null){
            builder.setTitle(object.getTitle());
        }

        return builder.build().toByteString();
    }


}
