package com.theplatform.web.tv.gws.uri;

import com.theplatform.contrib.data.api.objects.*;

/**
 * This class handles generating AccountIds.  There is no CURN equivalent for this ID like the other IDs we return.
 * Unfortunately this doesn't fit in well with generating Ids like the other endpoints in {@link MerlinIdHelper}.
 * I wanted to avoid shoehorning this logic into that class hence the separate code.
 *
 */
public class AccountIdHelper {
    protected final String accountIdBaseUrl;

    public AccountIdHelper(String defaultOwnerId) {
        this.accountIdBaseUrl = defaultOwnerId.substring( 0 , defaultOwnerId.lastIndexOf("/") + 1);
    }


    public Muri createId(long id) {
        StringBuilder builder = new StringBuilder( 75);
        builder.append(accountIdBaseUrl).append(id);
        return new Muri( builder.toString(), id);
    }

}
