/**
 * Services that are exposed to external clients.  There are two services:
 * <ul>
 *     <li>{@link com.theplatform.web.tv.contentresolution.api.ContentResolutionService ContentResolutionService} (the primary service)
 *          which resolves channels, listings, and stations based on availability ids, product contexts, and merge policies.  The
 *          majority of clients use ContentResolutionService.
 *     </li>
 * </ul>
 */
package com.theplatform.web.tv.gws.service;