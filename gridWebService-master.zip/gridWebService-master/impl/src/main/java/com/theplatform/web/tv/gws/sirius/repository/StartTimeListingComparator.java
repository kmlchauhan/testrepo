package com.theplatform.web.tv.gws.sirius.repository;

import com.theplatform.web.tv.gws.sirius.model.CRSListing;

import java.util.Comparator;

public class StartTimeListingComparator implements Comparator<CRSListing> {

    @Override
    public int compare(CRSListing aListing, CRSListing anotherListing) {
        long aListingStartTime = aListing.getStartTime();
        long anotherListingStartTime = anotherListing.getStartTime();
        if(aListing.getId() == anotherListing.getId()) return 0;
        return aListingStartTime < anotherListingStartTime ? -1 :  1;
    }

}
