package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.data.tv.linear.api.data.objects.LinearCollection;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.LinearCollectionProto.LinearCollectionMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSLinearCollection;
import org.apache.commons.lang.ArrayUtils;

import java.util.Arrays;

public class LinearCollectionSerializer extends AbstractSiriusObjectSerializer<CRSLinearCollection> {

    public LinearCollectionSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSLinearCollection unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        LinearCollectionMessage.Builder message = LinearCollectionMessage.newBuilder().mergeFrom(bytes);
        CRSLinearCollection linearCollection = new CRSLinearCollection(message.getId());

        linearCollection.setSdStationIds(ArrayUtils.toPrimitive(message.getSdStationIdsList().toArray(new Long[0])));
        linearCollection.setHdStationIds(ArrayUtils.toPrimitive(message.getHdStationIdsList().toArray(new Long[0])));
        linearCollection.setUhdStationIds(ArrayUtils.toPrimitive(message.getUhdStationIdsList().toArray(new Long[0])));

        return linearCollection;
    }

    @Override
    public ByteString marshallPayload(CRSLinearCollection payload) {
        LinearCollectionMessage.Builder builder = LinearCollectionMessage.newBuilder();

        builder.setId(payload.getId());
        builder.addAllSdStationIds(Arrays.asList(ArrayUtils.toObject(payload.getSdStationIds())));
        builder.addAllHdStationIds(Arrays.asList(ArrayUtils.toObject(payload.getHdStationIds())));
        builder.addAllUhdStationIds(Arrays.asList(ArrayUtils.toObject(payload.getUhdStationIds())));

        return builder.build().toByteString();
    }
}
