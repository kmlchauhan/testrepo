package com.theplatform.web.tv.gws.service.common.aop.stats;

import com.theplatform.contrib.stats.StatsCollector;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import static java.lang.System.currentTimeMillis;

/**
 * Created by jcoelho on 5/22/13.
 */
@Aspect
public class StatsCollectionAspect {

    private StatsCollector statsCollector = StatsCollector.getInstance();


    @Around("(within(com.theplatform.web.tv.gws.service..*) && @annotation(collectStats))")
    public Object doProfilingForResolveStations(ProceedingJoinPoint pjp, CollectStats collectStats) throws Throwable {

        long startTime = currentTimeMillis();

        Object retVal = pjp.proceed();

        String prefix = collectStats.prefix();
        String methodName = pjp.getTarget().getClass().getSimpleName() + " : " + prefix + (prefix.equals("") ? "" : "-") + pjp.getSignature().getName();

        statsCollector.record(methodName, currentTimeMillis() - startTime);

        return retVal;
    }
}
