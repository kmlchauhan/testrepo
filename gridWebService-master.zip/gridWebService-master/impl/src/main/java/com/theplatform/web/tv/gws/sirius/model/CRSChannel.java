package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.web.tv.gws.sirius.repository.utils.*;

import java.util.*;

public class CRSChannel extends LongDataRepoObject implements Comparable<CRSChannel> {

    private int digicableId;
    private long stationId;
    private long locationId;
    private int channelNumber;
    private Boolean sdv;
    private Long sdvTimeout;
    private long ownerId;
    private String onScreenCallsign;
    private String emergencyAlertSystemType;
    private boolean ipDeliveryOnly;
    private String sortIndexPolicy;             // Policy on how to set the sortIndex lfield.  The default is 100 * the channel number
    private String[] displayPolicies;           //  Special Logic passed on to clients on how/when certain fields will be displayed.  In our case, there will be a DoNotDisplayChannelNumber
    private CanonicalIds productContexts;

    public CRSChannel() {
        super( SiriusObjectType.fromFriendlyName("Channel"));
    }

    public CRSChannel(long id) {
        super( SiriusObjectType.fromFriendlyName("Channel"), id);
    }

    public int getDigicableId() {
        return digicableId;
    }

    public void setDigicableId(int digicableId) {
        this.digicableId = digicableId;
    }

    public long getStationId() {
        return stationId;
    }

    public void setStationId(long stationId) {
        this.stationId = stationId;
    }

    public int getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(int channelNumber) {
        this.channelNumber = channelNumber;
    }

    public long getLocationId() {
        return locationId;
    }

    public void setLocationId(long locationId) {
        this.locationId = locationId;
    }

    public Boolean getSdv() {
        return sdv;
    }

    public void setSdv(Boolean sdv) {
        this.sdv = sdv;
    }

    public Long getSdvTimeout() {
        return sdvTimeout;
    }

    public void setSdvTimeout(Long sdvTimeout) {
        this.sdvTimeout = sdvTimeout;
    }

    public long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(long ownerId) {
        this.ownerId = ownerId;
    }

    public String getOnScreenCallsign() {
        return onScreenCallsign;
    }

    public void setOnScreenCallsign(String onScreenCallsign) {
        this.onScreenCallsign = onScreenCallsign;
    }

    public String getEmergencyAlertSystemType() {
        return emergencyAlertSystemType;
    }

    public void setEmergencyAlertSystemType(String emergencyAlertSystemType) {
        this.emergencyAlertSystemType = nullSafeIntern(emergencyAlertSystemType);
    }

    public boolean isIpDeliveryOnly() {
        return ipDeliveryOnly;
    }

    public void setIpDeliveryOnly(boolean ipDeliveryOnly) {
        this.ipDeliveryOnly = ipDeliveryOnly;
    }

    public String getSortIndexPolicy() {
        return sortIndexPolicy;
    }

    public void setSortIndexPolicy(String sortIndexPolicy) {
        this.sortIndexPolicy = sortIndexPolicy;
    }

    public String[] getDisplayPolicies() {
        return displayPolicies;
    }

    public void setDisplayPolicies(String[] displayPolicies) {
        this.displayPolicies = displayPolicies;
    }

    public Set<Long> getProductContexts() {
        return productContexts.getLongIds();
    }

    public void setProductContexts(CanonicalIds productContexts) {
        this.productContexts = productContexts;
    }

    @Override
    public int compareTo(CRSChannel channel) {
        if (this.hashCode() > channel.hashCode()) {
            return 1;
        }
        if (this.hashCode() < channel.hashCode()) {
            return -1;
        }
        return 0;
    }

}
