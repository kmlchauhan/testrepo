package com.theplatform.web.tv.gws.service.common.converter;

import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.web.tv.gws.sirius.model.CRSRating;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * CRSRating to Rating (Used in the Info Object) Converter
 * Note: This will order the ratings but not the subratings.  It is up to the code writing into the repo
 * to order the subratings.
 *
 */
public class CRSRatingToRatingInfoConverter {
    private static final Comparator<Rating> RATINGS_SORT = new Comparator<Rating>() {
        public int compare(Rating one, Rating two){
            int i = one.getScheme().compareTo(two.getScheme());

            return i;
        }
    };

    public static final List<Rating> convert(CRSRating[] crsRatings) {
        if (crsRatings==null) return null;
        List<Rating> ratings = new ArrayList<>();
        for (CRSRating crsRating : crsRatings){
            ratings.add(convert(crsRating));
        }
        if (ratings.size()>1){
            Collections.sort(ratings, RATINGS_SORT);
        }
        return ratings;
    }

    private static final Rating convert(CRSRating crsRating) {
        if (crsRating == null) return null;
        Rating rating = new Rating();
        rating.setRating(crsRating.getRating());
        rating.setScheme(crsRating.getScheme());
        if (crsRating.getSubRatings() != null) {
            rating.setSubRatings(crsRating.getSubRatings());
        }
        return rating;
    }


}
