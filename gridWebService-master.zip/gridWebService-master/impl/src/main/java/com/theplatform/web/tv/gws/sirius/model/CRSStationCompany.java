package com.theplatform.web.tv.gws.sirius.model;

import com.comcast.merlin.sirius.model.LongDataRepoObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSStationCompany extends LongDataRepoObject implements Comparable<CRSStationCompany> {

    private long stationId;
    private long companyId;
    private String associationType;

    public CRSStationCompany(long id) {
        super( SiriusObjectType.fromFriendlyName("StationCompany"), id);
    }

    public long getStationId() {
        return stationId;
    }

    public void setStationId(long stationId) {
        this.stationId = stationId;
    }

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public String getAssociationType() {
        return associationType;
    }

    public void setAssociationType(String associationType) {
        this.associationType = associationType;
    }

    @Override
    public int compareTo(CRSStationCompany other) {
        if (this.id < other.getId()){
            return -1;
        } else if (this.id < other.getId()){
            return 1;
        } else{
            return 0;
        }
    }

}
