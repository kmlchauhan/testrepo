package com.theplatform.web.tv.gws.sirius.model;


import com.comcast.merlin.sirius.model.RepositoryObject;
import com.comcast.merlin.sirius.model.SiriusObjectType;

public class CRSTrendingProgram extends RepositoryObject implements Comparable<CRSTrendingProgram> {
    private long programId;
    private int score;
    private int rankingGroup;
    private boolean topTrending;

    public CRSTrendingProgram(){
        super( SiriusObjectType.fromFriendlyName("TrendingPrograms"));
    }

    public long getProgramId() {
        return programId;
    }

    public void setProgramId(long programId) {
        this.programId = programId;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getRankingGroup() {
        return rankingGroup;
    }

    public void setRankingGroup(int rankingGroup) {
        this.rankingGroup = rankingGroup;
    }

    public boolean isTopTrending() {
        return topTrending;
    }

    public void setTopTrending(boolean topTrending) {
        this.topTrending = topTrending;
    }

    @Override
    public int compareTo(CRSTrendingProgram other) {
        if (other == null || this.score > other.score) {
            return -1;
        }
        else if (this.score == other.score) {
            return 0;
        }
        else if (this.score < other.score) {
            return 1;
        }
        else if (this.programId < other.programId) {
            return -1;
        }
        else if (this.programId > other.programId) {
            return 1;
        }
        else {
            return 0;
        }
    }
}
