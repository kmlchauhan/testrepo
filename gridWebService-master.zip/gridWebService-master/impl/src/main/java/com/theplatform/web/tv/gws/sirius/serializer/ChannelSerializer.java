package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.ChannelProto.ChannelMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSChannel;
import com.theplatform.web.tv.gws.sirius.repository.utils.*;
import org.springframework.beans.factory.annotation.*;

import java.util.Arrays;

/**
 * Factory that converts Channel protobufs to CRSChannels and visa-versa.
 * 
 */
public class ChannelSerializer extends AbstractSiriusObjectSerializer<CRSChannel> {
    private CanonicalIdsFactory productContextCanonicalIdsFactory;

    public ChannelSerializer(SiriusObjectType siriusObjectType, CanonicalIdsFactory productContextCanonicalIdsFactory) {
        super(siriusObjectType);
        this.productContextCanonicalIdsFactory = productContextCanonicalIdsFactory;
    }

    @Override
    public CRSChannel unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        ChannelMessage.Builder message = ChannelMessage.newBuilder().mergeFrom(bytes);

        CRSChannel channel = new CRSChannel(message.getId());

        if (message.hasDigicableId()) {
            channel.setDigicableId(message.getDigicableId());
        }
        if (message.hasLocationId()) {
            channel.setLocationId(message.getLocationId());
        }
        if (message.hasStationId()) {
            channel.setStationId(message.getStationId());
        }
        if (message.hasChannelNumber()) {
            channel.setChannelNumber(message.getChannelNumber());
        }
        if (message.hasSdv()) {
            channel.setSdv(message.getSdv());
        }
        if (message.hasOwnerId()) {
            channel.setOwnerId(message.getOwnerId());
        }
        if (message.hasSdvTimeout()) {
            channel.setSdvTimeout(message.getSdvTimeout());
        }
        if (message.hasOnScreenCallsign()) {
            channel.setOnScreenCallsign(message.getOnScreenCallsign());
        }
        if (message.hasEmergencyAlertSystemType()) {
            channel.setEmergencyAlertSystemType(message.getEmergencyAlertSystemType());
        }
        if (message.hasIpDeliveryOnly()){
            channel.setIpDeliveryOnly(message.getIpDeliveryOnly());
        }
        if (message.hasSortIndexPolicy()){
            channel.setSortIndexPolicy(message.getSortIndexPolicy());
        }
        if (message.getDisplayPoliciesList()!=null && message.getDisplayPoliciesList().size()>0) {
            String[] displayPolicies = message.getDisplayPoliciesList().toArray(new String[message.getDisplayPoliciesList().size()]);
            Arrays.sort(displayPolicies);
            channel.setDisplayPolicies(displayPolicies);
        }
        channel.setProductContexts(productContextCanonicalIdsFactory.create(message.getProductContextIdsList()));
        return channel;
    }

    @Override
    public ByteString marshallPayload( CRSChannel channel) {
        ChannelMessage.Builder builder = ChannelMessage.newBuilder();

        builder.setId(channel.getId());
        builder.setDigicableId(channel.getDigicableId());
        builder.setLocationId(channel.getLocationId());
        builder.setStationId(channel.getStationId());
        builder.setChannelNumber(channel.getChannelNumber());
        builder.setSdv(channel.getSdv());
        builder.setOwnerId(channel.getOwnerId());
        if (channel.getOnScreenCallsign() != null) {
            builder.setOnScreenCallsign(channel.getOnScreenCallsign());
        }
        if (channel.getSdvTimeout()!=null)
            builder.setSdvTimeout(channel.getSdvTimeout());
        if (channel.getEmergencyAlertSystemType()!=null) {
            builder.setEmergencyAlertSystemType(channel.getEmergencyAlertSystemType());
        }
        builder.setIpDeliveryOnly(channel.isIpDeliveryOnly());
        if (channel.getSortIndexPolicy()!=null) {
            builder.setSortIndexPolicy(channel.getSortIndexPolicy());
        }
        if (channel.getDisplayPolicies()!=null && channel.getDisplayPolicies().length>0){
            builder.addAllDisplayPolicies(Arrays.asList(channel.getDisplayPolicies()));
        }
        builder.addAllProductContextIds(channel.getProductContexts());

        return builder.build().toByteString();
    }

}
