package com.theplatform.web.tv.gws.sirius.repository.utils;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.yammer.metrics.Metrics;
import com.yammer.metrics.core.Gauge;

import java.util.Optional;
import java.util.function.Supplier;

/**
 * This class is meant to be used for cases where there are lots of commonly used objects across different entity
 * types, e.g. {@link CanonicalIds}, where the object has the same attribute values. For
 * example, a {@link com.theplatform.web.tv.gws.sirius.model.CRSContentAvailability},
 * {@link com.theplatform.web.tv.gws.sirius.model.CRSChannel} are all capable of having one or more ProductContexts.
 * But in reality, these different entities should all be referencing the same set of ProductContext Ids.
 * <p>
 * This cache is used for holding the canonical definition of these objects. Note that the values will be kept
 * as weak references, so when no object is referencing them any longer, they will be removed.
 * <p>
 * Also note that this cache will re-use the {@link CacheKey} for lookups, and only create a new instance when actually
 * putting into the cache.
 *
 * Ported from DaveS's code in Tim.
 */
final class CanonicalObjectCache<K extends CanonicalObjectCache.CacheKey, V extends CanonicalObject> {

    private final Cache<CacheKey, V> cache;
    private final ThreadLocal<K> reusableInstance;
    private final Gauge<Long> size = new Gauge<Long>() {
        @Override
        public Long value() {
            return cache.size();
        }
    };

    CanonicalObjectCache(Class<?> clazz, final Supplier<K> keyFactory) {
        Metrics.newGauge(clazz, "cache-size", size);
        this.cache = CacheBuilder.newBuilder()
                // weak values will prevent un-used objects from staying in the system
                .weakValues()
                .build();

        this.reusableInstance = new ThreadLocal<K>() {
            @Override
            protected K initialValue() {
                return keyFactory.get();
            }
        };
    }

    long size() {
        return cache.size();
    }

    /**
     * Will return an Optional containing the value for the key as populated by the {@link KeyPopulator}. An
     * empty optional will be returned if one is not found.
     *
     * @param populator this populator will be called with a {@code CacheKey} that should be populated with the key
     *                  information. The key will then be used to lookup the value.
     * @return Optional with the value or an empty optional
     */
    Optional<V> get(KeyPopulator<K> populator) {
        K key = reusableInstance.get();
        populator.populate(key);

        return Optional.ofNullable(cache.getIfPresent(key));
    }

    /**
     * Returns the value for the {@link CacheKey} as populated by the specified {@code populator}. If the key is not found in the
     * cache, the {@code valueCreator} will be used to create the value that will be put into the cache for the key.
     *
     * @param populator    this populator will be called with a {@code CacheKey} that should be populated with the key
     *                     information. The key will then be used to lookup the value.
     * @param valueCreator this is used to create the value to store when the key is not found in the cache
     * @return value for {@code CacheKey}
     */
    V getOrPopulateCache(KeyPopulator<K> populator, ValueCreator<K, V> valueCreator) {
        K key = reusableInstance.get();
        populator.populate(key);

        V value = cache.getIfPresent(key);

        if (value == null) {
            value = valueCreator.createFromCacheKey(key);

            // the key has to be duplicated because we are storing it in the map at this point and cannot put the
            // reusable version in there
            cache.put(key.duplicate(), value);
        }

        return value;
    }

    @FunctionalInterface
    interface KeyPopulator<K extends CacheKey> {
        /**
         * Implementations need to populate the given {@code CacheKey} according to whatever defines it. For example,
         * for {@link MediaId}, the elements are accountGuid and mediaGuid.
         *
         * @param cacheKey that user should populate
         */
        void populate(K cacheKey);
    }

    @FunctionalInterface
    interface ValueCreator<K extends CacheKey, V> {
        /**
         * Implementations need to create the value that will be stored in the from the specified cacheKey.
         *
         * @param cacheKey that is used to create value
         * @return value to store in cache
         */
        V createFromCacheKey(K cacheKey);
    }

    /**
     * Defines the key into the cache. Note that subclasses must define the {@link #equals(Object)} and
     * {@link #hashCode()}  methods for this key to work correctly with the cache.
     */
    abstract static class CacheKey {
        /**
         * Implementations need to return a new instance with the same contents.
         *
         * @return new CacheKey
         */
        protected abstract CacheKey duplicate();

        @Override
        public abstract boolean equals(Object other);

        @Override
        public abstract int hashCode();
    }
}
