package com.theplatform.web.tv.gws.service.common.field.nullification;


import com.google.common.annotations.VisibleForTesting;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

/**
 * Encapsulate the fields that should be nullified/not nullified.
 */
public class SelectedProperties {

    /**
     * Property selection mode (inclusive vs exclusive)
     */
    private final NullificationMode nullificationMode;

    /**
     * Map of properties built from user specified input.  The key of the Map is the full path to each property
     * and the value is a Set of any child properties.  For example, if "foo.bar.baz,foo.bar.other" was passed
     * to the constructor, this Map would  contain:
     * <pre>{@code
     *      "foo" => ["foo.bar"]
     *      "foo.bar" => ["foo.bar.baz", "foo.bar.other"]
     *      "foo.bar.baz" => null
     *      "foo.bar.other" => null
     * }</pre>
     *
     */
    private final Map<String, Set<String>> properties;

    /**
     * Create a new instance for the specified fields
     * @param nullificationMode nullification mode (inclusive or exclusive)
     * @param csv one or more comma delimited Strings of OGNL style bean properties
     */
    public SelectedProperties(NullificationMode nullificationMode, String...csv) {
        this.nullificationMode = nullificationMode;

        List<String> values = new ArrayList<>();

        // loop over each CSV string.  for example, ["foo.one,foo.two", "foo.three,foo.four"]
        for (String currentCsv : csv) {
            if (StringUtils.isBlank(currentCsv)) {
                continue;
            }

            // split each input string into an array of properties.  we'll handle empty properties
            // and trimming whitespace later
            String[] split = StringUtils.split(currentCsv, ',');
            if (split != null) {
                CollectionUtils.addAll(values, split);
            }
        }

        this.properties = new HashMap<>();
        initProperties(values);

    }

    /**
     * Convert a List of String properties into a Map.  The Map contains the parent properties of each String.
     * See {@link #properties}.
     * @param values List of String properties
     */
    private void initProperties(List<String> values) {

        // sort the combined list of input properties.  if the List contains "foo,foo.bar" then "foo.bar" is redundant
        // since its parent property "foo" is already explicitly included.
        Collections.sort(values);

        // the previous property that was processed.  again, the List is sorted and we want to avoid including descendants
        // of properties that have been included.
        String prev = null;
        for (String current : values) {

            // remove leading/trailing whitespace
            String stripped = StringUtils.strip(current);

            // if the string is blank, superseded because its parent was included, or is a duplicate
            if (StringUtils.isBlank(stripped) || StringUtils.startsWith(stripped, prev + ".") || StringUtils.equals(stripped, prev)) {
                continue;
            }

            addProperty(stripped);
            prev = stripped;
        }
    }

    /**
     * Add a property and all of its ancestors to the Map
     * @param value period separated property ("foo.bar.baz")
     */
    private void addProperty(String value) {

        // store this property in the Map with no children.  since we're processing the List of properties in order,
        // any children will come later
        this.properties.put(value, null);

        // "foo.bar.baz" => ["foo", "bar", "baz"]
        String[] parents = StringUtils.split(value, '.');

        // build the ancestors of the current property by starting at the end of the array and counting backwards
        for (int i = parents.length; i > 1; i--) {

            // zero to the current index gives us this property
            String current = StringUtils.join(parents, '.', 0, i);

            // zero to one index before the current index gives us this property's parent
            String parent = StringUtils.join(parents, '.', 0, i - 1);

            // if the parent doesn't already have a set of child properties build one now
            // and associate the current property with its parent
            Set<String> children = this.properties.get(parent);
            if (children == null) {
                children = new ObjectOpenHashSet<>();
                this.properties.put(parent, children);
            }
            children.add(current);
        }
    }

    public NullificationMode getNullificationMode() {
        return nullificationMode;
    }

    /**
     * Check if a property was directly included for nullification/preservation.
     * @param path full path relative to the root
     * @return true if the property was specified for nullification/preservation
     */
    public boolean included(String path) {
        return properties.containsKey(path) && properties.get(path) == null;
    }

    /**
     * Check if any descendants of the property are included for nullification/preservation.
     * @param path path full path relative to the root
     * @return true if any descendants of the property are included for nullification/preservation.
     */
    public boolean childrenIncluded(String path) {
        return properties.containsKey(path) && properties.get(path) != null;
    }

    @VisibleForTesting
    Set<String> childrenOf(String path) {
        return properties.get(path);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SelectedProperties that = (SelectedProperties) o;

        if (nullificationMode != that.nullificationMode) return false;
        return properties.equals(that.properties);

    }

    @Override
    public int hashCode() {
        return 31 * nullificationMode.hashCode() + properties.hashCode();
    }
}
