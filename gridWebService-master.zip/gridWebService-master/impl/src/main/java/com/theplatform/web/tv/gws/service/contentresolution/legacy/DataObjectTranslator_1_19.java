package com.theplatform.web.tv.gws.service.contentresolution.legacy;

import com.theplatform.web.tv.contentresolution.api.objects.ApiObjectVisitor;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.contentresolution.api.objects.StationInfo;

public class DataObjectTranslator_1_19 extends ApiObjectVisitor {
    public final static DataObjectTranslator_1_19 INSTANCE = new DataObjectTranslator_1_19();

    @Override
    public void visitChannelInfo(ChannelInfo channelInfo){
        channelInfo.setOutOfHomeChannelId(null);
        channelInfo.setSortIndex(null);
    }


}