package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.TrendingProgramsProto.TrendingProgramsMessage;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.TrendingProgramsProto.TrendingProgramsMessage.TrendingProgramMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms;

import java.util.ArrayList;
import java.util.List;


public class TrendingProgramsSerializer extends AbstractSiriusObjectSerializer<CRSTrendingPrograms> {

    public TrendingProgramsSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSTrendingPrograms unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        TrendingProgramsMessage.Builder message = TrendingProgramsMessage.newBuilder().mergeFrom(bytes);

        CRSTrendingPrograms crsTrendingPrograms = new CRSTrendingPrograms();
        crsTrendingPrograms.setRetrievedTime(message.getRetrievedTime());
        crsTrendingPrograms.setTimeToLive(message.getTimeToLive());

        List<CRSTrendingProgram> crsProgramList = new ArrayList<>(message.getProgramsCount());
        crsTrendingPrograms.setPrograms(crsProgramList);

        for (TrendingProgramMessage current : message.getProgramsList()) {
            CRSTrendingProgram crsTrendingProgram = new CRSTrendingProgram();
            crsTrendingProgram.setProgramId(current.getProgramId());
            crsTrendingProgram.setRankingGroup(current.getRankingGroup());
            crsTrendingProgram.setScore(current.getScore());
            crsTrendingProgram.setTopTrending(current.getTopTrending());

            crsProgramList.add(crsTrendingProgram);
        }

        return crsTrendingPrograms;
    }

    @Override
    public ByteString marshallPayload( CRSTrendingPrograms crsTrendingPrograms) {
        TrendingProgramsMessage.Builder builder = TrendingProgramsMessage.newBuilder();
        builder.setTimeToLive(crsTrendingPrograms.getTimeToLive());
        builder.setRetrievedTime(crsTrendingPrograms.getRetrievedTime());

        for (CRSTrendingProgram current : crsTrendingPrograms) {
            TrendingProgramMessage.Builder programBuilder = TrendingProgramMessage.newBuilder();
            programBuilder.setProgramId(current.getProgramId());
            programBuilder.setRankingGroup(current.getRankingGroup());
            programBuilder.setScore(current.getScore());
            programBuilder.setTopTrending(current.isTopTrending());

            builder.addPrograms(programBuilder);
        }
        return builder.build().toByteString();
    }

}
