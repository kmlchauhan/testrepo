package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.data.tv.entity.api.data.objects.TagType;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.TagProto.TagMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSTag;

/**
 * @author jcoelho
 * @since 6/9/15.
 */
public class TagSerializer extends AbstractSiriusObjectSerializer<CRSTag> {

    public TagSerializer(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }

    @Override
    public CRSTag unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        TagMessage.Builder message = TagMessage.newBuilder().mergeFrom(bytes);
        return new CRSTag(message.getId(), message.getTitle(), TagType.getByFriendlyName(message.getType()));
    }

    @Override
    public ByteString marshallPayload(  CRSTag object) {
        TagMessage.Builder builder = TagMessage.newBuilder().setId(object.getId())
                .setTitle(object.getTitle());
        if (object.getType() != null)
            builder.setType(object.getType().getFriendlyName());

        return builder.build().toByteString();
    }


}
