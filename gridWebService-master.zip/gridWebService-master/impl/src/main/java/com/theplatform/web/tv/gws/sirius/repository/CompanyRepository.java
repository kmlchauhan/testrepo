package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSCompany;

public class CompanyRepository extends LongObjectRepository<CRSCompany> {
    public CompanyRepository(SiriusObjectType siriusObjectType) {
        super(siriusObjectType);
    }
}
