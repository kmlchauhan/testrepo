package com.theplatform.web.tv.gws.service.common.util;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.module.exception.BadParameterException;
import com.theplatform.web.tv.gws.sirius.model.CRSLocation;
import com.theplatform.web.tv.gws.sirius.repository.LocationRepository;
import com.theplatform.web.tv.gws.service.common.logic.Scope;
import com.theplatform.web.tv.gws.service.common.logic.ScopedAvailabilities;
import org.springframework.beans.factory.annotation.Required;

import java.net.URI;

public class OwnerUtil {

    private LocationRepository locationRepository;

    public long getOwnerId(ScopedAvailabilities scopedAvailabilities){
        URI locationUri = scopedAvailabilities.getByScope(Scope.STATION).get(0).getAvailabilityIds().get(0);
        long locationId = Muri.getObjectId(locationUri);
        CRSLocation crsLocation = locationRepository.get(locationId);
        if (crsLocation==null){
            throw new BadParameterException("Unknown Location provided (id = " + locationId + ").");
        }
        return crsLocation.getOwnerId();
    }

    public long getOwnerIdFromLocation(long locationId){
        CRSLocation crsLocation = locationRepository.get(locationId);
        if (crsLocation==null){
            throw new BadParameterException("Unknown Location provided (id = " + locationId + ").");
        }
        return crsLocation.getOwnerId();
    }


    @Required
    public void setLocationRepository(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }

}
