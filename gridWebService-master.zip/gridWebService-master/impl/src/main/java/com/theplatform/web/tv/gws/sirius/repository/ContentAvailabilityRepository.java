package com.theplatform.web.tv.gws.sirius.repository;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.comcast.merlin.sirius.repository.LongObjectRepository;
import com.theplatform.web.tv.gws.sirius.model.CRSContentAvailability;
import com.theplatform.web.tv.gws.sirius.repository.utils.JdkCollectionsCompositeKeySecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.OpenSetSecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.SecondaryIndex;
import com.theplatform.web.tv.gws.sirius.repository.utils.ThreePartKeySetSecondaryIndex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.util.*;

public class ContentAvailabilityRepository extends LongObjectRepository<CRSContentAvailability> {
    private static Logger logger = LoggerFactory.getLogger(ContentAvailabilityRepository.class);

    private SecondaryIndex<Long, CRSContentAvailability> streamAvailabilityIndex;           // AvailId -(1-n)-> Station CA

    private SecondaryIndex<Long, CRSContentAvailability> stationAvailabilityIndex;          // AvailId -(1-n)-> Stream CA

    private SecondaryIndex<Long, CRSContentAvailability> locatorAvailabilityIndex;

    private ThreePartKeySetSecondaryIndex<Long, Long, Long, CRSContentAvailability> locationStationToContentAvailabilityIndex;     // Location(AvailId), Station, OwnerId -(1-n) =>> Stream CA
    private JdkCollectionsCompositeKeySecondaryIndex<Long,Long,CRSContentAvailability> stationToContentAvailabilityIndex;       // stationId, ownerId  - (1-n) -> CRSContentAvailability

    // The new whitelist
    private Set<Long> ctvWhiteList;
    private Set<Long> cdvrWhiteList;
    private long comcastNationalAvail;
    private Long ctvProductContext;
    private Long cdvrProductContext;

    public ContentAvailabilityRepository(SiriusObjectType siriusObjectType, long comcastNationalAvail, Long ctvProductContext, Long cdvrProductContext) {
        super(siriusObjectType);
        this.comcastNationalAvail = comcastNationalAvail;
        this.cdvrProductContext = cdvrProductContext;
        this.ctvProductContext = ctvProductContext;

        streamAvailabilityIndex  = new OpenSetSecondaryIndex<>();
        stationAvailabilityIndex = new OpenSetSecondaryIndex<>();
        locatorAvailabilityIndex = new OpenSetSecondaryIndex<>();
        locationStationToContentAvailabilityIndex = new ThreePartKeySetSecondaryIndex<>();
        stationToContentAvailabilityIndex = new JdkCollectionsCompositeKeySecondaryIndex<>();

        ctvWhiteList  = new HashSet<>(7000);
        cdvrWhiteList = new HashSet<>(7000);
    }

    @Override
    protected void addToIndexes(CRSContentAvailability contentAvailability) {
        if(contentAvailability.getContentType()==CRSContentAvailability.CONTENT_TYPE_STREAM){
            streamAvailabilityIndex.put(contentAvailability.getAvailabilityId(), contentAvailability);
        }else if (contentAvailability.getContentType()==CRSContentAvailability.CONTENT_TYPE_STATION){
            stationAvailabilityIndex.put(contentAvailability.getAvailabilityId(), contentAvailability);
            locationStationToContentAvailabilityIndex.put(contentAvailability.getAvailabilityId(), contentAvailability.getContentId(), contentAvailability.getOwnerId(), contentAvailability);
            stationToContentAvailabilityIndex.put(contentAvailability.getContentId(), contentAvailability.getOwnerId(), contentAvailability);
            if (contentAvailability.getAvailabilityId()==comcastNationalAvail){
                    if ( contentAvailability.getProductContextIds().contains(ctvProductContext)) {
                        ctvWhiteList.add(contentAvailability.getContentId());
                    }
                    if ( contentAvailability.getProductContextIds().contains(cdvrProductContext)){
                        cdvrWhiteList.add(contentAvailability.getContentId());
                    }
            }
        }else if (contentAvailability.getContentType() == CRSContentAvailability.CONTENT_TYPE_LOCATOR){
            locatorAvailabilityIndex.put(contentAvailability.getAvailabilityId(), contentAvailability);
        }
    }

    @Override
    protected void removeFromIndexes(CRSContentAvailability contentAvailability) {
        streamAvailabilityIndex.remove(contentAvailability.getAvailabilityId(), contentAvailability);
        stationAvailabilityIndex.remove(contentAvailability.getAvailabilityId(), contentAvailability);
        locatorAvailabilityIndex.remove(contentAvailability.getAvailabilityId(), contentAvailability);
        locationStationToContentAvailabilityIndex.remove(contentAvailability.getAvailabilityId(), contentAvailability.getContentId(), contentAvailability.getOwnerId(), contentAvailability);
        stationToContentAvailabilityIndex.remove(contentAvailability.getContentId(), contentAvailability.getOwnerId(), contentAvailability);
        if (contentAvailability.getAvailabilityId()==comcastNationalAvail){
            if ( contentAvailability.getProductContextIds().contains(ctvProductContext)) {
                ctvWhiteList.remove(contentAvailability.getContentId());
            }
            if ( contentAvailability.getProductContextIds().contains(cdvrProductContext)){
                cdvrWhiteList.remove(contentAvailability.getContentId());
            }
        }
    }

    // Locator CA
    public Collection<CRSContentAvailability> getLocatorsByAvailabilityId(Long availabilityId) {
        return locatorAvailabilityIndex.getByIndexKey(availabilityId);
    }

    public Collection<CRSContentAvailability> getLocatorsByAvailabilityIds(Collection<Long> availabilityIds) {
        Collection<CRSContentAvailability> resultSet = new HashSet<CRSContentAvailability>();
        for (Long availabilityId : availabilityIds) {
            resultSet.addAll(this.getLocatorsByAvailabilityId(availabilityId));
        }
        return resultSet;
    }

    // Stream CA
    public Collection<CRSContentAvailability> getStreamsByAvailabilityId(Long availabilityId) {
        return streamAvailabilityIndex.getByIndexKey(availabilityId);
    }

    public Collection<CRSContentAvailability> getStreamsByAvailabilityIds(Collection<Long> availabilityIds) {
        Collection<CRSContentAvailability> resultSet = new HashSet<CRSContentAvailability>();
        for (Long availabilityId : availabilityIds) {
            resultSet.addAll(this.getStreamsByAvailabilityId(availabilityId));
        }
        return resultSet;
    }

    // Station CA
    public Collection<CRSContentAvailability> getStationsByAvailabilityId(Long availabilityId) {
        return stationAvailabilityIndex.getByIndexKey(availabilityId);
    }

    public Collection<CRSContentAvailability> getStationsByAvailabilityIds(Collection<Long> availabilityIds) {
        Collection<CRSContentAvailability> resultSet = new HashSet<CRSContentAvailability>();
        for (Long availabilityId : availabilityIds) {
            resultSet.addAll(this.getStationsByAvailabilityId(availabilityId));
        }
        return resultSet;
    }

    public Set<Long> getStationsAvailabilityIds(){
        return stationAvailabilityIndex.getKeys();
    }

    public Set<CRSContentAvailability> getContentAvailabilitysByLocationAndStation(Long locationId, Long stationId, Long ownerId) {
        return locationStationToContentAvailabilityIndex.getByIndexKey(locationId, stationId, ownerId);
    }

    public Set<CRSContentAvailability> getContentAvailabilitysByLocationAndStation(Collection<Long> locationIds, Long stationId, Long ownerId) {
        Set<CRSContentAvailability> crsContentAvailabilities = new HashSet<>();
        for(Long locationId : locationIds){
            Set<CRSContentAvailability> cas = locationStationToContentAvailabilityIndex.getByIndexKey(locationId, stationId, ownerId);
            if (cas != null) crsContentAvailabilities.addAll(cas);
        }
        return crsContentAvailabilities;
    }

    public Set<CRSContentAvailability> getContentAvailabilitysByStation(Long stationId, Long ownerId) {
        return stationToContentAvailabilityIndex.getByIndexKey( stationId, ownerId);
    }

    public boolean isCtvStation( Long station){
        return ctvWhiteList.contains(station);
    }

    public boolean isCdvrStation( Long station){
        return cdvrWhiteList.contains(station);
    }

}
