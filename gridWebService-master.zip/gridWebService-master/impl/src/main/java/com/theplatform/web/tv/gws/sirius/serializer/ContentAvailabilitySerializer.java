package com.theplatform.web.tv.gws.sirius.serializer;

import com.comcast.merlin.sirius.ingest.dispatcher.serialization.AbstractSiriusObjectSerializer;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.theplatform.web.tv.gws.ingest.dispatcher.serialization.proto.ContentAvailabilityProto.ContentAvailabilityMessage;
import com.theplatform.web.tv.gws.sirius.model.CRSContentAvailability;
import com.theplatform.web.tv.gws.sirius.repository.utils.*;

/**
 * Factory that converts ContentAvailability protobufs to CRSContentAvailabilitys and visa-versa.
 * 
 */
public class ContentAvailabilitySerializer extends AbstractSiriusObjectSerializer<CRSContentAvailability> {
    private CanonicalIdsFactory productContextCanonicalIdsFactory;

    public ContentAvailabilitySerializer(SiriusObjectType siriusObjectType, CanonicalIdsFactory productContextCanonicalIdsFactory) {
        super(siriusObjectType);
        this.productContextCanonicalIdsFactory = productContextCanonicalIdsFactory;
    }

    @Override
    public CRSContentAvailability unmarshallPayload(byte[] bytes) throws InvalidProtocolBufferException {
        ContentAvailabilityMessage.Builder message = ContentAvailabilityMessage.newBuilder().mergeFrom(bytes);

        CRSContentAvailability contentAvailability = new CRSContentAvailability(message.getId());

        if (message.hasAvailabilityId()) {
            contentAvailability.setAvailabilityId(message.getAvailabilityId());
        }
        if (message.hasContentId()) {
            contentAvailability.setContentId(message.getContentId());
        }
        if (message.hasOwnerId()) {
            contentAvailability.setOwnerId(message.getOwnerId());
        }
        if (message.hasContentType()) {
            contentAvailability.setContentType(message.getContentType());
        }
        contentAvailability.setProductContextIds(productContextCanonicalIdsFactory.create(message.getProductContextIdsList()));


        return contentAvailability;
    }

    @Override
    public ByteString marshallPayload( CRSContentAvailability contentAvailability) {
        ContentAvailabilityMessage.Builder builder = ContentAvailabilityMessage.newBuilder();

        builder.setId(contentAvailability.getId());
        builder.setAvailabilityId(contentAvailability.getAvailabilityId());
        builder.setContentId(contentAvailability.getContentId());
        builder.setOwnerId(contentAvailability.getOwnerId());
        builder.setContentType(contentAvailability.getContentType());
        builder.addAllProductContextIds(contentAvailability.getProductContextIds());

        return builder.build().toByteString();
    }


}
