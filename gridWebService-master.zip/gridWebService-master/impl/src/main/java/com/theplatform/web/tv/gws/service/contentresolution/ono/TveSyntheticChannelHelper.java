package com.theplatform.web.tv.gws.service.contentresolution.ono;

import com.github.zafarkhaja.semver.Version;
import com.theplatform.web.context.WebServiceContext;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfo;
import com.theplatform.web.tv.gws.service.common.util.*;
import com.theplatform.web.tv.gws.sirius.model.CRSChannel;
import com.theplatform.web.tv.gws.sirius.repository.ChannelRepository;
import com.theplatform.web.tv.gws.sirius.repository.ProductContextRepository;
import com.theplatform.web.tv.gws.service.common.converter.CRSChannelToChannelInfoConverter;
import com.theplatform.web.tv.gws.service.common.logic.Scope;
import com.theplatform.web.tv.gws.service.common.logic.ScopedAvailabilities;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.slf4j.*;
import org.springframework.beans.factory.annotation.Required;

import java.net.URI;
import java.util.*;

import static java.lang.Integer.parseInt;

public class TveSyntheticChannelHelper {
    private static final Logger logger = LoggerFactory.getLogger(TveSyntheticChannelHelper.class);

    static final int SYNTH_CHANNEL_NUMBER_OFFSET = 10000;
    static final String MINIMUM_REQUIRED_VERSION = "1.17";

    private WebServiceContext webServiceContext;
    private ProductContextRepository productContextRepository;
    private ChannelRepository channelRepository;
    private CRSChannelToChannelInfoConverter crsChannelToChannelInfoConverter;
    private ChannelCloner channelCloner;
    private DynamicProperties dynamicProperties;

    private final static String moneyTraceHeaderName = "X-MoneyTrace";

    public void populateSyntheticChannels(List<ChannelInfo> channelInfos,
                                          ScopedAvailabilities scopedAvailabilities,
                                          MerlinIdHelper merlinIdHelper) {
        if (!dynamicProperties.get(DynamicProperties.DynamicPropertiesEnum.ONO_SYNTHETIC_ENABLED).equals("true")
                || !isCorrectVersion(webServiceContext)
                || !scopedAvailabilities.hasScope(Scope.SHADOW)) return;

        ResponseAnalysis responseAnalysis = new ResponseAnalysis(productContextRepository, channelInfos);

        if (responseAnalysis.getTveProductContexts().isEmpty()) return;

        Set<CRSChannel> cloningCandidates = new HashSet<>();
        Set<URI> locationIds = scopedAvailabilities.getAvailabilityIds(Scope.SHADOW);

        for (URI locationId : locationIds) {
            Collection<CRSChannel> channels = channelRepository.getByLocationId(Muri.getObjectId(locationId));
            cloningCandidates.addAll(channels);
        }

        HashMap<Long, ChannelInfo> stationIdToClonedChannel = new HashMap<>();

        int shadowChannelCount = 0;
        int realOnoChannelCount = 0;
        List<Long> shadowStationIds = new ArrayList<>();
        List<Long> realOnoStationIds = new ArrayList<>();
        for (CRSChannel candidate : cloningCandidates) {
            long stationId = candidate.getStationId();

            if (channelRepository.syntheticChannelStationWhitelistContains(stationId)) {

                if (!responseAnalysis.containsTveStation(stationId)) {
                    ChannelInfo channelOnSameStation = stationIdToClonedChannel.get(stationId);

                    if (channelOnSameStation == null) {
                        // Don't double count - If channelOnSameStation is not null then we've already tracked that one.
                        shadowStationIds.add(stationId) ;
                        shadowChannelCount++;
                    } else {
                        // Deterministic - We've already ran into this channel.  Should we swap in a different channel?
                        if (channelOnSameStation.getChannelId().getId() < candidate.getId()) {
                            continue;
                        }
                    }

                    ChannelInfo channelInfo = crsChannelToChannelInfoConverter.convert(candidate, merlinIdHelper,
                            scopedAvailabilities.getAvailabilityResolution().getRecorderManager());

                    stationIdToClonedChannel.put(stationId, channelInfo);
                } else {
                    realOnoStationIds.add(stationId);
                    realOnoChannelCount++;
                }
            }
        }

        for (ChannelInfo channelInfo : stationIdToClonedChannel.values()) {
            ChannelInfo clone = channelCloner.clone(channelInfo, responseAnalysis.getTveProductContexts(), merlinIdHelper);
            channelInfos.add(clone);
        }

        String moneyTraceHeaderValue = webServiceContext.getWebServiceRequest().getHeaders().get(moneyTraceHeaderName);
        moneyTraceHeaderValue = moneyTraceHeaderValue == null ? "" : ("moneyTrace=" + moneyTraceHeaderValue);


        shadowStationIds.sort(Long::compare);
        realOnoStationIds.sort(Long::compare);
        List<Long> stationScopeIds = getAvailabilityIdList(scopedAvailabilities, Scope.STATION);
        List<Long> shadowScopeIds = getAvailabilityIdList(scopedAvailabilities, Scope.SHADOW);
        logger.info("Job=TveSyntheticChannelHelper realOnoChannelCount={} shadowChannelCount={} realOnoStationIds={} shadowStationIds={} stationScopeIds={} shadowScopeIds={} {}",
                realOnoChannelCount, shadowChannelCount, realOnoStationIds, shadowStationIds, stationScopeIds, shadowScopeIds, moneyTraceHeaderValue);
    }

    protected List<Long> getAvailabilityIdList(ScopedAvailabilities scopedAvailabilities, Scope scope) {
        List<Long> availabilityIds = new ArrayList<>();
        Set<URI> locationIds = scopedAvailabilities.getAvailabilityIds(scope);
        for (URI locationId : locationIds) {
            availabilityIds.add(Muri.getObjectId(locationId));
        }
        availabilityIds.sort(Long::compare);
        return availabilityIds;
    }

    static boolean isCorrectVersion(WebServiceContext webServiceContext) {
        String requestSchema = webServiceContext.getWebServiceRequest().getParameter("schema");
        return isGreaterThanOrEqualVersion(MINIMUM_REQUIRED_VERSION, requestSchema);
    }

    static boolean isGreaterThanOrEqualVersion(String minimumVersion, String requestedVersion){
        String[] minimumVersionTokens = minimumVersion.split("\\.");
        if(minimumVersionTokens.length != 2)
            throw new RuntimeException("Invalid schema version");
        Version minimum = Version.forIntegers(parseInt(minimumVersionTokens[0]), parseInt(minimumVersionTokens[1]));

        String[] requestSchemaTokens = requestedVersion.split("\\.");
        if(requestSchemaTokens.length != 2)
            throw new RuntimeException("Invalid schema version");
        Version requested = Version.forIntegers(parseInt(requestSchemaTokens[0]), parseInt(requestSchemaTokens[1]));

        return requested.greaterThanOrEqualTo(minimum);
    }

    @Required
    public void setWebServiceContext(WebServiceContext webServiceContext) {
        this.webServiceContext = webServiceContext;
    }

    @Required
    public void setProductContextRepository(ProductContextRepository productContextRepository) {
        this.productContextRepository = productContextRepository;
    }

    @Required
    public void setChannelRepository(ChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    @Required
    public void setCrsChannelToChannelInfoConverter(CRSChannelToChannelInfoConverter crsChannelToChannelInfoConverter) {
        this.crsChannelToChannelInfoConverter = crsChannelToChannelInfoConverter;
    }

    @Required
    public void setChannelCloner(ChannelCloner channelCloner) {
        this.channelCloner = channelCloner;
    }

    @Required
    public void setDynamicProperties(DynamicProperties dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }
}
