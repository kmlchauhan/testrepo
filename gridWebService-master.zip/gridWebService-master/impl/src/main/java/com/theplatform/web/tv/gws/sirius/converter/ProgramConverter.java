package com.theplatform.web.tv.gws.sirius.converter;

import com.comcast.merlin.sirius.ingest.producer.dataservice.converter.AbstractDataObjectConverter;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.web.tv.gws.sirius.model.CRSProgram;
import com.theplatform.web.tv.gws.sirius.model.CRSRating;
import org.apache.commons.collections.CollectionUtils;

import java.util.Arrays;
import java.util.List;

public class ProgramConverter extends AbstractDataObjectConverter<Program, CRSProgram> {

    @Override
    public CRSProgram convert(Program program){

        CRSProgram crsProgram = new CRSProgram();
        crsProgram.setId(LocalUriConverter.convertUriToID(program.getId()));
        crsProgram.setType(program.getType());
        if (program.getTitle() != null)
            crsProgram.setTitle(program.getTitle());
        if (program.getShortTitle() != null) {
            crsProgram.setGridTitle(program.getShortTitle());
        } else {
            crsProgram.setGridTitle(program.getTitle());
        }
        if (program.getCategory() != null)
            crsProgram.setCategory(ProgramCategory.getByFriendlyName(program.getCategory()));
        if (program.getSeriesId() != null)
            crsProgram.setSeriesId(LocalUriConverter.convertUriToID(program.getSeriesId()));
        if (program.getEpisodeTitle() != null) 
            crsProgram.setEpisodeTitle(program.getEpisodeTitle());
        if (program.getSportsSubtitle() != null)
            crsProgram.setSportsSubtitle(program.getSportsSubtitle());
        if (program.getAdult() != null)
            crsProgram.setAdult(program.getAdult());
        crsProgram.setTvSeasonNumber(program.getTvSeasonNumber());
        crsProgram.setTvSeasonEpisodeNumber(program.getTvSeasonEpisodeNumber());
        crsProgram.setSeriesEpisodeNumber(program.getSeriesEpisodeNumber());
        crsProgram.setPartNumber(program.getPartNumber());
        crsProgram.setTotalParts(program.getTotalParts());
        if (CollectionUtils.isNotEmpty(program.getTagIds())) {
            long[] tagIds = Muri.getObjectIdsAsArray(program.getTagIds());
            Arrays.sort(tagIds);
            crsProgram.setTagIds(tagIds);
        }
        if (program.getContentRatings() != null && program.getContentRatings().size()>0){
            crsProgram.setContentRatings( getCRSRatings(program.getContentRatings()));
        }
        crsProgram.setLanguage(program.getLanguage());
        return crsProgram;
    }

    private CRSRating[] getCRSRatings(List<Rating> rating) {
        CRSRating[] crsRatings = new CRSRating[rating.size()];
        for (int i=0; i<rating.size(); i++){
            crsRatings[i] =  getCRSRating(rating.get(i));
        }
        return crsRatings;
    }

    private CRSRating getCRSRating(Rating rating) {
        String scheme = rating.getScheme();
        String ratingString = rating.getRating();
        String[] subratings = null;
        if (rating.getSubRatings()!=null && rating.getSubRatings().length>0){
            subratings = rating.getSubRatings();
            Arrays.sort(subratings);
        }else{
            subratings = null;
        }
        return CRSRating.getInstance(scheme, ratingString, subratings);
    }


}
