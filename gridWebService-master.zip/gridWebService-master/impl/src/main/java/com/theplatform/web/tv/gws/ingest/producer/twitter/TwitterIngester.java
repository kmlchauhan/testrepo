package com.theplatform.web.tv.gws.ingest.producer.twitter;


import com.comcast.merlin.sirius.ingest.Action;
import com.comcast.merlin.sirius.ingest.Event;
import com.comcast.merlin.sirius.ingest.EventDispatcher;
import com.comcast.merlin.sirius.ingest.EventOrigin;
import com.google.common.base.Stopwatch;
import com.theplatform.web.tv.GridException;
import com.theplatform.web.tv.gws.ingest.producer.twitter.json.TwitterTrendingResponse;
import com.theplatform.web.tv.gws.sirius.model.CRSTrendingPrograms;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jmx.export.annotation.ManagedOperation;

/**
 * Ingest trending programs from Twitter and add them to Sirius.
 */
public abstract class TwitterIngester  {
    private final Logger log = LoggerFactory.getLogger(TwitterIngester.class);

    private TwitterClient twitterClient;
    private ScoreEvaluator scoreEvaluator;
    private TwitterMBean mbean;
    private EventDispatcher eventDispatcher;

    @ManagedOperation
    public void runTwitterIngest() throws GridException {
        log.info("Updating trending programs");

        // stats and timing
        mbean.incrementExecutionCount();
        mbean.setLastExecutionTime();
        Stopwatch stopwatch = new Stopwatch().start();

        // get the JSON response from Twitter
        TwitterTrendingResponse twitterTrendingResponse = twitterClient.fetchTrendingResponses();

        // map it to a CRSTrendingPrograms instance and apply our own scoring logic
        CRSTrendingPrograms crsTrendingPrograms = newTwitterToCrsMapper().map(twitterTrendingResponse);
        scoreEvaluator.updateTrendingPrograms(crsTrendingPrograms);

        // add it to Sirius
        Event<CRSTrendingPrograms> putEvent = new Event<>(EventOrigin.EXTERNAL, Action.PUT, crsTrendingPrograms);
        eventDispatcher.publish(putEvent);

            log.info("Completed trending programs update in {}", stopwatch);
    }

    /**
     * Prototype scoped bean provided by Spring.
     * @return a new instance of TwitterResponseToCRSTrendingPrograms with all dependencies autowired
     */
    protected abstract TwitterResponseToCRSTrendingPrograms newTwitterToCrsMapper();

    @Required
    public void setTwitterClient(TwitterClient twitterClient) {
        this.twitterClient = twitterClient;
    }

    @Required
    public void setScoreEvaluator(ScoreEvaluator scoreEvaluator) {
        this.scoreEvaluator = scoreEvaluator;
    }

    @Required
    public void setMbean(TwitterMBean mbean) {
        this.mbean = mbean;
    }

    @Required
    public void setEventDispatcher(EventDispatcher eventDispatcher) {
        this.eventDispatcher = eventDispatcher;
    }

}
