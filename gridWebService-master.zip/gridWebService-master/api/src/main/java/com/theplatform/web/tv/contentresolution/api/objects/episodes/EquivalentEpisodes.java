package com.theplatform.web.tv.contentresolution.api.objects.episodes;

import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.springframework.beans.MethodInvocationException;

import javax.xml.bind.annotation.*;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@XmlAccessorType(XmlAccessType.NONE)
public class EquivalentEpisodes {

    private Set<ProgramInfo> equivalentEpisodes;

    public EquivalentEpisodes() {
        equivalentEpisodes = new HashSet<>();
    }

    public EquivalentEpisodes(Set<ProgramInfo> equivalentEpisodes) {
        this.equivalentEpisodes = equivalentEpisodes;
    }

    @XmlElement(name="episode")
    public Set<ProgramInfo> getEquivalentEpisodes() {
        return equivalentEpisodes;
    }

    public void setEquivalentEpisodes(Set<ProgramInfo> equivalentEpisodes) {
        this.equivalentEpisodes = equivalentEpisodes;
    }

    @JsonIgnore
    public ProgramInfo getOne() {
        if (equivalentEpisodes.size() != 1) {
            return null;
        }

        return equivalentEpisodes.iterator().next();
    }
}
