package com.theplatform.web.tv.contentresolution.api.objects.episodes;

import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class EpisodeSequence {

    private List<EquivalentEpisodes> episodes;

    public EpisodeSequence() {
        episodes = new ArrayList<>();
    }

    public EpisodeSequence(List<Set<ProgramInfo>> episodes) {
        this.episodes = new ArrayList<>();

        for (Set<ProgramInfo> equivalentEpisodes : episodes) {
            this.episodes.add(new EquivalentEpisodes(equivalentEpisodes));
        }
    }

    @XmlElementWrapper(name = "episodeSequence")
    @XmlElement(name = "equivalentEpisodes")
    public List<EquivalentEpisodes> getEpisodes() {
        return episodes;
    }

    public void setEpisodes(List<EquivalentEpisodes> episodes) {
        this.episodes = episodes;
    }

    public int size() {
        return episodes.size();
    }

    public EquivalentEpisodes get(int i) {
        return episodes.get(i);
    }
}
