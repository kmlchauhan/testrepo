package com.theplatform.web.tv.contentresolution.api.client;


import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.authentication.token.api.exception.AuthenticationException;
import com.theplatform.authentication.token.api.exception.UserDisabledException;
import com.theplatform.module.context.thread.CorrelationIdAccessor;
import com.theplatform.module.context.thread.TraceDestinationAccessor;
import com.theplatform.web.api.client.*;
import com.theplatform.web.api.exception.WebServiceException;
import com.theplatform.web.api.marshalling.PayloadForm;
import com.theplatform.web.api.model.Endpoint;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;

import java.io.InputStream;

/**
 * Copied over from theplatform code
 * The original RawWebServiceClient did not support overriding the QueryParameterBuilder
 *
 * @author Jason Coelho
 */
public class CustomRawWebServiceClient extends com.theplatform.web.api.client.RawWebServiceClient {

    private static HttpClient defaultHttpClient = new HttpClient(new MultiThreadedHttpConnectionManager());
    private static QueryStringBuilder queryStringBuilder = new QueryStringBuilder();
    private QueryParameterBuilder queryParameterBuilder;
    private String baseURL;
    private String schema;
    private PayloadForm form;
    private CorrelationIdAccessor correlationIdAccessor;
    private TraceDestinationAccessor traceDestinationAccessor;
    private boolean retryOnAuthenticationException;
    private String pipeline;
    private AdditionalRequestHeaderBuilder additionalRequestHeaderBuilder;

    public CustomRawWebServiceClient( String baseURL,
                                      AuthorizationHeaderFactory authorization,
                                      String schema,
                                      String idForm,
                                      String clientId,
                                      Boolean verboseMode,
                                      String userAgentHeader,
                                      ClientConfiguration clientConfiguration,
                                      Endpoint endpoint,
                                      String pipeline) {
        super(baseURL, authorization, schema);

        setQueryParameterBuilder(createCustomQueryParameterBuilder(idForm, clientId, verboseMode ));

        if (userAgentHeader != null && !userAgentHeader.isEmpty())
            setUserAgent(userAgentHeader);
        if (clientConfiguration.getHttpClient() != null)
            setHttpClient(clientConfiguration.getHttpClient());
        if (clientConfiguration.getProxyHost() != null)
            setProxyHost(clientConfiguration.getProxyHost());
        if (clientConfiguration.getProxyPort() != null)
            setProxyPort(clientConfiguration.getProxyPort().intValue());
        if (clientConfiguration.getUserAgent() != null)
            setUserAgent(clientConfiguration.getUserAgent());
        else
            setUserAgent(String.format("WebServiceClient<%s> 3.5", new Object[]{endpoint.getName().getLocalPart()}));
        setForm(clientConfiguration.getPayloadForm());
        setTrace(clientConfiguration.getTrace());
        setCorrelationIdAccessor(clientConfiguration.getCorrelationIdAccessor());
        setAcceptCompression(clientConfiguration.isAcceptCompression());
        setPipeline(pipeline);
    }

    private CustomQueryParameterBuilder createCustomQueryParameterBuilder(String idForm, String clientId, boolean verboseMode) {
        CustomQueryParameterBuilder queryParameterBuilder = new CustomQueryParameterBuilder();
        queryParameterBuilder.setClientId(clientId);
        queryParameterBuilder.setIdForm(idForm);
        queryParameterBuilder.setVerboseMode(verboseMode);
        return queryParameterBuilder;
    }

    protected void setBaseURL(String baseURL) {
        if (!baseURL.endsWith("/"))
            baseURL = baseURL + "/";
        this.baseURL = baseURL;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public void setForm(PayloadForm form) {
        this.form = form;
    }

    public void setCorrelationIdAccessor(CorrelationIdAccessor correlationIdAccessor) {
        this.correlationIdAccessor = correlationIdAccessor;
    }

    public void setAdditionalRequestHeaderBuilder(AdditionalRequestHeaderBuilder additionalRequestHeaderBuilder) {
        this.additionalRequestHeaderBuilder = additionalRequestHeaderBuilder;
    }

    public void setRetryOnAuthenticationException(boolean retryOnAuthenticationException) {
        this.retryOnAuthenticationException = retryOnAuthenticationException;
    }

    public void setPipeline(String pipeline) {
        this.pipeline = pipeline;
    }

    public RawResponse call(InputStream inputStream) throws WebServiceException {
        String cid = correlationIdAccessor == null ? null : correlationIdAccessor.getCorrelationId();
        ParameterMap parameterMap = queryParameterBuilder.buildQueryStringMap(schema, form, null, cid, pipeline);
        PostMethod method = new PostMethod(this.baseURL);
        method.setQueryString(queryStringBuilder.build(parameterMap));
        if (getAuthorization() != null)
            method.setRequestHeader("Authorization", this.getAuthHeader());

        method.setRequestHeader("Accept-Encoding", isAcceptCompression() ? "gzip" : "");
        method.setRequestHeader("User-Agent", getUserAgent());
        if (cid != null && cid.length() > 0)
            method.setRequestHeader("X-thePlatform-cid", cid);

        if (additionalRequestHeaderBuilder != null)
            additionalRequestHeaderBuilder.setAdditionalHeaders(method);

        InputStreamRequestEntity requestEntity = new InputStreamRequestEntity(inputStream);
        method.setRequestEntity(requestEntity);
        return this.executeHttpMethod(method);
    }

    protected void setQueryParameterBuilder(QueryParameterBuilder queryParameterBuilder) {
        this.queryParameterBuilder = queryParameterBuilder;
    }

    protected String getAuthHeader() {
        try {
            return getAuthorization().getAuthorizationHeader();
        } catch (AuthenticationException var2) {
            throw new com.theplatform.module.exception.AuthenticationException(var2.getMessage(), var2);
        } catch (UserDisabledException var3) {
            throw new com.theplatform.module.exception.AuthenticationException(var3.getMessage(), var3);
        }
    }

    static {
        String proxyHost = System.getProperty("http.proxyHost");
        if (proxyHost == null)
            proxyHost = System.getProperty("proxyHost");

        String proxyPort = System.getProperty("http.proxyPort");
        if (proxyPort == null)
            proxyPort = System.getProperty("proxyPort");

        if (proxyHost != null && proxyPort != null)
            defaultHttpClient.getHostConfiguration().setProxy(proxyHost, Integer.parseInt(proxyPort));

        defaultHttpClient.getHttpConnectionManager().getParams().setDefaultMaxConnectionsPerHost(20);
    }
}
