package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.Arrays;

/**
 * @author jcoelho
 */
@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class MergeProfile {

    private Muri mergeProfileId;

    public MergeProfile(Muri mergeProfileId) {
        this.mergeProfileId = mergeProfileId;
    }

    public Muri getMergeProfileId() {
        return mergeProfileId;
    }

    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, Arrays.asList("uniqueProductContext"));
    }

    public boolean equals(MergeProfile o) {
        return EqualsBuilder.reflectionEquals(o, this, Arrays.asList("uniqueProductContext"));
    }

}
