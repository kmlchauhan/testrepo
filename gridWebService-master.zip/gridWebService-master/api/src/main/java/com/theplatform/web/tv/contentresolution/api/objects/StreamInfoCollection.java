package com.theplatform.web.tv.contentresolution.api.objects;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
@Deprecated                                         // LocatorInfoCollection replaced this in 1.21
public class StreamInfoCollection extends ContentResolutionResponse implements VisitableApiObject {
    public final static StreamInfoCollection EMPTY;

    static {
        EMPTY = new StreamInfoCollection();
        List<StreamInfo> emptyList = Collections.emptyList();
        EMPTY.setStreams(emptyList);
    }

    private List<StreamInfo> streams;

    public StreamInfoCollection() {
        super();
        streams = new ArrayList<>();
    }

    public List<StreamInfo> getStreams() {
        return streams;
    }

    public void setStreams(List<StreamInfo> streams) {
        this.streams = streams;
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((streams == null) ? 0 : streams.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        StreamInfoCollection other = (StreamInfoCollection) obj;
        if (streams == null) {
            if (other.streams != null)
                return false;
        } else if (!streams.equals(other.streams))
            return false;
        return true;
    }

    public void accept(ApiObjectVisitor visitor) {
        visitor.visitStreamInfoCollection(this);
        if (streams != null) {
            for (StreamInfo current : streams) {
                if (current != null) {
                    current.accept(visitor);
                }
            }
        }
    }
}
