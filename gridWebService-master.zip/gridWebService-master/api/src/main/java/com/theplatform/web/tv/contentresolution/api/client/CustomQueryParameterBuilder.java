package com.theplatform.web.tv.contentresolution.api.client;

import com.theplatform.web.api.client.ParameterMap;
import com.theplatform.web.api.client.QueryParameterBuilder;
import com.theplatform.web.api.marshalling.PayloadForm;

import java.util.Arrays;

/**
 * Extended thePlatform's query parameter builder because it did not support adding of
 * clientId and idForm to the request parameters.
 *
 * @author jcoelho
 * @since 8/7/14.
 */
public class CustomQueryParameterBuilder extends QueryParameterBuilder {

    private String clientId;
    private String idForm;
    private boolean verboseMode;

    public ParameterMap buildQueryStringMap(String schema, PayloadForm form, String trace, String cid, String pipeline) {
        ParameterMap parameterMap = super.buildQueryStringMap(schema, form, trace, cid, pipeline);
        parameterMap.put("clientId", Arrays.asList(clientId));
        parameterMap.put("idForm", Arrays.asList(idForm));
        parameterMap.put("verboseMode", Arrays.asList(Boolean.toString(verboseMode)));
        return parameterMap;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public void setIdForm(String idForm) {
        this.idForm = idForm;
    }

    public void setVerboseMode(boolean verboseMode) {
        this.verboseMode = verboseMode;
    }
}
