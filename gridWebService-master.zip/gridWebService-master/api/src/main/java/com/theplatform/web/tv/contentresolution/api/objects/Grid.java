package com.theplatform.web.tv.contentresolution.api.objects;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.ArrayList;
import java.util.List;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class Grid extends ContentResolutionResponse implements VisitableApiObject {
    
    private String title;
    private List<Header> header;
    private List<ChannelInfo> channels;

    public Grid() {
        super();
        header   = new ArrayList<Header>();
        channels = new ArrayList<ChannelInfo>();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<Header> getHeader() {
        return header;
    }

    public void setHeader(List<Header> header) {
        this.header = header;
    }

    public List<ChannelInfo> getChannels() {
        return channels;
    }

    public void setChannels(List<ChannelInfo> channels) {
        this.channels = channels;
    }

    public void addHeader(Header header) {
        this.header.add(header);
    }

    public void addChannel(ChannelInfo channel) {
        this.channels.add(channel);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((title == null) ? 0 : title.hashCode());
        result = prime * result + ((header == null) ? 0 : header.hashCode());
        result = prime * result + ((channels == null) ? 0 : channels.hashCode());
        return result;
    }

    public void accept(ApiObjectVisitor visitor) {
        visitor.visitGrid(this);

        if (header != null) {
            for (Header current : header) {
                if (current != null) {
                    visitor.visitHeader(current);
                }
            }
        }

        if (channels != null) {
            for (ChannelInfo current : channels) {
                if (current != null) {
                    current.accept(visitor);
                }
            }
        }
    }
}
