package com.theplatform.web.tv;

import com.theplatform.web.api.exception.WebServiceException;

/**
 * Exception class for the Grid Service
 */
public class GridException extends WebServiceException {

    private static final long serialVersionUID = 1L;

    public GridException(String message) {
        super(message);
    }

    public GridException(String message, Throwable cause) {
        super(message, cause);
    }

    public GridException(Throwable cause) {
        super(cause);
    }
}