package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlList;
import javax.xml.bind.annotation.XmlValue;
import java.util.ArrayList;
import java.util.List;

import static org.apache.commons.lang.builder.HashCodeBuilder.reflectionHashCode;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class MainImageImageTypeList {
    private List<Muri> mainImageImageTypes;

    public MainImageImageTypeList (){
        mainImageImageTypes = new ArrayList<Muri>();
    }
    
    @XmlList
    @XmlValue
    public List<Muri> getMainImageImageTypes() {
        return mainImageImageTypes;
    }

    public void setMainImageImageTypes(List<Muri> link) {
        this.mainImageImageTypes = link;
    }

    @Override
    public int hashCode() {
        return reflectionHashCode(this);
    }

}
