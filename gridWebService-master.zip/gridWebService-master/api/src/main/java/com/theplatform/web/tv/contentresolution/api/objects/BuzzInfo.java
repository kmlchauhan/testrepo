package com.theplatform.web.tv.contentresolution.api.objects;



import com.theplatform.contrib.data.api.objects.Muri;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.HashMap;
import java.util.Map;

/**
 * (C) Comcast
 * User: jstoke201
 * Date: 7/19/13
 * Time: 2:01 PM
 */
@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class BuzzInfo {
    private Map <Muri, Integer> buzzMap= new HashMap<Muri, Integer>();

    public Map<Muri, Integer> getBuzzMap() {
        return buzzMap;
    }

    public void setBuzzMap(Map<Muri, Integer> buzzMap) {
        this.buzzMap = buzzMap;
    }
}
