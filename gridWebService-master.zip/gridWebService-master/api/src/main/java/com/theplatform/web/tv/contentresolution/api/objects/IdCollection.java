package com.theplatform.web.tv.contentresolution.api.objects;


import com.theplatform.contrib.data.api.objects.Muri;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class IdCollection {
    private List<Muri> ids;
    public IdCollection(){
        ids = new ArrayList<>();
    }

    public List<Muri> getIds() {
        return ids;
    }

    public void setIds(List<Muri> ids) {
        if (ids!=null){
            Collections.sort(ids);
        }
        this.ids = ids;
    }


    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }


    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }


}
