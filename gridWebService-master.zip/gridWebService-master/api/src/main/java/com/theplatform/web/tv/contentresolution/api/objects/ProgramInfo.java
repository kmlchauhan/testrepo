package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.contrib.data.api.objects.Muri;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.List;

import static org.apache.commons.lang.builder.HashCodeBuilder.reflectionHashCode;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class ProgramInfo implements VisitableApiObject {

    protected Muri programId;
    protected String title;
    protected String gridTitle;
    protected String category;
    protected Muri seriesId;
    protected String type;
    protected String episodeTitle;
    protected String sportsSubtitle;
    protected Boolean adult;
    protected List<Muri> tagIds;
    private List<Rating> contentRatings;
    private Integer tvSeasonNumber;
    private Integer tvSeasonEpisodeNumber;
    private Integer seriesEpisodeNumber;
    private Integer partNumber;
    private Integer totalParts;
    private String language;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGridTitle() {
        return gridTitle;
    }

    public void setGridTitle(String gridTitle) {
        this.gridTitle = gridTitle;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEpisodeTitle() {
        return episodeTitle;
    }

    public void setEpisodeTitle(String episodeTitle) {
        this.episodeTitle = episodeTitle;
    }

    public Muri getProgramId() {
        return programId;
    }

    public void setProgramId(Muri programId) {
        this.programId = programId;
    }

    public Muri getSeriesId() {
        return seriesId;
    }

    public void setSeriesId(Muri seriesId) {
        this.seriesId = seriesId;
    }

    public String getSportsSubtitle() {
        return sportsSubtitle;
    }

    public void setSportsSubtitle(String sportsSubtitle) {
        this.sportsSubtitle = sportsSubtitle;
    }

    public Boolean getAdult() {
        return adult;
    }

    public void setAdult(Boolean adult) {
        this.adult = adult;
    }

    public List<Muri> getTagIds() {
        return tagIds;
    }

    public void setTagIds(List<Muri> tagIds) {
        this.tagIds = tagIds;
    }

    public List<Rating> getContentRatings() {
        return contentRatings;
    }

    public void setContentRatings(List<Rating> contentRatings) {
        this.contentRatings = contentRatings;
    }

    public Integer getTvSeasonNumber() {
        return tvSeasonNumber;
    }

    public void setTvSeasonNumber(Integer tvSeasonNumber) {
        this.tvSeasonNumber = tvSeasonNumber;
    }

    public Integer getTvSeasonEpisodeNumber() {
        return tvSeasonEpisodeNumber;
    }

    public void setTvSeasonEpisodeNumber(Integer tvSeasonEpisodeNumber) {
        this.tvSeasonEpisodeNumber = tvSeasonEpisodeNumber;
    }

    public Integer getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(Integer partNumber) {
        this.partNumber = partNumber;
    }

    public Integer getTotalParts() {
        return totalParts;
    }

    public void setTotalParts(Integer totalParts) {
        this.totalParts = totalParts;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public void accept(ApiObjectVisitor visitor) {
        visitor.visitProgramInfo(this);
    }

    @Override
    public int hashCode() {
        return reflectionHashCode(this);
    }

    public Integer getSeriesEpisodeNumber() {
        return seriesEpisodeNumber;
    }

    public void setSeriesEpisodeNumber(Integer seriesEpisodeNumber) {
        this.seriesEpisodeNumber = seriesEpisodeNumber;
    }
}
