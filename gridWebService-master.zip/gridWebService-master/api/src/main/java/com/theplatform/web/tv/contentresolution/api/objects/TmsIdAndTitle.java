package com.theplatform.web.tv.contentresolution.api.objects;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Date: 3/25/14
 *
 * @author mmattozzi
 */
@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class TmsIdAndTitle {

    private static Pattern TMS_ID_AND_TITLE_PATTERN = Pattern.compile("(.*)\\s\\(([A-Z]{2}\\d+)\\)");

    protected String tmsId;
    protected String title;

    public TmsIdAndTitle() {
    }

    public TmsIdAndTitle(String tmsId, String title) {
        this.tmsId = tmsId;
        this.title = title;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TmsIdAndTitle that = (TmsIdAndTitle) o;

        if (tmsId != null ? !tmsId.equals(that.tmsId) : that.tmsId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return tmsId != null ? tmsId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return String.format("%s (%s)", title, tmsId);
    }

    public static TmsIdAndTitle fromString(String input) {
        Matcher matcher = TMS_ID_AND_TITLE_PATTERN.matcher(input);
        if (matcher.matches()) {
            return new TmsIdAndTitle(matcher.group(2), matcher.group(1));
        } else {
            return new TmsIdAndTitle("UNKNOWN", "UNKNOWN");
        }
    }

    public String getTmsId() {
        return tmsId;
    }

    public void setTmsId(String tmsId) {
        this.tmsId = tmsId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
