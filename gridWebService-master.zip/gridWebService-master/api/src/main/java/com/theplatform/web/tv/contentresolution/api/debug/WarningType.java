package com.theplatform.web.tv.contentresolution.api.debug;


/**
 * Used by Debug Mode (see VerboseInfo) to define what we are warning about.
 *
 */
public enum WarningType{
    InvalidObject,                // Object does not exist in the CRS Repository
    ProductContextDropped,        // ProductContext was dropped from Channel
    ChannelDropped,               // Channel was dropped
    StreamWarning;               // Warning related to stream lookup

}
