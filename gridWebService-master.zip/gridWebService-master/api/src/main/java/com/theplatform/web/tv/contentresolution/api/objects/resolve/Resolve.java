package com.theplatform.web.tv.contentresolution.api.objects.resolve;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import com.theplatform.contrib.data.api.objects.Muri;
import org.apache.commons.lang3.StringUtils;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.web.tv.contentresolution.api.objects.MainImageImageTypeList;
import com.theplatform.web.tv.contentresolution.api.objects.MergeProfile;

/**
 * Domain Object representing data that will be sent to the content resolution service.
 *
 * @author jcoelho
 */
public abstract class Resolve {

    private AvailabilityResolution availabilityResolution;
    @Deprecated
    private MergeProfile mergeProfile;
    private MainImageImageTypeList mainImageImageTypeList;


    @XmlElement(name = "resolveAvailabilityResponse", namespace = "http://xml.theplatform.com/tv/web/AvailabilityResolution")
    final public AvailabilityResolution getAvailabilityResolution() {
        return availabilityResolution;
    }

    final public void setAvailabilityResolution(AvailabilityResolution availabilityResolution) {
        this.availabilityResolution = availabilityResolution;
    }

    @Deprecated
    @XmlElement(namespace = "http://xml.theplatform.com/tv/web/AvailabilityResolution")
    final public String getMergeProfile() {
        if (mergeProfile != null)
            return mergeProfile.getMergeProfileId().toString();
        else
            return null;
    }

    @Deprecated
    final public void setMergeProfile(String mergeProfile) {
        this.mergeProfile = new MergeProfile(new Muri(mergeProfile));
    }

    @XmlElement(namespace = "http://xml.theplatform.com/tv/web/AvailabilityResolution")
    final public String getMainImageImageTypeList() {
        List<String> mainImage = new ArrayList<String>();
        if (mainImageImageTypeList != null) {
            List<Muri> mainImageImageTypes = mainImageImageTypeList.getMainImageImageTypes();
            for (Muri Muri : mainImageImageTypes)
                mainImage.add(Muri.toString());
        }
        return StringUtils.join(mainImage, ",");
    }

    final public void setMainImageImageTypeList(String mainImageImageTypeList) {
        if (mainImageImageTypeList != null) {
            List<Muri> mainImageTypes = new ArrayList<Muri>();
            for (String CRSUri : mainImageImageTypeList.split(","))
                mainImageTypes.add( new Muri(CRSUri));

            MainImageImageTypeList m = new MainImageImageTypeList();
            m.setMainImageImageTypes(mainImageTypes);
            this.mainImageImageTypeList = m;
        }
    }
}
