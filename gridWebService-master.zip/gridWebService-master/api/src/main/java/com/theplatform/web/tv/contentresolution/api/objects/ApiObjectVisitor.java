package com.theplatform.web.tv.contentresolution.api.objects;


import com.theplatform.contrib.data.api.objects.Muri;

import java.util.Collection;
import java.util.Map;

/**
 * Avoid boilerplate for loops and null checks to change a few properties on a deeply nested object -
 * extend this class and pass an instance of your visitor to the {@link VisitableApiObject#accept(ApiObjectVisitor visitor)} accept method}
 * of any VisitableApiObject.
 */
public abstract class ApiObjectVisitor {
    public void visitGrid(Grid grid) {}

    public void visitHeader(Header header) {}

    public void visitChannelInfoCollection(ChannelInfoCollection channelInfoCollection) {}

    public void visitChannelInfo(ChannelInfo channelInfo) {}

    public void visitStationInfo(StationInfo stationInfo) {}

    public void visitCompanyAssociationInfo(CompanyAssociationInfo companyAssociationInfo) {}

    public void visitProductContextInfo(ProductContextInfo productContextInfo) {}

    public void visitStreamInfoCollection(StreamInfoCollection streamInfoCollection) {}

    public void visitStreamInfo(StreamInfo streamInfo) {}

    public void visitLocatorInfo(LocatorInfo locatorInfo) {}

    public void visitLocatorInfoCollection(LocatorInfoCollection locatorInfoCollection){}

    public void visitListingInfo(ListingInfo listingInfo) {}

    public void visitProgramInfo(ProgramInfo programInfo) {}

    public void visitTrendingPrograms(TrendingPrograms trendingPrograms) {}

    public void visitTrendingProgram(TrendingProgram trendingProgram) {}

    public <T extends VisitableApiObject, C extends Collection<T>> C visitEach(C objects) {
        for (VisitableApiObject current : objects) {
            current.accept(this);
        }
        return objects;
    }

    public void visitEpisodeMap(EpisodesMap episodesMap){
        if (episodesMap == null || episodesMap.getEpisodeIdToEpisodes()==null) {
            return;
        }
        Map<Muri, ProgramInfo[]> episodeIdToEpisodes = episodesMap.getEpisodeIdToEpisodes();
        for (Muri muri :  episodeIdToEpisodes.keySet()){
            for (ProgramInfo programInfo : episodeIdToEpisodes.get(muri)){
                visitProgramInfo(programInfo);
            }
        }
    }

    public static ApiObjectVisitor chain(ApiObjectVisitor...visitors) {
        return new ChainedApiObjectVisitor(visitors);
    }

    public static ApiObjectVisitor NO_OP = new ApiObjectVisitor() {};

    private static class ChainedApiObjectVisitor extends ApiObjectVisitor {
        private ApiObjectVisitor[] visitors;

        public ChainedApiObjectVisitor(ApiObjectVisitor[] visitors) {
            this.visitors = visitors;
        }

        @Override
        public void visitGrid(Grid grid) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitGrid(grid);
            }
        }

        @Override
        public void visitHeader(Header header) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitHeader(header);
            }
        }

        @Override
        public void visitChannelInfoCollection(ChannelInfoCollection channelInfoCollection) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitChannelInfoCollection(channelInfoCollection);
            }
        }

        @Override
        public void visitChannelInfo(ChannelInfo channelInfo) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitChannelInfo(channelInfo);
            }
        }

        @Override
        public void visitStationInfo(StationInfo stationInfo) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitStationInfo(stationInfo);
            }
        }

        @Override
        public void visitCompanyAssociationInfo(CompanyAssociationInfo companyAssociationInfo) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitCompanyAssociationInfo(companyAssociationInfo);
            }
        }

        @Override
        public void visitProductContextInfo(ProductContextInfo productContextInfo) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitProductContextInfo(productContextInfo);
            }
        }

        @Override
        public void visitStreamInfoCollection(StreamInfoCollection streamInfoCollection) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitStreamInfoCollection(streamInfoCollection);
            }
        }

        @Override
        public void visitStreamInfo(StreamInfo streamInfo) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitStreamInfo(streamInfo);
            }
        }

        @Override
        public void visitLocatorInfo(LocatorInfo locatorInfo) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitLocatorInfo(locatorInfo);
            }
        }

        @Override
        public void visitListingInfo(ListingInfo listingInfo) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitListingInfo(listingInfo);
            }
        }

        @Override
        public void visitProgramInfo(ProgramInfo programInfo) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitProgramInfo(programInfo);
            }
        }

        @Override
        public void visitTrendingPrograms(TrendingPrograms trendingPrograms) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitTrendingPrograms(trendingPrograms);
            }
        }

        @Override
        public void visitTrendingProgram(TrendingProgram trendingProgram) {
            for (ApiObjectVisitor visitor : visitors) {
                visitor.visitTrendingProgram(trendingProgram);
            }
        }
    }
}
