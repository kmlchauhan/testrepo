package com.theplatform.web.tv.contentresolution.api.objects;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.ArrayList;
import java.util.List;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class LocatorInfoCollection extends ContentResolutionResponse implements VisitableApiObject {
    private List<LocatorInfo> locatorInfos;

    public LocatorInfoCollection(){
        super();
        locatorInfos = new ArrayList<>();
    }

    public void setLocatorInfos(List<LocatorInfo> locatorInfos) {
        this.locatorInfos = locatorInfos;
    }

    public List<LocatorInfo> getLocatorInfos() {
        return locatorInfos;
    }
    public void accept(ApiObjectVisitor visitor) {
        visitor.visitLocatorInfoCollection(this);
        if (locatorInfos != null) {
            for (LocatorInfo current : locatorInfos) {
                if (current != null) {
                    current.accept(visitor);
                }
            }
        }
    }
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }


    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

}
