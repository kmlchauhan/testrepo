package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import java.util.HashSet;
import java.util.Set;

@JsonPropertyOrder(alphabetic = true)
public class AssociatedStations {
    private Set<Muri> sd = new HashSet<>();
    private Set<Muri> hd = new HashSet<>();
    private Set<Muri> uhd = new HashSet<>();

    @JsonProperty("SD")
    public Set<Muri> getSd() {
        return sd;
    }

    public void setSd(Set<Muri> sd) {
        this.sd = sd;
    }

    @JsonProperty("HD")
    public Set<Muri> getHd() {
        return hd;
    }

    public void setHd(Set<Muri> hd) {
        this.hd = hd;
    }

    @JsonProperty("UHD")
    public Set<Muri> getUhd() {
        return uhd;
    }

    public void setUhd(Set<Muri> uhd) {
        this.uhd = uhd;
    }

    public void addSd(Muri stationId) {
        sd.add(stationId);
    }

    public void addHd(Muri stationId) {
        hd.add(stationId);
    }

    public void addUhd(Muri stationId) {
        uhd.add(stationId);
    }
}
