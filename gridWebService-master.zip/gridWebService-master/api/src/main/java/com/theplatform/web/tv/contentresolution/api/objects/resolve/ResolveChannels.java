package com.theplatform.web.tv.contentresolution.api.objects.resolve;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author jcoelho
 */
@XmlRootElement(name = "resolveChannels", namespace = "http://xml.theplatform.com/tv/web/AvailabilityResolution")
public final class ResolveChannels extends Resolve {

}
