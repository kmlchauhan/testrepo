package com.theplatform.web.tv.contentresolution.api.client;

import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.contrib.web.api.client.HeaderStuffingBaseWebServiceClient;
import com.theplatform.web.api.client.ClientConfiguration;
import com.theplatform.web.api.model.Endpoint;
import com.theplatform.web.tv.contentresolution.api.ContentResolutionService;

/**
 * API client for the Grid Web Service
 */
public class ContentResolutionClient extends HeaderStuffingBaseWebServiceClient<ContentResolutionService> {

    public ContentResolutionClient(String baseUrl,
                                   AuthorizationHeaderFactory authorization,
                                   ClientConfiguration clientConfiguration,
                                   String idForm,
                                   String clientId) {
        this(baseUrl, authorization, clientConfiguration, idForm, clientId, false, null);
    }

    public ContentResolutionClient(String baseUrl,
                                   AuthorizationHeaderFactory authorization,
                                   ClientConfiguration clientConfiguration,
                                   String idForm,
                                   String clientId,
                                   Boolean verboseMode) {
        this(baseUrl, authorization, clientConfiguration, idForm, clientId, verboseMode, null);
    }

    public ContentResolutionClient(String baseUrl,
                                   AuthorizationHeaderFactory authorization,
                                   ClientConfiguration clientConfiguration,
                                   String idForm,
                                   String clientId,
                                   String schema) {
        this(baseUrl, authorization, clientConfiguration, idForm, clientId, false, schema);
    }

    private ContentResolutionClient(String baseUrl,
                                   AuthorizationHeaderFactory authorization,
                                   ClientConfiguration clientConfiguration,
                                   String idForm,
                                   String clientId,
                                   Boolean verboseMode,
                                   String schema ) {
        super(baseUrl, authorization, clientConfiguration);
        Endpoint endpoint = new Endpoint(this.getServiceInterface());
        // If the schema is not specified, assume the latest.
        if (schema==null){
            schema=endpoint.getVersion();
        }
        this.rawClient = createRawWebServiceClient( authorization,
                                                    clientConfiguration,
                                                    idForm,
                                                    clientId,
                                                    verboseMode,
                                                    endpoint,
                                                    schema);
    }

    private CustomRawWebServiceClient createRawWebServiceClient(AuthorizationHeaderFactory authorization,
                                                                ClientConfiguration clientConfiguration,
                                                                String idForm,
                                                                String clientId,
                                                                Boolean verboseMode,
                                                                Endpoint endpoint,
                                                                String schema) {
        return new CustomRawWebServiceClient( getRequestURL(),
                                              authorization,
                                              schema,
                                              idForm,
                                              clientId,
                                              verboseMode,
                                              buildUserAgentHeader(),
                                              clientConfiguration,
                                              endpoint,getPipeline());
    }

    protected Class<ContentResolutionService> getServiceInterface() {
        return ContentResolutionService.class;
    }
}
