package com.theplatform.web.tv.contentresolution.api.notifications;

/**
 * API for out-bound notifications.
 * <br><br>
 *
 */