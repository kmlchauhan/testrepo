package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.HashMap;
import java.util.Map;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class LocatorInfo implements Comparable<LocatorInfo> {

    private Muri locatorId;
    private String format;
    private Muri locatorUri;
    private Integer width;                  
    private Integer height;                 
    private Long bitrate;                   
    private String codec;
    private String protectionScheme;
    private String provider;
    private String externalStreamId;

    // Stream Related Fields. Added in 1.21
    private Muri streamId;
    private Muri primaryStreamUrn;
    private String status;
    private Boolean external;
    private Boolean isDai;
    private Boolean travelRights;
    private String serviceZoneType;
    private String type;

    private Muri namespaceId;
    private String namespaceTitle;

    private String quality;
    private Map<String, String> playerConfig;

    public Muri getLocatorId() {
        return locatorId;
    }

    public void setLocatorId(Muri locatorId) {
        this.locatorId = locatorId;
    }

    /**
     * @return the format
     */
    public String getFormat() {
        return format;
    }

    /**
     * @param format the format to set
     */
    public void setFormat(String format) {
        this.format = format;
    }
    /**
     * @return the height
     */
    public Integer getHeight() {
        return height;
    }

    /**
     * @param height the height to set
     */
    public void setHeight(Integer height) {
        this.height = height;
    }

    /**
     * @return the width
     */
    public Integer getWidth() {
        return width;
    }

    /**
     * @param width the width to set
     */
    public void setWidth(Integer width) {
        this.width = width;
    }

    /**
     * @return the bitrate
     */
    public Long getBitrate() {
        return bitrate;
    }

    /**
     * @param bitrate the bitrate to set
     */
    public void setBitrate(Long bitrate) {
        this.bitrate = bitrate;
    }

    public Muri getLocatorUri() {
        return locatorUri;
    }

    public void setLocatorUri(Muri locatorUri) {
        this.locatorUri = locatorUri;
    }

    public String getCodec() {
        return codec;
    }

    public void setCodec(String codec) {
        this.codec = codec;
    }

    public String getProtectionScheme() {
        return protectionScheme;
    }

    public void setProtectionScheme(String protectionScheme) {
        this.protectionScheme = protectionScheme;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getExternalStreamId() {
        return externalStreamId;
    }

    public void setExternalStreamId(String externalStreamId) {
        this.externalStreamId = externalStreamId;
    }

    public Muri getStreamId() {
        return streamId;
    }

    public void setStreamId(Muri streamId) {
        this.streamId = streamId;
    }

    public Muri getPrimaryStreamUrn() {
        return primaryStreamUrn;
    }

    public void setPrimaryStreamUrn(Muri primaryStreamUrn) {
        this.primaryStreamUrn = primaryStreamUrn;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Boolean getExternal() {
        return external;
    }

    public void setExternal(Boolean external) {
        this.external = external;
    }

    public Boolean getIsDai() {
        return isDai;
    }

    public void setIsDai(Boolean dai) {
        isDai = dai;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public Boolean getTravelRights() {
        return travelRights;
    }

    public void setTravelRights(Boolean travelRights) {
        this.travelRights = travelRights;
    }

    public String getServiceZoneType() {
        return serviceZoneType;
    }

    public void setServiceZoneType(String serviceZoneType) {
        this.serviceZoneType = serviceZoneType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Muri getNamespaceId() {
        return namespaceId;
    }

    public void setNamespaceId(Muri namespaceId) {
        this.namespaceId = namespaceId;
    }

    public String getNamespaceTitle() {
        return namespaceTitle;
    }

    public void setNamespaceTitle(String namespaceTitle) {
        this.namespaceTitle = namespaceTitle;
    }

    public Map<String, String> getPlayerConfig() {
        return playerConfig;
    }

    public void setPlayerConfig(Map<String, String> playerConfig) {
        this.playerConfig = playerConfig;
    }

    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }


    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

    public void accept(ApiObjectVisitor visitor) {
        visitor.visitLocatorInfo(this);
        // No other Info Objects
    }


    @Override
    public int compareTo(LocatorInfo other) {
        // At least LocatorId or LocatorURI are required but not both.
        // Sort by LocatorID First and LocatorURI Second

        if (locatorId!=null && other.getLocatorId()!=null) {
            return locatorId.compareTo(other.getLocatorId());
        } else if (locatorId!=null && other.getLocatorId()==null){
            return -1;
        } else if (locatorId==null && other.getLocatorId()!=null){
            return 1;
        } else {
            return locatorUri.compareTo(other.getLocatorUri());
        }

    }
}
