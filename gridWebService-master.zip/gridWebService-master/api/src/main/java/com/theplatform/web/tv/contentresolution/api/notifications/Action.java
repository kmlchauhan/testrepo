package com.theplatform.web.tv.contentresolution.api.notifications;

/**
 * Outbound Notification are either CREATE or DELETE
 *
 */
public enum Action {

    /**
     * Notification of Create or Update
     */
    PUT,

    /**
     * Notification of Delete
     */
    DELETE;
}
