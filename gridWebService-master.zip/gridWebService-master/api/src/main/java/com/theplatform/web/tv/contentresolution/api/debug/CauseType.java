package com.theplatform.web.tv.contentresolution.api.debug;

/**
 * Used by Debug Mode (see VerboseInfo) to define the cause of a warning.
 *
 */
public enum CauseType {
    AvailabilityNotFound,             // Availability Id not in the CRS Repo
    ProgramNotFound,                  // Program not in the CRS Repo
    PhaseII,                          // Related to the Old ProductContext Logic, Phase II check
    NoStationCA,                      // A matching Station ContentAvailability was not found.
    DefaultStream,                    // The default stream was applied
    NoStreamCA,                       // A matching Stream ContentAvailability was not found.
    MultipleStreams,                  // When multiple Stream ContentAvailabilitys match, only one stream can be
                                      // applied to the response.  Record the alternate.
    NoProductContext,                 // No ProductContext Ids.  All ProductContext we removed
                                      // Possible Reasons, PhaseII (old PC Logic) check or No Station CA (new logic)
    NotOnTaggingWhitelist,            // Channel/Station no on the tagging whitelist.
    NoComesBeforeNhlChannel;          // See NhlChannelHelper. If a ComesBefore onDemand NHL channel is identified but
                                      // the channel for it to come before does not exist.
}

