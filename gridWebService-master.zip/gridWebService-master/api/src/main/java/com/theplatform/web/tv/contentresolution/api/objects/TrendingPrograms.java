package com.theplatform.web.tv.contentresolution.api.objects;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlTransient;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Date: 2/6/14
 *
 * @author mmattozzi
 */
@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class TrendingPrograms implements VisitableApiObject {

    protected List<TrendingProgram> trendingPrograms = new ArrayList<>();
    protected Date retrievedTime;
    protected Long timeToLive;

    public List<TrendingProgram> getTrendingPrograms() {
        return trendingPrograms;
    }

    public void setTrendingPrograms(List<TrendingProgram> trendingPrograms) {
        this.trendingPrograms = trendingPrograms;
    }

    public Date getRetrievedTime() {
        return retrievedTime;
    }

    public void setRetrievedTime(Date retrievedTime) {
        this.retrievedTime = retrievedTime;
    }

    /**
     * Calculate the maximum age based on the current system time, the time when the results were retrieved, and the TTL.
     * If the the results have already expired (current time is past retrievedTime + timeToLive) zero is returned.
     * @return an integer greater than or equal to zero or null if retrievedTime or timeToLive were not set.
     */
    public Long getMaxAge() {
        if (retrievedTime != null && timeToLive != null) {
            Long timeSinceOld=new Date().getTime()-retrievedTime.getTime();
            Long timeTillNext=timeToLive-(timeSinceOld/1000);
            if (timeTillNext<0){
                timeTillNext=0L;
            }
            return timeTillNext;
        } else {
            return null;
        }
    }

    @JsonIgnore
    @XmlTransient
    public Long getTimeToLive() {
        return timeToLive;
    }

    /**
     * Set the time to live in seconds.  Null values are permitted.
     * @param timeToLive time to live in seconds.
     */
    public void setTimeToLive(Long timeToLive) {
        this.timeToLive = timeToLive;
    }


    public void accept(ApiObjectVisitor visitor) {
        visitor.visitTrendingPrograms(this);
        if (trendingPrograms != null) {
            for (TrendingProgram current : trendingPrograms) {
                if (current != null) {
                    current.accept(visitor);
                }
            }
        }
    }
}
