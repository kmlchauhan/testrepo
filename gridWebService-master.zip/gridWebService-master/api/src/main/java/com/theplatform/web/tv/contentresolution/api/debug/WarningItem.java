package com.theplatform.web.tv.contentresolution.api.debug;

import com.theplatform.contrib.data.api.objects.Muri;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.Collection;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import static org.apache.commons.lang.builder.EqualsBuilder.reflectionEquals;

/**
 *  This class provides details that led to the warning.  This class will be sparsely populated only with values
 *  relevant to the warning.
 *
 */
@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class WarningItem implements Comparable<WarningItem>{
    private Muri channelId;
    private Muri stationId;
    private Muri availabilityId;
    private Muri listingId;
    private Muri programId;
    private Muri streamId;
    private Set<Muri> productContextIds;
    private Muri alternateId;               // When there are multiple matches the unused alternate id is specified here.
    private Muri alternateLocatorId;          // When there are alternate Stream Ids, this will list the locatorId that was dropped.

    private static final Comparator<Muri> CRSURI_COMPARATOR =
            new Comparator<Muri>() {
                public int compare(Muri a, Muri b) {
                    if (a.getId() < b.getId()){
                        return -1;
                    } else if (a.getId() > b.getId()){
                        return 1;
                    } else {
                        return 0;
                    }
                }
            };


    public static WarningItem instance(){
        return new WarningItem();
    }

    public Muri getChannelId() {
        return channelId;
    }

    public WarningItem setChannelId(Muri id) {
        if (id == null) return this;
        this.channelId = id;
        return this;
    }

    public Muri getAvailabilityId() {
        return availabilityId;
    }

    public WarningItem setAvailabilityId(Muri id) {
        if (id == null) return this;
        this.availabilityId = id;
        return this;
    }

    public Muri getProgramId() {
        return programId;
    }

    public WarningItem setProgramId(Muri id) {
        if (id == null) return this;
        this.programId = id;
        return this;
    }

    public Set<Muri> getProductContextIds() {
        return productContextIds;
    }

    public WarningItem setProductContextIds(Collection<Muri> productContextIds) {
        this.productContextIds = new TreeSet<>( CRSURI_COMPARATOR );
        this.productContextIds.addAll(productContextIds);
        return this;
    }

    public WarningItem addProductContextId(Muri id) {
        if (id == null) return this;
        if (productContextIds == null){
            productContextIds = new TreeSet<>(CRSURI_COMPARATOR);
        }
        this.productContextIds.add(id);
        return this;
    }

    /**
     *  When there are multiple matches the unused ID will be populated in the alternateId.
     *
     */
    public Muri getAlternateId() {
        return alternateId;
    }

    public WarningItem setAlternateId(Muri id) {
        if (id == null) return this;
        this.alternateId = id;
        return this;
    }

    public Muri getAlternateLocatorId() {
        return alternateLocatorId;
    }

    public WarningItem setAlternateLocatorId(Muri id) {
        if (id == null) return this;
        this.alternateLocatorId = id;
        return this;
    }

    public Muri getStreamId() {
        return streamId;
    }

    public WarningItem setStreamId(Muri id) {
        if (id == null) return this;
        this.streamId = id;
        return this;
    }

    public Muri getListingId() {
        return listingId;
    }

    public WarningItem setListingId(Muri id) {
        if (id == null) return this;
        this.listingId = id;
        return this;
    }

    public Muri getStationId() {
        return stationId;
    }

    public WarningItem setStationId(Muri id) {
        if (id == null) return this;
        this.stationId = id;
        return this;
    }

    /**
     * Return a string that should be easy to search in Splunk
     * Write out numbers and not the entire URI to make it easier to splunk.
     * e.g.   streamId=8838313091489045163
     */
    @Override
    public String toString(){
        StringBuilder builder = new StringBuilder();

        if (channelId!=null){
            builder.append(" channelId=").append(channelId.getId());
        }
        if (stationId!=null){
            builder.append(" stationId=").append(stationId.getId());
        }
        if (availabilityId!=null){
            builder.append(" availabilityId=").append(availabilityId.getId());
        }
        if (listingId!=null){
            builder.append(" listingId=").append(listingId.getId());
        }
        if (streamId!=null){
            builder.append(" streamId=").append(streamId.getId());
        }
        if (alternateId!=null){
            builder.append(" alternateId=").append(alternateId.getId());
        }
        if (alternateLocatorId!=null){
            builder.append(" alternateLocatorId=").append(alternateLocatorId.getId());
        }
        if (productContextIds!=null && productContextIds.size()>0){
            builder.append(" productContextIds=");
            boolean multiple = false;
            for (Muri pid : productContextIds){
                if (multiple) builder.append(",");
                builder.append(pid.getId());
                multiple = true;
            }
        }
        return builder.toString();
    }

    @Override
    public boolean equals(Object obj) {
        return reflectionEquals(this, obj);
    }

    @Override
    public int compareTo(WarningItem o) {
        if (channelId!=null){
            if (channelId.compareTo(o.channelId)!=0) return channelId.compareTo(o.channelId);
        } else if (o.channelId!=null){
            return -1;
        }
        if (stationId!=null){
            if (stationId.compareTo(o.stationId)!=0) return stationId.compareTo(o.stationId);
        } else if (o.stationId!=null){
            return -1;
        }
        if (availabilityId!=null){
            if (availabilityId.compareTo(o.availabilityId)!=0) return availabilityId.compareTo(o.availabilityId);
        } else if (o.availabilityId!=null){
            return -1;
        }
        if (listingId!=null){
            if (listingId.compareTo(o.listingId)!=0) return listingId.compareTo(o.listingId);
        } else if (o.listingId!=null){
            return -1;
        }
        if (programId!=null){
            if (programId.compareTo(o.programId)!=0) return programId.compareTo(o.programId);
        } else if (o.programId!=null){
            return -1;
        }
        if (alternateId!=null){
            if (alternateId.compareTo(o.alternateId)!=0) return alternateId.compareTo(o.alternateId);
        } else if (o.alternateId!=null){
            return -1;
        }
        if (alternateLocatorId!=null){
            if (alternateLocatorId.compareTo(o.alternateLocatorId)!=0) return alternateLocatorId.compareTo(o.alternateLocatorId);
        } else if (o.alternateLocatorId!=null){
            return -1;
        }
        if (productContextIds!=null){
            int i=0;
            // The list is already sorted
            for ( Muri muri : productContextIds){
                // Other has less PC in its list?
                if (i<(o.getProductContextIds().size()-1)){
                    return 1;
                }
                if (muri.compareTo((Muri) o.getProductContextIds().toArray()[i])!=0){
                    return muri.compareTo((Muri) o.getProductContextIds().toArray()[i]);
                }
                i++;
            }
            // Other had more PC in its list?
            if (productContextIds.size()< productContextIds.size()){
                return -1;
            }
        } else if (o.productContextIds!=null){
            return -1;
        }

        return 0;
    }
}



