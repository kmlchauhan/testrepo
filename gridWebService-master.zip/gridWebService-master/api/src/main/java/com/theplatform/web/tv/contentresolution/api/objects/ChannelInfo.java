package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import java.util.*;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

import static org.apache.commons.lang.builder.EqualsBuilder.reflectionEquals;
import static org.apache.commons.lang.builder.HashCodeBuilder.reflectionHashCode;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class ChannelInfo implements VisitableApiObject {

    private Muri channelId;
    private Integer number;
    private StationInfo stationInfo;
    private Boolean sdv;
    private Long sdvTimeout;
    private String emergencyAlertSystemType;
    private String onScreenCallsign;
    private Integer digicableId;
    private Muri outOfHomeChannelId;
    private Muri ownerId;
    private Boolean ipDeliveryOnly;

    /* Added in 1.21 */
    private List<LocatorInfo> locators;

    // Added in 1.21 to support backwards compatibilty.  This will NOT be Marshalled to JSON/XML
    // This is only used in the frontend
    // If it is 0 then there was no Identified Stream
    private long backwardsCompatibilityStreamId;

    // Special policies designating whether there are special actions to be taken with certain fields on the
    // channel. Sigh.  For example, DoNotDisplayChannelNumber
    private List<String> displayPolicies;
    // Index of placement in a diplayed list of channels.  You cannot use channel number order.
    private Integer sortIndex;

    public Muri getChannelId() {
        return channelId;
    }

    public void setChannelId(Muri channelId) {
        this.channelId = channelId;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Boolean getSdv() {
        return sdv;
    }

    public void setSdv(Boolean sdv) {
        this.sdv = sdv;
    }

    public Long getSdvTimeout() {
        return sdvTimeout;
    }

    public void setSdvTimeout(Long sdvTimeout) {
        this.sdvTimeout = sdvTimeout;
    }

    @XmlElement(name = "localizedStation")
    public StationInfo getStationInfo() {
        return stationInfo;
    }

    public void setStationInfo(StationInfo stationInfo) {
        this.stationInfo = stationInfo;
    }

    public String getEmergencyAlertSystemType() {
        return emergencyAlertSystemType;
    }

    public void setEmergencyAlertSystemType(String emergencyAlertSystemType) {
        this.emergencyAlertSystemType = emergencyAlertSystemType;
    }

    public String getOnScreenCallsign() {
        return onScreenCallsign;
    }

    public void setOnScreenCallsign(String onScreenCallsign) {
        this.onScreenCallsign = onScreenCallsign;
    }

    public Integer getDigicableId() {
        return digicableId;
    }

    public void setDigicableId(Integer digicableId) {
        this.digicableId = digicableId;
    }

    public Muri getOutOfHomeChannelId() {
        return outOfHomeChannelId;
    }

    public void setOutOfHomeChannelId(Muri outOfHomeChannelId) {
        this.outOfHomeChannelId = outOfHomeChannelId;
    }

    public List<LocatorInfo> getLocators() {
        return locators;
    }

    public void addLocator(LocatorInfo locator) {
        if (locator==null) return;
        if (locators==null) locators = new ArrayList<>();
        locators.add(locator);
    }

    public void addLocators(Collection<LocatorInfo> locators) {
        if (locators==null) return;
        if (this.locators==null) this.locators = new ArrayList<>();
        this.locators.addAll(locators);
    }

    public void setLocators(List<LocatorInfo> locators) {
        this.locators = locators;
    }

    public Muri getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Muri ownerId) {
        this.ownerId = ownerId;
    }

    public Boolean getIpDeliveryOnly() {
        return ipDeliveryOnly;
    }

    public void setIpDeliveryOnly(Boolean ipDeliveryOnly) {
        this.ipDeliveryOnly = ipDeliveryOnly;
    }

    public Integer getSortIndex() {
        return sortIndex;
    }

    public void setSortIndex(Integer sortIndex) {
        this.sortIndex = sortIndex;
    }

    public List<String> getDisplayPolicies() {
        return displayPolicies;
    }

    public void setDisplayPolicies(String...displayPolicies) {
        if (displayPolicies==null) return;
        this.displayPolicies = Arrays.asList(displayPolicies);
    }

    @JsonIgnore
    @XmlTransient
    public long getBackwardsCompatibilityStreamId() {
        return backwardsCompatibilityStreamId;
    }

    public void setBackwardsCompatibilityStreamId(long backwardsCompatibilityStreamId) {
        this.backwardsCompatibilityStreamId = backwardsCompatibilityStreamId;
    }

    @JsonIgnore
    public String getKey() {
        return getStationInfo().getStationId() + ":" + getNumber();
    }

    @JsonIgnore
    public List<ProductContextInfo> getProductContexts() {
        return stationInfo.getProductContextList();
    }

    @Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

    public void accept(ApiObjectVisitor visitor) {
        visitor.visitChannelInfo(this);
        if (stationInfo != null) {
            stationInfo.accept(visitor);
        }
        if (locators != null){
            for (int i = 0; i < locators.size(); i++) {
                LocatorInfo current = locators.get(i);
                if (current != null) {
                    current.accept(visitor);
                }
            }
        }
    }

    @Override
    public int hashCode() {
        return reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
        return reflectionEquals(this, obj);
    }

}
