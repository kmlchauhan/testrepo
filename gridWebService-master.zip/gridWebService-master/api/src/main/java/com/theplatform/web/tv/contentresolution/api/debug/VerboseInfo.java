package com.theplatform.web.tv.contentresolution.api.debug;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.*;

/**
 * An instance of this class will be returned when a requestWarnings is made with verboseMode flag set to true.
 *
 * The warning responseWarnings is ordered to be consistent between requests.
 *
 */
@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class VerboseInfo {

    private Map<WarningType, Map<CauseType, Set<WarningItem>>> requestWarnings;
    private Map<WarningType, Map<CauseType, Set<WarningItem>>> responseWarnings;


    public Map<WarningType, Map<CauseType, Set<WarningItem>>> getRequestWarnings() {
        return requestWarnings;
    }

    public Map<WarningType, Map<CauseType, Set<WarningItem>>> getResponseWarnings() {
        return responseWarnings;
    }

    /**
     * Required for the marshaller.  Private because you should use the add method to add an item
     */
    private void setRequestWarnings(Map<WarningType, Map<CauseType, Set<WarningItem>>> requestWarnings) {
        this.requestWarnings = requestWarnings;
    }

    /**
     * Required for the marshaller.  Private because you should use the add method to add an item
     */
    private void setResponseWarnings(Map<WarningType, Map<CauseType, Set<WarningItem>>> responseWarnings) {
        this.responseWarnings = responseWarnings;
    }

    public void addRequestWarning( WarningType warningType, CauseType causeType, WarningItem warningItem){
        if (requestWarnings ==null) requestWarnings = new TreeMap<>();
        addItem(requestWarnings, warningType, causeType, warningItem);
    }

    public void addResponseWarning(WarningType warningType, CauseType causeType, WarningItem warningItem){
        if (responseWarnings ==null) responseWarnings = new TreeMap<>();
        addItem(responseWarnings, warningType, causeType, warningItem);
    }

    private void addItem( Map<WarningType, Map<CauseType, Set<WarningItem>>> root,
                          WarningType warningType,
                          CauseType causeType,
                          WarningItem warningItem){
        if (root.get(warningType)==null){
            root.put(warningType, new TreeMap<CauseType, Set<WarningItem>>());
        }
        if (root.get(warningType).get(causeType)==null){
            root.get(warningType).put(causeType, new TreeSet<WarningItem>());
        }
        root.get(warningType).get(causeType).add(warningItem);
    }



}
