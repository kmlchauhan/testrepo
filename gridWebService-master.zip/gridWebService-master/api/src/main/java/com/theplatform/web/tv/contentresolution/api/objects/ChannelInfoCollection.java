package com.theplatform.web.tv.contentresolution.api.objects;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.ArrayList;
import java.util.List;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class ChannelInfoCollection extends ContentResolutionResponse implements VisitableApiObject {
    
    private String version;
    private List<ChannelInfo> channels;

    public ChannelInfoCollection(int initialSize) {
        super();
        channels = new ArrayList<>(initialSize);
    }

    public ChannelInfoCollection() {
        this(200);
    }

    public List<ChannelInfo> getChannels() {
        return channels;
    }

    public void setChannels(List<ChannelInfo> channels) {
        this.channels = channels;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((channels == null) ? 0 : channels.hashCode());
        result = prime * result + ((version == null) ? 0 : version.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        ChannelInfoCollection other = (ChannelInfoCollection) obj;
        if (channels == null) {
            if (other.channels != null)
                return false;
        } else if (!channels.equals(other.channels))
            return false;
        if (version == null) {
            if (other.version != null)
                return false;
        } else if (!version.equals(other.version))
            return false;
        return true;
    }

    public void accept(ApiObjectVisitor visitor) {
        visitor.visitChannelInfoCollection(this);
        if (channels != null) {
            for (ChannelInfo current : channels) {
                if (current != null) {
                    current.accept(visitor);
                }
            }
        }
    }

}
