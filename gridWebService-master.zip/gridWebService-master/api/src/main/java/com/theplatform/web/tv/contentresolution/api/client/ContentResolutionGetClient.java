package com.theplatform.web.tv.contentresolution.api.client;

import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.contrib.web.api.client.HeaderStuffingBaseWebServiceClient;
import com.theplatform.web.api.client.ClientConfiguration;
import com.theplatform.web.tv.contentresolution.api.ContentResolutionService;

/**
 * Created by jcoelho on 6/7/13.
 */
public class ContentResolutionGetClient extends HeaderStuffingBaseWebServiceClient<ContentResolutionService> {

    public ContentResolutionGetClient(String baseURL, AuthorizationHeaderFactory authorizationHeaderFactory) {
        super(baseURL, authorizationHeaderFactory);
    }

    public ContentResolutionGetClient(String baseUrl, AuthorizationHeaderFactory authorization,
            ClientConfiguration clientConfiguration) {
        super(baseUrl, authorization, clientConfiguration);
    }

    protected Class<ContentResolutionService> getServiceInterface() {
        return ContentResolutionService.class;
    }

}