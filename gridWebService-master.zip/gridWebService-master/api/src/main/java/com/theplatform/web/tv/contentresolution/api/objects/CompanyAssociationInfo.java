package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class CompanyAssociationInfo {

    private Muri companyId;

    private String companyName;
    private String associationType;
    private Muri stationCompanyId;
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAssociationType() {
        return associationType;
    }

    public void setAssociationType(String associationType) {
        this.associationType = associationType;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((associationType == null) ? 0 : associationType.hashCode());
        result = prime * result + ((companyName == null) ? 0 : companyName.hashCode());
        result = prime * result + ((companyId == null) ? 0 : companyId.hashCode());
        result = prime * result + ((stationCompanyId == null) ? 0 : stationCompanyId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CompanyAssociationInfo other = (CompanyAssociationInfo) obj;
        if (associationType == null) {
            if (other.associationType != null)
                return false;
        } else if (!associationType.equals(other.associationType))
            return false;
        if (companyName == null) {
            if (other.companyName != null)
                return false;
        } else if (!companyName.equals(other.companyName))
            return false;
        if (companyId == null) {
            if (other.companyId != null)
                return false;
        } else if (!companyId.equals(other.companyId))
            return false;
        if (stationCompanyId == null) {
            if (other.stationCompanyId != null)
                return false;
        } else if (!stationCompanyId.equals(other.stationCompanyId))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

    public Muri getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Muri companyId) {
        this.companyId = companyId;
    }

    public Muri getStationCompanyId() {
        return stationCompanyId;
    }

    public void setStationCompanyId(Muri stationCompanyId) {
        this.stationCompanyId = stationCompanyId;
    }
}
