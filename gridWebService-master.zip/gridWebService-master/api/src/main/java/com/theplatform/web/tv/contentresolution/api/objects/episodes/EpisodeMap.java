package com.theplatform.web.tv.contentresolution.api.objects.episodes;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ProgramInfo;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.*;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class EpisodeMap {
    private Map<Muri, EpisodeSequence>  episodeIdToEpisodes;

    public EpisodeMap() { // for marshalling
        episodeIdToEpisodes = new HashMap<>();
    }

    public EpisodeMap(Map<Muri, List<Set<ProgramInfo>>> episodeIdToEpisodes) {
        this.episodeIdToEpisodes = new HashMap<>(episodeIdToEpisodes.size());

        for (Map.Entry<Muri, List<Set<ProgramInfo>>> entry : episodeIdToEpisodes.entrySet()) {
            EpisodeSequence episodeSequence = new EpisodeSequence(entry.getValue());
            this.episodeIdToEpisodes.put(entry.getKey(), episodeSequence);
        }
    }

    public Map<Muri, EpisodeSequence> getEpisodeIdToEpisodes() {
        return episodeIdToEpisodes;
    }

    public void setEpisodeIdToEpisodes(Map<Muri, EpisodeSequence> episodeIdToEpisodes) {
        this.episodeIdToEpisodes = episodeIdToEpisodes;
    }

    public EpisodeSequence get(Muri muri) {
        return episodeIdToEpisodes.get(muri);
    }
}
