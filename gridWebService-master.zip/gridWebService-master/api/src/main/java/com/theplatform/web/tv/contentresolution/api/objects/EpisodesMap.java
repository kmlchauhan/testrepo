package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class EpisodesMap {
    private Map<Muri, ProgramInfo[]> episodeIdToEpisodes;

    public EpisodesMap() {}

    public EpisodesMap(Map<Muri, ProgramInfo[]> episodeIdToEpisodes) {
        this.episodeIdToEpisodes = episodeIdToEpisodes;
    }

    public List<ProgramInfo> get(Muri providedEpisodeId) {
        ProgramInfo[] programInfos = episodeIdToEpisodes.get(providedEpisodeId);

        if (programInfos == null) {
            return null;
        } else {
            return Arrays.asList(programInfos);
        }
    }

    public Map<Muri, ProgramInfo[]> getEpisodeIdToEpisodes() {
        return episodeIdToEpisodes;
    }

    public void setEpisodeIdToEpisodes(Map<Muri, ProgramInfo[]> episodeIdToEpisodes) {
        this.episodeIdToEpisodes = episodeIdToEpisodes;
    }
}
