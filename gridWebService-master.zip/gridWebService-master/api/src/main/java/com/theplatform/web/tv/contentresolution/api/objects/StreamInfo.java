package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
@Deprecated                                         // LocatorInfo replaced this in 1.21
public class StreamInfo implements VisitableApiObject {
    private Muri streamId;
    private Boolean isDefault;
    private List<LocatorInfo> locators;
    private String status;
    private Muri stationId;
    private Boolean external;
    private Boolean isDai;

    public StreamInfo() {
        locators = new ArrayList<>();
    }

    @XmlElementWrapper(name = "locators")
    @XmlElement(name = "locator")
    public List<LocatorInfo> getLocators() {
        return locators;
    }

    public void setLocators(List<LocatorInfo> locators) {
        if (locators == null)
            this.locators = new ArrayList<>();
        else
            this.locators = locators;
    }

    @XmlAttribute(name = "streamId")
    public Muri getStreamId() {
        return streamId;
    }

    public void setStreamId(Muri streamId) {
        this.streamId = streamId;
    }

    public Boolean getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Boolean isDefault) {
        this.isDefault = isDefault;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Muri getStationId() {
        return stationId;
    }

    public void setStationId(Muri stationId) {
        this.stationId = stationId;
    }

    public Boolean getExternal() {
        return external;
    }

    public void setExternal(Boolean external) {
        this.external = external;
    }

    public Boolean getIsDai() {
        return isDai;
    }

    public void setIsDai(Boolean isDai) {
        this.isDai = isDai;
    }

    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }


    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

    public void accept(ApiObjectVisitor visitor) {
        visitor.visitStreamInfo(this);
        if (locators != null)
        {
            for (int i = 0; i < locators.size(); i ++) {
                LocatorInfo current = locators.get(i);
                if (current != null) {
                    visitor.visitLocatorInfo(current);
                }
            }
        }
    }

}
