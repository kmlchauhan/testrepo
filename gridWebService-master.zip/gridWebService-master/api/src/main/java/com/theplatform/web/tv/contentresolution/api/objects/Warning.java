
package com.theplatform.web.tv.contentresolution.api.objects;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;

/**
 * THIS SHOULD BE REMOVED after Sprint-2015-07 successfully sits in production
 * The object was always returned and never null in responses.  Will keep it until we know nobody is using it.
 */
@Deprecated
public class Warning {
}
