package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.HashMap;
import java.util.Map;

import static org.apache.commons.lang.builder.HashCodeBuilder.reflectionHashCode;

/**
 * Date: 3/25/14
 *
 * @author mmattozzi
 */
@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class TmsMatches {

    public static Muri UNRESOLVED_TMSID_Muri = new Muri("urn:tms:unresolved");

    protected Map<TmsIdAndTitle, Muri> attemptedMatchesInternal = new HashMap<>();
    protected Float matchRate = Float.NaN;

    protected Float last24HoursMatchRate = 0f;
    protected Map<TmsIdAndTitle, Muri> last24HoursAttemptedMatchesInternal = new HashMap<>();

    @JsonIgnore
    public Map<TmsIdAndTitle, Muri> getAttemptedMatchesInternal() {
        return attemptedMatchesInternal;
    }

    @JsonIgnore
    public void setAttemptedMatchesInternal(Map<TmsIdAndTitle, Muri> attemptedMatches) {
        this.attemptedMatchesInternal = attemptedMatches;
    }

    @JsonIgnore
    public Map<TmsIdAndTitle, Muri> getLast24HoursAttemptedMatchesInternal() {
        return last24HoursAttemptedMatchesInternal;
    }

    @JsonIgnore
    public void setLast24HoursAttemptedMatchesInternal(Map<TmsIdAndTitle, Muri> last24HoursAttemptedMatchesInternal) {
        this.last24HoursAttemptedMatchesInternal = last24HoursAttemptedMatchesInternal;
    }

    /**
     * Some cheesy stringifying to make this field play nice with the WSS usage of Jackson.
     * @return
     */
    public Map<String, Muri> getLast24HoursAttemptedMatches() {
        Map<String, Muri> attemptedMatches = new HashMap<String, Muri>();
        for (Map.Entry<TmsIdAndTitle, Muri> entry : last24HoursAttemptedMatchesInternal.entrySet()) {
            attemptedMatches.put(entry.getKey().toString(), entry.getValue());
        }
        return attemptedMatches;
    }

    /**
     * Some cheesy parsing to make this field play nice with the WSS usage of Jackson.
     * @param attemptedMatches
     */
    public void setLast24HoursAttemptedMatches(Map<String, Muri> attemptedMatches) {
        last24HoursAttemptedMatchesInternal = new HashMap<TmsIdAndTitle, Muri>();
        for (Map.Entry<String, Muri> attemptedMatch : attemptedMatches.entrySet()) {
            last24HoursAttemptedMatchesInternal.put(TmsIdAndTitle.fromString(attemptedMatch.getKey()), attemptedMatch.getValue());
        }
    }

    /**
     * Some cheesy stringifying to make this field play nice with the WSS usage of Jackson.
     * @return
     */
    public Map<String, Muri> getAttemptedMatches() {
        Map<String, Muri> attemptedMatches = new HashMap<String, Muri>();
        for (Map.Entry<TmsIdAndTitle, Muri> entry : attemptedMatchesInternal.entrySet()) {
            attemptedMatches.put(entry.getKey().toString(), entry.getValue());
        }
        return attemptedMatches;
    }

    /**
     * Some cheesy parsing to make this field play nice with the WSS usage of Jackson.
     * @param attemptedMatches
     */
    public void setAttemptedMatches(Map<String, Muri> attemptedMatches) {
        attemptedMatchesInternal = new HashMap<TmsIdAndTitle, Muri>();
        for (Map.Entry<String, Muri> attemptedMatch : attemptedMatches.entrySet()) {
            attemptedMatchesInternal.put(TmsIdAndTitle.fromString(attemptedMatch.getKey()), attemptedMatch.getValue());
        }
    }

    public Float getMatchRate() {
        return matchRate;
    }

    public void setMatchRate(Float matchRate) {
        this.matchRate = matchRate;
    }

    public Float getLast24HoursMatchRate() {
        return last24HoursMatchRate;
    }

    public void setLast24HoursMatchRate(Float last24HoursMatchRate) {
        this.last24HoursMatchRate = last24HoursMatchRate;
    }

    @Override
    public int hashCode() {
        return reflectionHashCode(this);
    }

}
