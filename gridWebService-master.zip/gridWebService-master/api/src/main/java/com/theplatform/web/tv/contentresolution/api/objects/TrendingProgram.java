package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlTransient;

/**
 * Date: 2/6/14
 *
 * @author mmattozzi
 */
@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class TrendingProgram implements VisitableApiObject {

    protected Muri programId;
    protected ProgramInfo programInfo;
    protected Integer score;
    protected Integer rankingGroup;
    protected Boolean topTrending;

    protected ProgramInfo transientProgramInfo;

    public Muri getProgramId() {
        return programId;
    }

    public void setProgramId(Muri programId) {
        this.programId = programId;
    }

    public ProgramInfo getProgramInfo() {
        return programInfo;
    }

    public void setProgramInfo(ProgramInfo programInfo) {
        this.programInfo = programInfo;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getRankingGroup() {
        return rankingGroup;
    }

    public void setRankingGroup(Integer rankingGroup) {
        this.rankingGroup = rankingGroup;
    }

    public Boolean getTopTrending() {
        return topTrending;
    }

    public void setTopTrending(Boolean topTrending) {
        this.topTrending = topTrending;
    }

    @JsonIgnore
    @XmlTransient
    public ProgramInfo getTransientProgramInfo() {
        return transientProgramInfo;
    }

    public void setTransientProgramInfo(ProgramInfo transientProgramInfo) {
        this.transientProgramInfo = transientProgramInfo;
    }

    @Override
    public void accept(ApiObjectVisitor visitor) {
        visitor.visitTrendingProgram(this);
        if (programInfo != null) {
            visitor.visitProgramInfo(programInfo);
        }
    }
}
