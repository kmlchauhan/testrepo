package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.contrib.data.api.objects.Muri;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.*;
import java.beans.Transient;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class StationInfo implements VisitableApiObject {

    // Core station non-collection fields
    private Muri stationId;
    private String title;
    private String callsign;
    @Deprecated // Moved to ChannelInfo
    private String onScreenCallsign;
    @Deprecated // Moved to ChannelInfo in 1.21
    private Integer digicableId;
    private String timeZone;
    private Date expirationDate;
    @Deprecated // Property populated on Locators in 1.25
    private Muri associatedStationId;
    // holds associatedStationId so DataObjectTranslator can maintain backwards compatability
    private Muri transientAssociatedStationId;
    private Boolean hd;
    private String language;
    private Integer otaChannelNumber;
    private Boolean payPerView;
    private String shortName;
    private Boolean vod;
    private Boolean uhd;
    private String hdLevel;
    private String colorDepth;
    private String quality;
    private Map<String, Muri> qualityVariants;

    // Core station collection fields
    private List<CompanyAssociationInfo> companyAssociations;
    private List<Muri> tagIds;

    // CRS fields
    private String recorderManager;

    @Deprecated // Moved to productContextList
    private List<Muri> productContexts;

    private List<ProductContextInfo> productContextList;

    @Deprecated         // Properties populated on Locators in 1.21.
    private StreamInfo stream;

    private List<ListingInfo> listings;

    public StationInfo() {
        companyAssociations = new ArrayList<>();
        tagIds = new ArrayList<>();
        productContextList = new ArrayList<>();
    }

    public Muri getStationId() {
        return stationId;
    }

    public void setStationId(Muri stationId) {
        this.stationId = stationId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCallsign() {
        return callsign;
    }

    public void setCallsign(String callsign) {
        this.callsign = callsign;
    }

    @Deprecated // Moved to ChannelInfo
    public String getOnScreenCallsign() {
        return onScreenCallsign;
    }

    @Deprecated // Moved to ChannelInfo
    public void setOnScreenCallsign(String onScreenCallsign) {
        this.onScreenCallsign = onScreenCallsign;
    }

    @Deprecated // Moved to ChannelInfo in 1.21
    public Integer getDigicableId() {
        return digicableId;
    }

    @Deprecated // Moved to ChannelInfo in 1.21
    public void setDigicableId(Integer digicableId) {
        this.digicableId = digicableId;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Boolean getHd() {
        return hd;
    }

    public void setHd(Boolean hd) {
        this.hd = hd;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Integer getOtaChannelNumber() {
        return otaChannelNumber;
    }

    public void setOtaChannelNumber(Integer otaChannelNumber) {
        this.otaChannelNumber = otaChannelNumber;
    }

    public Boolean getPayPerView() {
        return payPerView;
    }

    public void setPayPerView(Boolean payPerView) {
        this.payPerView = payPerView;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public Boolean getVod() {
        return vod;
    }

    public void setVod(Boolean vod) {
        this.vod = vod;
    }

    public Boolean getUhd() {
        return uhd;
    }

    public void setUhd(Boolean uhd) {
        this.uhd = uhd;
    }

    public String getHdLevel() {
        return hdLevel;
    }

    public void setHdLevel(String hdLevel) {
        this.hdLevel = hdLevel;
    }

    public Map<String, Muri> getQualityVariants() {
        return qualityVariants;
    }

    public void setQualityVariants(Map<String, Muri> qualityVariants) {
        this.qualityVariants = qualityVariants;
    }

    public String getColorDepth() {
        return colorDepth;
    }

    public void setColorDepth(String colorDepth) {
        this.colorDepth = colorDepth;
    }

    @XmlElementWrapper(name = "companyAssociations")
    @XmlElement(name = "companyAssociation")
    public List<CompanyAssociationInfo> getCompanyAssociations() {
        return companyAssociations;
    }

    public void setCompanyAssociations(List<CompanyAssociationInfo> companyAssociations) {
        this.companyAssociations = companyAssociations;
    }

    @XmlElementWrapper(name = "tagIds")
    @XmlElement(name = "tagIds")
    public List<Muri> getTagIds() {
        return tagIds;
    }

    public void setTagIds(List<Muri> tagIds) {
        this.tagIds = tagIds;
    }

    /**
     * Pass through to StreamInfo to get LocatorInfo-s
     *
     */
    @Deprecated             /* Moved to ChannelInfo in 1.21 */
    @JsonIgnore
    public List<LocatorInfo> getLocators() {
        if (stream==null) return null;
        return stream.getLocators();
    }

    public String getRecorderManager() {
        return recorderManager;
    }

    public void setRecorderManager(String recorderManager) {
        this.recorderManager = recorderManager;
    }

    @XmlElementWrapper(name = "productContextList")
    public List<ProductContextInfo> getProductContextList() {
        return productContextList;
    }

    public void setProductContextList(List<ProductContextInfo> productContexts) {
        this.productContextList = productContexts;
    }

    @Deprecated             /* Properties moved to LocatorInfo in 1.21 */
    public StreamInfo getStream() {
        return stream;
    }

    @Deprecated             /* Properties moved to LocatorInfo in 1.21 */
    public void setStream(StreamInfo stream) {
        this.stream = stream;
    }

    public List<ListingInfo> getListings() {
        return listings;
    }

    public void setListings(List<ListingInfo> listings) {
        this.listings = listings;
    }

    @JsonIgnore
    public String getKey() {
        return String.valueOf(stationId);
    }

    /**
     * Use productContextInfos going forward
     */
    @Deprecated
    @XmlElementWrapper(name = "productContexts")
    public List<Muri> getProductContexts() {
        return productContexts;
    }

    @Deprecated
    public void setProductContexts(List<Muri> productContexts) {
        this.productContexts = productContexts;
    }

    @JsonIgnore
    @XmlTransient
    public Muri getTransientAssociatedStationId() {
        return transientAssociatedStationId;
    }

    public void setTransientAssociatedStationId(Muri transientAssociatedStationId) {
        this.transientAssociatedStationId = transientAssociatedStationId;
    }
    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((associatedStationId == null) ? 0 : associatedStationId.hashCode());
        result = prime * result + ((callsign == null) ? 0 : callsign.hashCode());
        result = prime * result + ((digicableId == null) ? 0 : digicableId.hashCode());
        result = prime * result + ((expirationDate == null) ? 0 : expirationDate.hashCode());
        result = prime * result + ((hd == null) ? 0 : hd.hashCode());
        result = prime * result + ((language == null) ? 0 : language.hashCode());
        result = prime * result + ((onScreenCallsign == null) ? 0 : onScreenCallsign.hashCode());
        result = prime * result + ((otaChannelNumber == null) ? 0 : otaChannelNumber.hashCode());
        result = prime * result + ((payPerView == null) ? 0 : payPerView.hashCode());
        result = prime * result + ((productContexts == null) ? 0 : productContexts.hashCode());
        result = prime * result + ((productContextList == null) ? 0 : productContextList.hashCode());
        result = prime * result + ((recorderManager == null) ? 0 : recorderManager.hashCode());
        result = prime * result + ((shortName == null) ? 0 : shortName.hashCode());
        result = prime * result + ((companyAssociations == null) ? 0 : companyAssociations.hashCode());
        result = prime * result + ((stationId == null) ? 0 : stationId.hashCode());
        result = prime * result + ((stream == null) ? 0 : stream.hashCode());
        result = prime * result + ((tagIds == null) ? 0 : tagIds.hashCode());
        result = prime * result + ((timeZone == null) ? 0 : timeZone.hashCode());
        result = prime * result + ((title == null) ? 0 : title.hashCode());
        result = prime * result + ((vod == null) ? 0 : vod.hashCode());
        result = prime * result + ((listings == null) ? 0 : listings.hashCode());
        result = prime * result + ((uhd == null) ? 0 : uhd.hashCode());
        result = prime * result + ((hdLevel == null) ? 0 : hdLevel.hashCode());
        result = prime * result + ((colorDepth == null) ? 0 : colorDepth.hashCode());
        result = prime * result + ((transientAssociatedStationId == null) ? 0 : transientAssociatedStationId.hashCode());
        result = prime * result + ((quality == null) ? 0 : quality.hashCode());
        result = prime * result + ((qualityVariants == null) ? 0 : qualityVariants.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {

        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;

        StationInfo other = (StationInfo) obj;
        if (associatedStationId == null) {
            if (other.associatedStationId != null)
                return false;
        } else if (!associatedStationId.equals(other.associatedStationId))
            return false;
        if (callsign == null) {
            if (other.callsign != null)
                return false;
        } else if (!callsign.equals(other.callsign))
            return false;
        if (digicableId == null) {
            if (other.digicableId != null)
                return false;
        } else if (!digicableId.equals(other.digicableId))
            return false;
        if (expirationDate == null) {
            if (other.expirationDate != null)
                return false;
        } else if (!expirationDate.equals(other.expirationDate))
            return false;
        if (hd == null) {
            if (other.hd != null)
                return false;
        } else if (!hd.equals(other.hd))
            return false;
        if (language == null) {
            if (other.language != null)
                return false;
        } else if (!language.equals(other.language))
            return false;
        if (onScreenCallsign == null) {
            if (other.onScreenCallsign != null)
                return false;
        } else if (!onScreenCallsign.equals(other.onScreenCallsign))
            return false;
        if (otaChannelNumber == null) {
            if (other.otaChannelNumber != null)
                return false;
        } else if (!otaChannelNumber.equals(other.otaChannelNumber))
            return false;
        if (payPerView == null) {
            if (other.payPerView != null)
                return false;
        } else if (!payPerView.equals(other.payPerView))
            return false;
        if (productContexts == null) {
            if (other.productContexts != null)
                return false;
        } else if (!productContexts.equals(other.productContexts))
            return false;
        if (productContextList == null) {
            if (other.productContextList != null)
                return false;
        } else if (!productContextList.equals(other.productContextList))
            return false;
        if (recorderManager == null) {
            if (other.recorderManager != null)
                return false;
        } else if (!recorderManager.equals(other.recorderManager))
            return false;
        if (shortName == null) {
            if (other.shortName != null)
                return false;
        } else if (!shortName.equals(other.shortName))
            return false;
        if (companyAssociations == null) {
            if (other.companyAssociations != null)
                return false;
        } else if (!companyAssociations.equals(other.companyAssociations))
            return false;
        if (stationId == null) {
            if (other.stationId != null)
                return false;
        } else if (!stationId.equals(other.stationId))
            return false;
        if (stream == null) {
            if (other.stream != null)
                return false;
        } else if (!stream.equals(other.stream))
            return false;
        if (tagIds == null) {
            if (other.tagIds != null)
                return false;
        } else if (!tagIds.equals(other.tagIds))
            return false;
        if (timeZone == null) {
            if (other.timeZone != null)
                return false;
        } else if (!timeZone.equals(other.timeZone))
            return false;
        if (title == null) {
            if (other.title != null)
                return false;
        } else if (!title.equals(other.title))
            return false;
        if (vod == null) {
            if (other.vod != null)
                return false;
        } else if (!vod.equals(other.vod))
            return false;
        if (listings == null) {
            if (other.listings != null)
                return false;
        } else if (!listings.equals(other.listings))
            return false;
        if (uhd == null) {
            if (other.uhd != null)
                return false;
        } else if (!uhd.equals(other.uhd))
            return false;
        if (hdLevel== null) {
            if (other.hdLevel!= null)
                return false;
        } else if (!hdLevel.equals(other.hdLevel))
            return false;
        if (colorDepth== null) {
            if (other.colorDepth!= null)
                return false;
        } else if (!colorDepth.equals(other.colorDepth))
            return false;
        if (transientAssociatedStationId == null) {
            if (other.transientAssociatedStationId != null)
                return false;
        } else if (!transientAssociatedStationId.equals(other.transientAssociatedStationId))
            return false;
        if (quality == null){
            if (other.quality != null)
                return false;
        } else if (!quality.equals(other.quality))
            return false;
        if (qualityVariants == null){
            if (other.qualityVariants != null)
                return false;
        } else if (!qualityVariants.equals(other.qualityVariants))
            return false;

        return true;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

    public Muri getAssociatedStationId() {
        return associatedStationId;
    }

    public void setAssociatedStationId(Muri associatedStationId) {
        this.associatedStationId = associatedStationId;
    }

    public void accept(ApiObjectVisitor visitor) {
        visitor.visitStationInfo(this);

        if (companyAssociations != null) {
            for (int i = 0; i < companyAssociations.size(); i++) {
                CompanyAssociationInfo current = companyAssociations.get(i);
                if (current != null) {
                    visitor.visitCompanyAssociationInfo(current);
                }
            }
        }

        if (productContextList != null) {
            for (int i = 0; i < productContextList.size(); i++) {
                ProductContextInfo current = productContextList.get(i);
                if (current != null) {
                    visitor.visitProductContextInfo(current);
                }
            }
        }

        if (listings != null) {
            for (int i = 0; i < listings.size(); i++) {
                ListingInfo current = listings.get(i);
                if (current != null) {
                    current.accept(visitor);
                }
            }
        }

        if (stream != null) {
            stream.accept(visitor);
        }
    }
}
