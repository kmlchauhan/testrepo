package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.data.tv.linear.api.data.objects.AiringType;
import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.contrib.data.api.objects.Muri;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.Date;
import java.util.List;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class ListingInfo implements VisitableApiObject {

    private Muri listingId;
    private Muri stationId;
    private String title;
    private Date startTime;
    private Date endTime;
    private Integer inWindowMinutes;
    private Integer price;
    private Rating contentRating;
    private List<Rating> contentRatings;
    private AiringType airingType;
    private String captionType;
    private String hdLevel;
    private String quality;
    private String colorDepth;
    private ProgramInfo programInfo;
    private Boolean payPerView;
    private Boolean descriptiveVideoService;
    private Boolean availableInVod;
    private Boolean autoextendable;
    private Muri extendableEntityId;

    private String audioType;
    private ProgramInfo seriesInfo;
    private String showingType;
    private Boolean sap;
    private Boolean subjectToBlackout;
    private Boolean subtitled;
    private Boolean threeD;
    private String cci;
    private Integer dvrProgramId;
    private Integer dvrSeriesId;
    private List<Muri> tagIds;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getInWindowMinutes() {
        return inWindowMinutes;
    }

    public void setInWindowMinutes(Integer inWindowMinutes) {
        this.inWindowMinutes = inWindowMinutes;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Rating getContentRating() {
        return contentRating;
    }

    public void setContentRating(Rating contentRating) {
        this.contentRating = contentRating;
    }

    public AiringType getAiringType() {
        return airingType;
    }

    public void setAiringType(AiringType airingType) {
        this.airingType = airingType;
    }

    public String getCaptionType() {
        return captionType;
    }

    public void setCaptionType(String captionType) {
        this.captionType = captionType;
    }

    public String getHdLevel() {
        return hdLevel;
    }

    public void setHdLevel(String hdLevel) {
        this.hdLevel = hdLevel;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public String getColorDepth() {
        return colorDepth;
    }

    public void setColorDepth(String colorDepth) {
        this.colorDepth = colorDepth;
    }

    public ProgramInfo getProgramInfo() {
        return programInfo;
    }

    public void setProgramInfo(ProgramInfo programInfo) {
        this.programInfo = programInfo;
    }

    public Boolean getPayPerView() {
        return payPerView;
    }

    public void setPayPerView(Boolean payPerView) {
        this.payPerView = payPerView;
    }

    public Boolean getDescriptiveVideoService() {
        return descriptiveVideoService;
    }

    public void setDescriptiveVideoService(Boolean descriptiveVideoService) {
        this.descriptiveVideoService = descriptiveVideoService;
    }

    public Boolean getAvailableInVod() {
        return availableInVod;
    }

    public void setAvailableInVod(Boolean availableInVod) {
        this.availableInVod = availableInVod;
    }

    public Boolean getAutoextendable() {
        return autoextendable;
    }

    public void setAutoextendable(Boolean autoextendable) {
        this.autoextendable = autoextendable;
    }

    public Muri getExtendableEntityId() {
        return extendableEntityId;
    }

    public void setExtendableEntityId(Muri extendableEntityId) {
        this.extendableEntityId = extendableEntityId;
    }

    public String getAudioType() {
        return audioType;
    }

    public void setAudioType(String audioType) {
        this.audioType = audioType;
    }

    public ProgramInfo getSeriesInfo() {
        return seriesInfo;
    }

    public void setSeriesInfo(ProgramInfo seriesInfo) {
        this.seriesInfo = seriesInfo;
    }

    public String getShowingType() {
        return showingType;
    }

    public void setShowingType(String showingType) {
        this.showingType = showingType;
    }

    public Boolean getSap() {
        return sap;
    }

    public void setSap(Boolean sap) {
        this.sap = sap;
    }

    public Boolean getSubjectToBlackout() {
        return subjectToBlackout;
    }

    public void setSubjectToBlackout(Boolean subjectToBlackout) {
        this.subjectToBlackout = subjectToBlackout;
    }

    public Boolean getSubtitled() {
        return subtitled;
    }

    public void setSubtitled(Boolean subtitled) {
        this.subtitled = subtitled;
    }

    public Boolean getThreeD() {
        return threeD;
    }

    public void setThreeD(Boolean threeD) {
        this.threeD = threeD;
    }

    public String getCci() {
        return cci;
    }

    public void setCci(String cci) {
        this.cci = cci;
    }

    public Integer getDvrProgramId() {
        return dvrProgramId;
    }

    public void setDvrProgramId(Integer dvrProgramId) {
        this.dvrProgramId = dvrProgramId;
    }

    public Integer getDvrSeriesId() {
        return dvrSeriesId;
    }

    public void setDvrSeriesId(Integer dvrSeriesId) {
        this.dvrSeriesId = dvrSeriesId;
    }

    public List<Muri> getTagIds() {
        return tagIds;
    }

    public void setTagIds(List<Muri> tagIds) {
        this.tagIds = tagIds;
    }

    public Muri getListingId() {
        return listingId;
    }

    public void setListingId(Muri listingId) {
        this.listingId = listingId;
    }

    public Muri getStationId() {
        return stationId;
    }

    public void setStationId(Muri stationId) {
        this.stationId = stationId;
    }

    public List<Rating> getContentRatings() {
        return contentRatings;
    }

    public void setContentRatings(List<Rating> contentRatings) {
        this.contentRatings = contentRatings;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((title == null) ? 0 : title.hashCode());
        result = prime * result + ((listingId == null) ? 0 : listingId.hashCode());
        result = prime * result + ((startTime == null) ? 0 : startTime.hashCode());
        result = prime * result + ((endTime == null) ? 0 : endTime.hashCode());
        result = prime * result + ((inWindowMinutes == null) ? 0 : inWindowMinutes.hashCode());
        result = prime * result + ((price == null) ? 0 : price.hashCode());
        result = prime * result + ((contentRating == null) ? 0 : contentRating.hashCode());
        result = prime * result + ((contentRatings == null) ? 0 : contentRatings.hashCode());
        // Careful.AiringType enum did have a hashcode calc and we were receiving different values on different nodes.  Just use the string.
        result = prime * result + ((airingType == null) ? 0 : airingType.getFriendlyName().hashCode());
        result = prime * result + ((captionType == null) ? 0 : captionType.hashCode());
        result = prime * result + ((hdLevel == null) ? 0 : hdLevel.hashCode());
        result = prime * result + ((payPerView == null) ? 0 : payPerView.hashCode());
        result = prime * result + ((programInfo == null) ? 0 : programInfo.hashCode());
        result = prime * result + ((descriptiveVideoService == null) ? 0 : descriptiveVideoService.hashCode());
        result = prime * result + ((availableInVod == null) ? 0 : availableInVod.hashCode());
        result = prime * result + ((autoextendable == null) ? 0 : autoextendable.hashCode());
        result = prime * result + ((extendableEntityId == null) ? 0 : extendableEntityId.hashCode());

        result = prime * result + ((seriesInfo == null) ? 0 : seriesInfo.hashCode());
        result = prime * result + ((audioType == null) ? 0 : audioType.hashCode());
        result = prime * result + ((showingType == null) ? 0 : showingType.hashCode());
        result = prime * result + ((sap == null) ? 0 : sap.hashCode());
        result = prime * result + ((subjectToBlackout == null) ? 0 : subjectToBlackout.hashCode());
        result = prime * result + ((subtitled == null) ? 0 : subtitled.hashCode());
        result = prime * result + ((threeD == null) ? 0 : threeD.hashCode());
        result = prime * result + ((cci == null) ? 0 : cci.hashCode());
        result = prime * result + ((dvrProgramId == null) ? 0 : dvrProgramId.hashCode());
        result = prime * result + ((dvrSeriesId == null) ? 0 : dvrSeriesId.hashCode());
        result = prime * result + ((tagIds == null) ? 0 : tagIds.hashCode());
        result = prime * result + ((stationId == null) ? 0 : stationId.hashCode());

        return result;
    }

    public void accept(ApiObjectVisitor visitor) {
        visitor.visitListingInfo(this);
        if (programInfo != null)
            visitor.visitProgramInfo(programInfo);

        if (seriesInfo != null)
            visitor.visitProgramInfo(seriesInfo);
    }
}
