package com.theplatform.web.tv.contentresolution.api.objects;


/**
 * Interface for classes that accept an ApiVisitor.
 */
public interface VisitableApiObject {

    /**
     * Visit this object and every child object.
     * @param visitor
     */
    public void accept(ApiObjectVisitor visitor);
}
