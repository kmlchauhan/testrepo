@XmlSchema(
        elementFormDefault = XmlNsForm.QUALIFIED, xmlns = {@XmlNs(prefix = "ns2",
        namespaceURI = "http://xml.theplatform.com/tv/web/AvailabilityResolution")})
package com.theplatform.web.tv.contentresolution.api.objects.resolve;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;