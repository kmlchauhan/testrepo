package com.theplatform.web.tv.contentresolution.api.objects;

import com.theplatform.web.tv.contentresolution.api.debug.VerboseInfo;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.util.*;

@JsonPropertyOrder(alphabetic = true)
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class ContentResolutionResponse {

    private List<Warning> warnings;

    private VerboseInfo verboseInfo;


    public ContentResolutionResponse() {
        this.warnings = new ArrayList<>();
    }

    @Deprecated
    public List<Warning> getWarnings() {
        return this.warnings;
    }

    @Deprecated
    public void setWarnings(List<Warning> warnings) {
        this.warnings = warnings;
    }

    public VerboseInfo getVerboseInfo() {
        return verboseInfo;
    }

    public void setVerboseInfo(VerboseInfo verboseInfo) {
        this.verboseInfo = verboseInfo;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((warnings == null) ? 0 : warnings.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ContentResolutionResponse other = (ContentResolutionResponse) obj;
        if (warnings == null) {
            if (other.warnings != null)
                return false;
        } else if (!warnings.equals(other.warnings))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "ContentResolutionResponse [warnings=" + warnings + "]";
    }
    
}
