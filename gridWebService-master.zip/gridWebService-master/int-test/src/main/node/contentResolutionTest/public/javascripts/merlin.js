
$(document).ready(function() {
	prettyPrint()
});

$(function() {
    $( "#contentResolutionResolveType" ).buttonset();
    $( "#availabilityResolutionResolveType" ).buttonset();
    $( "#environmentType" ).buttonset();
    $( "#formType" ).buttonset();
	$( "button" ).button();

	$( "#opener" ).click(function() {
  		 $( "#dialog" ).toggle( "slide", {direction:"up"} );
	});

	$( "#closeButton" ).click(function() {
  		 $( "#dialog" ).toggle( "slide", {direction:"up"} );
	});

	$("#requestButton").click(function(){
		 $("#wait").toggle("slide", {direction:"up"})
  		 $( "#dialog" ).toggle( "slide", {direction:"up"} );

		var env = $("input[name=env]:checked").val();
		var arResolveType = $("input[name=availabilityResolutionResolveType]:checked").val();
		var crResolveType = $("input[name=contentResolutionResolveType]:checked").val();
		var form = $("input[name=form]:checked").val();
		var device = $("input[name=device]").val();
		var productContext = $("input[name=productContext]").val();
		var mergeProfile = $("input[name=mergeProfile]").val();
		var mainImageTypeGroup = $("input[name=mainImageTypeGroup]").val();
		var accountNumber = $("input[name=accountNumber]").val();

		$.ajax({
		  	url: "/" + env +"/resolve/"+arResolveType+"/"+crResolveType+"?raw=1&form=" +form+"&device="+device+"&productContext="+productContext+"&mergeProfile="+mergeProfile+"&mainImageTypeGroup="+mainImageTypeGroup+"&accountNumber="+accountNumber
		}).done(function ( data ) {
			$("#arRequest").text(data.availabilityRequest)
			$("#arResponse").text(data.availabilityResponse)
			$("#crRequest").text(data.contentResolutionRequest)
			$("#crResponse").text(data.contentResolutionResponse)
			$("#crHeader").text(data.contentResolutionHeader)

			$("#arRequestString").html("http://" + data.availabilityPostOptions.host + ":" +  data.availabilityPostOptions.port + data.availabilityPostOptions.path);
			$("#crRequestString").html("http://" + data.contentResolutionPostOptions.host + ":" +  data.contentResolutionPostOptions.port + data.contentResolutionPostOptions.path);

			prettyPrint();
		  	$( "#wait" ).toggle( "slide" , {direction:"up"});
		});
	})

});