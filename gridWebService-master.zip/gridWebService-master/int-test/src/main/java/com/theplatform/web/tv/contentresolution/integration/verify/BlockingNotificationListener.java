package com.theplatform.web.tv.contentresolution.integration.verify;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.notification.AwsNotificationListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

public class BlockingNotificationListener{
    private static final Logger logger = LoggerFactory.getLogger(BlockingNotificationListener.class);

    // Be careful at making this too large.  In some cases we want to make sure the notif doesn't get created and don't want to delay the test too long.
    private static final long MAX_WAIT_MILLIS = 180_000;

    private AwsNotificationListener awsNotificationListener;

    public BlockingNotificationListener(AwsNotificationListener awsNotificationListener){
        this.awsNotificationListener = awsNotificationListener;
    }


    public <T> List<T> get(URI id, Class<T> valueType, int expectMinCount){
        return this.get( Muri.getObjectId(id), valueType, expectMinCount);
    }


    /**
     *
     * @param id            The Id of the object we're waiting for
     * @param valueType     The class of the type expected.
     * @param expectMinCount
     * @param <T>
     * @return
     */
    public <T> List<T> get( long id, Class<T> valueType, int expectMinCount){
        long startTime = System.currentTimeMillis();
        List <T> objects = null;
        long delay = 0L;
        while (true){
            objects = awsNotificationListener.get(id, valueType);
            if (delay>MAX_WAIT_MILLIS){
                String message = "Waited for more than " + delay + " millis on object " + id +" expecting a count of " + expectMinCount ;
                logger.error(message);
                return new ArrayList<>();
            }else if (objects!=null && objects.size()>=expectMinCount){
                return objects;
            } else {
                try{
                    Thread.sleep(200);
                } catch (Exception exc){}
                delay = System.currentTimeMillis()-startTime;
            }

        }

    }


}
