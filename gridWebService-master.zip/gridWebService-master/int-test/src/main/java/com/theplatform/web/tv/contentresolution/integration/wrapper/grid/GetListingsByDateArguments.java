package com.theplatform.web.tv.contentresolution.integration.wrapper.grid;

import java.util.Date;

public class GetListingsByDateArguments {

    public Long stationId;
    public Date startTime;
    public Date endTime;
    public Integer gridUnitWidth;
    public Long[] programTagIds;
    public String fields;

    public GetListingsByDateArguments() {
        stationId = null;
        startTime = null;
        endTime = null;
        gridUnitWidth = null;
    }

    public GetListingsByDateArguments stationId(Long stationId) {
        this.stationId = stationId;
        return this;
    }

    public GetListingsByDateArguments startTime(Date startTime) {
        this.startTime = startTime;
        return this;
    }

    public GetListingsByDateArguments endTime(Date endTime) {
        this.endTime = endTime;
        return this;
    }

    public GetListingsByDateArguments gridUnitWidth(Integer gridUnitWidth) {
        this.gridUnitWidth = gridUnitWidth;
        return this;
    }

    public GetListingsByDateArguments programTagIds(Long[] programTagIds) {
        this.programTagIds = programTagIds;
        return this;
    }

    public GetListingsByDateArguments fields(String fields) {
        this.fields = fields;
        return this;
    }

}
