package com.theplatform.web.tv.contentresolution.integration.wrapper.grid;

import com.theplatform.contrib.data.api.objects.Muri;

import java.util.List;

public class GetListingsByIdArguments {

    public List<Muri> listingIds;

    public GetListingsByIdArguments() {
        this.listingIds = null;
    }

    public GetListingsByIdArguments listingIds(List<Muri> listingIds) {
        this.listingIds = listingIds;
        return this;
    }
}
