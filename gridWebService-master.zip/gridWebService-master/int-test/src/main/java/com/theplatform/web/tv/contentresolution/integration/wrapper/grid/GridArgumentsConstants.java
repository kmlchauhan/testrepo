package com.theplatform.web.tv.contentresolution.integration.wrapper.grid;

public class GridArgumentsConstants {

    protected static final Integer DEFAULT_NUM_GRID_UNITS = 6;
    protected static final Integer DEFAULT_GRID_UNIT_WIDTH = 30;
    protected static final Integer DEFAULT_OFFSET = 0;
}
