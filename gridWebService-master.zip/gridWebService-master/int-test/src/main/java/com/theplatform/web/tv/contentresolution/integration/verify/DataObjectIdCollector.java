package com.theplatform.web.tv.contentresolution.integration.verify;

import com.theplatform.data.api.objects.DataObject;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class DataObjectIdCollector {

    private static final URI[] URI = new URI[0];

    public static <T extends DataObject> Collection<URI> collect(List<T>... dataObjects) {
        List<T> unifiedList = new ArrayList<T>();
        for (List<T> list : dataObjects) {
            unifiedList.addAll(list);
        }
        return collect(unifiedList);
    }

    public static <T extends DataObject> Collection<URI> collect(List<T> dataObjects) {
        @SuppressWarnings("unchecked")
        Collection<URI> collection = CollectionUtils.collect(dataObjects,
                new Transformer() {
                    @Override
                    public Object transform(Object input) {
                        T channel = (T) input;
                        return channel.getId();
                    }
                });
        return new ArrayList<URI>(collection);
    }

    public static <T extends DataObject> URI[] collectToArray(List<T> dataObjects) {
        return collect(dataObjects).toArray(URI);
    }
}
