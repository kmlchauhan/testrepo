package com.theplatform.web.tv.contentresolution.integration.wrapper;

import com.theplatform.web.api.annotation.WebServiceVersion;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.IdCollection;
import com.theplatform.web.tv.contentresolution.api.ContentResolutionService;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfoCollection;
import com.theplatform.web.tv.contentresolution.api.objects.Grid;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.gws.uri.IdForm;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.*;
import com.theplatform.web.tv.GridException;

import java.util.List;

/**
 * Created by jcoelho on 6/7/13.
 */
public interface ContentResolutionServiceTestWrapper {

    public static final String CURRENT_SCHEMA_VERSION = ContentResolutionService.class.getAnnotation(WebServiceVersion.class).value();

    public ChannelInfoCollection resolveChannels(ResolveArguments arguments) throws GridException;

    public ChannelInfoCollection resolveChannelsByStreamId(ResolveByStreamIdArguments arguments) throws GridException;

    public Grid getGrid(GetGridArguments arguments) throws GridException;

    public Grid getGridByDate(GetGridByDateArguments arguments) throws GridException;

    public List<ListingInfo> getListings(GetListingsArguments arguments) throws GridException;

    public List<ListingInfo> getListingsByDate(GetListingsByDateArguments arguments) throws GridException;

    public List<ListingInfo> getListingsById(GetListingsByIdArguments arguments) throws GridException;

    public IdCollection getChannelAvailabilityIds() throws GridException;

    public ChannelInfoCollection getChannelsByAvailabilityId( Muri channelsAvailabilityId) throws GridException;;

    public IdCollection getStreamsByStationIdAndAvailabilityId(Muri stationId, Muri availabilityId);

    IdForm getIdForm();
}
