package com.theplatform.web.tv.contentresolution.integration.verify;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.data.api.client.DataService;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.contrib.data.api.objects.Muri;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.HeadMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;

/**
 *  The DataObjectFactory and the DataObjectFactoryBlockerDecorator wrapper being used by our tests does not support
 *  deletes.  We shouldn't use the DataServiceClient directly because the delete may take time to propagate to CRS.
 *  This class will block until CRS recognizes the delete.
 *
 */
public class DataObjectDeleteBlocker {
    private static final Logger logger = LoggerFactory.getLogger(DataObjectDeleteBlocker.class);

    private static final long MAX_WAIT = 15000;

    private HttpClient httpClient;
    private String crsBaseUrl;

    public DataObjectDeleteBlocker(String crsBaseUrl){
        this.httpClient = new HttpClient();
        this.crsBaseUrl = crsBaseUrl;
    }


    public void delete(DataObjectFactory dataServiceFactory, URI id) {
        DataService dataServiceClient = dataServiceFactory.getClient();
        SiriusObjectType type = SiriusObjectType.fromDataServiceObjectClass(dataServiceFactory.getDataObjectClass());
        String endpointName = type.getFriendlyName();

        boolean success = false;
        int attempts = 0;
        while (!success && attempts<5)
        try {
            attempts++;
            dataServiceClient.delete(id);
            success = true;
        }catch (Exception exc){
            logger.error( "Failed attempt to delete " + id, exc);
            try {
                Thread.sleep(3_000);
            }catch (Exception e){}
        }

        blockDelete(Muri.getObjectId( id), endpointName);
    }


    private void blockDelete( long id, String endpointName ){
        Long diff = 0l;
        String uri = crsBaseUrl+"sirius/data/"+ endpointName +"/" + id;
        HeadMethod headMethod = new HeadMethod(uri);
        int responseCode;
        long currentTimeMillis = System.currentTimeMillis();
        try {
            responseCode = httpClient.executeMethod(headMethod);
            while(diff < MAX_WAIT) {
                responseCode = httpClient.executeMethod(headMethod);
                if (responseCode!=200) break;
                Thread.sleep(200);
                diff = System.currentTimeMillis() - currentTimeMillis;
            }
        } catch (Exception e) {
            logger.error("Error trying to wait for " + uri + "\n" + e.getMessage());
            throw new RuntimeException("Error trying to wait till object is on CRS.", e);
        }
        if(responseCode == 200){
            String message = "Waited for more than "+ diff +" millis for the delete of object \""+uri+"\". Received response code = " + responseCode;
            logger.error(message);
        }else{
            logger.info("Object checker received " + uri);
        }
    }


}
