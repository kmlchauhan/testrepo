package com.theplatform.web.tv.contentresolution.integration.wrapper.grid;

/**
 * Wrapper class for arguments of getListings method for GridService.
 * 
 * @author gservente
 */
public class GetListingsArguments {

    public Long stationId;
    public Integer numGridUnits;
    public Integer gridUnitWidth;
    public Integer offset;
    public Long[] programTagIds;
    public String fields;

    public GetListingsArguments() {
        this.stationId = null;
        this.numGridUnits = null;
        this.gridUnitWidth = null;
        this.gridUnitWidth = null;
        this.offset = null;
    }

    public GetListingsArguments stationId(Long stationId) {
        this.stationId = stationId;
        return this;
    }

    public GetListingsArguments numGridUnits(Integer numGridUnits) {
        this.numGridUnits = numGridUnits;
        return this;
    }

    public GetListingsArguments gridUnitWidth(Integer gridUnitWidth) {
        this.gridUnitWidth = gridUnitWidth;
        return this;
    }

    public GetListingsArguments offset(Integer offset) {
        this.offset = offset;
        return this;
    }

    public GetListingsArguments programTagIds(Long... programTagIds) {
        this.programTagIds = programTagIds;
        return this;
    }

    public GetListingsArguments fields(String fields) {
        this.fields = fields;
        return this;
    }
}
