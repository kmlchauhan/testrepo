package com.theplatform.web.tv.contentresolution.integration;

import com.amazon.sqs.javamessaging.SQSConnection;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.internal.StaticCredentialsProvider;
import com.theplatform.web.tv.notification.AwsNotificationListener;

import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.Session;

/**
 *  Factory used for creating/getting a single instance of #AwsNotificationListener
 *
 *  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 *  Using this factory to configure the bean creation in XML will also create multiple instance if the failsafe
 *  forkCount is greater than 1 (it is in CRS).  In that case you will have multiple instances even if it's a
 *  singleton.
 *  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 */
public class AwsNotificationListenerFactory {
    private static AwsNotificationListener awsNotificationListener;



    public static synchronized AwsNotificationListener create ( String accessKey
                                          , String secretKey
                                          , String region
                                          , String proxyHost
                                          , int proxyPort
                                          , String queueName) throws JMSException{
        if (awsNotificationListener==null) {
            BasicAWSCredentials basicAWSCredentials
                    = new BasicAWSCredentials(accessKey, secretKey);
            StaticCredentialsProvider staticCredentialsProvider = new StaticCredentialsProvider(basicAWSCredentials);

            ClientConfiguration clientConfiguration = new ClientConfiguration();
            clientConfiguration.setProxyHost(proxyHost);
            clientConfiguration.setProxyPort(proxyPort);

            SQSConnectionFactory connectionFactory =
                    SQSConnectionFactory.builder()
                            .withRegionName(region)
                            .withClientConfiguration(clientConfiguration)
                            .withAWSCredentialsProvider(staticCredentialsProvider)
                            .build();

            SQSConnection connection = connectionFactory.createConnection();
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            Queue queue = session.createQueue(queueName);


            MessageConsumer messageConsumer = session.createConsumer(queue);

            awsNotificationListener = new AwsNotificationListener();
            messageConsumer.setMessageListener(awsNotificationListener);
            connection.start();
        }

        return awsNotificationListener;
    }



}
