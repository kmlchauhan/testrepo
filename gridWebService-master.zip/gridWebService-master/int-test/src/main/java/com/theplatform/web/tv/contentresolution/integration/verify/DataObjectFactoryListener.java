package com.theplatform.web.tv.contentresolution.integration.verify;


public interface DataObjectFactoryListener {

    public void notify(CRSObjectNotification notification);

}
