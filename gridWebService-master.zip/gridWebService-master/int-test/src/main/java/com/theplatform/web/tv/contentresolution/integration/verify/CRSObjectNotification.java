package com.theplatform.web.tv.contentresolution.integration.verify;


public class CRSObjectNotification {

    private String endpointName;
    
    public String getEndpointName() {
        return endpointName;
    }

    public void setEndpointName(String endpointName) {
        this.endpointName = endpointName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    private Long id;

    public CRSObjectNotification(String endpointName, Long id) {
        this.endpointName = endpointName;
        this.id = id;
    }

}
