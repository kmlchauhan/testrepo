package com.theplatform.web.tv.contentresolution.integration.verify;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.decorator.DataObjectFactoryDecorator;
import com.theplatform.data.api.client.DataService;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.DataObject;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.HeadMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class DataObjectFactoryBlockerDecorator<O extends DataObject, C extends DataService<O>> extends DataObjectFactoryDecorator<O, C> {
    private static final Logger logger = LoggerFactory.getLogger(DataObjectFactoryBlockerDecorator.class);

    private String endpointName;
    private HttpClient httpClient;
    private String crsBaseUrl;

    private static final long MAX_WAIT = 240_000;

    public DataObjectFactoryBlockerDecorator(DataObjectFactory<O, C> decoratedFactory, String crsBaseUrl) {
        super(decoratedFactory);
        this.httpClient = new HttpClient();
        SiriusObjectType type = SiriusObjectType.fromDataServiceObjectClass(((DataServiceClient<?>)decoratedFactory.getClient()).getDataObjectClass());
        this.endpointName = type.getFriendlyName();
        this.crsBaseUrl =crsBaseUrl;
    }

    @Override
    public O create(Object... fieldOverrides) {
        O createdObject = decoratedFactory.create(fieldOverrides);
        block(Muri.getObjectId(createdObject.getId()));

        return createdObject;
    }

    @Override
    public List<O> create(Integer amount, Object... fieldOverrides) {
        List<O> createdObjects = this.decoratedFactory.create(amount, fieldOverrides);

        for (O object : createdObjects) {
            block(Muri.getObjectId(object.getId()));
        }

        return createdObjects;
    }

    private void block(long id){
        Long diff = 0l;
        String uri = crsBaseUrl+"sirius/data/"+ endpointName +"/" + id;
        HeadMethod headMethod = new HeadMethod(uri);
        int responseCode;
        long currentTimeMillis = System.currentTimeMillis();
        try {
            responseCode = httpClient.executeMethod(headMethod);
            while(diff < MAX_WAIT) {
                responseCode = httpClient.executeMethod(headMethod);
                if (responseCode==200) break;
                Thread.sleep(200);
                diff = System.currentTimeMillis() - currentTimeMillis;
            }
        } catch (Exception e) {
            logger.error("Error trying to wait for " + uri + "\n" + e.getMessage());
            throw new RuntimeException("Error trying to wait till object is on CRS.", e);
        }
        if(responseCode != 200){
            String message = "Waited for more than "+ diff +" millis on object \""+uri+"\". Received response code = " + responseCode;
            logger.error(message);
            //throw new RuntimeException(message);
        }else{
            logger.info("Object checker received " + uri);
        }
    }

}
