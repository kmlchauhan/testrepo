package com.theplatform.web.tv.contentresolution.integration.verify;


import com.theplatform.web.tv.contentresolution.integration.verify.CRSObjectNotification;

public interface Pollable {

    public CRSObjectNotification poll();
}
