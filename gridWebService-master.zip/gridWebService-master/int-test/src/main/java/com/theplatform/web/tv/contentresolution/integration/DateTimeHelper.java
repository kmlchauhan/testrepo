package com.theplatform.web.tv.contentresolution.integration;

import org.joda.time.DateTimeZone;
import org.joda.time.MutableDateTime;

public class DateTimeHelper {

    public static MutableDateTime getActualHourOfDate() {
        MutableDateTime dateTime = new MutableDateTime(DateTimeZone.UTC);
        dateTime.setMillisOfSecond(0);
        dateTime.setSecondOfMinute(0);
        dateTime.setMinuteOfHour(0);
        return dateTime;
    }
}
