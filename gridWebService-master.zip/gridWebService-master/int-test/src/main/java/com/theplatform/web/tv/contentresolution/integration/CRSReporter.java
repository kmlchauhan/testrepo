package com.theplatform.web.tv.contentresolution.integration;

import org.apache.commons.collections.CollectionUtils;
import org.testng.ISuite;
import org.testng.reporters.XMLReporter;
import org.testng.xml.XmlSuite;

import java.util.List;

public class CRSReporter extends XMLReporter {

    @Override
    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
        if (CollectionUtils.isNotEmpty(suites) && CollectionUtils.isNotEmpty(suites.get(0).getAllMethods())) {
            if (!outputDirectory.endsWith("/"))
                outputDirectory += "/";
            outputDirectory += suites.get(0).getAllMethods().get(0).getTestClass().getRealClass().getCanonicalName();
        }
        super.generateReport(xmlSuites, suites, outputDirectory);
    }
}
