package com.theplatform.web.tv.contentresolution.integration.wrapper;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.IdCollection;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfoCollection;
import com.theplatform.web.tv.contentresolution.api.objects.Grid;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.gws.uri.IdForm;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetGridArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetGridByDateArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetListingsArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetListingsByDateArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetListingsByIdArguments;
import com.theplatform.web.tv.GridException;

import java.util.List;

public class CheckerCRSTestWrapper implements ContentResolutionServiceTestWrapper {

    ContentResolutionServiceTestWrapper delegate;

    public CheckerCRSTestWrapper(ContentResolutionServiceTestWrapper delegate) {
        this.delegate = delegate;
    }

    public ChannelInfoCollection resolveChannels(ResolveArguments arguments) throws GridException {
        return delegate.resolveChannels(arguments);
    }

    @Override
    public ChannelInfoCollection resolveChannelsByStreamId(ResolveByStreamIdArguments arguments) throws GridException {
        return delegate.resolveChannelsByStreamId(arguments);
    }

    public Grid getGrid(GetGridArguments arguments) throws GridException {
        return delegate.getGrid(arguments);
    }

    public Grid getGridByDate(GetGridByDateArguments arguments) throws GridException {
        return delegate.getGridByDate(arguments);
    }

    public List<ListingInfo> getListings(GetListingsArguments arguments) throws GridException {
        return delegate.getListings(arguments);
    }

    public List<ListingInfo> getListingsById(GetListingsByIdArguments arguments) throws GridException {
        return delegate.getListingsById(arguments);
    }

    public List<ListingInfo> getListingsByDate(GetListingsByDateArguments arguments) throws GridException {
        return delegate.getListingsByDate(arguments);
    }


    @Override
    public IdCollection getChannelAvailabilityIds() throws GridException {
        return delegate.getChannelAvailabilityIds();
    }

    @Override
    public ChannelInfoCollection getChannelsByAvailabilityId(Muri channelsAvailabilityId) throws GridException {
        return delegate.getChannelsByAvailabilityId(channelsAvailabilityId);
    }

    @Override
    public IdCollection getStreamsByStationIdAndAvailabilityId(Muri stationId, Muri availabilityId) {
        return delegate.getStreamsByStationIdAndAvailabilityId(stationId, availabilityId);
    }

    public IdForm getIdForm() {
        return delegate.getIdForm();
    }

}
