/**
 *  Classes for verifying that CRS has received created objects from
 *  dataservices and populated its respective repository.
 *
 */
package com.theplatform.web.tv.contentresolution.integration.verify;
