package com.theplatform.web.tv.contentresolution.integration.wrapper;

import com.theplatform.web.api.client.exception.ServiceConnectionException;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.IdCollection;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfoCollection;
import com.theplatform.web.tv.contentresolution.api.objects.Grid;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.gws.uri.IdForm;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.*;
import com.theplatform.web.tv.GridException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class RetryCRSTestWrapper implements ContentResolutionServiceTestWrapper {
    private static Logger logger = LoggerFactory.getLogger(RetryCRSTestWrapper.class);

    ContentResolutionServiceTestWrapper delegate;
    private int tries;

    public RetryCRSTestWrapper(ContentResolutionServiceTestWrapper delegate, int tries) {
        this.delegate = delegate;
        if (tries>1){
            this.tries = tries;
        } else {
            this.tries=1;
        }
    }

    public ChannelInfoCollection resolveChannels(ResolveArguments arguments) throws GridException {
        ServiceConnectionException retExc = null;
        for (int i=1; i<=tries; i++){
            try{
                return delegate.resolveChannels(arguments);
            }catch (ServiceConnectionException exc){
                if(i<tries){
                    logger.info("Retrying... resolveChannels threw a service exception. " + exc.getCause().getMessage());
                }else{
                    retExc = exc;
                }
            }
        }
        throw retExc;
    }

    @Override
    public ChannelInfoCollection resolveChannelsByStreamId(ResolveByStreamIdArguments arguments) throws GridException {
        ServiceConnectionException retExc = null;
        for (int i=1; i<=tries; i++){
            try{
                return delegate.resolveChannelsByStreamId(arguments);
            }catch (ServiceConnectionException exc){
                if(i<tries){
                    logger.info("Retrying... resolveChannelsByStreamId threw a service exception. " + exc.getCause().getMessage());
                }else{
                    retExc = exc;
                }
            }
        }
        throw retExc;
    }

    public Grid getGrid(GetGridArguments arguments) throws GridException {
        ServiceConnectionException retExc = null;
        for (int i=1; i<=tries; i++){
            try{
                return delegate.getGrid(arguments);
            }catch (ServiceConnectionException exc){
                if(i<tries){
                    logger.info("Retrying... getGrid threw a service exception. " + exc.getCause().getMessage());
                }else{
                    retExc = exc;
                }
            }
        }
        throw retExc;
    }

    public Grid getGridByDate(GetGridByDateArguments arguments) throws GridException {
        ServiceConnectionException retExc = null;
        for (int i=1; i<=tries; i++){
            try{
                return delegate.getGridByDate(arguments);
            }catch (ServiceConnectionException exc){
                if(i<tries){
                    logger.info("Retrying... getGridByDate threw a service exception. " + exc.getCause().getMessage());
                }else{
                    retExc = exc;
                }
            }
        }
        throw retExc;
    }

    public List<ListingInfo> getListings(GetListingsArguments arguments) throws GridException {
        ServiceConnectionException retExc = null;
        for (int i=1; i<=tries; i++){
            try{
                return delegate.getListings(arguments);
            }catch (ServiceConnectionException exc){
                if(i<tries){
                    logger.info("Retrying... getListings threw a service exception. " + exc.getCause().getMessage());
                }else{
                    retExc = exc;
                }
            }
        }
        throw retExc;
    }

    public List<ListingInfo> getListingsById(GetListingsByIdArguments arguments) throws GridException {
        ServiceConnectionException retExc = null;
        for (int i=1; i<=tries; i++){
            try{
                return delegate.getListingsById(arguments);
            }catch (ServiceConnectionException exc){
                if(i<tries){
                    logger.info("Retrying... getListingsById threw a service exception. " + exc.getCause().getMessage());
                }else{
                    retExc = exc;
                }
            }
        }
        throw retExc;
    }

    public List<ListingInfo> getListingsByDate(GetListingsByDateArguments arguments) throws GridException {
        ServiceConnectionException retExc = null;
        for (int i=1; i<=tries; i++){
            try{
                return delegate.getListingsByDate(arguments);
            }catch (ServiceConnectionException exc){
                if(i<tries){
                    logger.info("Retrying... getListingsByDate threw a service exception. " + exc.getCause().getMessage());
                }else{
                    retExc = exc;
                }
            }
        }
        throw retExc;
    }


    @Override
    public IdCollection getChannelAvailabilityIds() throws GridException {
        ServiceConnectionException retExc = null;
        for (int i=1; i<=tries; i++){
            try{
                return delegate.getChannelAvailabilityIds();
            }catch (ServiceConnectionException exc){
                if(i<tries){
                    logger.info("Retrying... Backend.getChannelAvailabilityIds threw a service exception. " + exc.getCause().getMessage());
                }else{
                    retExc = exc;
                }
            }
        }
        throw retExc;
    }

    @Override
    public ChannelInfoCollection getChannelsByAvailabilityId(Muri channelsAvailabilityId) throws GridException {
        ServiceConnectionException retExc = null;
        for (int i=1; i<=tries; i++){
            try{
                return delegate.getChannelsByAvailabilityId(channelsAvailabilityId);
            }catch (ServiceConnectionException exc){
                if(i<tries){
                    logger.info("Retrying... Backend.getChannelsByAvailabilityId threw a service exception. " + exc.getCause().getMessage());
                }else{
                    retExc = exc;
                }
            }
        }
        throw retExc;
    }

    @Override
    public IdCollection getStreamsByStationIdAndAvailabilityId(Muri stationId, Muri availabilityId) {
        ServiceConnectionException retExc = null;
        for (int i=1; i<=tries; i++){
            try{
                return delegate.getStreamsByStationIdAndAvailabilityId( stationId, availabilityId);
            }catch (ServiceConnectionException exc){
                if(i<tries){
                    logger.info("Retrying... getStreamsByStationIdAndAvailabilityId threw a service exception. " + exc.getCause().getMessage());
                }else{
                    retExc = exc;
                }
            }
        }
        throw retExc;
    }


    public IdForm getIdForm() {
        return delegate.getIdForm();
    }

}

