package com.theplatform.web.tv.contentresolution.integration.wrapper;


import com.comcast.compass.availability.common.domain.AvailabilityResolution;

public class ResolveByStreamIdArguments {
    public AvailabilityResolution resolveAvailabilityResponse;
    public Long streamId;
    public String fields;
    public Boolean filterAdult;

    public ResolveByStreamIdArguments(AvailabilityResolution resolveAvailabilityResponse, Long streamId) {
        this.resolveAvailabilityResponse = resolveAvailabilityResponse;
        this.streamId = streamId;
    }

    public ResolveByStreamIdArguments(AvailabilityResolution resolveAvailabilityResponse, Long streamId, String fields) {
        this.resolveAvailabilityResponse = resolveAvailabilityResponse;
        this.streamId = streamId;
        this.fields = fields;
    }

    public AvailabilityResolution getResolveAvailabilityResponse() {
        return resolveAvailabilityResponse;
    }

    public Long getStreamId() {
        return streamId;
    }

    public String getFields() {
        return fields;
    }

    public Boolean getFilterAdult() {
        return filterAdult;
    }
}
