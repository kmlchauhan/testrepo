package com.theplatform.web.tv.contentresolution.integration.wrapper;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.IdCollection;
import com.theplatform.web.tv.contentresolution.api.ContentResolutionService;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfoCollection;
import com.theplatform.web.tv.contentresolution.api.objects.Grid;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.gws.uri.IdForm;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.*;
import com.theplatform.web.tv.GridException;

import java.util.List;

public class ContentResolutionServicePostTestWrapper implements ContentResolutionServiceTestWrapper {

    private final ContentResolutionService service;
    private GridMethodsCRSTestWrapper gridMethodsTestWrapper;
    private IdForm idForm;

    public ContentResolutionServicePostTestWrapper(ContentResolutionService service, IdForm idForm) {
        this.service = service;
        this.gridMethodsTestWrapper = new GridMethodsCRSTestWrapper(service);
        this.idForm = idForm;
    }

    public ContentResolutionService getService() {
        return service;
    }

    @Override
    public ChannelInfoCollection resolveChannels(ResolveArguments arguments) throws GridException {
        return this.service.resolveChannels(arguments.getResolveAvailabilityResponse(),
            arguments.getFields(), arguments.getByStreamStatus(),arguments.getFilterAdult());
    }

    public ChannelInfoCollection resolveChannelsByStreamId(ResolveByStreamIdArguments arguments) throws GridException {
        return this.service.resolveChannelsByStreamId(arguments.getResolveAvailabilityResponse(), arguments.getStreamId(), arguments.getFields(), arguments.getFilterAdult());
    }

    public Grid getGrid(GetGridArguments arguments) throws GridException {
        return gridMethodsTestWrapper.getGrid(arguments);
    }

    public Grid getGridByDate(GetGridByDateArguments arguments) throws GridException {
        return gridMethodsTestWrapper.getGridByDate(arguments);
    }

    public List<ListingInfo> getListings(GetListingsArguments arguments) throws GridException {
        return gridMethodsTestWrapper.getListings(arguments);
    }

    public List<ListingInfo> getListingsById(GetListingsByIdArguments arguments) throws GridException {
        return gridMethodsTestWrapper.getListingsById(arguments);
    }

    public List<ListingInfo> getListingsByDate(GetListingsByDateArguments arguments) throws GridException {
        return gridMethodsTestWrapper.getListingsByDate(arguments);
    }

    @Override
    public IdCollection getChannelAvailabilityIds() throws GridException {
        return service.getChannelAvailabilityIds();
    }

    @Override
    public ChannelInfoCollection getChannelsByAvailabilityId(Muri channelsAvailabilityId) throws GridException {
        return service.getChannelsByAvailabilityId(channelsAvailabilityId);
    }

    public IdCollection getStreamsByStationIdAndAvailabilityId(Muri stationId, Muri availabilityId) {
        return service.getStreamsByStationIdAndAvailabilityId(stationId, availabilityId);
    }

    @Override
    public IdForm getIdForm() {
        return idForm;
    }

}
