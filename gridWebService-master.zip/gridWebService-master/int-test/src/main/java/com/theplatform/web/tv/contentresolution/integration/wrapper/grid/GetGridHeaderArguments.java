package com.theplatform.web.tv.contentresolution.integration.wrapper.grid;

public class GetGridHeaderArguments {

    public Integer numGridUnits;
    public Integer gridUnitWidth;
    public Integer offset;
    public String timeZone;

    public GetGridHeaderArguments numGridUnits(Integer numGridUnits) {
        this.numGridUnits = numGridUnits;
        return this;
    }

    public GetGridHeaderArguments gridUnitWidth(Integer gridUnitWidth) {
        this.gridUnitWidth = gridUnitWidth;
        return this;
    }

    public GetGridHeaderArguments offset(Integer offset) {
        this.offset = offset;
        return this;
    }

    public GetGridHeaderArguments timeZone(String timeZone) {
        this.timeZone = timeZone;
        return this;
    }

}
