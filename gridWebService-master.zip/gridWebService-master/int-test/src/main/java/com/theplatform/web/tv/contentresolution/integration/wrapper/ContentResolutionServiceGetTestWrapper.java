package com.theplatform.web.tv.contentresolution.integration.wrapper;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.module.exception.BadParameterException;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.IdCollection;
import com.theplatform.web.tv.contentresolution.api.client.ContentResolutionGetClient;
import com.theplatform.web.tv.contentresolution.api.objects.ChannelInfoCollection;
import com.theplatform.web.tv.contentresolution.api.objects.Grid;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.gws.uri.IdForm;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetGridArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetGridByDateArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetListingsArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetListingsByDateArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetListingsByIdArguments;
import com.theplatform.web.tv.GridException;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.GetMethod;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class ContentResolutionServiceGetTestWrapper implements ContentResolutionServiceTestWrapper {

    ContentResolutionGetClient contentResolutionGetClient;
    private GridMethodsCRSTestWrapper gridMethodsTestWrapper;
    private IdForm idForm;

    public ContentResolutionServiceGetTestWrapper(ContentResolutionGetClient contentResolutionGetClient,IdForm idForm) {
        this.contentResolutionGetClient = contentResolutionGetClient;
        this.gridMethodsTestWrapper = new GridMethodsCRSTestWrapper(contentResolutionGetClient.getService());
        this.idForm = idForm;
    }

    @Override
    public ChannelInfoCollection resolveChannels(ResolveArguments arguments) {
        GetMethod getMethod;
        ChannelInfoCollection responseObject;
        String strMethodResponse = "";

        try {
            getMethod = executeGet(arguments, "resolveChannels");
            ObjectMapper om = new ObjectMapper();
            strMethodResponse = getMethod.getResponseBodyAsString();
            responseObject = (om.readValue(getMethod.getResponseBody(), ResolveChannelResponse.class)).getResolveChannelsResponse();
        } catch (IOException e) {
            e.printStackTrace();
            throw new BadParameterException(strMethodResponse);
        }
        return responseObject;
    }

    @Override
    public ChannelInfoCollection resolveChannelsByStreamId(ResolveByStreamIdArguments arguments) {
        GetMethod getMethod;
        ChannelInfoCollection responseObject;
        String strMethodResponse = "";

        try {
            getMethod = executeGet(arguments, "resolveChannelsByStreamId");
            ObjectMapper om = new ObjectMapper();
            strMethodResponse = getMethod.getResponseBodyAsString();
            responseObject = (om.readValue(getMethod.getResponseBody(), ResolveChannelsByStreamIdResponse.class)).getResolveChannelsByStreamIdResponse();
        } catch (IOException e) {
            throw new BadParameterException(strMethodResponse);
        }
        return responseObject;
    }

    @Override
    public Grid getGrid(GetGridArguments arguments) {
        GetMethod getMethod;
        Grid responseObject;
        String strMethodResponse = "";

        try {
            getMethod = executeGet(arguments, "getGrid");
            ObjectMapper om = new ObjectMapper();
            strMethodResponse = getMethod.getResponseBodyAsString();
            responseObject = (om.readValue(getMethod.getResponseBody(), GetGridResponse.class)).getGetGridResponse();
        } catch (IOException e) {
            e.printStackTrace();
            throw new BadParameterException(strMethodResponse);
        }
        return responseObject;
    }

    @Override
    public Grid getGridByDate(GetGridByDateArguments arguments) {
        GetMethod getMethod;
        Grid responseObject;
        String strMethodResponse = "";

        try {
            getMethod = executeGet(arguments, "getGridByDate");
            ObjectMapper om = new ObjectMapper();
            strMethodResponse = getMethod.getResponseBodyAsString();
            responseObject = (om.readValue(getMethod.getResponseBody(), GetGridByDateResponse.class)).getGetGridByDateResponse();
        } catch (IOException e) {
            e.printStackTrace();
            throw new BadParameterException(strMethodResponse);
        }
        return responseObject;
    }

    @Override
    public List<ListingInfo> getListings(GetListingsArguments arguments) throws GridException {
        List<ListingInfo> responseObject;
        String strMethodResponse = "";
        try {
            ObjectMapper om = new ObjectMapper();
            GetMethod getMethod = executeGet(arguments, "getListings");
            strMethodResponse = getMethod.getResponseBodyAsString();
            responseObject = om.readValue(getMethod.getResponseBody(), GetListingsResponse.class).getGetListingsResponse();
        } catch (IOException e) {
            e.printStackTrace();
            throw new BadParameterException(strMethodResponse);
        }
        return responseObject;
    }

    @Override
    public List<ListingInfo> getListingsById(GetListingsByIdArguments arguments) throws GridException {
        List<ListingInfo> responseObject;
        String strMethodResponse = "";
        try {
            ObjectMapper om = new ObjectMapper();
            GetMethod getMethod = executeGet(arguments, "getListingsById");
            strMethodResponse = getMethod.getResponseBodyAsString();
            responseObject = om.readValue(getMethod.getResponseBody(), GetListingsByIdResponse.class).getGetListingsByIdResponse();
        } catch (IOException e) {
            e.printStackTrace();
            throw new BadParameterException(strMethodResponse);
        }
        return responseObject;
    }

    @Override
    public List<ListingInfo> getListingsByDate(GetListingsByDateArguments arguments) throws GridException {
        List<ListingInfo> responseObject;
        String strMethodResponse = "";
        try {
            ObjectMapper om = new ObjectMapper();
            GetMethod getMethod = executeGet(arguments, "getListingsByDate");
            strMethodResponse = getMethod.getResponseBodyAsString();
            responseObject = om.readValue(getMethod.getResponseBody(), GetListingsByDateResponse.class).getGetListingsByDateResponse();
        } catch (IOException e) {
            e.printStackTrace();
            throw new BadParameterException(strMethodResponse);
        }
        return responseObject;
    }

    public IdCollection getChannelAvailabilityIds() throws GridException{
        throw new RuntimeException("Unsupported GET test");
    }

    public ChannelInfoCollection getChannelsByAvailabilityId( Muri channelsAvailabilityId) throws GridException{
        throw new RuntimeException("Unsupported GET test");
    }

    public IdCollection getProductContextByStationId(Muri stationId, long ownerId) throws GridException{
        throw new RuntimeException("Unsupported GET test");
    }

    @Override
    public IdCollection getStreamsByStationIdAndAvailabilityId(Muri stationId, Muri availabilityId) {
        throw new RuntimeException("Unsupported GET test");
    }


    @Override
    public IdForm getIdForm() {
        return idForm;
    }

    protected GetMethod executeGet(Object arguments, String type, Header... headers) throws IOException {
        String requestURL = contentResolutionGetClient.getRequestURL();

        GetMethod method = new GetMethod(requestURL + "/" + type);

        method.setQueryString(getJsonRequestParameters(
                arguments,
                getIdForm(),
                "ContentResolutionGetTestClient"));

        for (Header h : headers)
            method.setRequestHeader(h);

        HostConfiguration hostConfiguration = new HostConfiguration();
        hostConfiguration.setHost(new URI(requestURL, false));

        HttpClient httpClient = new HttpClient();
        httpClient.executeMethod(hostConfiguration, method);
        return method;
    }

    protected NameValuePair[] getJsonRequestParameters(Object arguments, IdForm idForm, String clientId) {
        List<NameValuePair> nameValuePairs = new ArrayList<>();
        nameValuePairs.addAll(Arrays.asList(
                new NameValuePair("schema", CURRENT_SCHEMA_VERSION),
                new NameValuePair("form", "json"),
                new NameValuePair("idForm", idForm.toString()),
                new NameValuePair("clientId", clientId)
        ));

        Field[] fields = arguments.getClass().getDeclaredFields();
        for (Field field : fields) {
            try {
                nameValuePairs.addAll(createNameValuePairs(field, arguments));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return nameValuePairs.toArray(new NameValuePair[nameValuePairs.size()]);
    }

    /**
     * Attempt to create a list of name value pairs depending on the field and value in the Object.
     * @param field
     * @param arguments
     * @return
     * @throws IllegalAccessException
     * @throws IOException
     */
    protected List<NameValuePair> createNameValuePairs(Field field, Object arguments) throws IllegalAccessException, IOException {
        List<NameValuePair> nameValuePairs = new ArrayList<>();
            Object value = field.get(arguments);
            if (value != null) {
                if (value instanceof Date) {
                    nameValuePairs.add(new NameValuePair("_" + field.getName(), Long.valueOf(((Date) value).getTime()).toString()));
                } else if (value instanceof AvailabilityResolution) {
                    ObjectMapper om = new ObjectMapper();
                    nameValuePairs.add(new NameValuePair("_" + field.getName(), om.writeValueAsString(value)));
                } else if (value instanceof List) {
                    List<?> objectList = (List<?>)value;
                    for (int i = 0; i < objectList.size(); i++) {
                        nameValuePairs.add(new NameValuePair("_" + field.getName() + "[" +i+ "]", objectList.get(i).toString()));
                    }
                } else if (value.getClass().isArray()) {
                    Object[] objectArray = (Object[])value;
                    for (int i = 0; i < objectArray.length; i++) {
                        nameValuePairs.add(new NameValuePair("_" + field.getName() + "[" +i+ "]", objectArray[i].toString()));
                    }
                } else {
                    nameValuePairs.add(new NameValuePair("_" + field.getName(), value.toString()));
                }
            } else if (field.getType().equals(List.class) || field.getType().isArray() || field.getType().equals(Muri.class)) {
                //Do not add a NameValuePair for a null List or array. Attempting to do so will cause an error on the server
            }else {
                nameValuePairs.add(new NameValuePair("_" + field.getName(), null));
            }
        return nameValuePairs;
    }

    public static class ResolveChannelResponse {
        private ChannelInfoCollection resolveChannelsResponse;

        public ChannelInfoCollection getResolveChannelsResponse() {
            return resolveChannelsResponse;
        }

        public void setResolveChannelsResponse(ChannelInfoCollection resolveChannelsResponse) {
            this.resolveChannelsResponse = resolveChannelsResponse;
        }
    }

    public static class ResolveChannelsByStreamIdResponse {
        private ChannelInfoCollection resolveChannelsByStreamIdResponse;

        public ChannelInfoCollection getResolveChannelsByStreamIdResponse() {
            return resolveChannelsByStreamIdResponse;
        }

        public void setResolveChannelsByStreamIdResponse(ChannelInfoCollection resolveChannelsByStreamIdResponse) {
            this.resolveChannelsByStreamIdResponse = resolveChannelsByStreamIdResponse;
        }
    }

    public static class GetGridResponse {
        private Grid getGridResponse;

        public Grid getGetGridResponse() {
            return getGridResponse;
        }

        public void setGetGridResponse(Grid getGridResponse) {
            this.getGridResponse = getGridResponse;
        }
    }

    public static class GetGridByDateResponse {
        private Grid getGridByDateResponse;

        public Grid getGetGridByDateResponse() {
            return getGridByDateResponse;
        }

        public void setGetGridByDateResponse(Grid getGridByDateResponse) {
            this.getGridByDateResponse = getGridByDateResponse;
        }
    }

    public static class GetListingsResponse {
        private List<ListingInfo> getListingsResponse;

        public List<ListingInfo> getGetListingsResponse() {
            return getListingsResponse;
        }

        public void setGetListingsResponse(List<ListingInfo> getListingsResponse) {
            this.getListingsResponse = getListingsResponse;
        }
    }

    public static class GetListingsByIdResponse {
        private List<ListingInfo> getListingsByIdResponse;

        public List<ListingInfo> getGetListingsByIdResponse() {
            return getListingsByIdResponse;
        }

        public void setGetListingsByIdResponse(List<ListingInfo> getListingsByIdResponse) {
            this.getListingsByIdResponse = getListingsByIdResponse;
        }
    }

    public static class GetListingsByDateResponse {
        private List<ListingInfo> getListingsByDateResponse;

        public List<ListingInfo> getGetListingsByDateResponse() {
            return getListingsByDateResponse;
        }

        public void setGetListingsByDateResponse(List<ListingInfo> getListingsByDateResponse) {
            this.getListingsByDateResponse = getListingsByDateResponse;
        }
    }
}
