package com.theplatform.web.tv.contentresolution.integration;

import com.comcast.compass.availability.common.domain.Availabilities;
import com.comcast.compass.availability.common.domain.AvailabilityResolution;
import com.theplatform.contrib.client.DataObjectUri;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.DataService;
import com.theplatform.data.tv.linear.api.client.ChannelClient;
import com.theplatform.data.tv.linear.api.client.LocationClient;
import com.theplatform.data.tv.linear.api.client.StationClient;
import com.theplatform.data.tv.linear.api.data.objects.Channel;
import com.theplatform.data.tv.linear.api.data.objects.Location;
import com.theplatform.data.tv.linear.api.data.objects.Station;
import com.theplatform.data.tv.linear.api.data.objects.StationCompany;
import com.theplatform.data.tv.linear.api.fields.ChannelField;
import com.theplatform.data.tv.linear.test.api.data.factory.ChannelFactory;
import com.theplatform.data.tv.offer.api.data.objects.ProductContext;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ProductContextInfo;
import com.theplatform.web.tv.gws.uri.IdForm;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.apache.commons.lang.ArrayUtils;
import org.testng.Assert;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CrsTestUtils {

    protected static final String URN_PRODUCT_CONTEXT_PREFIX = "merlin:offer:productcontext";
    public static final String URN_LOCATION_PREFIX = "merlin:linear:location";
    public static final String URN_AVAILABILITY_TAG_PREFIX = "merlin:offer:availabilitytag";
    public static final URI DEFAULT_AD_ZONE = URI.create("merlin:location:region:8634448521213633172");
    public static final URI DEFAULT_RECORDER_MANAGER = URI.create("merlin:location:recordermanager:5000000000000177");
    public static final String DEFAULT_VERSION = "1.0";
    public static final String STATION_SCOPE = "station";
    public static final String STREAM_SCOPE = "stream";

    public static URI getAvailabilityUrn(URI availabilityId) {
        String prefix;
        if (availabilityId.toString().contains("/Location/")) {
            prefix = URN_LOCATION_PREFIX;
        } else if (availabilityId.toString().contains("/AvailabilityTag/")) {
            prefix = URN_AVAILABILITY_TAG_PREFIX;
        } else {
            throw new IllegalArgumentException(availabilityId + "is not a valid availability id (expecting a URI for either a Location or AvailabilityTag");
        }
        return URI.create(prefix + ":" + URIUtils.getIdValue(availabilityId));
    }

    public static AvailabilityResolution getAvailabilityResolution(Availabilities... availabilitiesList) {
        AvailabilityResolution availabilityResolution = new AvailabilityResolution();
        availabilityResolution.setAdZone(DEFAULT_AD_ZONE);
        availabilityResolution.setRecorderManager(DEFAULT_RECORDER_MANAGER);
        availabilityResolution.setVersion(DEFAULT_VERSION);
        List<Availabilities> list = new ArrayList();
        for (Availabilities availabilities : availabilitiesList) {
            list.add(availabilities);
        }
        availabilityResolution.setAvailabilityGroups(list);
        return availabilityResolution;
    }

    public static Availabilities getAvailabilities(URI productContextUrn, String scope, URI... availabilityIds) {
        Availabilities availabilities = new Availabilities();
        availabilities.setProductContext(productContextUrn);
        availabilities.setScope(scope);
        List<URI> availabilityUrns = new ArrayList();
        for (URI availabilityId : availabilityIds) {
            URI availabilityUrn = getAvailabilityUrn(availabilityId);
            availabilityUrns.add(availabilityUrn);
        }
        availabilities.setAvailabilityIds(availabilityUrns);
        return availabilities;
    }

    public static Collection<URI> extractStationIds(List<StationCompany> stationCompanies) {
        ArrayList<URI> stationIds = new ArrayList<>(stationCompanies.size());

        for (StationCompany stationCompany : stationCompanies) {
            stationIds.add(stationCompany.getStationId());
        }
        return stationIds;
    }

    public static URI createProductContextUrn(ProductContext productContext, MerlinIdHelper merlinIdHelper) throws URISyntaxException {
        MerlinIdHelper urnHelper = MerlinIdHelper.withDefaultIdForm(merlinIdHelper, IdForm.URN);
        Muri muri = urnHelper.createProductContextId((new DataObjectUri(productContext.getId())).getObjectId());
        return URI.create(muri.getUri());
    }

    public static DataObjectFactory<Channel, DataService<Channel>> createChannelFactoryWithDigiCable(DataService<Channel> client, DataObjectFactory<Station, DataService<Station>> stationFactory, DataObjectFactory<Location, DataService<Location>> controllerLocationFactory, ValueProvider<Long> idProvider) {
        DataObjectFactory<Channel, DataService<Channel>> channelFactory = new ChannelFactory(client, stationFactory, controllerLocationFactory, idProvider);
        channelFactory.addPresetFieldsOverrides(ChannelField.digicableId, new Integer(101));   /* The populated digicableId will ensure we have a locator */
        return channelFactory;
    }

    public static final Long parseLongId(URI id){
        String tokens[] = id.toString().split("/");
        return Long.parseLong(tokens[tokens.length-1]);
    }

    public static void assertProductContextInfoListEqualsNoOrder(List<ProductContextInfo> actual,
                                                                 List<ProductContext> expected,
                                                                 MerlinIdHelper merlinIdHelper)  {
        List<ProductContextInfo> expectedProductContextInfo = new ArrayList<>();
        for (ProductContext pc : expected)
            expectedProductContextInfo.add(createProductContextInfoFromProductContext(pc, merlinIdHelper));
        Assert.assertEqualsNoOrder(actual.toArray(), expectedProductContextInfo.toArray());
    }

    public static void assertUriListEqualsCrsUriList(List<Muri> muris, List<URI> uris){
        Long[] crdUriIds = ArrayUtils.toObject(Muri.getIdsAsArray(muris));
        Long[] uriIds = ArrayUtils.toObject(Muri.getObjectIdsAsArray(uris));
        Assert.assertEqualsNoOrder( crdUriIds, uriIds);
    }

    /**
     * This should only ever be done in a testing scenario and NOT in the regular
     * functioning of CRS!
     * Collection<CRSUri> --> Collection<URI>
     */
    public static Collection<URI> convertCrsURIToURI(Collection<Muri> muris)  {
        if (muris ==null) return null;
        List<URI> uris = new ArrayList<>(muris.size());
        for (Muri muri : muris){
            uris.add(URI.create(muri.getUri()));
        }
        return uris;
    }
    /**
     * This should only ever be done in a testing scenario and NOT in the regular
     * functioning of CRS!
     * Collection<URI> --> Collection<CRSUri>
     */
    public static List<Muri> convertURItoCRSUri(List<URI> uris)  {
        if (uris==null) return null;
        List<Muri> muris = new ArrayList<>(uris.size());
        for (URI uri : uris){
            muris.add(new Muri(uri.toString()));
        }
        return muris;
    }


    static public ProductContextInfo createProductContextInfoFromProductContext(ProductContext p, MerlinIdHelper merlinIdHelper)  {
        ProductContextInfo pI = null;
        try {
            pI = new ProductContextInfo(merlinIdHelper.createProductContextId((new DataObjectUri(p.getId())).getObjectId()));
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
        pI.setTitle(p.getTitle());
        pI.setType(p.getType());
        return pI;
    }
}

