package com.theplatform.web.tv.contentresolution.integration.wrapper;


import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.springframework.beans.factory.annotation.Required;

import java.io.IOException;

public class IntTestClientUtils {
    private static final int RETRIES = 3;

    private String gridWsBaseUrl;

    public void setTveSyntheticChannelWhitelist(long locationId) {
        makeCall("/inttest/tveSyntheticChannelWhitelist/set/" + locationId);
    }

    private String makeCall(String request){
        String response = null;
        HttpClient httpClient = new HttpClient();
        String address = gridWsBaseUrl + request;
        GetMethod method = new GetMethod(address);
        method.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler(RETRIES, false));
        try {
            // Execute the method.
            int statusCode = httpClient.executeMethod(method);

            if (statusCode != HttpStatus.SC_OK) {
                throw new RuntimeException("Method failed: " + address + "\n" + method.getStatusLine());
            }

            byte[] responseBody = method.getResponseBody();
            response = new String(responseBody);
        } catch (HttpException e) {
            throw new RuntimeException("Fatal protocol violation: "  + address + "\n" +  e.getMessage());
        } catch (IOException e) {
            throw new RuntimeException("Fatal transport error: "  + address + "\n" +  e.getMessage());
        } finally {
            method.releaseConnection();
        }
        return response;
    }

    @Required
    public void setGridWsBaseUrl(String gridWsBaseUrl) {
        if (gridWsBaseUrl.endsWith("/")){
            this.gridWsBaseUrl = gridWsBaseUrl.substring(0,gridWsBaseUrl.length()-1);
        }else{
            this.gridWsBaseUrl = gridWsBaseUrl;
        }

    }
}
