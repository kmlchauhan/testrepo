package com.theplatform.web.tv.contentresolution.integration.wrapper.grid;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;

import java.util.Date;

public class GetGridByDateArguments {
    public AvailabilityResolution resolveAvailabilityResponse;
    public Date startTime;
    public Integer numGridUnits;
    public Integer gridUnitWidth;
    public String timeZone;
    public String[] categories;
    public Long[] companyIds;
    public Long[] stationTagIds;
    public String[] locatorFormats;
    public Boolean hd;
    public Integer rowStart;
    public Integer rowEnd;
    public Long[] programTagIds;
    public String fields;

    public GetGridByDateArguments availabilityResolution(AvailabilityResolution availabilityResolution) {
        this.resolveAvailabilityResponse = availabilityResolution;
        return this;
    }

    public GetGridByDateArguments numGridUnits(Date startTime) {
        this.startTime = startTime;
        return this;
    }

    public GetGridByDateArguments numGridUnits(Integer numGridUnits) {
        this.numGridUnits = numGridUnits;
        return this;
    }

    public GetGridByDateArguments gridUnitWidth(Integer gridUnitWidth) {
        this.gridUnitWidth = gridUnitWidth;
        return this;
    }

    public GetGridByDateArguments timeZone(String timeZone) {
        this.timeZone = timeZone;
        return this;
    }

    public GetGridByDateArguments categories(String[] categories) {
        this.categories = categories;
        return this;
    }

    public GetGridByDateArguments companyIds(Long[] companyIds) {
        this.companyIds = companyIds;
        return this;
    }

    public GetGridByDateArguments stationTagIds(Long[] stationTagIds) {
        this.stationTagIds = stationTagIds;
        return this;
    }

    public GetGridByDateArguments locatorFormats(String[] locatorFormats) {
        this.locatorFormats = locatorFormats;
        return this;
    }

    public GetGridByDateArguments hd(Boolean hd) {
        this.hd = hd;
        return this;
    }

    public GetGridByDateArguments rowStart(Integer rowStart) {
        this.rowStart = rowStart;
        return this;
    }

    public GetGridByDateArguments rowEnd(Integer rowEnd) {
        this.rowEnd = rowEnd;
        return this;
    }

    public GetGridByDateArguments programTagIds(Long[] programTagIds) {
        this.programTagIds = programTagIds;
        return this;
    }

    public GetGridByDateArguments fields(String fields) {
        this.fields = fields;
        return this;
    }
    
    public Integer getExpectedGridUnitWidth() {
        return gridUnitWidth == null ? GridArgumentsConstants.DEFAULT_GRID_UNIT_WIDTH : gridUnitWidth;
    }
}
