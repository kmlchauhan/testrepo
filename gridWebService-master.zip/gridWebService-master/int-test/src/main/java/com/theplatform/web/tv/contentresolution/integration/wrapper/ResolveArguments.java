package com.theplatform.web.tv.contentresolution.integration.wrapper;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;

public class ResolveArguments {
    /**
     * NOTE! All properties should be public so that they are picked up by ContentResolutionServiceGetTestWrapper
     */
    public AvailabilityResolution resolveAvailabilityResponse;
    public String fields;
    public String byStreamStatus;
    public Boolean filterAdult;

    public ResolveArguments(AvailabilityResolution resolveAvailabilityResponse,
                            String fields,
                            String byStatusField) {
        this.resolveAvailabilityResponse = resolveAvailabilityResponse;
        this.fields = fields;
        this.byStreamStatus = byStatusField;
    }

    public ResolveArguments(AvailabilityResolution resolveAvailabilityResponse, String fields) {
        this(resolveAvailabilityResponse, fields, null);
    }
    
    public ResolveArguments(AvailabilityResolution resolveAvailabilityResponse) {
        this(resolveAvailabilityResponse, null);
    }

    public ResolveArguments resolveTags(AvailabilityResolution resolveTags) {
        this.resolveAvailabilityResponse = resolveTags;
        return this;
    }

    public AvailabilityResolution getResolveAvailabilityResponse() {
        return resolveAvailabilityResponse;
    }

    public String getFields() {
        return fields;
    }

    public void setFields(String fields) {
        this.fields = fields;
    }

    public String getByStreamStatus() {
        return byStreamStatus;
    }

    public void setByStreamStatus(String byStatusField) {
        this.byStreamStatus = byStatusField;
    }

    public Boolean getFilterAdult() {
        return filterAdult;
    }

    public void setFilterAdult(Boolean filterAdult) {
        this.filterAdult = filterAdult;
    }
}
