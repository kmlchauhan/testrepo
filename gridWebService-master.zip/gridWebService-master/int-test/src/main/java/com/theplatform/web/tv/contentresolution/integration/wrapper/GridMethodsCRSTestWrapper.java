package com.theplatform.web.tv.contentresolution.integration.wrapper;

import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.ContentResolutionService;
import com.theplatform.web.tv.contentresolution.api.objects.Grid;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetGridArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetGridByDateArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetListingsArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetListingsByDateArguments;
import com.theplatform.web.tv.contentresolution.integration.wrapper.grid.GetListingsByIdArguments;
import com.theplatform.web.tv.GridException;

import java.util.Date;
import java.util.List;

public class GridMethodsCRSTestWrapper {

    private final ContentResolutionService service;

    public GridMethodsCRSTestWrapper(ContentResolutionService service) {
        this.service = service;
    }

    public ContentResolutionService getService() {
        return service;
    }

    public Grid getGrid(GetGridArguments arguments) throws GridException {

        return service.getGrid(arguments.resolveAvailabilityResponse,
                arguments.numGridUnits, arguments.gridUnitWidth, arguments.offset,
                arguments.timeZone, arguments.categories,
                arguments.companyIds, arguments.stationTagIds, arguments.locatorFormats, arguments.hd,
                arguments.rowStart, arguments.rowEnd, arguments.programTagIds, arguments.fields);
    }

    public Grid getGridByDate(GetGridByDateArguments arguments) throws GridException {
        return service.getGridByDate(arguments.resolveAvailabilityResponse,
                arguments.startTime, arguments.numGridUnits, arguments.gridUnitWidth,
                arguments.timeZone, arguments.categories,
                arguments.companyIds, arguments.stationTagIds, arguments.locatorFormats, arguments.hd,
                arguments.rowStart, arguments.rowEnd, arguments.programTagIds, arguments.fields);
    }

    public List<ListingInfo> getListings(GetListingsArguments arguments) throws GridException {
        Long stationId = arguments.stationId;
        Integer numGridUnits = arguments.numGridUnits;
        Integer gridUnitWidth = arguments.gridUnitWidth;
        Integer offset = arguments.offset;
        return service.getListings(stationId, numGridUnits, gridUnitWidth, offset, arguments.programTagIds, arguments.fields);
    }

    public List<ListingInfo> getListingsById(GetListingsByIdArguments arguments) throws GridException {
        List<Muri> listingIds = arguments.listingIds;
        return service.getListingsById(listingIds, null, null);
    }

    public List<ListingInfo> getListingsByDate(GetListingsByDateArguments arguments) throws GridException {
        Long stationId = arguments.stationId;
        Date startTime = arguments.startTime;
        Date endTime = arguments.endTime;
        Integer gridUnitWidth = arguments.gridUnitWidth;
        return service.getListingsByDate(stationId, startTime, endTime, gridUnitWidth, arguments.programTagIds, arguments.fields);
    }

}
