package com.theplatform.web.tv.contentresolution.integration.wrapper.grid;

import com.comcast.compass.availability.common.domain.AvailabilityResolution;

public class GetGridArguments {
    public AvailabilityResolution resolveAvailabilityResponse;
    public Integer numGridUnits;
    public Integer gridUnitWidth;
    public Integer offset;
    public String timeZone;
    public String[] categories;
    public Long[] companyIds;
    public Long[] stationTagIds;
    public String[] locatorFormats;
    public Boolean hd;
    public Integer rowStart;
    public Integer rowEnd;
    public Long[] programTagIds;
    public String fields;

    public GetGridArguments availabilityResolution(AvailabilityResolution availabilityResolution) {
        this.resolveAvailabilityResponse = availabilityResolution;
        return this;
    }

    public GetGridArguments numGridUnits(Integer numGridUnits) {
        this.numGridUnits = numGridUnits;
        return this;
    }

    public GetGridArguments gridUnitWidth(Integer gridUnitWidth) {
        this.gridUnitWidth = gridUnitWidth;
        return this;
    }

    public GetGridArguments offset(Integer offset) {
        this.offset = offset;
        return this;
    }

    public GetGridArguments timeZone(String timeZone) {
        this.timeZone = timeZone;
        return this;
    }

    public GetGridArguments categories(String[] categories) {
        this.categories = categories;
        return this;
    }

    public GetGridArguments companyIds(Long[] companyIds) {
        this.companyIds = companyIds;
        return this;
    }

    public GetGridArguments stationTagIds(Long[] stationTagIds) {
        this.stationTagIds = stationTagIds;
        return this;
    }

    public GetGridArguments locatorFormats(String[] locatorFormats) {
        this.locatorFormats = locatorFormats;
        return this;
    }

    public GetGridArguments hd(Boolean hd) {
        this.hd = hd;
        return this;
    }

    public GetGridArguments rowStart(Integer rowStart) {
        this.rowStart = rowStart;
        return this;
    }

    public GetGridArguments rowEnd(Integer rowEnd) {
        this.rowEnd = rowEnd;
        return this;
    }

    public GetGridArguments programTagIds(Long[] programTagIds) {
        this.programTagIds = programTagIds;
        return this;
    }

    public GetGridArguments fields(String fields) {
        this.fields = fields;
        return this;
    }
    
    public Integer getExpectedOffset() {
        return offset == null ? GridArgumentsConstants.DEFAULT_OFFSET : offset;
    }

    public Integer getExpectedNumGridUnits() {
        return numGridUnits == null ? GridArgumentsConstants.DEFAULT_NUM_GRID_UNITS : numGridUnits;
    }

    public Integer getExpectedGridUnitWidth() {
        return gridUnitWidth == null ? GridArgumentsConstants.DEFAULT_GRID_UNIT_WIDTH : gridUnitWidth;
    }

}
