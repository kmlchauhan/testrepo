package com.theplatform.web.tv.contentresolution.integration;

import com.theplatform.data.tv.linear.api.data.objects.Listing;
import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.contrib.data.api.objects.Muri;
import com.theplatform.web.tv.contentresolution.api.objects.ListingInfo;
import com.theplatform.web.tv.gws.uri.MerlinIdHelper;
import org.fest.assertions.api.Assertions;
import org.testng.Assert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.*;

public class ListingInfoAssertionHelper {

    static final public void assertListingsInfoCorrespondToListings(List<ListingInfo> actualListings, List<Listing> expectedListings, MerlinIdHelper merlinIdHelper) {
        assertNotNull(actualListings);
        assertEquals(actualListings.size(), expectedListings.size());

        Map<Long,Listing> listingMap = new HashMap<>(expectedListings.size());
        for (Listing listing : expectedListings){
            listingMap.put( Muri.getObjectId(listing.getId()), listing);
        }
        for (ListingInfo actualListing : actualListings){
            Listing expectedListing = listingMap.get(actualListing.getListingId().getId());
            assertNotNull(expectedListing, "We received a listing that we did not expect. ListingId: " + actualListing.getListingId().getId());
            assertListing( actualListing, expectedListing);
        }

    }

    final static public void assertListingsInfoCorrespondToListings(List<ListingInfo> actualListings, List<Listing> expectedListings, int fromListing,
                                                                    int toListing, MerlinIdHelper merlinIdHelper) {
        List<Listing> list = expectedListings.subList(fromListing, toListing);
        assertListingsInfoCorrespondToListings(actualListings, list, merlinIdHelper);
    }

    final static public void assertListing(ListingInfo actualListing, Listing expectedListing){

        // Listing's Ratings
        assertRatings( actualListing.getContentRatings(), expectedListing.getContentRatings());

        // Listing.Program's Ratings - Only test if the program was included in the expected
        if (expectedListing.getProgram() != null){
            assertRatings(actualListing.getProgramInfo().getContentRatings(), expectedListing.getProgram().getContentRatings());
        }

    }

    public static final void assertRatings( List<Rating> actualRatings, List<Rating> expectedRatings){
        if (actualRatings == null || actualRatings.isEmpty()){
            Assertions.assertThat(expectedRatings).isNullOrEmpty();
        }else{
            Assert.assertEquals(actualRatings.size(), expectedRatings.size(), "Object contains a different numbers of ratings.");
            String previousScheme = null;           // To check order
            for ( Rating actualRating : actualRatings){
                boolean success = false;
                for (Rating expectedRating : expectedRatings){
                    if (actualRating.getScheme().equals(expectedRating.getScheme())){
                        Assert.assertEquals(actualRating.getRating(), expectedRating.getRating());
                        Assert.assertEquals(actualRating.getScheme(), expectedRating.getScheme());

                        if (actualRating.getSubRatings()==null || expectedRating.getSubRatings()==null){
                            Assert.assertNull(actualRating.getSubRatings(),"DS Subratings were null.  The subratings returned by CRS should also be null.");
                            Assert.assertNull(expectedRating.getSubRatings(),"CRS Subratings were null but the subratings returned by CRS was not.");
                        }else{
                            Assert.assertEquals(actualRating.getSubRatings().length, expectedRating.getSubRatings().length);
                            // Make sure that both have the same list of subratings.  Keep in mind the one from the DS
                            // may be ordered differently.  That's fine
                            Assert.assertEqualsNoOrder(actualRating.getSubRatings(), expectedRating.getSubRatings());
                            // Now check the oder of the subratings from CRS.  That order DOES matter.
                            for (int j = 0; j < actualRating.getSubRatings().length; j++) {
                                if (j>0){
                                    Assert.assertTrue( actualRating.getSubRatings()[j-1].compareTo(actualRating.getSubRatings()[j]) <=0, "Subratings returned by CRS must be ordered.");
                                }
                            }
                        }

                        // Check order
                        if (previousScheme != null){
                            int order = previousScheme.compareTo(actualRating.getScheme());
                            if (order>0){
                                Assert.fail("Ratings are in the wrong order.  Should be ascending by scheme.");
                            }
                        }
                        previousScheme = actualRating.getScheme();
                        success=true;
                        break;
                    }
                }
                if (!success){
                    fail("Unable to find rating in ListingInfo with scheme.  The Ratings do not match.");
                }

            }

        }
    }


}
