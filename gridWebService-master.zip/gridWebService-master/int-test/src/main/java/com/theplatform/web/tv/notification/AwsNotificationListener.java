package com.theplatform.web.tv.notification;

import com.amazon.sqs.javamessaging.message.SQSTextMessage;
import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.data.tv.linear.api.data.objects.Listing;
import com.theplatform.web.tv.gws.ingest.consumer.notifier.model.CRSNotification;
import com.theplatform.web.tv.gws.ingest.consumer.notifier.model.NotificationListing;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.Message;
import javax.jms.MessageListener;
import java.util.*;


/**
 *  Used for pulling in AWS notifications that CRS produced for integration testing.
 *
 *  It's important to use only one instance of this class otherwise you'll have multiple consumers from the same
 *  queue.  See #AwsNotificationListenerFactory
 *
 *  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 *  Be careful because the DirtiesContext will create a new instance if defined without a factory in the XML
 *  configuration.  Less obviously, using the factory to configure the bean creation in XML will also create
 *  multiple instance if the failsafe forkCount is greater than 1 (it is in CRS).  In that case you will have
 *  multiple instances even if it's a singleton.
 *  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 *
 *
 */
public class AwsNotificationListener implements MessageListener{
    private final Logger logger = LoggerFactory.getLogger(AwsNotificationListener.class);

    // We need the Set because AWS can/does return duplicate messages.
    private final Map<Long, Map<Long, CRSNotification>> lookup = new HashMap<>();
    private final Map<SiriusObjectType, Class<? extends CRSNotification> > mapCRSObjectTypeToCRSNotificationClass = new HashMap<>();


    private static int INSTANCE = 0;
    public AwsNotificationListener(){
        INSTANCE++;
        if (INSTANCE>1){
            String error =
                      "*****************************************************************************\n"
                    + "*****************************************************************************\n"
                    + "**                                                                         **\n"
                    + "** MULTIPLE INSTANCES OF AwsNotificationListener !!! {} Instances          **\n"
                    + "**                                                                         **\n"
                    + "*****************************************************************************\n"
                    + "*****************************************************************************\n";
            logger.error(error, INSTANCE);


        }
        ClassLoader cl = ClassLoader.getSystemClassLoader();
        logger.info("New Instance of AwsNotificationListener.  Instance={} ClassLoader={}", INSTANCE, cl.toString());

        SiriusObjectType listingType = SiriusObjectType.register("Listing", Listing.class, MerlinEntityType.LISTING);

        mapCRSObjectTypeToCRSNotificationClass.put( listingType, NotificationListing.class);
    }

    @Override
    public void onMessage(Message message){
        String body = null;
        String objectType = null;
        try {
            objectType = message.getStringProperty(CRSNotification.ATTRIBUTE_OBJECT_TYPE);
            SiriusObjectType crsNotificationType = SiriusObjectType.fromFriendlyName(objectType);
            Class<? extends CRSNotification> notificationClass = mapCRSObjectTypeToCRSNotificationClass.get(crsNotificationType);

            SQSTextMessage sqsTextMessage = (SQSTextMessage) message;
            body = sqsTextMessage.getText();
            ObjectMapper mapper = new ObjectMapper();

            CRSNotification crsNotification = mapper.readValue(body, notificationClass);
            logger.info("Task=AwsNotificationListener id={} method={} Thread={}", crsNotification.getId(), crsNotification.getMethod(), this);
            addNotification(crsNotification);
       }catch(Exception exc){
            logger.error( "Problem receiving AWS SQS Notification \nbody: {}\nobjectTpe: {}", body, objectType, exc);
        }
    }

    public synchronized  <T> List<T> get(Long id, Class<T> valueType){
        if (lookup.get(id)==null){
            return new ArrayList<>();
        }
        ArrayList<T> list = new ArrayList<>((Collection<T>) lookup.get(id).values());
        return list;
    }

    private synchronized void addNotification(CRSNotification crsNotification){
        Map<Long,CRSNotification> notifications = lookup.get(crsNotification.getId());
        if (notifications==null){
            // This will keep the messages in order of timestamp which may be slightly different than how AWS delivered
            // them.  But keeping them in this order will make it easier to test.  Also, will dedupe the same message
            // delivered twice.
            notifications = new TreeMap<>();
            lookup.put(crsNotification.getId(), notifications);
        }
        notifications.put(crsNotification.getTimestamp(), crsNotification);
    }



    public void purge( SiriusObjectType crsObjectType, long id){
        if (lookup.get(id)!=null){
            lookup.get(id).clear();
        }
    }

}
