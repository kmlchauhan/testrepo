package com.theplatform.web.tv.contentresolution.integration.verify;

import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.client.DataService;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.tv.entity.api.client.TagClient;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.tag.api.client.TagAssociationClient;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;

public class TagAssociationFactory<E extends DataObject, EC extends DataService<E>> extends
        DataObjectFactoryImpl<TagAssociation, DataService<TagAssociation>> {

    public TagAssociationFactory(DataService<TagAssociation> client, DataObjectFactory<Tag, DataService<Tag>> tagFactory, DataObjectFactory<E, EC> entityFactory,
                                 ValueProvider<Long> idProvider) {
        super(client, TagAssociation.class, idProvider);
        this.addPresetFieldsOverrides(
                TagAssociationField.tagId, new DataObjectIdProvider(tagFactory),
                TagAssociationField.entityId, new DataObjectIdProvider(entityFactory));
    }

}
