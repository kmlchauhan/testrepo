package com.theplatform.web.tv.contentresolution.integration.verify;

import com.google.common.io.Resources;
import com.theplatform.contrib.testing.blocking.BlockingStrategy;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;

/**
 * I ended up not needing this, but committing in case its needed in
 * the future
 */
public class CRSBlockingStrategy implements BlockingStrategy {
    private static final Logger logger = LoggerFactory.getLogger(CRSBlockingStrategy.class);
    private final URL detailedStatusUrl;
    private final String siriusObjectType;

    public CRSBlockingStrategy(URL detailedStatusUrl, String siriusObjectType) {
        this.detailedStatusUrl = detailedStatusUrl;
        this.siriusObjectType = siriusObjectType;
    }

    @Override
    public void blockUntilCreated(CreateContext context) {
        blockUntilProcessed(context);
    }

    @Override
    public void blockUntilUpdated(UpdateContext context) {
        blockUntilProcessed(context);
    }

    @Override
    public void blockUntilDeleted(DeleteContext context) {
        blockUntilProcessed(context);
    }

    private void blockUntilProcessed(Context context) {
        long notificationId = context.getNotificationId();

        try {
            while (fetchProcessedNotificationId() < notificationId) {
                Thread.sleep(100);
            }

            logger.info("Grid processed notification {} for {} {}",
                        notificationId, siriusObjectType, context.getObjectId());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private long fetchProcessedNotificationId() throws IOException {
        String metricsJson = Resources.toString(detailedStatusUrl, Charset.forName("UTF-8"));
        JSONObject metrics = new JSONObject(metricsJson);
        JSONArray ingestStats = metrics.getJSONArray("ingestStats");

        for (int i=0; i <= ingestStats.length(); ++i) {
            JSONObject ingestStat = ingestStats.getJSONObject(i);

            if (ingestStat.getString("siriusObjectType").equals(siriusObjectType)) {
                JSONObject notificationRepoWriter = ingestStat.getJSONObject("notificationRepoWriter");
                return notificationRepoWriter.getLong("lastReplayedNotificationSequenceId");
            }
        }

        throw new RuntimeException("No listener found for " + siriusObjectType);
    }
}
