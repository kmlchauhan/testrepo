package com.theplatform.web.tv.contentresolution.integration.verify;

import com.comcast.merlin.sirius.model.SiriusObjectType;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.decorator.DataObjectFactoryDecorator;
import com.theplatform.data.api.client.DataService;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.HeadMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class CRSCheckerDOFDecorator<O extends DataObject, C extends DataService<O>> extends DataObjectFactoryDecorator<O, C>{

    private static final Logger logger = LoggerFactory.getLogger(CRSCheckerDOFDecorator.class);
    private HttpClient httpClient;
    private String endpointName;
    private String crsBaseUrl;

    public CRSCheckerDOFDecorator(DataObjectFactory<O, C> decoratedFactory, String crsBaseUrl) {
        super(decoratedFactory);
        this.crsBaseUrl = crsBaseUrl;
        this.httpClient = new HttpClient();
        SiriusObjectType type = SiriusObjectType.fromDataServiceObjectClass(((DataServiceClient<?>)decoratedFactory.getClient()).getDataObjectClass());
        this.endpointName = type.getFriendlyName();
    }

    @Override
    public O create(Object... fieldOverrides) {
        O createdObject = decoratedFactory.create(fieldOverrides);
        this.waitTillObjectIsOnCrs(createdObject);
        return createdObject;
    }
    
    @Override
    public List<O> create(Integer amount, Object... fieldOverrides) {
        List<O> createdObjects = this.decoratedFactory.create(amount, fieldOverrides);
        for (O object : createdObjects) {
            this.waitTillObjectIsOnCrs(object);
        }
        return createdObjects;
    }

    private void waitTillObjectIsOnCrs(O object) {
        int responseCode = -1;
        Long id = LocalUriConverter.convertUriToID(object.getId());
        Long diff = 0l;
        String uri = crsBaseUrl+"sirius/data/"+endpointName+"/"+id;
        try {
            HeadMethod headMethod = new HeadMethod(uri);
            responseCode = httpClient.executeMethod(headMethod);
            long currentTimeMillis = System.currentTimeMillis();
            while(responseCode !=  200 && diff < 2000) {
                Thread.sleep(100);
                diff = System.currentTimeMillis() - currentTimeMillis;
                responseCode = httpClient.executeMethod(headMethod);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error trying to wait till object is on CRS.", e);
        }
        if(responseCode != 200)
            logger.error("Waited for more than "+ diff +" millis on object \""+uri+"\".");
    }

}
