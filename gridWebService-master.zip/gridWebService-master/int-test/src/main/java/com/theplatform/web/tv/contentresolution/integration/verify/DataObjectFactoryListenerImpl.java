package com.theplatform.web.tv.contentresolution.integration.verify;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class DataObjectFactoryListenerImpl implements DataObjectFactoryListener, Pollable {

    Queue<CRSObjectNotification> queue;
    
    public DataObjectFactoryListenerImpl() {
        this.queue = new ConcurrentLinkedQueue<CRSObjectNotification>();
    }
    
    @Override
    public void notify(CRSObjectNotification notification) {
        this.queue.add(notification);
    }
    
    @Override
    public CRSObjectNotification poll() {
        return this.queue.poll();
    }

}
