package com.theplatform.web.tv.contentresolution.integration.verify;

import java.util.List;

import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.decorator.DataObjectFactoryDecorator;
import com.theplatform.data.api.client.DataService;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;

public class DataObjectFactoryNotifierDecorator<O extends DataObject, C extends DataService<O>> extends DataObjectFactoryDecorator<O, C>{

    private DataObjectFactoryListener listener;
    private String endpointName;

    public DataObjectFactoryNotifierDecorator(DataObjectFactory<O, C> decoratedFactory, DataObjectFactoryListener listener) {
        super(decoratedFactory);
        this.listener = listener;
        this.endpointName = ((DataServiceClient<O>)decoratedFactory.getClient()).getDataObjectClass().getSimpleName();
    }

    @Override
    public O create(Object... fieldOverrides) {
        O createdObject = decoratedFactory.create(fieldOverrides);
        this.listener.notify(new CRSObjectNotification(endpointName, LocalUriConverter.convertUriToID(createdObject.getId())));
        return createdObject;
    }
    
    @Override
    public List<O> create(Integer amount, Object... fieldOverrides) {
        List<O> createdObjects = this.decoratedFactory.create(amount, fieldOverrides);
        for (O object : createdObjects) {
            this.listener.notify(new CRSObjectNotification(endpointName, LocalUriConverter.convertUriToID(object.getId())));
        }
        return createdObjects;
    }
}
