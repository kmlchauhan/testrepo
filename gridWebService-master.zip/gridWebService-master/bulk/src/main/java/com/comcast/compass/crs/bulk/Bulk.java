package com.comcast.compass.crs.bulk;

import com.comcast.merlin.sirius.ingest.IngestMode;
import com.comcast.merlin.sirius.ingest.producer.dataservice.bulk.SiriusBulkLoader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.File;

/**
 * @author jcoelho
 * @since 2/11/15.
 */
public class Bulk {

    public static void main(String... args) {

        cleanupUberstore();

        ApplicationContext context = new ClassPathXmlApplicationContext("spring/spring-bulk.xml");

        SiriusBulkLoader s = (SiriusBulkLoader) context.getBean("siriusBulkLoader");
        try {
            s.start(IngestMode.BULK);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        System.exit(0);
    }

    private static void cleanupUberstore() {
        File file = new File("uberstore/1.index");
        file.delete();
        file = new File("uberstore/1.data");
        file.delete();
    }
}
