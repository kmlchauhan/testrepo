#/bin/bash

# this container needs to be built locally

DENIS_HOST="https://api.denis.comcast.net:9443"

docker run -it \
-e DENIS_ACCESS_KEY=${DENIS_ACCESS_KEY} \
-e DENIS_SECRET_KEY=${DENIS_SECRET_KEY} \
-e DENIS_HOST=${DENIS_HOST} \
-v `pwd`/private/.ssh/:/root/.ssh/ \
-v `pwd`:/platform-terraform \
platform-tf
