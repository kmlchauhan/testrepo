node("deploy") {

    // This script is adapted from this example:
    // https://objectpartners.com/2016/06/01/automating-terraform-projects-with-jenkins/

    stage "Checkout and init docker"

    projectRootDirectory = pwd()
    println ("project root: " + projectRootDirectory)
    checkout scm

    withCredentials([usernamePassword(credentialsId: 'mims_aurora_dev', passwordVariable: 'TF_VAR_mims_aurora_password', usernameVariable: 'TF_VAR_mims_aurora_username'), usernamePassword(credentialsId: 'sonar_aurora_dev', passwordVariable: 'TF_VAR_sonar_aurora_password', usernameVariable: 'TF_VAR_sonar_aurora_username')]) {
        // switch working directory at container start to get around
        // https://issues.jenkins-ci.org/browse/JENKINS-33510
        dir("${projectRootDirectory}/environments/${env.ENVIRONMENT_NAME}/${env.ENVIRONMENT_DATA_CENTER}") {

            // stand up the platform terraform container and set up all of the
            // necessary environment vars
            image = docker.image('hub.comcast.net/merlin/platform-tf:0.11.8')
            image.pull()
            image.withRun("-e EC2_URL=ec2.us-east-1.amazonaws.com " +
                          "-e AWS_REGION=us-east-1 " +
                          "-e AWS_ACCESS_KEY=${env.AWS_ACCESS_KEY} " +
                          "-e AWS_SECRET_KEY=${env.AWS_SECRET_KEY} " +
                          "-e DENIS_ACCESS_KEY=${env.DENIS_ACCESS_KEY} " +
                          "-e DENIS_SECRET_KEY=${env.DENIS_SECRET_KEY} " +
                          "-e DENIS_HOST=${env.DENIS_HOST} " +
                          "-e http_proxy=${env.HTTP_PROXY} " +
                          "-e https_proxy=${env.HTTPS_PROXY} " +
                          "-e no_proxy=${env.NO_PROXY} " +
                          "-e OS_USERNAME=${env.OS_USERNAME} " +
                          "-e os_username=${env.OS_USERNAME} " +
                          "-e OS_PASSWORD=${env.OS_PASSWORD} " +
                          "-e os_password=${env.OS_PASSWORD} " +
                          "-e TF_VAR_mims_aurora_password=${env.TF_VAR_mims_aurora_password} " +
                          "-e TF_VAR_rds_password=${env.TF_VAR_rds_password} " +
                          "-e TF_VAR_rds_agent_password=${env.TF_VAR_rds_agent_password} " +
			  "-e TF_VAR_sonar_aurora_password=${env.TF_VAR_sonar_aurora_password} " +
                          "-v ${projectRootDirectory}/modules/:${projectRootDirectory}/modules/"){ c ->

                // have to switch user to root for permissions issues with the plugins directory
                // also have to mount the modules directory as a volume
                // every command listed within the 'inside' block actually runs
                // as a 'docker exec' command against the container....
                image.inside("-u root -v ${projectRootDirectory}/modules/:${projectRootDirectory}/modules/") {

                    // add color to the text output
                    wrap([$class: 'AnsiColorBuildWrapper', colorMapName: 'xterm']) {
                      
                        apply = false

                        stage('Plan') {

                            // dump out a bunch of stuff about what's running in the container
                            sh "pwd"
                            sh "ls -alh"
                            sh "ls -alh ../../../"
                            sh "whoami"
                            sh "ls /root/.terraform.d/plugins/"

                            // Output Terraform version
                            sh "terraform --version"

                            //Remove the terraform state file so we always start from a clean state
                            if (fileExists(".terraform/terraform.tfstate")) {
                                sh "rm -rf .terraform/terraform.tfstate"
                            }

                            if (fileExists("status")) {
                                sh "rm status"
                            }

                            // init the configured s3 backend
                            sh "terraform init -backend=true"
                            // get the current remote state:
                            sh "terraform get"

                            // run a plan, save its output in a file, exit with detailed 0,1,2 codes
                            sh "set +e; terraform plan -out=plan.out -detailed-exitcode; echo \$? > status"
                            def exitCode = readFile('status').trim()
                            echo "Terraform Plan Exit Code: ${exitCode}"

                            // 0 means plan said no changes detected, no work necessary:
                            if (exitCode == "0") {
                                currentBuild.result = 'SUCCESS'
                            }

                            // 1 means something ain't right, plan failed to run:
                            if (exitCode == "1") {
                                slackSend channel: "${env.SLACK_CHANNEL_NAME}", color: '#0080ff', message: "@here Plan Failed: ${env.JOB_NAME} - ${env.BUILD_NUMBER} (<${env.BUILD_URL}console|Open>)"
                              currentBuild.result = 'FAILURE'
                            }

                            // 2 means a successful plan, but changes were detected,
                            // and a subsequent plan is required:
                            if (exitCode == "2") {
                                slackSend channel: "${env.SLACK_CHANNEL_NAME}", color: 'good', message: "@here Plan Awaiting Approval: ${env.JOB_NAME} - ${env.BUILD_NUMBER} (<${env.BUILD_URL}console|Open>)"
                                try {

                                    // to prevent an infinite wait, and therefore a hogged build agent,
                                    // timeout after 5 minutes:
                                    timeout(time: 300, unit: 'SECONDS') {
                                        input message: 'Apply Plan?', ok: 'Apply'
                                        apply = true
                                    }
                                } catch (err) {
                                    slackSend channel: "${env.SLACK_CHANNEL_NAME}", color: 'warning', message: "@here Plan Discarded: ${env.JOB_NAME} - ${env.BUILD_NUMBER} (<${env.BUILD_URL}console|Open>)"
                                    apply = false
                                    currentBuild.result = 'UNSTABLE'
                                }
                            }
                        }

                        stage('Apply') {

                            if (apply) {
                                if (fileExists("status.apply")) {
                                    sh "rm status.apply"
                                }
                                // actually do stuff based on the plan.out file we just created:
                                sh 'set +e; terraform apply plan.out; echo \$? > status.apply'
                                def applyExitCode = readFile('status.apply').trim()
                                if (applyExitCode == "0") {
                                    slackSend channel: "${env.SLACK_CHANNEL_NAME}", color: 'good', message: "@here Changes Applied ${env.JOB_NAME} - ${env.BUILD_NUMBER} (<${env.BUILD_URL}console|Open>)"
                                } else {
                                    slackSend channel: "${env.SLACK_CHANNEL_NAME}", color: 'danger', message: "@here Apply Failed: ${env.JOB_NAME} - ${env.BUILD_NUMBER} (<${env.BUILD_URL}console|Open>)"
                                    currentBuild.result = 'FAILURE'
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}