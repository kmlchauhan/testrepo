Initialize this environment from this directory like this: 
    
     terraform init -backend=true
     
Execute subsequent commands like this:

Always do a dry-run to check what will happen first!
    
    terraform plan
    
Actually run your new config once you're happy with how the plan looks:

    terraform apply
    
Optionally target only 1 host:

    terraform apply --target=aws_instance.image_rendering_proxy
    terraform apply --target=denis_record_set.image_rendering_proxy_record_set
    

    
