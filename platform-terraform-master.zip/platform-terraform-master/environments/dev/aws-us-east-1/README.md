NOTE - THIS CONFIG IS FOR THE DEV INSTANCES IN THE PROD ACCOUNT

Initialize this environment from this directory like this: 
    
     terraform init -backend=true
     
Execute subsequent commands like this:

    terraform plan
    
