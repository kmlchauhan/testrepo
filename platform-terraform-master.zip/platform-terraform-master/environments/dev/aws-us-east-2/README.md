Initialize this environment from this directory like this: 
    
     terraform init -backend=true
     
Execute subsequent commands like this:

    terraform plan
    
