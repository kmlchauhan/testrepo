Please see here for info:

https://etwiki.sys.comcast.net/display/COMPASS/Using+Terraform+on+the+Merlin+Platform

