#!/usr/bin/env bash

# Entrypoint script for docker container

set -ex

ansible-galaxy install -r /platform-terraform/requirements_internal.yml

bash -c "$@"
