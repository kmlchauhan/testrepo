## ReactiveOps K8S Workshop

From [ReactiveOps K8S Workshop](https://github.com/reactiveops/k8s-workshop):


In this sample application you will be launching a two tier webapp. The web app is a Ruby app using Sinatra. The app is a key value storage and retrieval service with a Redis backend.

### Interacting with the App
* [instance_ip]:[port]/[key]/[value] will set a key value
* [instance_ip]:[port]/[key] will retreive the value
* [instance_ip]:[port] returns "Hello from Kubernetes"


----

## How to Run

Execute the *setup.sh*. This script will download and install the necessary files into your EKS k8s cluster.

```
./setup.sh [AWS profile] [path to kubeconfig file]
```

For example:

```
./setup.sh saml /Users/toutte236/src/tpx/sst/architecture/eks/onecloud-aws-eks-tf/clusters/eks-cluster-036/kubeconfig
```

```
sample-applications/reativeops-k8s-workshop/setup.sh `bin/get_variable.rb aws_profile` `bin/get_variable.rb kubeconfig`
```

----

## How to Tear Down

Execute the *setup.sh*. This script will download and install the necessary files into your EKS k8s cluster.

```
./destroy.sh [AWS profile] [path to kubeconfig file]
```

For example:

```
./destroy.sh saml /Users/toutte236/src/tpx/sst/architecture/eks/onecloud-aws-eks-tf/clusters/eks-cluster-036/kubeconfig
```

```
sample-applications/reativeops-k8s-workshop/destroy.sh `bin/get_variable.rb aws_profile` `bin/get_variable.rb kubeconfig`
```

----

## Based On

This sample application is based on the [ReactiveOps K8S Workshop](https://github.com/reactiveops/k8s-workshop).
