#!/bin/bash

if [[ -n $1 ]] && [[ -n $2 ]]; then
  echo "# cloning git repo to /tmp"
  rm -fr /tmp/k8s-workshop
  mkdir /tmp/k8s-workshop
  git clone https://github.com/reactiveops/k8s-workshop /tmp/k8s-workshop
  cd /tmp/k8s-workshop/complete

  echo "# spinning down the web apps"
  cat 02_webapp/app.horizontal_pod_autoscaler.yml | sed 's/minReplicas: 1/minReplicas: 6/g' > 02_webapp/app.horizontal_pod_autoscaler.yml.1
  mv 02_webapp/app.horizontal_pod_autoscaler.yml.1 02_webapp/app.horizontal_pod_autoscaler.yml
  AWS_PROFILE=$1 kubectl delete -n k8s-workshop -f 02_webapp/ --kubeconfig=$2
  echo "# pausing to give the web apps time"
  sleep 10

  echo "# spinning down redis"
  AWS_PROFILE=$1 kubectl delete -n k8s-workshop -f 01_redis/ --kubeconfig=$2
  echo "# pausing to give redis time"
  sleep 10

  echo "# deleting namespace"
  AWS_PROFILE=$1 kubectl delete -f namespace.yml --kubeconfig=$2
  sleep 10

else
  echo "Usage: $0 [AWS profile] [kubeconfig-file]"
  exit 1
fi
