The file *iam-role-policy.txt* contains the AWS IAM *role* and *policies* that need to be in place to run the terraform script.

```
% aws iam get-account-authorization-details
```

# AWS IAM permissions

The kops user will require the following IAM permissions to function properly:

```
AmazonEC2FullAccess
AmazonRoute53FullAccess
AmazonS3FullAccess
IAMFullAccess
AmazonVPCFullAccess
```

By default, *kops* tries to make IAM roles and policies that are described in these files:

- aws_iam_role_policy_nodes.cluster-name.k8s.local_policy
- aws_iam_role_masters.cluster-name.k8s.local_policy
- aws_iam_role_nodes.cluster-name.k8s.local_policy
- aws_iam_role_policy_masters.cluster-name.k8s.local_policy

# Comcast ASTRO Governance

The following policies are not allowed:

```
IAMFullAccess
AmazonVPCFullAccess
```

In the *variables.yml* file, you specific the *VPC_ID*, *NODES_SUBNET_ID*, *ROLE_ARN*, *ROLE_NAME* and *IGW_ID*.
