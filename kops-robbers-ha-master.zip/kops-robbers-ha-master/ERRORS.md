

# List of Current Errors

----

## 001: InvalidDhcpOptionID.NotFound:

Status: INTERMITTENT ERROR

Sometimes receive the following from *terraform apply*. Happens like one out of 10 times. Haven't figured out the pattern

```
Error: Error applying plan:

1 error(s) occurred:

* aws_vpc_dhcp_options.kops-robbers-ha-006--k8s-local: 1 error(s) occurred:

* aws_vpc_dhcp_options.kops-robbers-ha-006--k8s-local: Error waiting for DHCP Options (dopt-70b68408) to become available: InvalidDhcpOptionID.NotFound: The dhcpOption ID 'dopt-70b68408' does not exist
	status code: 400, request id: e759c516-3598-4325-87d9-bd4d400d5d44
```

Resolution:

----

## 002: Master in us-east-1c does not come up

Status: FIXED

The k8s api server never comes up on the master in us-east-1c.

```
kube-apiserver.log:E0330 14:33:08.039256       6 cacher.go:277] unexpected ListAndWatch error: storage/cacher.go:/horizontalpodautoscalers: Fa
iled to list *autoscaling.HorizontalPodAutoscaler: client: etcd cluster is unavailable or misconfigured; error #0: dial tcp 127.0.0.1:4001: ge
tsockopt: connection refused
```

Resolution:

Human error. In the *variables.yml* file had a mismatch between a Availability Zone and a subnet. Had specified AZ us-east-1c and the  subnet was in us-east-1d.

Updated subnet and now all masters are online.
