
## Sample Cluster

This directory contains a script *setup.sh* that will spin up a simple cluster:

- redis master and replica
- sinatra webapp front-end
- prometheus & grafana monitoring and metrics
- ELK stack for logs

----

## How to Use

- copy the script and yaml files to a master node
- login to the master node
- edit the file grafana-values.yaml
  - you need to add two key / value pairs into the file

```
admadminUser: "SOME VALUE"
adminPassword: "SOME VALUE"
```
- execute the *setup.sh* script

NOTE: Run this script on a master node *after* all the nodes are online. `kubectl get nodes` will display the state of the nodes.

----

## Grafana Dashboards

Highly recommend the following dashboards:

- [Kubernetes All Nodes](https://grafana.com/dashboards/3131)
- [Kubernetes cluster monitoring (via Prometheus)](https://grafana.com/dashboards/1621)

----

## Based On

- [Kubernetes monitoring with Prometheus in 15 minutes](https://itnext.io/kubernetes-monitoring-with-prometheus-in-15-minutes-8e54d1de2e13)
- [k8s-workshop](https://github.com/reactiveops/k8s-workshop) from [ReactiveOps](https://www.reactiveops.com/)
- [ELK-Kubernetes](https://github.com/kayrus/elk-kubernetes)
- [Simple Kubernetes cluster metrics monitoring with Prometheus and Grafana](https://medium.com/@timfpark/simple-kubernetes-cluster-monitoring-with-prometheus-and-grafana-dd27edb1641)
