
#kubectl create clusterrolebinding tiller-cluster-admin     --clusterrole=cluster-admin     --serviceaccount=kube-system:default
#export KUBERNETES_MASTER=https://$KUBERNETES_SERVICE_HOST:$KUBERNETES_SERVICE_PORT_HTTPS
#kubectl delete deployment tiller-deploy --namespace=kube-system ; kubectl delete service tiller-deploy --namespace=kube-system
