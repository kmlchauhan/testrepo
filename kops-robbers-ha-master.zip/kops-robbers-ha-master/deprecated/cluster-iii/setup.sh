#!/bin/sh -f

echo "# setting environment variables for logging with elastic search and kibana"
export KUBE_LOGGING_DESTINATION=elasticsearch
export KUBE_ENABLE_NODE_LOGGING=true
export KUBE_ENABLE_INSECURE_REGISTRY=true
export KUBE_AWS_ZONE=us-west-1c
export KUBERNETES_PROVIDER=aws
export MASTER_SIZE=t2.medium
export NODE_SIZE=t2.large
export NUM_NODES=2
export MINION_ROOT_DISK_SIZE=100
export DIRECTORY=$PWD

echo "#"
echo "# installing nginx"
echo "#"
sudo apt-get install nginx -y > nginx.out

echo "#"
echo "# installing helm"
echo "#"
wget https://storage.googleapis.com/kubernetes-helm/helm-v2.9.0-rc3-linux-amd64.tar.gz
tar xzvf helm-v2.9.0-rc3-linux-amd64.tar.gz
sudo cp linux-amd64/helm /usr/local/bin/.

echo "#"
echo "# installing tiller"
echo "#"
cd $DIRECTORY
kubectl apply -f tiller.yaml
sleep 15

echo "#"
echo "# initializing helm"
echo "#"
helm init

echo "#"
echo "# installing prometheus and graphana"
echo "#"
helm repo add coreos https://s3-eu-west-1.amazonaws.com/coreos-charts/stable/
helm install coreos/prometheus-operator --name prometheus-operator --namespace monitoring --set prometheus.rbacEnable=false --set rbacEnable=false --set exporter-kube-state.rbacEnable=false
helm install coreos/kube-prometheus --name kube-prometheus --set global.rbacEnable=false --namespace monitoring
sleep 15
echo "# port forwarding granfana and prometheus from pod to localhost"
export GRAFANA=`kubectl get pods -n monitoring | grep grafana | cut -f 1 -d ' '`
nohup kubectl port-forward $GRAFANA -n monitoring 3000:3000 > /dev/null &
nohup kubectl port-forward -n monitoring prometheus-kube-prometheus-prometheus-0 9090:9090 > /dev/null &

echo "#"
echo "# installing ELK stack"
echo "#"
echo "#"
echo "# spinning up ELK stack: multi-master elasticsearch, kibana, and fluentd for log capture and indexing"
echo "#"
cd $DIRECTORY
git clone https://github.com/kayrus/elk-kubernetes
cd elk-kubernetes
cat es-config/elasticsearch.yml | sed 's/${NETWORK_HOST}/0.0.0.0/g' > es-config/elasticsearch.yml.1
mv es-config/elasticsearch.yml.1 es-config/elasticsearch.yml
mv docker/fluentd/tg-agent.conf docker/fluentd/tg-agent.conf.O
cat td-agent.conf.O | sed 's/log_level fatal/log_level info/g' | sed 's/\/var\/log\/containers\/\*.log/\/var\/log\/containers\/\*.log\n  log_level info/' > td-agent.conf
./deploy.sh
sleep 15
export KIBANA=`kubectl get pods -n monitoring | grep kibana | cut -f 1 -d ' '`
nohup kubectl port-forward -n monitoring $KIBANA 5601:5601 > /dev/null &

cd $DIRECTORY
sudo cp default.nginx.conf  /etc/nginx/sites-enabled/default
sudo /etc/init.d/nginx restart

echo "#"
echo "# prometheus is running on port 9000"
echo "# grafana is running on port 80 and 9001"
echo "# kibana is running on port 9002"
echo "#"
echo "NOTE: you may have trouble accessing those ports over CCEmployee WIFI ... You may want to be on the hardwire."
echo "#"
echo "# note: access you'll need to login to AWS and open those ports to your IP address range"
echo "#"
echo "# in graphana, you can import dashboard 3131, which will allow you to see your entire k8s cluster"
echo "#"
echo "# you can see the pods in this namespace by running"
echo "#"
echo "# kubectl get pods -n monitoring"
echo "#"
export WEBAPP=`kubectl get services -n k8s-workshop -o yaml | grep hostname | cut -f 9 -d ' '`
echo "# webapp is running on this host $WEBAPP"
echo "#"
