This folder contains *deprecated* components of *kops-robbers-ha*.

----

## Sample cluster

In the *cluster* directory is a script (*setup.sh*) that you can copy into a master node and run. This script will create a sample *k8s* cluster that contains:

- sinatra web app
- redis master and replica highly available cluster
- monitoring via *Prometheus* and *Grafana*
- lop capture in *ELK* stack
- nginx proxy to get to dashboards

NOTE: Run this script on a master node *after* all the nodes are online. `kubectl get nodes` will display the state of the nodes.

----

## Sample cluster-ii

In the *cluster-ii* directory are a set of scripts and a Makefile that creates a sample cluster as above.

The difference between *cluster* and *cluster-ii* is that *cluster-ii* contains a modular scripts for each installed component. For example, there's a script that only installs the *ELK* stack.

The goal is to provide a developer with simple, plug-n-play scripts that you can adapt easily to your environment.

NOTE: Run these scripts on a master node *after* all the nodes are online. `kubectl get nodes` will display the state of the nodes.

----

## Sample cluster-iii

In the *cluster-iii* directory is a script (*setup.sh*) that you can copy into a master node and run. This script will install monitoring and log capture on the k8s cluster:

- monitoring via *Prometheus* and *Grafana*
- lop capture in *ELK* stack
- nginx proxy to get to dashboards

NOTE: Run this script on a master node *after* all the nodes are online. `kubectl get nodes` will display the state of the nodes.

----
