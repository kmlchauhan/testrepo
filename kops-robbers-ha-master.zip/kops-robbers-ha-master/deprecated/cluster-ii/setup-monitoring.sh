#!/bin/sh -f

echo "#"
echo "# installing prometheus and graphana"
echo "#"
helm repo add coreos https://s3-eu-west-1.amazonaws.com/coreos-charts/stable/
helm install coreos/prometheus-operator --name prometheus-operator --namespace monitoring --set prometheus.rbacEnable=false --set rbacEnable=false --set exporter-kube-state.rbacEnable=false
helm install coreos/kube-prometheus --name kube-prometheus --set global.rbacEnable=false --namespace monitoring
sleep 15
