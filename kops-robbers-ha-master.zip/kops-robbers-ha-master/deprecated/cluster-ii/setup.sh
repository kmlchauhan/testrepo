#!/bin/sh -f

echo "# setting environment variables for logging with elastic search and kibana"
export KUBE_LOGGING_DESTINATION=elasticsearch
export KUBE_ENABLE_NODE_LOGGING=true
export KUBE_ENABLE_INSECURE_REGISTRY=true
export KUBE_AWS_ZONE=us-west-1c
export KUBERNETES_PROVIDER=aws
export MASTER_SIZE=t2.large
export NODE_SIZE=t2.medium
export NUM_NODES=2
export MINION_ROOT_DISK_SIZE=100
export DIRECTORY=$PWD

./setup-sample-app.sh
cd $DIRECTORY
sleep 10
./setup-nginx-proxy.sh
cd $DIRECTORY
sleep 10
./setup-helm-tiller.sh
cd $DIRECTORY
sleep 10
./setup-monitoring.sh
cd $DIRECTORY
sleep 10
./setup-elk-stack.sh
cd $DIRECTORY
sleep 10
./setup-port-forwarding.sh
cd $DIRECTORY
sleep 10
./setup-end.sh
