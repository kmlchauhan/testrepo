#!/bin/sh -f

echo "#"
echo "# installing ELK stack"
echo "#"
echo "#"
echo "# spinning up ELK stack: multi-master elasticsearch, kibana, and fluentd for log capture and indexing"
echo "#"
git clone https://github.com/kayrus/elk-kubernetes
cd elk-kubernetes
cat es-config/elasticsearch.yml | sed 's/${NETWORK_HOST}/0.0.0.0/g' > es-config/elasticsearch.yml.1
mv es-config/elasticsearch.yml.1 es-config/elasticsearch.yml
mv docker/fluentd/tg-agent.conf docker/fluentd/tg-agent.conf.O
cat td-agent.conf.O | sed 's/log_level fatal/log_level info/g' | sed 's/\/var\/log\/containers\/\*.log/\/var\/log\/containers\/\*.log\n  log_level info/' > td-agent.conf
./deploy.sh
