#!/bin/sh -f

echo "#"
echo "# installing nginx"
echo "#"
sudo apt-get install nginx -y > nginx.out
