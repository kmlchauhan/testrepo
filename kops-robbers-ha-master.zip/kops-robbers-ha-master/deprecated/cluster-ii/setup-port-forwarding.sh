#!/bin/sh -f

echo "#"
echo "# configuring port forwarding and nginx proxy"
echo "#"

cp /etc/nginx/sites-enabled/default /tmp/master
export GRAFANA=`kubectl get pods -n monitoring | grep grafana | cut -f 1 -d ' '`
nohup kubectl port-forward $GRAFANA -n monitoring 3000:3000 > /dev/null &
nohup kubectl port-forward -n monitoring prometheus-kube-prometheus-prometheus-0 9090:9090 > /dev/null &
export KIBANA=`kubectl get pods -n monitoring | grep kibana | cut -f 1 -d ' '`
nohup kubectl port-forward -n monitoring $KIBANA 5601:5601 > /dev/null &

sudo cp default.nginx.conf  /etc/nginx/sites-enabled/default
sudo /etc/init.d/nginx restart
