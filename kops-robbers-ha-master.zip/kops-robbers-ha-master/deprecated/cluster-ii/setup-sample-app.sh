#!/bin/sh -f

echo "# cloning git repo"

git clone https://github.com/reactiveops/k8s-workshop
cd k8s-workshop/complete

echo "# applying namespace file"
kubectl apply -f namespace.yml

echo "# spinning up redis"
kubectl apply -n k8s-workshop -f 01_redis/
echo "# pausing to give redis time"
sleep 3

echo "# getting deployments"
kubectl get deployments -n k8s-workshop

echo "# listing pods"
kubectl get pods -n k8s-workshop

echo "# getting services"
kubectl get services -n k8s-workshop

echo "# spinning up the web app"
cat 02_webapp/app.horizontal_pod_autoscaler.yml | sed 's/minReplicas: 1/minReplicas: 10/g' > 02_webapp/app.horizontal_pod_autoscaler.yml.1
mv 02_webapp/app.horizontal_pod_autoscaler.yml.1 02_webapp/app.horizontal_pod_autoscaler.yml
kubectl apply -n k8s-workshop -f 02_webapp/

echo "# pausing"
sleep 3

echo "# getting the nodes"
kubectl get nodes -n k8s-workshop

echo "# getting the pods"
kubectl get pods -n k8s-workshop

echo "# some fun kubectl commands"
echo "#"
echo "# kubectl get pods -n k8s-workshop"
echo "# kubectl describe pod <pod name> -n k8s-workshop"
echo "# kubectl logs <pod name> -n k8s-workshop"
echo "#"
echo "# you should be able to go to the public ip of the elb and see the web page"
echo "#"
echo "# to get the hostname of the load balancer:"
echo "#"
echo "# kubectl get services -n k8s-workshop -o yaml"
echo "#"
echo "# run a shell in a node"
echo "#"
echo "# kubectl exec -it  <pod name> -n k8s-workshop -- /bin/bash"
echo "#"
echo "# describe services in the workspace"
echo "#"
echo "# kubectl describe services --namespace=k8s-workshop"
echo "#"
echo "# to delete the deployments"
echo "#"
echo "# kubectl delete deployment redis-primary -n k8s-workshop"
echo "# kubectl delete deployment redis-replica -n k8s-workshop"
echo "# kubectl delete deployment webapp -n k8s-workshop"
