
## Sample Cluster-II

This directory contains a set of scripts for spinning up a simple cluster with monitoring and metrics.

- redis master and replica
- sinatra webapp front-end
- prometheus & grafana monitoring and metrics
- ELK stack for logs

----

## How to Use

The scripts are modular and are designed for developers to modify and confirm to their specific application.

NOTE: Run these scripts on a master node *after* all the nodes are online. `kubectl get nodes` will display the state of the nodes.

----

## Grafana Dashboards

Highly recommend the following dashboards:

- [Kubernetes All Nodes](https://grafana.com/dashboards/3131)
- [Kubernetes cluster monitoring (via Prometheus)](https://grafana.com/dashboards/1621)

----

## Based On

- [Kubernetes monitoring with Prometheus in 15 minutes](https://itnext.io/kubernetes-monitoring-with-prometheus-in-15-minutes-8e54d1de2e13)
- [k8s-workshop](https://github.com/reactiveops/k8s-workshop) from [ReactiveOps](https://www.reactiveops.com/)
- [ELK-Kubernetes](https://github.com/kayrus/elk-kubernetes)
- [Simple Kubernetes cluster metrics monitoring with Prometheus and Grafana](https://medium.com/@timfpark/simple-kubernetes-cluster-monitoring-with-prometheus-and-grafana-dd27edb1641)
