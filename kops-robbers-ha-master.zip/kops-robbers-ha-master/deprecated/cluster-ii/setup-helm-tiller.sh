#!/bin/sh -f

echo "#"
echo "# installing helm"
echo "#"
wget https://storage.googleapis.com/kubernetes-helm/helm-v2.9.0-rc3-linux-amd64.tar.gz
tar xzvf helm-v2.9.0-rc3-linux-amd64.tar.gz
sudo cp linux-amd64/helm /usr/local/bin/.

echo "#"
echo "# installing tiller"
echo "#"
kubectl apply -f tiller.yaml
sleep 30

echo "#"
echo "# initializing helm"
echo "#"
helm init
