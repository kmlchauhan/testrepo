#!/bin/bash

if [[ -n $1 ]] && [[ -n $2 ]]; then
  echo "# cloning git repo to /tmp"
  rm -fr /tmp/k8s-workshop
  mkdir /tmp/k8s-workshop
  git clone https://github.com/reactiveops/k8s-workshop /tmp/k8s-workshop
  cd /tmp/k8s-workshop/complete

  echo "# applying namespace file"
  AWS_PROFILE=$1 kubectl apply -f namespace.yml --cluster=$2

  echo "# spinning up redis"
  AWS_PROFILE=$1 kubectl apply -n k8s-workshop -f 01_redis/ --cluster=$2
  echo "# pausing to give redis time"
  sleep 10

  echo "# getting deployments"
  AWS_PROFILE=$1 kubectl get deployments -n k8s-workshop --cluster=$2

  echo "# listing pods"
  AWS_PROFILE=$1 kubectl get pods -n k8s-workshop --cluster=$2

  echo "# getting services"
  AWS_PROFILE=$1 kubectl get services -n k8s-workshop --cluster=$2

  echo "# spinning up the web app"
  cat 02_webapp/app.horizontal_pod_autoscaler.yml | sed 's/minReplicas: 1/minReplicas: 6/g' > 02_webapp/app.horizontal_pod_autoscaler.yml.1
  mv 02_webapp/app.horizontal_pod_autoscaler.yml.1 02_webapp/app.horizontal_pod_autoscaler.yml
  AWS_PROFILE=$1 kubectl apply -n k8s-workshop -f 02_webapp/ --cluster=$2

  echo "# pausing"
  sleep 10

  echo "# getting the nodes"
  AWS_PROFILE=$1 kubectl get nodes -n k8s-workshop --cluster=$2

  echo "# getting the pods"

  for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
  do
     AWS_PROFILE=$1 kubectl get pods -n k8s-workshop --cluster=$2
     sleep 5
  done

  echo "# some fun kubectl commands"
  echo "#"
  echo "# AWS_PROFILE=$1 kubectl get pods -n k8s-workshop --cluster=$2"
  echo "# AWS_PROFILE=$1 kubectl describe pod <pod name> -n k8s-workshop --cluster=$2"
  echo "# AWS_PROFILE=$1 kubectl logs <pod name> -n k8s-workshop --cluster=$2"
  echo "#"
  echo "# you should be able to go to the public ip of the elb and see the web page"
  echo "#"
  echo "# to get the hostname of the load balancer:"
  echo "#"
  echo "# AWS_PROFILE=$1 kubectl get services -n k8s-workshop -o yaml --cluster=$2 | grep hostname"
  echo "#"
  echo "# run a shell in a pod"
  echo "#"
  echo "# AWS_PROFILE=$1 kubectl exec -it  <pod name> -n k8s-workshop --cluster=$2 -- /bin/bash"
  echo "#"
  echo "# describe services in the workspace"
  echo "#"
  echo "# AWS_PROFILE=$1 kubectl describe services -n k8s-workshop --cluster=$2"
  echo "#"
  echo "# to delete the deployments"
  echo "#"
  echo "# AWS_PROFILE=$1 kubectl delete deployment redis-primary -n k8s-workshop --cluster=$2"
  echo "# AWS_PROFILE=$1 kubectl delete deployment redis-replica -n k8s-workshop --cluster=$2"
  echo "# AWS_PROFILE=$1 kubectl delete deployment webapp -n k8s-workshop --cluster=$2"
  echo "#"
  echo "#"
  echo "#"
  WEBHOST=`AWS_PROFILE=$1 kubectl get services -n k8s-workshop -o yaml --cluster=$2 | grep hostname | awk '{print $3}'`
  echo "#"
  echo "# the web servers are running behind the ELB $WEBHOST"
  echo "#"
  echo "# curl http://$WEBHOST"
  echo "#"
else
  echo "Usage: $0 [AWS profile] [kubeconfig-file]"
  exit 1
fi
