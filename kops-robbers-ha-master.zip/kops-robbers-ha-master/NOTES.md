
## Create a Cluster

```
% aws s3 mb s3://20180329-ha-cluster
% kops create cluster --cloud=aws --node-count 3 --node-size t2.medium --master-size t2.large --dns private --name=cluster-name.k8s.local --state=s3://20180329-ha-cluster --out=. --target=terraform --zones=us-east-1a,us-east-1b,us-east-1c --master-zones=us-east-1a,us-east-1b,us-east-1c --networking="weave" --api-loadbalancer-type="public"
% terraform plan -out=kubernetes.tfplan
```
## Convert HCL to JSON

```
% npm i hcl-to-json -g
% hcl2json kubernetes.tf > kubernetes.json
```
