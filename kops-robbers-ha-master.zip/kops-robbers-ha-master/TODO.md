
## TODOs

- determine if all of this is needed on the role ... feels like too open

```
AmazonEC2FullAccess
AmazonRoute53FullAccess
AmazonS3FullAccess
AWSConnfigRole
AutoScalingFullAccess
AWSKeyManagementServicePowerUser
```

- in bin/ssh_config, check the instance STATE for not *terminated*

```
"State": {
    "Code": 48,
    "Name": "terminated"
},
```

- create script to attach policies to role

- make destroy should remove the s3_bucket
  - check terraform

- refactor

Just use `role_name`. Derive the others in the scripts.

```
:role_arn: arn:aws:iam::778038366081:role/OneCloud/kubernetes-tack-master
:role_name: kubernetes-tack-master
:instance_profile_arn: arn:aws:iam::778038366081:instance-profile/kubernetes-tack-master
```

- bin/sed_files.rb

If not using, delete.

- Update `kops` to latest version and use latest version of `k8s`

Need to compare terraform created on newest version of kops.

Re-copy `addons` directory from EKS work.
