
## Kops-Robbers-HA in a Comcast ASTRO Governed account

![Astro](/images/astro-die-cut.png)

## Purpose

The purpose of this repo is to configure and spin-up a High Availability *kubernetes* cluster using *kops* in a Comcast OneCloud ASTRO governed AWS account.

Why? Governance matters and the rules on ASTRO accounts do not allow:

- IamCreateUser
- VpcCreate
- VpcSubnetCreate

The Open Source tools I researched that make k8s clusters assume that you have permissions to make users, create VPCs and subnets, etc.

Based on [kops](https://github.com/kubernetes/kops) Version 1.8.1.

----

## High Availability

For the purpose of this project, High Availability means:

- three masters, each in a separate availability zone
- workers spread across three availability zones
- cluster and log monitoring via *Prometheus* and *Grafana*
- log capture in *ELK* stack

----

## Dependencies

- [aws cli (1.10+)](https://aws.amazon.com/cli)
- aws_adfs_auth
- [kops (1.8+)](https://github.com/kubernetes/kops)
- [ruby (2.0+)](https://www.ruby-lang.org/en/)
- [terraform (0.9+)](https://www.terraform.io/)

----

## Requirements

- for HA, you need three subnets in three different availability zones

----

## OneCloud Links

- [User Guide](https://etwiki.sys.comcast.net/pages/viewpage.action?spaceKey=SPACE&title=OneCloud+User+Guide)
- [OneCloud Portal](https://onecloud.comcast.net/)

----

## How to Spin Up a Cluster

#### 1. Create a Role in OneCloud

- Login to the [OneCloud portal](https://onecloud.comcast.net/) and create a *role* for your account.
  - Instructions are [here](https://onecloud.comcast.net/docs/user-guide/custom-roles).
- Login to the [AWS Console](https://console.aws.amazon.com)
  - Go to the IAM page and attach the following permissions and policies to the role.

```
AmazonEC2FullAccess
AmazonRoute53FullAccess
AmazonS3FullAccess
AWSConnfigRole
AutoScalingFullAccess
AWSKeyManagementServicePowerUser
```

- Go to the IAM page, and make sure the role has ec2.amazon.com *Trust Relationship*

```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::778038366081:root"
      },
      "Action": "sts:AssumeRole"
    },
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "ec2.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

#### 2. Configure the variables.yml file

- copy *variables.yml.example* to *variables.yml*
- update the *variables.yml* file with at least the following:
  - *aws_profile*: name of the AWS profile, for example *saml*
  - *cluster_name*: name of the cluster (maximum of 20 characters)
  - *public_key_path*: path to the public key that will be used to access the master and nodes
  - *private_key_path*: path to the private key that corresponds to the *public_key_path*. Note: this is only used in *make ssh_config*
  - *region*: region where you want the cluster to operate
  - *vpc_id*: the VPC ID where the cluster will run
  - *az_1*: first availability zone
  - *az_2*: second availability zone
  - *az_3*: third availability zone
  - *subnet_1*: a subnet with-in the VPC and *az_1*
  - *subnet_2*: a subnet with-in the VPC and *az_2*
  - *subnet_3*: a subnet with-in the VPC and *az_3*
  - *role_arn*: ARN of the role you created in OneCloud
  - *role_name*: name of the OneCloud role
  - *instance_profile_arn*: ARN of the instance profile that was created for the OneCloud role
  - *nodes_cluster_min_size*: minimum number of EC2 instances for nodes
  - *nodes_cluster_max_size*: maximum number of EC2 instances for nodes
  - *comcast_internal_cidrs*: CIDR blocks that are allowed access into the API server running on the worker nodes (generally internal Comcast, on campus blocks)

Note:

You can find the *instance_profile_arn* via:

```
% aws iam list-instance-profiles
```

#### 3. Update your AWS credentials (Optional)

After you configure the variables file:

- Make sure your AWS credentials / token for the *aws_profile* are up to date. If you need to update your profile using *aws_adfs_auth*:

```
make aws_credentials
```

#### 4. Make the cluster:

```
% make all
```

You will be asked to confirm that you want to do this.

The make process will:

- Create and configure a S3 bucket to hold the cluster configuration, PKI, etc.
- Generate *terraform* configuration files.
- Deploy the *terraform* plan to AWS and spin up the resources.
- Apply a security group on the cluster so that you can access via [Project AutoBahn](https://autobahn.comcast.com).
- Add the cluster configuration and state files to the git repo.
- Update your `~/.ssh/config` with the master and nodes.
- Display a list of the master and server nodes.
- Update your `~/.kube/config` file with an entry for the new cluster.

Notes:

- the output and configuration files (including terraform state) from the make process will be stored in a directory `clusters/<CLUSTER_NAME>/.`

##### Host File Entry

The `make` process will add an entry to your local /etc/hosts file so that you can access the API server on the masters.

The format of the entries are:

```
<IP-ADDRESS>	api.<CLUSTER_NAME>.<DNS_ZONE>
```

Example host entries:

```
18.205.239.89	api.kops-robbers-ha-078.k8s.local
54.226.64.14	api.kops-robbers-ha-079.k8s.local
```

##### Accessing the Cluster with `kubectl`

After the cluster is made, you can use `kubectl` to access it.

The make process will add an entry to your `~/.kube/config` file for the new cluster. The new cluster will be added as the default cluster in the file, so you can use `kubectl` to access the cluster by just calling it. For example:

```
kubectl get nodes
```

You can also *explicitly* reference the *cluster name* by adding the `--cluster=` parameter. For example:

```
kubectl get nodes --cluster=kops-robbers-ha-081.k8s.local
```

You can also use the helper script `bin/get_variable.rb` to display values in the `variables.yml` file.

```
kubectl get nodes --cluster=`bin/get_variable.rb cluster_param`
```

----

## How to Spin Down (ie. delete) the Cluster

```
% make destroy
```

----

## To List the AWS EC2 Instances in the Cluster

Will display the EC2 instance name and public IP address:

```
% make list_instances
```

----

## To Display SSH Config for AutoBahn

Will display the SSH config file lines to easily ssh / jump to the cluster nodes. Note: *make all* does this and appends the master and node instances to your ~/.ssh/config file.

```
% make ssh_config
```

----

## Additional Help

```
% make help
```

----

## Cluster Monitoring and Metrics: Prometheus, Grafana

You can monitor the cluster by installing Prometheus and Grafana:

```
make cluster_monitoring
```

After installing, you can access:

- [Grafana on http://localhost:9095](http://localhost:9095)
- [Prometheus on http://localhost:9096](http://localhost:9096)

![Grafana-1](/images/grafana-1.png)

![Grafana-2](/images/grafana-2.png)

![Grafana-3](/images/grafana-3.png)

![Grafana-3](/images/grafana-4.png)

![Prometheus-1](/images/prometheus-1.png)

----

## Log capture in ELK Stack

You can install the [ELK Stack](https://www.elastic.co/elk-stack) ([ElasticSearch](https://www.elastic.co/products/elasticsearch), [Fluentd](http://www.fluentd.org/), [Kibana](https://www.elastic.co/products/kibana)) to capture logs from the pods running in the cluster.

```
make elk
```

After installing, you can access:

- [Kibana on http://localhost:5601](http://localhost:5601)

![Kibana-1](/images/kibana-1.png)

![Kibana-2](/images/kibana-2.png)

![Kibana-3](/images/kibana-3.png)

----

## Sample Applications

The *sample-applications* folder contains some example k8s applications.

#### ReactiveOps K8S Workshop

[ReactiveOps](https://www.reactiveops.com/) is a *DevOps* as a service company that focuses on [kubernetes](https://kubernetes.io/).

The sample application in folder [samples-applications/reactiveops-k8s-workshop](https://github.comcast.com/toutte236/kops-robbers-ha/tree/master/sample-applications/reativeops-k8s-workshop) is from a hands-on class ReactiveOps teaches on k8s. The [application](https://github.com/reactiveops/k8s-workshop):

- spins up a master / replica [redis cluster](https://redis.io/)
- front ends the redis cluster with a series of [sinatra web servers](http://sinatrarb.com/)
- uses k8s' [horizontal pod autoscaler](https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/) to scale the web servers when the *targetCPUUtilizationPercentage* is over 30

To install this application:

```
make sample-application-reactiveops
```

----

## Based On

The initial version of *kops-robbers-ha* was based on [sst-arch-kops-k8s](https://github.comcast.com/toutte236/sst-arch-kops-k8s)

----

## Future Work

----

## Limitations

- currently designed for AWS. Earlier version was tested on GCP. Has not been tested in Azure.

----

## Known Issues

- none

----

## Helpful Links

- [Kubernetes](https://kubernetes.io)
- [ELK-Kubernetes](https://github.com/kayrus/elk-kubernetes)
- [Prometheus Operator](https://github.com/coreos/prometheus-operator)
- [Simple Kubernetes cluster metrics monitoring with Prometheus and Grafana](https://medium.com/@timfpark/simple-kubernetes-cluster-monitoring-with-prometheus-and-grafana-dd27edb1641)

----

## Author

<a href="mailto:todd_outten@comcast.com">Todd Outten</a>

@todd_outten on #slack
